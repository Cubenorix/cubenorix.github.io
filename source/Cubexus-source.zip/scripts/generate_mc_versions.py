#!/usr/bin/env python3
# Copyright (C) 2025-2026 Cubexus Team
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Create a small launcher catalogue from Mojang's official version manifests.

This script is intentionally manual, not part of npm run build: an offline build
must not silently replace production launcher metadata. Review the diff before
publishing a refreshed snapshot.
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "public" / "api" / "mc-versions.json"
SOURCE = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"
USER_AGENT = "Cubexus-Launcher-Metadata/1.0 (support@cubexus.net)"
COMMON = ["1.21.1", "1.20.6", "1.20.4", "1.20.1", "1.19.2", "1.18.2", "1.16.5", "1.12.2", "1.8.9"]


def get_json(url: str) -> dict:
    request = Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    with urlopen(request, timeout=25) as response:
        return json.load(response)


def main() -> int:
    manifest = get_json(SOURCE)
    by_id = {row["id"]: row for row in manifest.get("versions", []) if row.get("id") and row.get("url")}
    selected: list[str] = []
    for row in manifest.get("versions", []):
        if row.get("type") == "release" and row.get("id") not in selected:
            selected.append(row["id"])
        if len(selected) >= 16:
            break
    for version in [manifest.get("latest", {}).get("snapshot"), *COMMON]:
        if version and version in by_id and version not in selected:
            selected.append(version)

    rows = []
    for version in selected:
        base = by_id[version]
        detail = get_json(base["url"])
        java = detail.get("javaVersion") or {}
        rows.append({
            "id": version,
            "type": base.get("type", "release"),
            "url": base["url"],
            "sha1": base.get("sha1"),
            "release_time": base.get("releaseTime"),
            "java_version": java.get("majorVersion"),
            "java_component": java.get("component"),
        })

    payload = {
        "schema_version": 1,
        "source": SOURCE,
        "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "latest": manifest.get("latest", {}),
        "versions": rows,
        "notice": "Метаданные получены из официального манифеста Mojang. Лаунчер должен проверять SHA-1 файлов из version JSON.",
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", "utf-8")
    print(f"Wrote {OUT.relative_to(ROOT)} with {len(rows)} reviewed version records")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"Failed without changing launcher policy: {error}", file=sys.stderr)
        raise
