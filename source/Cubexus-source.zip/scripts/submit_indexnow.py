#!/usr/bin/env python3
# Copyright (C) 2025-2026 Cubexus Team
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Notify IndexNow-compatible search engines after a Cubexus deployment."""
import json
import re
from pathlib import Path
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[1]
HOST = "cubenorix.github.io"
BASE = "https://" + HOST
key = (ROOT / "seo" / "indexnow-key.txt").read_text("utf-8").strip()
xml = (ROOT / "public" / "sitemap.xml").read_text("utf-8")
urls = re.findall(r"<loc>(https://[^<]+)</loc>", xml)
payload = json.dumps({
    "host": HOST,
    "key": key,
    "keyLocation": f"{BASE}/{key}.txt",
    "urlList": urls,
}).encode("utf-8")
req = Request("https://api.indexnow.org/indexnow", data=payload, headers={"Content-Type": "application/json; charset=utf-8", "User-Agent": "Cubexus-SEO/1.0"}, method="POST")
with urlopen(req, timeout=30) as response:
    print(f"IndexNow: HTTP {response.status}; submitted {len(urls)} URLs")
