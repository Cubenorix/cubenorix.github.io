#!/usr/bin/env python3
# Copyright (C) 2025-2026 Cubexus Team
# SPDX-License-Identifier: AGPL-3.0-or-later
"""Generate crawlable Cubexus landing/project pages from a compact Modrinth snapshot."""
from __future__ import annotations
import html
import json
import os
import re
from pathlib import Path
from urllib.parse import quote

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / "public"
BASE = os.environ.get("CUBEXUS_ORIGIN", "https://cubenorix.github.io").rstrip("/")
if not re.fullmatch(r"https://[A-Za-z0-9.-]+(?::\d+)?", BASE):
    raise SystemExit("CUBEXUS_ORIGIN must be an HTTPS origin without a path")
PROJECTS = json.loads((ROOT / "seo" / "projects.json").read_text("utf-8"))

LABELS = {
    "mod": ("Моды Minecraft", "minecraft-mods", "mod"),
    "shader": ("Шейдеры Minecraft", "minecraft-shaders", "shader"),
    "plugin": ("Плагины Minecraft", "minecraft-plugins", "plugin"),
    "modpack": ("Сборки Minecraft", "minecraft-modpacks", "modpack"),
}
LASTMOD = "2026-08-23"
SEO_ALIASES = {
    "create": ["Create мод", "мод Create", "Криэйт", "Крейд мод"],
    "sodium": ["Sodium мод", "мод Sodium", "Содиум", "Соудим мод"],
    "jei": ["JEI", "Just Enough Items", "Джеи мод"],
    "iris": ["Iris Shaders", "Ирис шейдеры"],
    "fabric-api": ["Fabric API", "Фабрик АПИ"],
    "optifine": ["OptiFine", "ОптиФайн"],
}
RUSSIAN_INTRO = {
    "create": "Create — технологический мод Minecraft с механизмами, вращением, автоматизацией и декоративными блоками.",
    "sodium": "Sodium — мод оптимизации графики Minecraft, повышающий FPS и уменьшающий микрофризы на совместимых версиях.",
    "jei": "Just Enough Items (JEI) показывает предметы и рецепты Minecraft и помогает находить способы крафта.",
    "iris": "Iris Shaders добавляет современную поддержку шейдеров и обычно используется вместе с Sodium.",
    "fabric-api": "Fabric API — библиотека, необходимая многим модам для загрузчика Fabric.",
}

STYLE = """
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;background:#101014;color:#ececf1;font:16px/1.65 system-ui,-apple-system,sans-serif}a{color:#ffb46e}.wrap{max-width:940px;margin:auto;padding:30px 20px 70px}.head{display:flex;align-items:center;gap:13px;color:#fff;text-decoration:none}.head img{width:54px;height:54px;object-fit:contain}.head b{font-size:22px;color:#ff9b2f}main{margin-top:34px;background:#18181d;border:1px solid #303038;border-radius:24px;padding:clamp(22px,5vw,46px)}h1{font-size:clamp(30px,5vw,52px);line-height:1.1;margin:0 0 18px;color:#fff}h2{margin-top:34px}.lead{font-size:18px;color:#b9b9c4}.btn{display:inline-block;margin:20px 8px 0 0;padding:13px 20px;border-radius:13px;background:#ed6a12;color:#fff;text-decoration:none;font-weight:800}.btn.alt{background:#292930}.meta{display:flex;flex-wrap:wrap;gap:8px;margin:20px 0}.meta span{padding:5px 10px;border:1px solid #3b342f;border-radius:999px;color:#d8a878;font-size:13px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:10px}.card{display:block;padding:15px;border:1px solid #303038;border-radius:14px;color:#eee;text-decoration:none;background:#1d1d22}.card small{display:block;color:#9696a2;margin-top:3px}.crumb{font-size:13px;color:#8f8f99;margin-bottom:20px}.icon{float:right;width:96px;height:96px;object-fit:contain;margin:0 0 18px 22px;border-radius:18px}footer{color:#777782;font-size:13px;margin-top:25px}@media(max-width:560px){.icon{width:68px;height:68px}main{padding:22px}}
""".strip()


def clean(value, limit=500):
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    if len(text) <= limit:
        return text
    clipped = text[: limit + 1].rsplit(" ", 1)[0].rstrip(" ,;:-")
    return clipped + "…"


def doc(title, description, canonical, body, structured=""):
    t = html.escape(clean(title, 90))
    d = html.escape(clean(description, 180))
    c = html.escape(canonical, quote=True)
    return f"""<!doctype html><!-- Cubexus; Copyright (C) 2025-2026 Cubexus Team; generated source under AGPL-3.0-or-later --><html lang=\"ru\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>{t}</title><meta name=\"description\" content=\"{d}\"><meta name=\"robots\" content=\"index,follow,max-image-preview:large\"><link rel=\"canonical\" href=\"{c}\"><link rel=\"me\" href=\"https://t.me/Cubenix\"><link rel=\"license\" href=\"{BASE}/license/\"><link rel=\"icon\" href=\"/favicon.ico\" sizes=\"any\"><link rel=\"icon\" type=\"image/png\" sizes=\"48x48\" href=\"/favicon-48.png\"><link rel=\"icon\" type=\"image/png\" sizes=\"192x192\" href=\"/favicon-192.png\"><link rel=\"apple-touch-icon\" sizes=\"180x180\" href=\"/apple-touch-icon.png\"><meta property=\"og:site_name\" content=\"Cubexus\"><meta property=\"og:type\" content=\"website\"><meta property=\"og:title\" content=\"{t}\"><meta property=\"og:description\" content=\"{d}\"><meta property=\"og:url\" content=\"{c}\"><meta property=\"og:image\" content=\"{BASE}/og-cubexus.jpg\"><style>{STYLE}</style>{structured}</head><body><div class=\"wrap\"><a class=\"head\" href=\"/\"><img src=\"/logo-512.png\" alt=\"Логотип Cubexus\" width=\"54\" height=\"54\"><b>Cubexus</b><span>проекты Minecraft</span></a>{body}<footer>© 2025–2026 Cubexus Team · <a href=\"{BASE}/license/\">Код AGPL-3.0-or-later; бренд и оригинальный контент защищены</a><br>Официальные адреса: <a href=\"{BASE}/official/\">{BASE.removeprefix('https://')}</a> · <a href=\"https://t.me/Cubenix\">Telegram @Cubenix</a><br>Неофициальный фан-сайт Minecraft. Minecraft — товарный знак Mojang Studios.</footer></div></body></html>"""


def project_page(row):
    slug = clean(row["slug"], 120)
    name = clean(row["title"], 120)
    kind = row.get("kind", "mod")
    label, landing, catalog_type = LABELS.get(kind, LABELS["mod"])
    source_desc = clean(row.get("description"), 360)
    intro = RUSSIAN_INTRO.get(slug, f"{name} — проект сообщества Minecraft категории «{label}».")
    versions = row.get("versions") or []
    version_note = f" Совместимые версии: Minecraft {', '.join(versions[-4:])}." if versions else ""
    desc = f"{intro}{version_note} Описание, совместимость и переход к файлам проекта на Modrinth."
    cats = row.get("categories") or []
    icon = row.get("icon_url") or "/logo-512.png"
    tags = "".join(f"<span>{html.escape(clean(x, 35))}</span>" for x in (cats[:8] + versions[-4:]))
    aliases = SEO_ALIASES.get(slug, [])
    alias_html = f'<p class="meta"><span>Также ищут: {html.escape(", ".join(aliases))}</span></p>' if aliases else ""
    app_url = f"/#/project/{quote(slug)}"
    canonical = f"{BASE}/projects/{quote(slug)}/"
    official_url = f"https://modrinth.com/{catalog_type}/{quote(slug)}"
    structured_data = [
        {
            "@context": "https://schema.org", "@type": "SoftwareApplication",
            "name": name, "description": source_desc or desc, "url": canonical,
            "applicationCategory": "GameApplication", "applicationSubCategory": label,
            "operatingSystem": "Windows, macOS, Linux", "isAccessibleForFree": True,
            "author": {"@type": "Person", "name": clean(row.get("author"), 100) or "Project author"},
            "image": icon, "sameAs": official_url, "dateModified": LASTMOD,
            "isPartOf": {"@id": f"{BASE}/#website"},
        },
        {
            "@context": "https://schema.org", "@type": "BreadcrumbList",
            "itemListElement": [
                {"@type": "ListItem", "position": 1, "name": "Cubexus", "item": f"{BASE}/"},
                {"@type": "ListItem", "position": 2, "name": label, "item": f"{BASE}/{landing}/"},
                {"@type": "ListItem", "position": 3, "name": name, "item": canonical},
            ],
        },
    ]
    if aliases:
        structured_data[0]["alternateName"] = aliases
    structured = '<script type="application/ld+json">' + json.dumps(structured_data, ensure_ascii=False).replace("</", "<\\/") + "</script>"
    body = f"""<main><nav class=\"crumb\" aria-label=\"Хлебные крошки\"><a href=\"/\">Cubexus</a> → <a href=\"/{landing}/\">{html.escape(label)}</a> → <span aria-current=\"page\">{html.escape(name)}</span></nav><img class=\"icon\" src=\"{html.escape(icon, quote=True)}\" alt=\"Иконка {html.escape(name)}\" width=\"96\" height=\"96\" loading=\"lazy\"><h1>{html.escape(name)} скачать для Minecraft</h1><p class=\"lead\">{html.escape(intro)}</p><p>{html.escape(source_desc or ('Страница проекта ' + name + ' в каталоге Minecraft.'))}</p>{alias_html}<div class=\"meta\">{tags}<span>{int(row.get('downloads') or 0):,} загрузок по данным каталога</span></div><a class=\"btn\" href=\"{app_url}\">Открыть карточку в Cubexus →</a><a class=\"btn alt\" href=\"{official_url}\" rel=\"noopener noreferrer\">Страница проекта на Modrinth</a><a class=\"btn alt\" href=\"{official_url}/versions\" rel=\"noopener noreferrer\">Выбрать файл на Modrinth</a><h2>Версии и безопасная установка</h2><p>Выберите точную версию Minecraft и совместимый загрузчик. До установки проверьте зависимости, лицензию и источник файла. Для собственной сборки Cubexus загружает реальные JAR-файлы в папку <code>mods</code>.</p><p><a href=\"/#/catalog?type={catalog_type}&q={quote(name)}\">Найти похожие проекты в каталоге Cubexus</a></p></main>"""
    return doc(f"{name} для Minecraft — версии и загрузка | Cubexus", desc, canonical, body, structured)


def category_page(kind, title, slug, catalog_type):
    rows = [x for x in PROJECTS if x.get("kind") == kind][:36]
    cards = "".join(f"<a class=\"card\" href=\"/projects/{quote(clean(x['slug'],120))}/\"><b>{html.escape(clean(x['title'],100))}</b><small>{html.escape(clean(x.get('description'),130))}</small></a>" for x in rows)
    desc = f"Скачать {title.lower()}: популярные проекты, версии, совместимость и прямые ссылки. Поиск по полному каталогу Cubexus."
    body = f"""<main><div class=\"crumb\"><a href=\"/\">Cubexus</a> → {html.escape(title)}</div><h1>{html.escape(title)} — скачать и найти проект</h1><p class=\"lead\">{html.escape(desc)}</p><a class=\"btn\" href=\"/#/catalog?type={catalog_type}\">Открыть полный каталог →</a><h2>Популярные проекты</h2><div class=\"grid\">{cards}</div></main>"""
    return doc(f"{title} скачать — Cubexus", desc, f"{BASE}/{slug}/", body)


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, "utf-8")

# Remove only previously generated page trees.
for row in PROJECTS:
    write(PUBLIC / "projects" / clean(row["slug"], 120) / "index.html", project_page(row))
for kind, (title, slug, catalog_type) in LABELS.items():
    write(PUBLIC / slug / "index.html", category_page(kind, title, slug, catalog_type))

maps_body = """<main><div class=\"crumb\"><a href=\"/\">Cubexus</a> → Карты Minecraft</div><h1>Карты Minecraft — найти и скачать</h1><p class=\"lead\">Карты на прохождение, выживание, приключения, паркур и мини-игры. Откройте живой поиск Cubexus и перейдите прямо к странице выбранного проекта.</p><a class=\"btn\" href=\"/#/catalog?type=map\">Открыть каталог карт →</a><h2>Поиск проекта</h2><p>Введите название карты или автора в поиске. Cubexus покажет источник, описание и прямую ссылку на страницу проекта.</p></main>"""
write(PUBLIC / "minecraft-maps" / "index.html", doc("Карты Minecraft скачать — Cubexus", "Скачать карты Minecraft на прохождение, выживание, приключения и паркур. Поиск проектов и прямые ссылки в Cubexus.", f"{BASE}/minecraft-maps/", maps_body))

official_structured = '<script type="application/ld+json">' + json.dumps({
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Cubexus",
    "alternateName": ["Кубексус", "Cubexus Minecraft"],
    "url": f"{BASE}/",
    "logo": f"{BASE}/logo-512.png",
    "sameAs": ["https://t.me/Cubenix", "https://t.me/CubexusSupportBot"],
}, ensure_ascii=False).replace("</", "<\\/") + "</script>"
official_body = """<main><div class=\"crumb\"><a href=\"/\">Cubexus</a> → Официальные адреса</div><img class=\"icon\" src=\"/logo-512.png\" alt=\"Официальный логотип Cubexus\" width=\"96\" height=\"96\"><h1>Официальные адреса Cubexus</h1><p class=\"lead\">Эта страница помогает отличить официальный проект Cubexus от копий и страниц, использующих похожее название.</p><div class=\"meta\"><span>Официальный сайт</span><span>Официальный канал</span><span>Бот техподдержки</span></div><a class=\"btn\" href=\"/\">cubenorix.github.io</a><a class=\"btn alt\" href=\"https://t.me/Cubenix\" rel=\"me\">Канал @Cubenix</a><a class=\"btn alt\" href=\"https://t.me/CubexusSupportBot\">Поддержка @CubexusSupportBot</a><h2>Проверка подлинности</h2><p>Единственный объявленный официальный Telegram-канал проекта — <strong>@Cubenix</strong>. Отдельный бот технической поддержки — <strong>@CubexusSupportBot</strong>. Официальный сайт использует исходный логотип Cubexus и напрямую ссылается на оба адреса. Другие сайты, каналы и боты не являются официальными только из-за совпадения имени.</p><p>Дата публикации этой записи: 23 августа 2026 года.</p></main>"""
write(PUBLIC / "official" / "index.html", doc("Официальный сайт, Telegram и поддержка Cubexus", "Официальные адреса Cubexus: сайт, Telegram-канал @Cubenix и бот технической поддержки @CubexusSupportBot.", f"{BASE}/official/", official_body, official_structured))

license_body = """<main><div class=\"crumb\"><a href=\"/\">Cubexus</a> → Лицензия</div><img class=\"icon\" src=\"/logo-512.png\" alt=\"Логотип Cubexus\" width=\"96\" height=\"96\"><h1>Лицензия и права Cubexus</h1><p class=\"lead\">Собственный программный код Cubexus открыт по GNU AGPL-3.0-or-later. Бренд, официальный логотип и оригинальные редакционные материалы не передаются по AGPL автоматически.</p><div class=\"meta\"><span>SPDX: AGPL-3.0-or-later</span><span>© 2025–2026 Cubexus Team</span></div><a class=\"btn\" href=\"/AGPL-3.0.txt\">Полный текст AGPL-3.0</a><a class=\"btn alt\" href=\"/#/license\">Пояснение на сайте</a><h2>Что разрешено</h2><p>AGPL разрешает использовать, изучать, копировать, изменять и распространять код при соблюдении лицензии. Оператор модифицированного сетевого сервиса должен предложить его пользователям соответствующий исходный код.</p><h2>Что не входит</h2><p>Лицензия кода не выдаёт право выдавать форк за официальный Cubexus. Сторонние моды, иконки, описания и файлы остаются у своих авторов и регулируются лицензиями источников. Minecraft является товарным знаком Mojang Studios.</p></main>"""
write(PUBLIC / "license" / "index.html", doc("Лицензия Cubexus — код AGPL-3.0-or-later", "Код Cubexus распространяется по GNU AGPL-3.0-or-later; бренд, оригинальный контент и сторонние материалы имеют отдельный правовой режим.", f"{BASE}/license/", license_body))

urls = [(f"{BASE}/", "1.0", "daily"), (f"{BASE}/official/", "1.0", "weekly"), (f"{BASE}/license/", "0.8", "monthly")]
for _, (_, slug, _) in LABELS.items(): urls.append((f"{BASE}/{slug}/", "0.9", "daily"))
urls.append((f"{BASE}/minecraft-maps/", "0.9", "daily"))
for row in PROJECTS:
    urls.append((f"{BASE}/projects/{quote(clean(row['slug'],120))}/", "0.8", "weekly"))
xml = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
for loc, priority, change in urls:
    xml.append(f"  <url><loc>{html.escape(loc)}</loc><lastmod>{LASTMOD}</lastmod><changefreq>{change}</changefreq><priority>{priority}</priority></url>")
xml.append('</urlset>')
write(PUBLIC / "sitemap.xml", "\n".join(xml) + "\n")
print(f"Generated {len(PROJECTS)} project pages, {len(LABELS)+1} category pages and {len(urls)} sitemap URLs")
