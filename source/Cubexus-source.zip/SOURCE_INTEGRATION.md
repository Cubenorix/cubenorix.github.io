# Cubexus — source integration policy

Updated: 2026-08-23

Cubexus exposes 60 connected platforms, catalogues, official projects, tools, and references. A platform being listed does **not** mean that every search contacts it or that Cubexus republishes its files.

## Official/public APIs used

- Modrinth — primary catalogue search and version/file metadata.
- Hangar — Paper/Velocity plugin cards.
- Spiget / SpigotMC — public plugin metadata and free-resource links.
- Poggit — PocketMine release index.
- Polymart — only resources reported as free; paid files are never proxied.
- GitHub — repository search with the Cubexus user agent.
- Smithed — official pack search API.
- Modpack Index — public JSON API for mods and modpacks.
- Mojang/Minecraft Services — nickname, UUID, and skin lookup.
- Official project/release pages are used for Paper, Purpur, Fabric, Forge, NeoForge, Quilt, Velocity, Folia, Pufferfish, Leaf, Leaves, Cuberite, PowerNukkitX, OptiFine, and GeyserMC.

## Bounded metadata/search adapters

These sources can contribute public cards and links without Cubexus claiming ownership of their files: CurseForge, Planet Minecraft, Minecraft Maps, Create Mod schematics, Ru-Minecraft, MCPEDL, Minecraft Inside, 10Minecraft, MCBase, ResourcePack.net, BuiltByBit, Sponge Ore, MC百科, Minecraft Forum, Shaders Mods, MinecraftShader, Minecraft-Max, Schematics.gg, Minecraft Schematics, MCBuild, MinecraftStorage, MCPEHub, and MineBBS.

Sponge Ore's current JSON endpoint requires authorization, so Cubexus uses the public search page as a metadata adapter instead of pretending that an unauthenticated API is available.

## Directories, tools, and references

NameMC, The Skindex, SkinMC, Vanilla Tweaks, Feed The Beast, BBSMC, ShaderLabs, Blockbench, MCreator, Misode, Bedrock Wiki, and Minecraft Wiki are presented as appropriate directories/tools/references. They are not treated as bulk mod APIs.

## Safety and load controls

- One aggregated search contacts at most five secondary providers. Modrinth is queried separately as the primary API.
- Provider selection depends on content type; secondary indexes rotate only after the search cache window.
- Identical in-flight searches are coalesced.
- Search results use a 12-minute hot cache and retain a prior non-empty result for up to 24 hours if refresh fails.
- The client no longer launches a second `type=all` aggregate search for every filtered search.
- Source reachability checks run in batches of six, cache successes for 60 seconds and failures for 20 seconds, and coalesce concurrent probes.
- Paid BuiltByBit/Polymart resources, random APKs, and unauthorized mirrors are not downloaded or presented as free.
- Tool/reference sites do not enter the live project total.
- The live total keeps last-good values and does not add large overlapping API totals that would obviously double-count the same projects.

## Intentionally not treated as active download catalogues

Retired software (for example Waterfall), unavailable sites, duplicate mirrors without a safe canonical link, sources requiring undisclosed private credentials, and sites whose terms or technical controls do not permit safe automated retrieval remain links/references or are omitted. Cubexus does not bypass authentication, payment, or anti-bot controls.

## Upgrade 2026-08-23 — emotes, cosmetics and diagnostics

The registry now has **77 unique sources**. The following additions are classified rather than treated as interchangeable download mirrors:

- **Emotecraft:** official Modrinth, KosmX GitHub and Hangar are trusted executable-file origins. The requested Minecraft Inside page is retained as a Russian version index/instruction page; the UI advises users to verify executable JARs against an official origin.
- **SPEMOTES:** all 26 public pack records are included with the genuine source mark and original Google Drive links. Cubexus stores only compact metadata, not the 12.1 MB upstream API payload.
- **Skins/renders:** Nova Skin, The Skindex, SkinMC, MineSkin, MC Heads and Crafatar. Mojang profile lookup remains authoritative for UUID/profile identity; directory cards and render APIs do not prove account ownership.
- **Capes/cosmetics:** MinecraftCapes, Cosmetica, LabyMod Cosmetics and Essential. Cubexus exposes catalog links but does not proxy purchases, credentials or account linking.
- **Repair/security:** MCDoctor.ai, Dig Yourself Out, MC Validator reference, VirusTotal, Modpack Update Checker and Better Compatibility Checker. Cubexus hashes selected files locally with SHA-256; it does not claim a clean hash or a single antivirus result proves safety.

Bounded fan-out remains unchanged: `/api/agg-search` runs at most five relevant providers for one query, coalesces identical work and caches the full provider result before applying offsets. Skin search uses a maximum of four directory providers; emote search uses a maximum of three relay providers in addition to the separately bounded Modrinth request.

## Project metadata transfer

Builder exports contain:

1. `cubexus-project.json` — Cubexus schema v2 with project IDs, exact version IDs, source URLs, files, hashes, dependencies and loader metadata;
2. `manifest.json` — compact backwards-compatible transfer manifest;
3. `modrinth.index.json` — Modrinth pack-compatible index for files whose source supplies a download URL;
4. `LINKS.txt` and `README.txt` — human-readable recovery data.

The builder imports `.json`, `.zip` and `.mrpack` and prefers the richest Cubexus manifest. Hard limits remain 200 entries and 12 concurrent jobs.
