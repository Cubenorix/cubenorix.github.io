# Cubexus notices

Copyright © 2025–2026 Cubexus Team.

## Program code

Unless a file says otherwise, original Cubexus program code is licensed under the **GNU Affero General Public License v3.0 or later** (`AGPL-3.0-or-later`). The complete license is in `LICENSE` and `public/AGPL-3.0.txt`.

A modified version used to provide a network service must offer the corresponding source code to users as required by AGPL section 13. Preserve copyright, SPDX and modification notices.

## Brand and original content

The AGPL code license does not grant trademark or passing-off rights. The Cubexus name, official imported logo, distinctive trade dress and original editorial content are not automatically licensed under AGPL. See `CONTENT-LICENSE.md`.

## Third-party materials

Minecraft, project files, project metadata, screenshots, icons and platform logos may belong to third parties and remain subject to their respective terms. Their presence in this repository does not relicense them under AGPL.

Minecraft is a trademark of Mojang Studios. Cubexus is an independent unofficial fan project and is not endorsed by Mojang Studios or Microsoft.
