/*
 * Cubexus Support Bot tests
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import worker, { normalizeQuery } from '../telegram-bot/src/index.js'

const env = {
  TELEGRAM_BOT_TOKEN: 'test-token-not-a-real-secret',
  TELEGRAM_WEBHOOK_SECRET: 'test_webhook_secret_123456789',
  BOT_USERNAME: 'CubexusSupportBot',
  PUBLIC_ORIGIN: 'https://cubenorix.github.io',
  AI_ENABLED: 'false',
}

function update(text) {
  return { update_id: 1, message: { message_id: 2, from: { id: 42 }, chat: { id: 42 }, text } }
}

function webhook(body, secret = env.TELEGRAM_WEBHOOK_SECRET) {
  return new Request('https://bot.example/telegram/webhook', {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'x-telegram-bot-api-secret-token': secret },
    body: JSON.stringify(body),
  })
}

test('bot alias normalizer handles requested Russian misspellings', () => {
  assert.equal(normalizeQuery('мод крейд скачать'), 'create')
  assert.equal(normalizeQuery('соудим мод'), 'sodium')
  assert.equal(normalizeQuery('wood crate'), 'wood crate')
})

test('bot health reveals configuration state but never secret values', async () => {
  const response = await worker.fetch(new Request('https://bot.example/'), env)
  assert.equal(response.status, 200)
  const text = await response.text()
  assert.match(text, /Cubexus Support Bot/)
  assert.equal(text.includes(env.TELEGRAM_BOT_TOKEN), false)
  assert.equal(text.includes(env.TELEGRAM_WEBHOOK_SECRET), false)
})

test('Telegram webhook rejects requests without the configured secret header', async () => {
  const response = await worker.fetch(webhook(update('/start'), 'wrong-secret'), env)
  assert.equal(response.status, 403)
})

test('start and help commands send the required technical-support menu', { concurrency: false }, async () => {
  const original = globalThis.fetch
  const sent = []
  try {
    globalThis.fetch = async (url, init) => {
      assert.match(String(url), /api\.telegram\.org/)
      sent.push(JSON.parse(init.body))
      return Response.json({ ok: true, result: { message_id: 10 } })
    }
    assert.equal((await worker.fetch(webhook(update('/start')), env)).status, 200)
    assert.equal((await worker.fetch(webhook(update('/help')), env)).status, 200)
    assert.match(sent[0].text, /Техническая поддержка/)
    for (const command of ['/start', '/help', '/support', '/site', '/rules', '/search', '/build', '/status']) {
      assert.match(sent[1].text, new RegExp(command.replace('/', '\\/')))
    }
  } finally {
    globalThis.fetch = original
  }
})

test('search normalizes a typo and returns a direct Cubexus project link', { concurrency: false }, async () => {
  const original = globalThis.fetch
  let telegramPayload = null
  try {
    globalThis.fetch = async (url, init = {}) => {
      const value = String(url)
      if (value.includes('api.modrinth.com')) {
        assert.match(value, /query=create/)
        return Response.json({ hits: [
          { slug: 'create-factory', title: 'Create Factory', description: 'addon', downloads: 500 },
          { slug: 'create', title: 'Create', description: 'technology', downloads: 10 },
        ] })
      }
      telegramPayload = JSON.parse(init.body)
      return Response.json({ ok: true, result: {} })
    }
    const response = await worker.fetch(webhook(update('/search мод крейд скачать')), env)
    assert.equal(response.status, 200)
    assert.match(telegramPayload.text, /\/#\/project\/create/)
    assert.equal(telegramPayload.text.indexOf('<b>Create</b>') < telegramPayload.text.indexOf('<b>Create Factory</b>'), true)
  } finally {
    globalThis.fetch = original
  }
})

test('build command creates a prefilled static-host-safe builder URL', { concurrency: false }, async () => {
  const original = globalThis.fetch
  let payload = null
  try {
    globalThis.fetch = async (_url, init) => {
      payload = JSON.parse(init.body)
      return Response.json({ ok: true, result: {} })
    }
    const response = await worker.fetch(webhook(update('/build # create + jei + sodium')), env)
    assert.equal(response.status, 200)
    assert.match(payload.text, /\/#\/builds\?mods=/)
    assert.match(payload.text, /%23%20create%20%2B%20jei%20%2B%20sodium/)
  } finally {
    globalThis.fetch = original
  }
})

test('AI remains disabled unless owner explicitly enables it with a Worker secret', { concurrency: false }, async () => {
  const original = globalThis.fetch
  let payload = null
  try {
    globalThis.fetch = async (_url, init) => {
      payload = JSON.parse(init.body)
      return Response.json({ ok: true, result: {} })
    }
    await worker.fetch(webhook(update('/ask почему не запускается мод?')), env)
    assert.match(payload.text, /ИИ-помощник пока выключен/)
  } finally {
    globalThis.fetch = original
  }
})
