/*
 * Cubexus launcher storage tests
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { onRequest } from '../functions/[[path]].js'

const next = () => new Response('static', { status: 200 })

test('missing launcher object storage fails closed instead of returning SPA HTML as a ZIP', async () => {
  const response = await onRequest({
    request: new Request('https://cubexus.pages.dev/downloads/launcher/Cubexus-win.zip'),
    env: {},
    next,
  })
  assert.equal(response.status, 503)
  assert.match(await response.text(), /not configured/)
  assert.match(response.headers.get('content-type'), /text\/plain/)
})

test('R2 launcher downloads preserve hashes, ranges and safe attachment headers', async () => {
  const body = Uint8Array.from([0x50, 0x4b, 0x03, 0x04])
  const bucket = {
    async get(key) {
      assert.equal(key, 'launcher/Cubexus-win.zip')
      return {
        body,
        size: body.length,
        etag: 'abc',
        httpEtag: '"abc"',
        writeHttpMetadata(headers) { headers.set('content-type', 'application/zip') },
      }
    },
  }
  const response = await onRequest({
    request: new Request('https://cubexus.pages.dev/downloads/launcher/Cubexus-win.zip'),
    env: { LAUNCHER_ASSETS: bucket },
    next,
  })
  assert.equal(response.status, 200)
  assert.equal(response.headers.get('etag'), '"abc"')
  assert.equal(response.headers.get('x-content-type-options'), 'nosniff')
  assert.match(response.headers.get('content-disposition'), /attachment; filename="Cubexus-win\.zip"/)
  assert.deepEqual([...new Uint8Array(await response.arrayBuffer())], [...body])
})

test('launcher storage rejects traversal and unknown top-level folders', async () => {
  for (const path of ['/downloads/launcher/%2e%2e%5csecret.zip', '/downloads/other/file.zip']) {
    const response = await onRequest({ request: new Request('https://cubexus.pages.dev' + path), env: {}, next })
    assert.equal(response.status, 404)
  }
})
