/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import { chromium } from 'playwright'
import assert from 'node:assert/strict'

const base = process.env.CUBEXUS_URL || 'http://127.0.0.1:5173'
const browser = await chromium.launch({ headless: true })
const context = await browser.newContext({ locale: 'ru-RU' })
const page = await context.newPage()

const root = await context.request.get(base + '/')
assert.equal(root.ok(), true)
const rootHtml = await root.text()
assert.match(rootHtml, /<title>Моды, карты, шейдеры и плагины Minecraft — Cubexus<\/title>/)
assert.match(rootHtml, /"@type": "WebSite"/)
assert.match(rootHtml, /logo-512\.png/)

const logo = await context.request.get(base + '/logo-512.png')
assert.equal(logo.ok(), true)
assert.match(logo.headers()['content-type'] || '', /image\/png/)

const project = await context.request.get(base + '/projects/create/')
assert.equal(project.ok(), true)
const projectHtml = await project.text()
assert.match(projectHtml, /Create для Minecraft — версии и загрузка \| Cubexus/)
assert.match(projectHtml, /BreadcrumbList/)
assert.match(projectHtml, /Криэйт/)
assert.match(projectHtml, /href="\/#\/project\/create"/)
assert.match(projectHtml, /href="https:\/\/modrinth\.com\/mod\/create\/versions"/)

const sitemap = await context.request.get(base + '/sitemap.xml')
assert.equal(sitemap.ok(), true)
const mapText = await sitemap.text()
assert.match(mapText, /https:\/\/cubexus\.yapp\.page\/projects\/create\//)
assert.equal((mapText.match(/<url>/g) || []).length >= 250, true)

await page.goto(base + '/', { waitUntil: 'domcontentloaded', timeout: 30000 })
await page.waitForFunction(() => document.title.includes('Моды, карты, шейдеры и плагины Minecraft'))
console.log(JSON.stringify({ title: await page.title(), projectPage: '/projects/create/', sitemapUrls: (mapText.match(/<url>/g) || []).length, logo: 'logo-512.png' }, null, 2))
await browser.close()
