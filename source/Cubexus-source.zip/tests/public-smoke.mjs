/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import { chromium } from 'playwright'
import assert from 'node:assert/strict'

const base = process.env.CUBEXUS_URL || 'https://cubenorix.github.io'
const route = (path) => /\.(?:yapp\.page|github\.io)/.test(new URL(base).hostname) ? '/#' + path : path
const browser = await chromium.launch({ headless: true })
const context = await browser.newContext({ locale: 'en-US', viewport: { width: 1440, height: 1000 } })
const page = await context.newPage()
const pageErrors = []
const translationResponses = []
page.on('pageerror', (err) => pageErrors.push(err.message))
page.on('response', (r) => {
  if (r.url().includes('clients5.google.com/translate_a/t')) translationResponses.push(r.status())
})

await page.goto(base + '/', { waitUntil: 'domcontentloaded', timeout: 30000 })
await page.waitForFunction(() => Number((document.querySelector('.stat-live strong')?.textContent || '').replace(/\D/g, '')) > 200000, null, { timeout: 30000 })
const homeTotal = Number((await page.locator('.stat-live strong').innerText()).replace(/\D/g, ''))
assert.equal(await page.locator('.live-source-counts', { hasText: /spigot/i }).isVisible(), true)
const telegram = page.locator('.official-channel-strip').first()
assert.equal(await telegram.isVisible(), true)
assert.equal(await telegram.getAttribute('href'), 'https://t.me/Cubenix')
// Полоса технической поддержки (@Cubenorixsupportbot) видна рядом с каналом (задача 1).
const supportStrip = page.locator('.official-channel-strip.support-strip')
assert.equal(await supportStrip.isVisible(), true)
assert.equal(await supportStrip.getAttribute('href'), 'https://t.me/Cubenorixsupportbot')

await page.goto(base + route('/register'), { waitUntil: 'domcontentloaded', timeout: 30000 })
await page.locator('.auth-readiness').waitFor({ timeout: 15000 })
await page.waitForFunction(() => document.querySelector('.auth-readiness')?.textContent.includes('D1'), null, { timeout: 15000 })
assert.equal(await page.getByRole('button', { name: /Создать аккаунт|Create account/i }).isDisabled(), true)
assert.equal(await page.getByRole('button', { name: /Microsoft/i }).count(), 0)

await page.goto(base + route('/community'), { waitUntil: 'domcontentloaded', timeout: 30000 })
const supportBot = page.locator('a[href="https://t.me/Cubenorixsupportbot"]').first()
assert.equal(await supportBot.isVisible(), true)

await page.goto(base + route('/servers'), { waitUntil: 'domcontentloaded', timeout: 30000 })
await page.locator('.server-detail-card').first().waitFor({ timeout: 15000 })
assert.equal(await page.locator('.server-detail-card').count(), 9)
assert.equal(await page.locator('.server-tech-grid').count(), 9)
assert.match(await page.locator('.server-detail-card').first().innerText(), /7Cubes|mc\.7cubes\.ru/)

await page.goto(base + route('/builds?mods=%23%20create%20%2B%20jei%20%2B%20sodium'), { waitUntil: 'domcontentloaded', timeout: 30000 })
await page.locator('textarea').first().waitFor({ timeout: 15000 })
assert.equal((await page.locator('textarea').first().inputValue()).startsWith('# create + jei + sodium'), true)

const launcherManifest = await context.request.get(base + '/api/launcher-update.json')
assert.equal(launcherManifest.ok(), true)
const launcherData = await launcherManifest.json()
assert.equal(launcherData.enabled, false)
assert.equal(launcherData.download_url_windows, null)

await page.goto(base + route('/catalog?type=mod'), { waitUntil: 'domcontentloaded', timeout: 30000 })
await page.locator('.catalog-list .cx-card').first().waitFor({ timeout: 30000 })
await page.waitForFunction(() => document.querySelectorAll('.catalog-list .cx-card').length >= 100, null, { timeout: 30000 })
assert.equal(await page.locator('.catalog-list .cx-card').count(), 100)
assert.equal(await page.locator('.catalog-pager').first().isVisible(), true)
const firstPageTitle = await page.locator('.catalog-list .cx-card h3').first().innerText()
await page.locator('.catalog-pager').first().getByRole('button', { name: '2', exact: true }).click()
await page.waitForURL(/page=2/, { timeout: 15000 })
await page.waitForFunction((old) => {
  const title = document.querySelector('.catalog-list .cx-card h3')?.textContent
  return document.querySelectorAll('.catalog-list .cx-card').length === 100 && title && title !== old
}, firstPageTitle, { timeout: 30000 })

await page.getByRole('button', { name: 'Language' }).click()
assert.equal(await page.locator('[role=option]').count(), 64)
assert.equal(await page.locator('[role=option] .lang-flag img').count(), 62)
await page.waitForFunction(() => [...document.querySelectorAll('[role=option] .lang-flag img')].every((x) => x.complete && x.naturalWidth > 0), null, { timeout: 20000 })

await page.goto(base + route('/catalog?type=all'), { waitUntil: 'domcontentloaded', timeout: 30000 })
await page.waitForFunction(() => document.querySelectorAll('.catalog-list .cx-card').length >= 100, null, { timeout: 30000 })
await page.waitForFunction(() => Number((document.querySelector('.results-summary strong')?.textContent || '').replace(/\D/g, '')) > 200000, null, { timeout: 30000 })
const liveTotal = Number((await page.locator('.results-summary strong').innerText()).replace(/\D/g, ''))
assert.equal(liveTotal > 200000, true)
assert.equal(await page.locator('.cx-card', { hasText: /spigot/i }).count() > 0, true)
assert.equal(await page.locator('.cx-card', { hasText: /hangar/i }).count() > 0, true)

await page.goto(base + route('/catalog?type=emote'), { waitUntil: 'domcontentloaded', timeout: 30000 })
const spe = page.locator('.cx-card', { hasText: 'SPEMOTES ALL 2026' }).first()
await spe.waitFor({ timeout: 30000 })
assert.equal((await page.locator('.cx-card', { hasText: /^SPE/ }).count()) >= 26, true)
const description = spe.locator('[class*="text-white/50"]').first()
await description.scrollIntoViewIfNeeded()
await page.waitForFunction((el) => el && el.textContent.trim().length > 20 && !/[А-Яа-яЁё]/.test(el.textContent), await description.elementHandle(), { timeout: 45000 })
if (base.includes('.yapp.page')) assert.equal(translationResponses.some((s) => s === 200), true)
assert.deepEqual(pageErrors, [])

console.log(JSON.stringify({ cards: 100, homeTotal, liveTotal, languages: 64, flagImages: 62, spemotes: await page.locator('.cx-card', { hasText: /^SPE/ }).count(), translation: (await description.innerText()).slice(0, 120), translationResponses }, null, 2))
await browser.close()
