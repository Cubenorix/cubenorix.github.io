/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import { useEffect, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { searchProjects, searchAddons, searchEmotes, searchTextures, parseQuery, rankHits, cacheHits } from '../api'
import ProjectCard, { CardSkeleton } from '../components/ProjectCard'
import SearchBox from '../components/SearchBox'
import { uniqueHits, verifyLevel } from '../stats'
import { CATEGORIES, FILTERS, MC_VERSIONS, LOCAL_CONTENT, ADDON_HOSTS } from '../data'
import { allLocal, searchLocalAll } from '../localMore'
import { useStore } from '../store'
import { t, catName } from '../i18n'
import { formatNumber } from '../languages'

function EmotecraftHub() {
  return (
    <section className="glass p-5 mb-5 emote-hub">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="max-w-2xl">
          <div className="text-xs uppercase tracking-widest text-orange-soft">Emotecraft Hub</div>
          <h2 className="font-outfit text-2xl mt-1">Эмоции, позы и анимации</h2>
          <p className="text-sm text-white/55 mt-2 leading-6">Нажми <b>B</b> для колеса эмоций. Свои файлы <code>.emote</code> положи в <code>.minecraft/emotes</code> или открой папку из настроек мода. Ниже — мод, серверные части и найденные наборы.</p>
        </div>
        <div className="emote-key">B</div>
      </div>
      <div className="flex flex-wrap gap-2 mt-4">
        <a className="tag on" href="https://modrinth.com/plugin/emotecraft" target="_blank" rel="noopener noreferrer">Modrinth · official</a>
        <a className="tag" href="https://github.com/KosmX/emotes" target="_blank" rel="noopener noreferrer">GitHub · official</a>
        <a className="tag" href="https://hangar.papermc.io/dima_dencep/emotecraft" target="_blank" rel="noopener noreferrer">Paper / Folia</a>
        <a className="tag" href="https://spemotes.spoverlay.ru/" target="_blank" rel="noopener noreferrer">SPEMOTES · 26 packs</a>
        <a className="tag" href="https://minecraft-inside.ru/mods/150286-emotecraft.html" target="_blank" rel="noopener noreferrer">Minecraft Inside · RU</a>
      </div>
      <p className="text-[11px] text-white/35 mt-3">Безопаснее скачивать исполняемый JAR с официальных Modrinth, GitHub, CurseForge или Hangar. Страницу Minecraft Inside сохраняем как русскую инструкцию и индекс версий.</p>
    </section>
  )
}

function SkinStudio({ q }) {
  const { lang } = useStore()
  const nick = String(q || '').trim().split(/\s+/)[0]
  const ok = /^[A-Za-z0-9_]{2,16}$/.test(nick)
  const [info, setInfo] = useState(null)
  useEffect(() => {
    if (!ok) { setInfo(null); return }
    let alive = true
    fetch('/api/skin?nick=' + encodeURIComponent(nick))
      .then((r) => r.json())
      .then((j) => { if (alive) setInfo(j) })
      .catch(() => { if (alive) setInfo(null) })
    return () => { alive = false }
  }, [nick, ok])
  const show = info?.ok ? info.nick : (ok ? nick : 'Steve')
  const body = (info?.body) || ('https://mc-heads.net/body/' + encodeURIComponent(show))
  const player = (info?.player) || ('https://mc-heads.net/player/' + encodeURIComponent(show))
  const head = (info?.avatar) || ('https://mc-heads.net/avatar/' + encodeURIComponent(show) + '/64')
  return (
    <div className="glass p-5 mb-5 flex flex-wrap gap-6 items-end">
      <img src={body} alt="" className="h-44 object-contain" />
      <img src={player} alt="" className="h-28 object-contain" />
      <div>
        <div className="flex items-center gap-2">
          <img src={head} alt="" className="w-10 h-10 rounded-lg" />
          <div>
            <div className="font-outfit text-xl">{show}</div>
            <div className="text-xs text-white/40">
              {info?.ok ? 'Mojang · minecraft.net' : (ok ? t(lang, 'catalog.nickHint') : t(lang, 'catalog.nickEx'))}
            </div>
            {info?.uuid ? <div className="font-mono text-[11px] text-white/35 mt-1">{info.uuid}</div> : null}
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mt-3">
          <a className="tag" href="https://www.minecraft.net/" target="_blank" rel="noopener noreferrer">minecraft.net</a>
          {info?.namemc ? <a className="tag" href={info.namemc} target="_blank" rel="noopener noreferrer">NameMC</a> : null}
          <a className="tag" href={'https://skinmc.net/search?search=' + encodeURIComponent(nick || 'Steve')} target="_blank" rel="noopener noreferrer">SkinMC</a>
          <a className="tag" href={'https://www.minecraftskins.com/search/skin/' + encodeURIComponent(nick || 'Steve') + '/1/'} target="_blank" rel="noopener noreferrer">The Skindex</a>
          <a className="tag" href={'https://minecraft.novaskin.me/search?q=' + encodeURIComponent(nick || 'Steve')} target="_blank" rel="noopener noreferrer">Nova Skin</a>
          <a className="tag" href="https://mineskin.org/" target="_blank" rel="noopener noreferrer">MineSkin</a>
        </div>
      </div>
    </div>
  )
}

// Modrinth allows up to 100 results per request. Use the full batch so the
// catalogue feels substantial while paging remains a single network request.
const PAGE = 100
const LOCAL_TYPES = new Set(['map', 'schematic', 'skin', 'core', 'bedrock', 'world', 'config', 'model', 'emote', 'cosmetic'])
const FACET_CAT = { library: 'library', optimization: 'optimization' }
const LOCAL = allLocal(LOCAL_CONTENT)

const CAT_GROUPS = [
  ['Игра', ['mods', 'addons', 'resourcepacks', 'datapacks', 'shaders', 'textures', 'emotes', 'cosmetics', 'models', 'modpacks', 'library', 'optimization']],
  ['Сервер', ['plugins', 'cores', 'bedrock']],
  ['Миры', ['maps', 'worlds', 'schematics', 'skins']],
]

function Pager({ page, pages, goPage, lang }) {
  if (pages <= 1) return null
  const near = [...new Set([1, page - 2, page - 1, page, page + 1, page + 2, pages])]
    .filter((n) => n >= 1 && n <= pages)
    .sort((a, b) => a - b)
  return (
    <nav className="catalog-pager" aria-label={`${page} / ${pages}`}>
      <button className="btn btn-ghost px-4 h-11 text-sm" onClick={() => goPage(page - 1)} disabled={page <= 1}>{t(lang, 'catalog.back')}</button>
      <div className="pager-pages">
        {near.map((n, i) => (
          <span className="contents" key={n}>
            {i > 0 && n - near[i - 1] > 1 ? <span className="pager-gap">…</span> : null}
            <button className={`pager-number${n === page ? ' on' : ''}`} onClick={() => goPage(n)} aria-current={n === page ? 'page' : undefined}>{n}</button>
          </span>
        ))}
      </div>
      <button className="btn btn-ghost px-4 h-11 text-sm" onClick={() => goPage(page + 1)} disabled={page >= pages}>{t(lang, 'catalog.next')}</button>
    </nav>
  )
}

export default function Catalog() {
  const { lang, db, setSearchMode } = useStore()
  const nav = useNavigate()
  const [sp, setSp] = useSearchParams()
  const q = sp.get('q') || ''
  const parsedQ = parseQuery(q)
  const type = sp.get('type') || parsedQ.type || (q ? 'all' : 'mod')
  const page = Math.max(1, Number(sp.get('page') || 1))
  const [index, setIndex] = useState('relevance')
  const [version, setVersion] = useState('')
  const [loader, setLoader] = useState('')
  const [hits, setHits] = useState([])
  const [total, setTotal] = useState(0)
  const [err, setErr] = useState('')
  const [loading, setLoading] = useState(false)
  const [safeOnly, setSafeOnly] = useState(false)
  const [parent, setParent] = useState(null)
  const [more, setMore] = useState(false)

  const isAddon = type === 'addon' || parsedQ.addon

  useEffect(() => {
    setParent(null)
    let alive = true
    const off = (page - 1) * PAGE
    const localForType = LOCAL_TYPES.has(type)
      ? searchLocalAll(LOCAL, q, type)
      : (q ? searchLocalAll(LOCAL, q, type === 'all' ? 'all' : type) : [])

    if (LOCAL_TYPES.has(type) && !q && type !== 'emote') {
      setLoading(true)
      const localCount = localForType.length
      const localSlice = localForType.slice(off, off + PAGE)
      const remaining = Math.max(0, PAGE - localSlice.length)
      const remoteOffset = Math.max(0, off - localCount)
      searchProjects({ query: type === 'map' || type === 'world' ? 'survival map' : type, limit: PAGE, offset: remoteOffset, type })
        .then((d) => {
          if (!alive) return
          const remote = uniqueHits(d.hits || []).slice(0, remaining || PAGE)
          const merged = uniqueHits([...localSlice, ...(off < localCount ? remote.slice(0, remaining) : remote)])
          cacheHits(merged)
          setHits(merged)
          setTotal(localCount + (Number(d.total_hits) || remote.length))
        })
        .catch(() => {
          if (!alive) return
          setHits(localSlice)
          setTotal(localCount)
        })
        .finally(() => { if (alive) setLoading(false) })
      return
    }

    const facets = []
    if (type === 'library' || type === 'optimization' || type === 'cosmetic') {
      facets.push(['project_type:mod'])
      facets.push([`categories:${type === 'cosmetic' ? 'cosmetic' : FACET_CAT[type]}`])
    } else if (type && type !== 'all' && !['addon', 'emote', 'texture'].includes(type) && !LOCAL_TYPES.has(type)) {
      facets.push([`project_type:${type}`])
    }
    if (version) facets.push([`versions:${version}`])
    if (loader && type !== 'texture') facets.push([`categories:${loader.toLowerCase()}`])
    setLoading(true)
    const run = isAddon
      ? searchAddons({ query: parsedQ.q.join(' ') || q, limit: PAGE, offset: off, version: version || parsedQ.versions[0], loader: loader || parsedQ.loaders[0] })
      : type === 'emote' || parsedQ.extra?.includes('emote')
        ? searchEmotes({ query: q, limit: PAGE, offset: Math.max(0, off - (q ? 0 : localForType.length)) })
        : type === 'texture'
          ? searchTextures({ query: q, limit: PAGE, offset: off, resolution: loader })
          : searchProjects({ query: q, limit: PAGE, offset: off, index, facets, type })
    run
      .then(async (d) => {
        if (!alive) return
        const extra = []
        if (type === 'skin') {
          const nick = String(q || '').trim().split(/\s+/)[0]
          if (/^[A-Za-z0-9_]{2,16}$/.test(nick)) {
            try {
              const sk = await fetch('/api/skin?nick=' + encodeURIComponent(nick)).then((r) => r.json())
              if (sk?.ok) {
                extra.push({
                  slug: 'mojang-' + sk.nick,
                  title: sk.nick,
                  description: 'Официальный скин Mojang · minecraft.net',
                  icon_url: sk.avatar,
                  sources: ['mojang', 'namemc'],
                  project_type: 'skin',
                  author: sk.nick,
                  url: sk.namemc,
                  downloads: 0,
                  external: true,
                  nick: sk.nick,
                })
              }
            } catch {}
          }
        }
        if (!alive) return
        const localPage = type === 'emote' && !q ? localForType.slice(off, off + PAGE) : (q || LOCAL_TYPES.has(type) ? localForType : [])
        const remoteRoom = type === 'emote' && !q ? Math.max(0, PAGE - localPage.length) : PAGE
        const combined = uniqueHits([...extra, ...localPage, ...(d.hits || []).slice(0, remoteRoom)])
        const merged = q ? rankHits(combined, parsedQ.q.join(' ') || q) : combined
        cacheHits(merged)
        const shown = safeOnly
          ? merged.filter((h) => verifyLevel({ downloads: h.downloads, likes: h.follows || h.likes || 0 }) || h.external)
          : merged
        setHits(shown.slice(0, LOCAL_TYPES.has(type) && q ? 80 : PAGE))
        setTotal(type === 'emote' && !q ? localForType.length + (Number(d.total_hits) || 0) : Math.max(d.total_hits || 0, shown.length, merged.length))
        setParent(d.parent || null)
        setErr(merged.length ? '' : '')
      })
      .catch(() => {
        if (!alive) return
        if (localForType.length) {
          setHits(localForType.slice(off, off + PAGE))
          setTotal(localForType.length)
          setErr('')
        } else setErr(t(lang, 'catalog.err'))
      })
      .finally(() => { if (alive) setLoading(false) })
    return () => { alive = false }
  }, [q, type, index, version, loader, page, safeOnly])

  const filters = type === 'plugin' ? FILTERS.plugins : FILTERS.mods
  const pages = Math.max(1, Math.ceil(total / PAGE))
  const goPage = (n) => {
    const next = Math.min(pages, Math.max(1, n))
    const obj = Object.fromEntries(sp.entries())
    obj.page = String(next)
    setSp(obj)
  }

  const heading = isAddon
    ? catName(lang, 'addons')
    : (type === 'all' ? t(lang, 'catalog.title') : catName(lang, CATEGORIES.find((c) => c.type === type)?.id || type, t(lang, 'catalog.title')))

  const setType = (next) => setSp({ q, type: next, page: '1' })

  return (
    <div className="relative z-10 max-w-7xl mx-auto px-4 pt-6 pb-16 page-in">
      <div className="mb-4"><SearchBox /></div>

      <div className="cat-chips hide-scroll">
        <button type="button" className={'tag ' + (type === 'all' ? 'on' : '')} onClick={() => setType('all')}>{t(lang, 'catalog.all')}</button>
        {CAT_GROUPS.flatMap(([, ids]) => ids).map((id) => {
          const c = CATEGORIES.find((x) => x.id === id)
          if (!c?.type) return null
          return (
            <button key={c.id} type="button" className={'tag ' + (type === c.type ? 'on' : '')} onClick={() => setType(c.type)}>
              {catName(lang, c.id)}
            </button>
          )
        })}
      </div>

      <div className="cat-bar">
        <select className="field py-2" value={index} onChange={(e) => { setIndex(e.target.value); goPage(1) }} aria-label={t(lang, 'catalog.sort')}>
          <option value="relevance">{t(lang, 'catalog.relevance')}</option>
          <option value="downloads">{t(lang, 'catalog.downloads')}</option>
          <option value="updated">{t(lang, 'catalog.updated')}</option>
          <option value="newest">{t(lang, 'catalog.newest')}</option>
        </select>
        <select className="field py-2 font-mono text-sm" value={version} onChange={(e) => { setVersion(e.target.value); goPage(1) }}>
          <option value="">{t(lang, 'catalog.versions')}</option>
          {MC_VERSIONS.filter((v) => !v.endsWith('…')).slice().reverse().slice(0, 40).map((v) => (
            <option key={v} value={v}>{v}</option>
          ))}
        </select>
        <button type="button" className={'tag ' + (safeOnly ? 'on' : '')} onClick={() => { setSafeOnly(!safeOnly); goPage(1) }}>
          <span className="safe-dot" /> {t(lang, 'catalog.verified')}
        </button>
        <button type="button" className={'tag ' + (db.searchMode === 'exact' ? 'on' : '')} onClick={() => setSearchMode(db.searchMode === 'exact' ? 'smart' : 'exact')}>
          {db.searchMode === 'exact' ? t(lang, 'catalog.exact') : t(lang, 'catalog.smart')}
        </button>
        <button type="button" className={'tag ' + (more ? 'on' : '')} onClick={() => setMore(!more)}>{t(lang, 'catalog.core')}</button>
      </div>
      {more ? (
        <div className="flex flex-wrap gap-1 mb-4">
          {filters.slice(0, 10).map((f) => (
            <button key={f} type="button" className={'tag ' + (loader === f ? 'on' : '')} onClick={() => { setLoader(loader === f ? '' : f); goPage(1) }}>{f}</button>
          ))}
        </div>
      ) : null}

      <h1 className="font-outfit text-3xl font-bold mb-2">
        {heading} {q && <span className="text-orange-soft font-mono text-xl">«{q}»</span>}
      </h1>
      {parent && <p className="text-sm text-white/55 mb-3">{parent.title}</p>}

      {type === 'addon' && (
        <div className="mb-4">
          <form className="flex gap-2 mb-3" onSubmit={(e) => { e.preventDefault(); const v = e.target.mod.value.trim(); setSp({ q: v, type: 'addon', page: '1' }) }}>
            <input name="mod" className="field" defaultValue={q} placeholder="JEI, Create…" />
            <button className="btn btn-primary px-5">{t(lang, 'hero.find')}</button>
          </form>
          <div className="flex flex-wrap gap-2">
            {ADDON_HOSTS.map((h) => (
              <button key={h.q} className={'tag ' + (q.toLowerCase() === h.q.toLowerCase() ? 'on' : '')} onClick={() => setSp({ q: h.q, type: 'addon', page: '1' })}>{h.name}</button>
            ))}
          </div>
        </div>
      )}

      {type === 'skin' && <SkinStudio q={q} />}
      {type === 'emote' && <EmotecraftHub />}
      <Pager page={page} pages={pages} goPage={goPage} lang={lang} />
      <div className="results-summary" aria-live="polite">
        {loading ? <span>{t(lang, 'catalog.searching')}</span> : (
          <>
            <strong>{formatNumber(total, lang)}</strong>
            <span>{formatNumber(total ? (page - 1) * PAGE + 1 : 0, lang)}–{formatNumber(Math.min(page * PAGE, total), lang)}</span>
            <span>{page} / {pages}</span>
          </>
        )}
      </div>
      {err && <div className="rounded-2xl border border-orange/30 p-3 text-orange-soft mb-4">{err}</div>}
      {loading && <div className="catalog-list">{Array.from({ length: 12 }).map((_, i) => <CardSkeleton key={i} />)}</div>}
      {!loading && hits.length === 0 && (
        <div className="rounded-[20px] glass p-10 text-center">
          <img src="/logo.png?v=5" alt="" className="w-12 h-12 mx-auto opacity-80 logo-img" />
          <h2 className="font-outfit text-xl mt-4">{t(lang, 'catalog.empty')}</h2>
          <button className="btn btn-ghost mt-5 px-5 py-2" onClick={() => nav('/add')}>{t(lang, 'catalog.addLink')}</button>
        </div>
      )}
      {!loading && hits.length > 0 && (
        <div className="catalog-list">
          {hits.map((p) => <ProjectCard key={p.slug || p.title} p={p} />)}
        </div>
      )}
      <Pager page={page} pages={pages} goPage={goPage} lang={lang} />
    </div>
  )
}
