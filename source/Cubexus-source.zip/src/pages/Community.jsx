/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import { ShieldCheck } from 'lucide-react'
import { COMMUNITY, TOPICS, OFFICIAL_TELEGRAM, SUPPORT_BOT_TELEGRAM, SUPPORT_BOT_USERNAME } from '../data/community'
import { useStore } from '../store'
import { t } from '../i18n'
import { Tx } from '../components/Translated'

function Copy({ text, label }) {
  const { notify, lang } = useStore()
  return (
    <button
      type="button"
      className="btn btn-ghost px-3 py-2 text-xs"
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text)
          notify(t(lang, 'toast.copied'))
        } catch {
          notify(t(lang, 'toast.error'), 'err')
        }
      }}
    >
      {label || t(lang, 'ui.copy')}
    </button>
  )
}

export default function Community() {
  const { lang } = useStore()
  const handle = '@' + COMMUNITY.username

  return (
    <div className="relative z-10 max-w-5xl mx-auto px-4 pt-8 pb-8 page-in">
      <section className="comm-hero">
        <div className="comm-banner-css">
          <img src="/logo.png?v=5" alt="Логотип Cubexus" width="88" height="88" />
          <div>
            <div className="comm-word">Cubexus</div>
            <div className="comm-sub">{t(lang, 'comm.sub')}</div>
          </div>
        </div>
        <div className="comm-veil">
          <div>
            <div className="official-kicker">
              <ShieldCheck size={15} aria-hidden="true" />
              <span>{t(lang, 'comm.verified')}</span>
            </div>
            <h1 className="font-outfit text-3xl sm:text-4xl">{t(lang, 'comm.title')}</h1>
            <p className="text-white/60 mt-2 max-w-xl leading-7">{t(lang, 'comm.lead')}</p>
            <div className="flex flex-wrap gap-2 mt-5">
              <a className="btn btn-primary px-5 py-2.5" href={OFFICIAL_TELEGRAM} target="_blank" rel="me noopener noreferrer">
                <img src="/social/telegram.svg" alt="" width="19" height="19" />
                {t(lang, 'comm.open')}
              </a>
              <Copy text={handle} label={handle} />
            </div>
          </div>
        </div>
      </section>

      <h2 className="font-outfit text-xl mt-10 mb-3">{t(lang, 'comm.topics')}</h2>
      <div className="grid sm:grid-cols-2 gap-3">
        {TOPICS.map((tp, i) => (
          <div key={tp.id} className="why-card stagger" style={{ animationDelay: i * 40 + 'ms' }}>
            <div className="flex items-baseline justify-between gap-2">
              <div className="font-outfit text-orange-soft"><Tx text={tp.name} /></div>
              <div className="text-[11px] text-white/35"><Tx text={tp.who} /></div>
            </div>
            <p className="text-sm text-white/55 mt-2 leading-6"><Tx text={tp.hint} /></p>
          </div>
        ))}
      </div>

      <section className="glass p-5 mt-8" aria-labelledby="support-bot-title">
        <div className="flex flex-col sm:flex-row sm:items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-[#229ED9]/15 border border-[#229ED9]/25 grid place-items-center shrink-0">
            <img src="/social/telegram.svg" alt="" width="29" height="29" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[11px] uppercase tracking-widest text-orange-soft">Техническая поддержка</div>
            <h2 id="support-bot-title" className="font-outfit text-2xl mt-1">@{SUPPORT_BOT_USERNAME}</h2>
            <p className="text-sm text-white/55 mt-2 leading-6">Официальный бот для поиска модов, ссылок на сборщик, правил, контакта поддержки и проверки сайта/источников. Серверная часть подготовлена как отдельный Cloudflare Worker; команды начнут отвечать после безопасной замены раскрытых токенов и настройки webhook владельцем.</p>
          </div>
          <a className="btn btn-primary px-5 py-2.5 shrink-0" href={SUPPORT_BOT_TELEGRAM} target="_blank" rel="noopener noreferrer">
            Открыть бота
          </a>
        </div>
        <div className="flex flex-wrap gap-1.5 mt-4">
          {['/start','/help','/support','/site','/rules','/search','/build','/status'].map((command) => <code className="tag" key={command}>{command}</code>)}
        </div>
        <p className="text-[11px] text-white/35 mt-3">Бот не должен просить пароль, токен или cookie. Для обращения используется support@cubexus.net; /ask передаёт текст Hugging Face только после явной команды и включения ИИ владельцем.</p>
      </section>

      <section className="official-proof mt-8" aria-labelledby="official-proof-title">
        <div className="official-proof-icon"><ShieldCheck size={28} aria-hidden="true" /></div>
        <div>
          <h2 id="official-proof-title" className="font-outfit text-xl">{t(lang, 'comm.checkTitle')}</h2>
          <p className="text-sm text-white/55 mt-2 leading-6">{t(lang, 'comm.checkLead')}</p>
          <div className="official-addresses mt-4">
            <a href="https://cubenorix.github.io/" target="_blank" rel="noopener noreferrer">cubenorix.github.io</a>
            <a href={OFFICIAL_TELEGRAM} target="_blank" rel="me noopener noreferrer">t.me/Cubenix</a>
            <a href={SUPPORT_BOT_TELEGRAM} target="_blank" rel="noopener noreferrer">t.me/{SUPPORT_BOT_USERNAME}</a>
          </div>
        </div>
      </section>

      <p className="text-white/35 text-xs mt-8 leading-6">
        {t(lang, 'comm.unofficial')} {COMMUNITY.mail}
      </p>
    </div>
  )
}
