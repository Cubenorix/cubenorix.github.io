/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import { useEffect, useState } from 'react'
import { searchProjects } from '../api'
import ProjectCard, { CardSkeleton } from '../components/ProjectCard'
import { uniqueHits, topScore } from '../stats'
import { useStore } from '../store'
import { t } from '../i18n'

export default function Top() {
  const { lang } = useStore()
  const [hits, setHits] = useState([])
  const [loading, setLoading] = useState(true)
  useEffect(() => {
    searchProjects({ query: '', limit: 100, index: 'downloads', facets: [['project_type:mod']] })
      .then((d) => {
        const list = uniqueHits(d.hits || [])
          .slice()
          .sort((a, b) => topScore(b) - topScore(a))
          .slice(0, 100)
        setHits(list)
      })
      .catch(() => setHits([]))
      .finally(() => setLoading(false))
  }, [])
  return (
    <div className="relative z-10 max-w-7xl mx-auto px-4 pt-10 pb-16">
      <h1 className="font-outfit text-4xl font-bold">{t(lang, 'pages.top')}</h1>
      <p className="text-white/50 mt-2 text-sm">60% / 30% / 10%</p>
      {loading && <div className="grid md:grid-cols-2 gap-3 mt-6">{Array.from({ length: 6 }).map((_, i) => <CardSkeleton key={i} />)}</div>}
      <div className="grid md:grid-cols-2 gap-3 mt-6">
        {hits.map((p, i) => (
          <div key={p.slug} className="relative">
            <div className="absolute -left-1 top-3 z-10 font-mono text-orange-soft text-sm w-8">{i + 1}</div>
            <div className="pl-7"><ProjectCard p={p} /></div>
          </div>
        ))}
      </div>
    </div>
  )
}
