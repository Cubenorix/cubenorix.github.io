/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import { useEffect, useState } from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import { ACHIEVEMENTS } from '../data'
import { t } from '../i18n'
import { StatusMark } from '../components/Marks'

const TAB_KEYS = [
  ['stats', 'profile.stats'],
  ['builds', 'profile.builds'],
  ['fav', 'profile.fav'],
  ['reviews', 'profile.reviews'],
  ['uploads', 'profile.upload'],
  ['settings', 'profile.face'],
]

export default function Profile() {
  const { user, db, logout, deleteAccount, updateProfile, addUpload, unlocked, notify, lang, authReady } = useStore()
  const nav = useNavigate()
  const [tab, setTab] = useState('stats')
  const [up, setUp] = useState({ title: '', description: '', type: 'mod' })
  const [form, setForm] = useState({ username: '', display: '', brand: '', nick: '', youtube: '', bio: '' })
  const [deletion, setDeletion] = useState({ password: '', confirm: '' })
  const [saving, setSaving] = useState(false)
  useEffect(() => {
    if (!user) return
    setForm({
      username: user.username || '', display: user.display || '', brand: user.brand || '',
      nick: user.nick || '', youtube: user.youtube || '', bio: user.bio || '',
    })
  }, [user])
  if (!authReady) return <div className="relative z-10 pt-24 text-center text-white/45">Проверяем сессию…</div>
  if (!user) return <Navigate to="/login" replace />
  const TABS = TAB_KEYS.map(([key, label]) => [key, t(lang, label)])
  const un = unlocked()
  const head = (form.nick || user.nick || user.username)
    ? '/api/img?url=' + encodeURIComponent('https://mc-heads.net/avatar/' + encodeURIComponent(form.nick || user.nick || user.username) + '/80')
    : ''

  const save = async (event) => {
    event.preventDefault()
    setSaving(true)
    const result = await updateProfile({
      username: form.username.trim() || user.username,
      display: form.display.trim(),
      brand: form.brand.trim(),
      nick: form.nick.trim(),
      youtube: form.youtube.trim(),
      bio: form.bio.trim(),
    })
    setSaving(false)
    notify(result.ok ? t(lang, 'ui.saved') : result.error, result.ok ? 'ok' : 'err')
  }

  return (
    <div className="relative z-10 max-w-5xl mx-auto px-4 pt-8 pb-16">
      <div className="atlas-strip glass p-5 flex flex-wrap items-center gap-4">
        {head ? <img src={head} alt="" className="w-16 h-16 rounded-2xl" /> : (
          <div className="w-16 h-16 rounded-2xl grid place-items-center font-outfit text-2xl" style={{ background: 'linear-gradient(135deg,#FFB347,#FF6B00)' }}>{user.username[0].toUpperCase()}</div>
        )}
        <div className="min-w-0">
          <h1 className="font-outfit text-2xl truncate">{user.brand || user.display || user.username}</h1>
          <div className="text-white/50 text-sm">{user.display && user.brand ? user.display : user.username} · {user.role === 'creator' ? t(lang, 'ui.author') : user.role}</div>
          {user.youtube && <a className="text-orange-soft text-sm" href={user.youtube} target="_blank" rel="noreferrer">YouTube</a>}
        </div>
        <button className="btn btn-ghost ml-auto px-4" onClick={async () => { await logout(); nav('/') }}>{t(lang, 'auth.logout')}</button>
      </div>

      <div className="flex flex-wrap gap-2 mt-4">
        {TABS.map(([k, n]) => <button key={k} className={'tag' + (tab === k ? ' on' : '')} onClick={() => setTab(k)}>{n}</button>)}
      </div>

      <div className="glass p-6 mt-4">
        {tab === 'stats' && (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {Object.entries(db.stats).map(([k, v]) => (
              <div key={k} className="bg-white/5 rounded-2xl p-4">
                <div className="font-mono text-2xl text-orange-soft">{v}</div>
                <div className="text-xs text-white/50">{k}</div>
              </div>
            ))}
          </div>
        )}

        {tab === 'builds' && (db.builds.length ? db.builds.map((b) => <div key={b.id} className="py-2 border-b border-white/5">{b.name}</div>) : <p className="text-white/45">{t(lang, 'ui.noBuilds')}</p>)}

        {tab === 'fav' && (db.favorites.length ? db.favorites.map((f) => <Link key={f.slug} to={'/project/' + f.slug} className="block py-2 hover:text-orange-soft">{f.title}</Link>) : <p className="text-white/45">{t(lang, 'ui.empty')}</p>)}

        {tab === 'reviews' && (
          <div className="space-y-3">
            {Object.entries(db.reviews || {}).flatMap(([slug, arr]) => (arr || []).filter((r) => r.user === user.username).map((r) => (
              <div key={r.id} className="border-b border-white/5 pb-2">
                <div className="text-orange-soft">{'★'.repeat(r.stars || 0)}</div>
                <div className="text-xs text-white/40">{slug}</div>
                <p>{r.text}</p>
              </div>
            )))}
            <Link to="/reviews" className="text-orange-soft text-sm">{t(lang, 'review.all')}</Link>
          </div>
        )}

        {tab === 'uploads' && (
          <form onSubmit={(e) => { e.preventDefault(); if (!up.title.trim()) return; addUpload(up); setUp({ title: '', description: '', type: 'mod' }) }} className="space-y-3">
            <input className="field" placeholder={t(lang, 'profile.name')} value={up.title} onChange={(e) => setUp({ ...up, title: e.target.value })} />
            <textarea className="field min-h-[80px]" placeholder={t(lang, 'profile.about')} value={up.description} onChange={(e) => setUp({ ...up, description: e.target.value })} />
            <select className="field" value={up.type} onChange={(e) => setUp({ ...up, type: e.target.value })}>
              {['mod', 'plugin', 'datapack', 'resourcepack', 'map', 'modpack', 'schematic'].map((tpe) => <option key={tpe} className="bg-[#12122A]" value={tpe}>{tpe}</option>)}
            </select>
            <label className="block text-sm text-white/50">{t(lang, 'profile.fileStay')}
              <input type="file" className="field mt-1" />
            </label>
            <button className="btn btn-primary px-4 py-2">{t(lang, 'profile.send')}</button>
            <div className="text-sm space-y-2 mt-4">
              {db.uploads.map((u) => (
                <div key={u.id} className="border-b border-white/5 pb-2">
                  <b>{u.title}</b> <StatusMark status={u.status === 'accepted' ? 'accepted' : 'review'} />
                </div>
              ))}
            </div>
          </form>
        )}

        {tab === 'settings' && (
          <form className="space-y-3 max-w-lg" onSubmit={save}>
            <label className="block text-sm text-white/50">{t(lang, 'profile.loginName')}
              <input className="field mt-1" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
            </label>
            <label className="block text-sm text-white/50">{t(lang, 'profile.display')}
              <input className="field mt-1" value={form.display} onChange={(e) => setForm({ ...form, display: e.target.value })} />
            </label>
            <label className="block text-sm text-white/50">{t(lang, 'profile.brand')}
              <input className="field mt-1" value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} placeholder="®VLAGUK_qwe8" />
            </label>
            <label className="block text-sm text-white/50">{t(lang, 'profile.nick')}
              <input className="field mt-1" value={form.nick} onChange={(e) => setForm({ ...form, nick: e.target.value })} />
            </label>
            <label className="block text-sm text-white/50">YouTube
              <input className="field mt-1" value={form.youtube} onChange={(e) => setForm({ ...form, youtube: e.target.value })} />
            </label>
            <label className="block text-sm text-white/50">{t(lang, 'profile.bio')}
              <textarea className="field mt-1 min-h-[80px]" value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} />
            </label>
            <button className="btn btn-primary px-5 py-2" disabled={saving}>{saving ? 'Сохраняем…' : t(lang, 'profile.save')}</button>
            <p className="text-xs text-white/35 leading-5">Двухфакторная аутентификация появится только после подключения проверенного почтового канала; фиктивный переключатель удалён.</p>
            <details className="auth-delete-box">
              <summary>Удалить аккаунт и серверную сессию</summary>
              <p>Операция необратима. Введите пароль и слово DELETE.</p>
              <input className="field" type="password" autoComplete="current-password" placeholder="Текущий пароль" value={deletion.password} onChange={(e) => setDeletion({ ...deletion, password: e.target.value })} />
              <input className="field" placeholder="DELETE" value={deletion.confirm} onChange={(e) => setDeletion({ ...deletion, confirm: e.target.value })} />
              <button type="button" className="btn btn-ghost px-4 py-2 text-[#ff9aaa]" onClick={async () => {
                const result = await deleteAccount(deletion.password, deletion.confirm)
                if (!result.ok) return notify(result.error, 'err')
                notify('Аккаунт удалён')
                nav('/')
              }}>Удалить аккаунт</button>
            </details>
          </form>
        )}

        {tab === 'stats' && (
          <div className="grid sm:grid-cols-2 gap-2 mt-6">
            {ACHIEVEMENTS.slice(0, 8).map((a) => (
              <div key={a.id} className={`p-3 rounded-2xl border ${un.some((x) => x.id === a.id) ? 'border-orange/50 bg-orange/10' : 'border-white/5 opacity-50'}`}>
                <div className="font-semibold">{a.title}</div>
                <div className="font-mono text-xs">{db.stats[a.stat] || 0} / {a.n}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
