/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import { SOURCES } from './data'
import { searchProjects, getProject, getVersions } from './api'

const HOST = [
  { id: 'modrinth', test: /modrinth\.com/i },
  { id: 'modrinth-black', test: /modrinth\.black/i },
  { id: 'curseforge', test: /curseforge\.com/i },
  { id: 'hangar', test: /hangar\.papermc\.io/i },
  { id: 'spigot', test: /spigotmc\.org/i },
  { id: 'polymart', test: /polymart\.org/i },
  { id: 'builtbybit', test: /builtbybit\.com/i },
  { id: 'ore', test: /spongepowered\.org/i },
  { id: 'pmc', test: /planetminecraft\.com/i },
  { id: 'mcpedl', test: /mcpedl\.com/i },
  { id: 'mcmaps', test: /minecraftmaps\.com/i },
  { id: 'smithed', test: /smithed\.net/i },
  { id: 'vanillatweaks', test: /vanillatweaks\.net/i },
  { id: 'shaderlabs', test: /shaderlabs\.org/i },
  { id: 'inside', test: /minecraft-inside\.ru/i },
  { id: 'bbsmc', test: /bbsmc\.net/i },
  { id: 'minebbs', test: /minebbs\.com/i },
  { id: 'shadersmods', test: /shadersmods\.com/i },
  { id: 'create', test: /createmod\.com/i },
  { id: 'github', test: /github\.com/i },
  { id: 'tenmc', test: /10minecraft\.ru/i },
  { id: 'namemc', test: /namemc\.com/i },
  { id: 'poggit', test: /poggit\.pmmp\.io/i },
  { id: 'ftb', test: /feed-the-beast\.com/i },
]

export function parseProjectUrl(raw) {
  try {
    const u = new URL(raw.trim())
    const plat = HOST.find((h) => h.test.test(u.hostname))
    const parts = u.pathname.split('/').filter(Boolean)
    const slug = decodeURIComponent(parts[parts.length - 1] || '').replace(/\.html?$/, '')
    const name = slug.replace(/[-_]+/g, ' ')
    return { ok: true, platform: plat?.id || 'unknown', host: u.hostname, slug, name, url: u.href }
  } catch {
    return { ok: false, error: 'Некорректная ссылка' }
  }
}

export function scoreSource(s) {
  const desc = String(s.description || s.body || '')
  const shots = Array.isArray(s.gallery) ? s.gallery.length : (s.screenshots || 0)
  const vers = s.versionCount || (Array.isArray(s.versions) ? s.versions.length : 0)
  const cats = Array.isArray(s.categories) ? s.categories.length : (s.tags || 0)
  const deps = s.depCount || 0
  const links = (s.source_url ? 1 : 0) + (s.issues_url ? 1 : 0) + (s.discord_url ? 1 : 0) + (s.wiki_url ? 1 : 0)
  const days = s.updated ? Math.max(0, 365 - (Date.now() - new Date(s.updated).getTime()) / 86400000) : 30
  const fresh = Math.round((days / 365) * 3 * 12)
  return Math.round(
    desc.length * 1 +
    shots * 5 +
    vers * 3 +
    (s.icon_url ? 10 : 0) +
    (s.logo ? 8 : 0) +
    deps * 4 +
    cats * 3 +
    (s.video ? 6 : 0) +
    links * 2 +
    (Number(s.downloads) || 0) * 0.00001 +
    (Number(s.rating) || 0) * 2 +
    fresh +
    (s.languages || 1) * 2
  )
}

function searchUrl(id, q) {
  const enc = encodeURIComponent(q)
  const map = {
    modrinth: `https://modrinth.com/mods?q=${enc}`,
    'modrinth-black': `https://modrinth.black/?q=${enc}`,
    curseforge: `https://www.curseforge.com/minecraft/search?search=${enc}`,
    pmc: `https://www.planetminecraft.com/projects/?keywords=${enc}`,
    inside: `https://minecraft-inside.ru/?s=${enc}`,
    bbsmc: `https://bbsmc.net/search?q=${enc}`,
    minebbs: `https://www.minebbs.com/search/?q=${enc}`,
    shadersmods: `https://shadersmods.com/?s=${enc}`,
    create: `https://createmod.com/ru/?s=${enc}`,
    github: `https://github.com/search?q=${enc}+minecraft`,
    tenmc: `https://10minecraft.ru/?s=${enc}`,
    hangar: `https://hangar.papermc.io/?query=${enc}`,
    spigot: `https://www.spigotmc.org/search/search?keywords=${enc}`,
    polymart: `https://polymart.org/search?query=${enc}`,
    builtbybit: `https://builtbybit.com/search/?q=${enc}`,
    ore: `https://ore.spongepowered.org/?q=${enc}`,
    mcpedl: `https://mcpedl.com/?s=${enc}`,
    mcmaps: `https://www.minecraftmaps.com/?s=${enc}`,
    smithed: `https://smithed.net/packs?q=${enc}`,
    vanillatweaks: `https://vanillatweaks.net/`,
    shaderlabs: `https://wiki.shaderlabs.org/wiki/Shader_Packs`,
    namemc: `https://namemc.com/minecraft-skins?query=${enc}`,
    poggit: `https://poggit.pmmp.io/plugins?term=${enc}`,
    ftb: `https://www.feed-the-beast.com/modpacks`,
  }
  return map[id] || '#'
}

export async function findAcrossPlatforms(urlOrName) {
  const parsed = String(urlOrName).startsWith('http') ? parseProjectUrl(urlOrName) : { ok: true, name: urlOrName, slug: urlOrName, platform: 'unknown', url: '' }
  if (!parsed.ok) return parsed
  const q = parsed.name || parsed.slug
  let hit = null
  let full = null
  let vers = []
  try {
    const data = await searchProjects({ query: q, limit: 8 })
    hit = (data.hits || []).find((h) => h.slug === parsed.slug) || (data.hits || [])[0] || null
  } catch {}
  if (hit) {
    try { full = await getProject(hit.slug) } catch { full = hit }
    try { vers = await getVersions(hit.slug) } catch { vers = [] }
  }
  const base = {
    ...(full || hit || {}),
    title: full?.title || hit?.title || q,
    description: (full?.body && full.body.length > String(full?.description || '').length) ? full.body : (full?.description || hit?.description || ''),
    body: full?.body || hit?.description || '',
    icon_url: full?.icon_url || hit?.icon_url,
    gallery: full?.gallery || [],
    downloads: full?.downloads || hit?.downloads || 0,
    categories: full?.categories || hit?.categories || [],
    loaders: full?.loaders || [],
    source_url: full?.source_url,
    issues_url: full?.issues_url,
    discord_url: full?.discord_url,
    wiki_url: full?.wiki_url,
    updated: full?.updated,
    versionCount: vers.length,
    depCount: (vers[0]?.dependencies || []).length,
    slug: full?.slug || hit?.slug || parsed.slug,
    author: hit?.author || '',
  }

  const platforms = await Promise.all(SOURCES.map(async (s) => {
    const page = s.id === parsed.platform ? parsed.url : searchUrl(s.id, base.title)
    let probe = { ok: false, found: false, ms: 0, title: '' }
    try {
      const r = await fetch('/api/probe?q=' + encodeURIComponent(base.title || q) + '&url=' + encodeURIComponent(page))
      probe = await r.json()
    } catch {}
    const found = Boolean(probe.ok) && (s.id === 'modrinth' || s.id === parsed.platform || probe.found)
    const variant = {
      ...base,
      platform: s.id,
      platformName: s.name,
      color: s.color,
      url: page,
      online: Boolean(probe.ok),
      probeMs: probe.ms,
      probeTitle: probe.title,
      screenshots: (base.gallery || []).length,
      versionCount: base.versionCount,
      languages: s.id === 'modrinth' ? 8 : 1,
      found,
    }
    return { ...variant, score: found ? scoreSource(variant) : 0 }
  }))
  platforms.sort((a, b) => b.score - a.score)

  const best = platforms[0]
  return {
    ok: true,
    parsed,
    query: q,
    platforms,
    best,
    merged: {
      ...base,
      description: platforms.reduce((a, b) => (String(b.description || '').length > String(a.description || '').length ? b : a), base).description,
      gallery: base.gallery,
      sources: platforms,
      primarySource: best?.platform,
    },
  }
}
