/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import { getProject, getVersion, getVersions, quickSearch } from './api.js'

const FAM = {
  fabric: 'fabric', quilt: 'fabric',
  forge: 'forge', neoforge: 'forge',
}

const CLASH = [
  ['sodium', 'optifine'],
  ['sodium', 'rubidium'],
  ['iris', 'optifine'],
  ['iris', 'oculus'],
  ['lithium', 'canary'],
  ['embeddium', 'sodium'],
]

const SLUG = {
  architectury: 'architectury-api',
  architecturyapi: 'architectury-api',
  athena: 'athena',
  resourcefullib: 'resourceful-lib',
  resourceful_lib: 'resourceful-lib',
  createbigcannons: 'create-big-cannons',
  create_big_cannons: 'create-big-cannons',
  flywheel: 'flywheel',
  ponder: 'ponder',
  veil: 'veil',
  railways: 'railways',
  create: 'create',
  crate: 'create',
  creat: 'create',
  jeu: 'jei',
  jei: 'jei',
  sodiom: 'sodium',
  soduim: 'sodium',
  sodium: 'sodium',
  chipped: 'chipped',
  creategoggles: 'create-goggles',
  mcwbridges: 'macaws-bridges',
  mcwfences: 'macaws-fences-and-walls',
}

export const MAX_PACK_ITEMS = 200
export const MAX_PACK_CONCURRENCY = 12

export function normalizeModQuery(query) {
  const q = String(query || '').trim()
  const low = q.toLowerCase()
  return SLUG[low] || SLUG[low.replace(/[^a-z0-9]+/g, '')] || q
}

export async function mapLimit(items, limit, worker) {
  const list = Array.isArray(items) ? items : []
  const out = new Array(list.length)
  const concurrency = Math.max(1, Math.min(MAX_PACK_CONCURRENCY, Number(limit) || 1, list.length || 1))
  let cursor = 0
  async function run(workerId) {
    while (true) {
      const index = cursor++
      if (index >= list.length) return
      out[index] = await worker(list[index], index, workerId)
    }
  }
  await Promise.all(Array.from({ length: concurrency }, (_, workerId) => run(workerId)))
  return out
}

export function splitTasks(count, cap = MAX_PACK_CONCURRENCY) {
  const total = Math.max(0, Math.min(MAX_PACK_ITEMS, Number(count) || 0))
  if (!total) return []
  const workers = Math.max(1, Math.min(MAX_PACK_CONCURRENCY, Number(cap) || 1, total))
  const base = Math.floor(total / workers)
  const extra = total % workers
  let from = 1
  return Array.from({ length: workers }, (_, i) => {
    const size = base + (i < extra ? 1 : 0)
    const task = { id: i + 1, from, to: from + size - 1, total: size, done: 0, active: '' }
    from += size
    return task
  })
}

function idOf(x) {
  return String(x?.slug || x?.project_id || x?.id || '').toLowerCase()
}

function keysOf(x) {
  return [x?.slug, x?.id, x?.project_id, x?.modid].filter(Boolean).map((s) => String(s).toLowerCase())
}

function blobOf(i) {
  return (idOf(i) + ' ' + String(i.title || '')).toLowerCase()
}

function family(loaders) {
  const s = new Set((loaders || []).map((l) => FAM[String(l).toLowerCase()]).filter(Boolean))
  if (s.has('fabric') && s.has('forge')) return 'mix'
  if (s.has('forge')) return 'forge'
  if (s.has('fabric')) return 'fabric'
  return ''
}

function pickVer(vers, game, loader, pin) {
  const list = Array.isArray(vers) ? vers : []
  if (pin) {
    const p = String(pin).replace(/^v/i, '').toLowerCase()
    // A pinned version is strict: never silently replace it with another release.
    return list.find((x) => String(x.version_number || '').replace(/^v/i, '').toLowerCase() === p)
      || list.find((x) => String(x.name || '').replace(/^v/i, '').toLowerCase() === p)
      || null
  }
  return list.find((x) => (x.game_versions || []).includes(game) && (x.loaders || []).includes(loader))
    || list.find((x) => (x.loaders || []).includes(loader) && (x.game_versions || []).some((g) => String(g).startsWith(String(game).split('.').slice(0, 2).join('.'))))
    || list.find((x) => (x.loaders || []).includes(loader))
    || list.find((x) => (x.game_versions || []).includes(game))
    || list[0]
    || null
}

function fileOf(v) {
  const files = Array.isArray(v?.files) ? v.files : []
  return files.find((f) => f && f.primary) || files[0] || null
}

function haveSet(list) {
  const s = new Set()
  for (const i of list) for (const k of keysOf(i)) s.add(k)
  return s
}

function owns(set, id) {
  const n = String(id || '').toLowerCase()
  if (!n) return false
  if (set.has(n)) return true
  const mapped = SLUG[n.replace(/[^a-z0-9]+/g, '')] || SLUG[n]
  if (mapped && set.has(mapped)) return true
  for (const k of set) if (k.includes(n) || n.includes(k)) return true
  return false
}

export function cmpVer(a, b) {
  const pa = String(a || '').split(/[^\d]+/).map(Number)
  const pb = String(b || '').split(/[^\d]+/).map(Number)
  const n = Math.max(pa.length, pb.length)
  for (let i = 0; i < n; i++) {
    const x = pa[i] || 0
    const y = pb[i] || 0
    if (x !== y) return x > y ? 1 : -1
  }
  return 0
}

export function analyze(items, game, loader, loaderVer) {
  const list = Array.isArray(items) ? items : []
  const problems = []
  const have = haveSet(list)

  const fams = list.map((i) => family(i.loaders)).filter(Boolean)
  if (fams.includes('fabric') && fams.includes('forge')) {
    problems.push({ kind: 'conflict', text: 'Смешаны Fabric и Forge/NeoForge. Авто оставит одно ядро.' })
  }

  const needMap = new Map()
  for (const i of list) {
    if (i.missing || !i.ok) {
      const pin = i.pin ? ` — требовалась точная версия ${i.pin}` : ''
      problems.push({ kind: 'miss', text: `Не найден совместимый файл: ${i.title || i.slug}${pin}; Minecraft ${game || '—'}, ${loader || '—'}.`, slug: i.slug })
    } else if (loader && (i.loaders || []).length && !(i.loaders || []).includes(loader)) {
      problems.push({ kind: 'version', text: `${i.title} ${i.version || ''}: нет файла под ${loader}. Доступно: ${(i.loaders || []).join(', ') || 'не указано'}; Minecraft: ${(i.games || []).slice(0, 8).join(', ') || i.game || 'не указано'}.`, slug: i.slug, version: i.version || '' })
    }
    for (const d of i.need || []) {
      if (!owns(have, d.id) && !owns(have, d.slug)) {
        const name = d.title || d.slug || d.id
        if (!needMap.has(name)) needMap.set(name, { from: [], dep: d })
        needMap.get(name).from.push(i.title)
      }
    }
    for (const d of i.bad || []) {
      if (owns(have, d.id) || owns(have, d.slug)) {
        const ver = d.requiredVersion ? ` версия ${d.requiredVersion}` : ''
        problems.push({ kind: 'conflict', text: `${i.title} несовместим с ${d.title || d.slug || d.id}${ver}. Оставь только один из них.`, slug: d.slug || d.id, version: d.requiredVersion || '' })
      }
    }
    if (i.needLoader && loaderVer && cmpVer(loaderVer, i.needLoader) < 0) {
      problems.push({ kind: 'version', text: i.title + ' хочет ' + loader + ' ' + i.needLoader + '+, сейчас ' + loaderVer })
    }
  }
  for (const [name, rec] of needMap) {
    const who = [...new Set(rec.from)].slice(0, 3).join(', ')
    const exact = rec.dep.requiredVersion
      ? ` точная версия ${rec.dep.requiredVersion}`
      : ` совместимая версия для Minecraft ${game || 'выбранной версии'} / ${loader || 'выбранного загрузчика'} (источник не закрепил точный номер)`
    problems.push({
      kind: 'need',
      text: `Нужно установить ${name}: ${exact}${rec.from.length > 1 ? `; требуют ${who}` : `; требует ${who}`}.`,
      slug: rec.dep.slug || rec.dep.id,
      version: rec.dep.requiredVersion || '',
    })
  }

  for (const [a, b] of CLASH) {
    const hasA = list.find((i) => blobOf(i).includes(a))
    const hasB = list.find((i) => blobOf(i).includes(b))
    if (hasA && hasB) problems.push({ kind: 'conflict', text: `${hasA.title} конфликтует с ${hasB.title}. Автопочинка оставит ${hasA.title} и удалит ${hasB.title}.`, slug: hasB.slug })
  }
  return problems
}

async function fillItem(hit, game, loader, extra) {
  let vers = []
  try { vers = await getVersions(hit.slug || hit.id) } catch { vers = [] }
  const v = pickVer(vers, game, loader, extra?.pin)
  const f = fileOf(v)
  const deps = Array.isArray(v?.dependencies) ? v.dependencies : []
  const depRow = (d) => ({
    id: d.project_id || '',
    slug: d.file_name || '',
    title: d.file_name || d.project_id || 'dependency',
    versionId: d.version_id || '',
    type: d.dependency_type || '',
  })
  return {
    slug: hit.slug || hit.id,
    id: hit.id || hit.project_id,
    project_id: hit.project_id || hit.id,
    title: hit.title || hit.slug || hit.id,
    icon_url: hit.icon_url,
    sourceUrl: hit.url || (hit.slug ? `https://modrinth.com/project/${hit.slug}` : ''),
    author: hit.author || '',
    license: hit.license || '',
    version: v?.version_number || '',
    versionId: v?.id || '',
    versionName: v?.name || '',
    published: v?.date_published || '',
    file: f,
    fileName: f?.filename || '',
    hashes: f?.hashes || {},
    fileSize: f?.size || 0,
    game: (v?.game_versions || []).includes(game) ? game : ((v?.game_versions || [])[0] || game),
    games: v?.game_versions || [],
    loaders: v?.loaders || hit.loaders || [],
    ok: !!v,
    missing: (!hit.slug && !hit.id) || (!!extra?.pin && !v),
    pinMissing: !!extra?.pin && !v,
    need: deps.filter((d) => d.dependency_type === 'required' && (d.project_id || d.file_name)).map(depRow),
    bad: deps.filter((d) => d.dependency_type === 'incompatible' && (d.project_id || d.file_name)).map(depRow),
    optional: deps.filter((d) => d.dependency_type === 'optional' && (d.project_id || d.file_name)).map(depRow),
    dependencies: deps.map(depRow),
    pin: extra?.pin || '',
    ...extra,
  }
}

export async function findMod(query, game, loader) {
  const q = String(query || '').trim()
  if (!q) return null
  const mapped = normalizeModQuery(q)
  try {
    const p = await getProject(mapped)
    if (p && (p.slug || p.title)) return fillItem(p, game, loader, { dep: true })
  } catch {}
  try {
    const data = await quickSearch({
      query: mapped,
      limit: 6,
      facets: [['project_type:mod'], [`versions:${game}`], [`categories:${loader}`]],
    })
    const hit = (data.hits || []).find((h) => String(h.slug).toLowerCase() === mapped || String(h.slug).toLowerCase().includes(String(mapped).toLowerCase()))
      || (data.hits || [])[0]
    if (hit) return fillItem(hit, game, loader, { dep: true })
  } catch {}
  return null
}

export async function autofix(items, game, loader) {
  let list = (items || []).filter((i) => i && !i.missing)
  const log = []
  const votes = { fabric: 0, forge: 0 }
  for (const i of list) {
    const f = family(i.loaders)
    if (f) votes[f] += 1
  }
  const keepFam = votes.forge > votes.fabric ? 'forge' : 'fabric'
  const wantLoader = keepFam === 'forge'
    ? (loader === 'neoforge' || loader === 'forge' ? loader : 'neoforge')
    : (loader === 'quilt' ? 'quilt' : 'fabric')

  const before = list.length
  list = list.filter((i) => {
    const f = family(i.loaders)
    return !f || f === keepFam || f === 'mix'
  })
  if (list.length < before) log.push('Убрал ' + (before - list.length) + ' мод(ов) чужого ядра')

  for (const [a, b] of CLASH) {
    const A = list.find((i) => blobOf(i).includes(a))
    const B = list.find((i) => blobOf(i).includes(b))
    if (A && B) {
      list = list.filter((i) => i !== B)
      log.push('Конфликт: оставил ' + A.title + ', убрал ' + B.title)
    }
  }

  let have = haveSet(list)
  const needRows = []
  for (const i of list) {
    for (const d of i.need || []) {
      const id = d.slug || d.id
      if (id && !owns(have, id) && !needRows.some((x) => (x.slug || x.id) === id)) needRows.push(d)
    }
    for (const d of i.bad || []) {
      if (d.id && owns(have, d.id)) {
        list = list.filter((x) => !keysOf(x).includes(String(d.id).toLowerCase()))
        log.push(`Конфликт метаданных: ${i.title} несовместим с ${d.title || d.slug || d.id}${d.requiredVersion ? ` версии ${d.requiredVersion}` : ''}. Оставил ${i.title}, убрал ${d.title || d.slug || d.id}.`)
        have = haveSet(list)
      }
    }
  }

  const room = Math.max(0, MAX_PACK_ITEMS - list.length)
  const added = await mapLimit(needRows.slice(0, room), MAX_PACK_CONCURRENCY, async (dep) => {
    let id = dep.slug || dep.id
    let pin = dep.requiredVersion || ''
    if (dep.versionId && !pin) {
      try {
        const exact = await getVersion(dep.versionId)
        pin = exact?.version_number || ''
        id = id || exact?.project_id || ''
      } catch {}
    }
    const row = await findMod(id, game, wantLoader)
    if (!row || !pin) return row
    return fillItem(row, game, wantLoader, { dep: true, pin })
  })
  have = haveSet(list)
  for (const row of added) {
    if (!row || !row.slug || !row.ok) continue
    if (owns(have, row.slug) || owns(have, row.id)) continue
    list.push(row)
    have.add(String(row.slug).toLowerCase())
    if (row.id) have.add(String(row.id).toLowerCase())
    log.push('Добавил ' + row.title + ' ' + (row.version || ''))
  }

  list = await mapLimit(list.slice(0, MAX_PACK_ITEMS), MAX_PACK_CONCURRENCY, async (i) => {
    try { return await fillItem(i, game, wantLoader, { dep: i.dep, pin: i.pin }) }
    catch { return { ...i, ok: !!i.file } }
  })

  if (!log.length) log.push('Сборка уже чистая')
  return { items: list, log, loader: wantLoader }
}

export async function enrich(hit, game, loader, pin) {
  return fillItem(hit, game, loader, { dep: false, pin: pin || '' })
}

export async function labelDeps(items) {
  const ids = []
  const versionIds = []
  for (const i of items || []) {
    for (const d of [...(i.need || []), ...(i.bad || []), ...(i.optional || [])]) {
      if (d.id && !ids.includes(d.id) && String(d.id).length >= 6) ids.push(d.id)
      if (d.versionId && !versionIds.includes(d.versionId)) versionIds.push(d.versionId)
    }
  }
  const map = {}
  const versions = {}
  await Promise.all([
    ...ids.slice(0, 40).map(async (id) => {
      try {
        const p = await getProject(id)
        if (p && (p.slug || p.title)) map[id] = { slug: p.slug, title: p.title, id: p.id || id, url: p.url || '' }
      } catch {}
    }),
    ...versionIds.slice(0, 40).map(async (id) => {
      try {
        const v = await getVersion(id)
        if (v) versions[id] = { version: v.version_number || v.name || id, projectId: v.project_id || '', games: v.game_versions || [], loaders: v.loaders || [] }
      } catch {}
    }),
  ])
  const decorate = (d) => {
    const v = versions[d.versionId] || {}
    const m = map[d.id || v.projectId] || map[v.projectId]
    return {
      ...d,
      id: d.id || v.projectId || '',
      slug: m?.slug || d.slug,
      title: m?.title || d.title || d.id,
      projectUrl: m?.slug ? `/project/${m.slug}` : (d.id ? `/project/${d.id}` : ''),
      requiredVersion: v.version || '',
      games: v.games || [],
      loaders: v.loaders || [],
    }
  }
  return (items || []).map((i) => ({
    ...i,
    id: i.id || i.project_id,
    project_id: i.project_id || i.id,
    need: (i.need || []).map(decorate),
    bad: (i.bad || []).map(decorate),
    optional: (i.optional || []).map(decorate),
    dependencies: (i.dependencies || []).map(decorate),
  }))
}

export function parseCrash(text) {
  const s = String(text || '')
  const mc = (
    s.match(/--fml\.mcVersion,\s*([0-9.]+)/)
    || s.match(/Minecraft\s+(?:Version[: ]+)?([0-9]+(?:\.[0-9]+)+)/i)
    || s.match(/minecraft@([0-9]+(?:\.[0-9]+)+)/i)
    || []
  )[1] || ''
  const nf = (s.match(/--fml\.neoForgeVersion,\s*([0-9.]+)/) || s.match(/NeoForge\s+([0-9.]+)\s+\(neoforge\)/) || [])[1] || ''
  const fg = (s.match(/--fml\.forgeVersion,\s*([0-9.]+)/) || s.match(/Forge(?: version)?[: ]+([0-9.]+)/i) || [])[1] || ''
  const fabric = (s.match(/Fabric Loader[: ]+([0-9.]+)/i) || s.match(/fabricloader@([0-9.]+)/i) || [])[1] || ''
  const quilt = (s.match(/Quilt Loader[: ]+([0-9.]+)/i) || [])[1] || ''
  const java = (s.match(/Java Version[: ]+([^\s,]+)/i) || s.match(/java version "([^"]+)"/i) || [])[1] || ''
  const missing = []
  const issues = []
  const addMissing = (row) => {
    const id = String(row.id || '').trim().replace(/["']/g, '')
    if (!id || missing.some((x) => x.id === id && x.by === row.by)) return
    missing.push({ id, by: String(row.by || '').trim(), range: String(row.range || 'совместимая версия').trim(), actual: String(row.actual || 'MISSING').trim() })
  }
  const re = /Mod ID:\s*'([^']+)'[\s\S]*?Requested by:\s*'([^']+)'[\s\S]*?Expected range:\s*'([^']+)'[\s\S]*?Actual version:\s*'([^']+)'/g
  let m
  while ((m = re.exec(s))) addMissing({ id: m[1], by: m[2], range: m[3], actual: m[4] })

  const compact = /^\s*([a-zA-Z][\w.-]*)\s+(\[[^\n]+?[)\]])\s+(MISSING|Actual:\s*\S+)\s*(?:\(([^)]+)\))?/gm
  while ((m = compact.exec(s))) addMissing({ id: m[1], by: m[4] || '', range: m[2], actual: /Actual:\s*(\S+)/.test(m[3]) ? m[3].replace(/Actual:\s*/, '') : 'MISSING' })

  // Fabric/Quilt wording: "Mod 'A' (a) 1.0 requires version 2.0 or later of mod 'B' (b), which is missing!"
  const fabricReq = /Mod\s+'[^']+'\s+\(([^)]+)\)[^\n]*?requires\s+(?:any\s+)?version\s+([^\n]+?)\s+of\s+(?:mod\s+)?'[^']+'\s+\(([^)]+)\)[^\n]*(missing|present|version\s+([^\s,;]+))/gi
  while ((m = fabricReq.exec(s))) addMissing({ id: m[3], by: m[1], range: m[2], actual: m[5] || (m[4].toLowerCase() === 'missing' ? 'MISSING' : m[4]) })
  const simpleReq = /(?:Mod\s+)?([\w.-]+)\s+requires\s+([\w.-]+)\s+([^\n,;]+)/gi
  while ((m = simpleReq.exec(s))) {
    if (String(m[2]).toLowerCase() !== 'version') addMissing({ id: m[2], by: m[1], range: m[3], actual: 'MISSING' })
  }

  const dup = [...s.matchAll(/(?:Duplicate(?: mod)?|Found duplicate file)[^\n:]*[: ]+([^\n]+)/gi)].map((x) => x[1].trim()).slice(0, 8)
  if (dup.length) issues.push({ kind: 'duplicate', text: 'Дубликаты JAR: ' + dup.join('; ') })
  const mixin = (s.match(/Mixin(?: apply)? failed[^\n]*/i) || s.match(/InvalidMixinException[^\n]*/i) || [])[0]
  if (mixin) issues.push({ kind: 'mixin', text: mixin.slice(0, 280) })
  const klass = (s.match(/(?:NoClassDefFoundError|ClassNotFoundException):?\s*([^\n]+)/) || [])[1]
  if (klass) issues.push({ kind: 'class', text: 'Не найден Java-класс: ' + klass.trim().slice(0, 220) })
  if (/OutOfMemoryError|Java heap space/i.test(s)) issues.push({ kind: 'memory', text: 'Недостаточно памяти Java (OutOfMemoryError / heap space).' })
  if (/UnsupportedClassVersionError/i.test(s)) issues.push({ kind: 'java', text: 'Неверная версия Java (UnsupportedClassVersionError).' })
  if (/Address already in use|FAILED TO BIND TO PORT/i.test(s)) issues.push({ kind: 'port', text: 'Порт сервера уже занят другим процессом.' })
  if (/EXCEPTION_ACCESS_VIOLATION|Problematic frame:/i.test(s)) issues.push({ kind: 'jvm', text: 'Нативный сбой JVM/драйвера; приложи hs_err_pid*.log.' })

  const format = /# A fatal error has been detected by the Java Runtime Environment/.test(s)
    ? 'hs_err_pid'
    : (/---- Minecraft Crash Report ----/.test(s) ? 'crash-report' : (/\[\d{2}:\d{2}:\d{2}\]/.test(s) ? 'latest/debug.log' : 'text'))
  return {
    game: mc,
    loader: nf ? 'neoforge' : (fg ? 'forge' : (quilt ? 'quilt' : (fabric ? 'fabric' : ''))),
    loaderVer: nf || fg || quilt || fabric || '',
    java,
    format,
    missing,
    issues,
  }
}

const OPTI = {
  fabric: ['sodium', 'lithium', 'iris', 'ferrite-core', 'entityculling', 'immediatelyfast', 'krypton', 'modernfix'],
  quilt: ['sodium', 'lithium', 'iris', 'ferrite-core', 'entityculling', 'immediatelyfast', 'krypton', 'modernfix'],
  forge: ['embeddium', 'oculus', 'ferritecore', 'entityculling', 'modernfix'],
  neoforge: ['sodium', 'lithium', 'iris', 'ferrite-core', 'entityculling', 'immediatelyfast', 'modernfix'],
}

export function optiPlan(items, loader) {
  const list = Array.isArray(items) ? items : []
  const want = OPTI[loader] || OPTI.fabric
  const skip = new Set()
  const have = list.map(blobOf).join(' ')
  if (have.includes('optifine')) {
    skip.add('sodium'); skip.add('iris'); skip.add('embeddium'); skip.add('oculus')
  }
  if (have.includes('rubidium') || have.includes('embeddium')) skip.add('sodium')
  if (have.includes('oculus')) skip.add('iris')
  if (have.includes('canary')) skip.add('lithium')
  const add = []
  const keep = []
  for (const slug of want) {
    if (skip.has(slug)) continue
    if (have.includes(slug) || have.includes(slug.replace(/-/g, ''))) { keep.push(slug); continue }
    add.push(slug)
  }
  return { add, keep, skip: [...skip] }
}

export function parseBuildSpec(raw) {
  const input = String(raw || '').trim()
  const parallel = /^#(?:\s|$)/.test(input)
  const body = parallel ? input.replace(/^#\s*/, '') : input
  const chunks = body
    .split(/\s*\+\s*|\n+|;(?=\s)/)
    .map((s) => s.trim())
    .filter(Boolean)
  const parsed = chunks
    .map((chunk) => {
      const spaced = chunk.match(/^(.+?)\s+(v?\d+(?:\.\d+)+(?:[\w.+-]*))\s*$/i)
      if (spaced && !/^\d/.test(spaced[1])) {
        return { q: normalizeModQuery(spaced[1]), pin: spaced[2].replace(/^v/i, ''), raw: chunk }
      }
      return { q: normalizeModQuery(chunk), pin: '', raw: chunk }
    })
    .filter((part) => part.q.length >= 2)
  const seen = new Set()
  const unique = []
  for (const part of parsed) {
    const key = `${part.q.toLowerCase()}@${part.pin.toLowerCase()}`
    if (seen.has(key)) continue
    seen.add(key)
    unique.push(part)
    if (unique.length >= MAX_PACK_ITEMS) break
  }
  return {
    parts: unique,
    parallel,
    total: parsed.length,
    truncated: parsed.length > MAX_PACK_ITEMS,
    concurrency: parallel ? MAX_PACK_CONCURRENCY : 1,
  }
}

export function parseParts(raw) {
  return parseBuildSpec(raw).parts
}

export async function rebuild(raw, game, loader) {
  const parts = parseParts(raw)
  const log = []
  if (!parts.length) return { items: [], log: ['Пустой список'], loader }

  const spec = parseBuildSpec(raw)
  if (spec.truncated) log.push(`Лимит ${MAX_PACK_ITEMS}: лишние позиции не добавлены`)
  const found = await mapLimit(parts, spec.parallel ? MAX_PACK_CONCURRENCY : 4, async (part) => {
    try {
      const hit = await findMod(part.q, game, loader)
      if (hit && (hit.slug || hit.id)) {
        const row = await fillItem(hit, game, loader, { pin: part.pin, dep: !!hit.dep })
        if (part.pin && row.pinMissing) log.push(`Нет точной версии: ${part.q} ${part.pin}`)
        return row
      }
      log.push('Не найден: ' + part.q)
      return { slug: part.q, title: part.q, missing: true, ok: false, pin: part.pin }
    } catch {
      log.push('Ошибка поиска: ' + part.q)
      return { slug: part.q, title: part.q, missing: true, ok: false, pin: part.pin }
    }
  })

  let items = found
  let wantLoader = loader
  for (let round = 1; round <= 3; round++) {
    const res = await autofix(items, game, wantLoader)
    items = res.items || items
    wantLoader = res.loader || wantLoader
    for (const line of res.log || []) {
      log.push(round > 1 ? ('раунд ' + round + ': ' + line) : line)
    }
    const left = analyze(items, game, wantLoader).filter((p) => p.kind === 'need' || p.kind === 'conflict')
    if (!left.length) break
  }
  return { items, log, loader: wantLoader }
}
