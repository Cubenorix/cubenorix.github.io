/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
export const FALLBACK_PUBLIC = 'https://dishes-baseball-see-survivor.trycloudflare.com'

export async function getPublicUrl() {
  try {
    const r = await fetch('/open.json', { cache: 'no-store' })
    const j = await r.json()
    if (j?.url && /^https:\/\//.test(j.url)) return j.url.replace(/\/$/, '')
  } catch {}
  return FALLBACK_PUBLIC
}

export async function copyText(s) {
  const t = String(s || '')
  if (!t) return false
  try {
    await navigator.clipboard.writeText(t)
    return true
  } catch {}
  try {
    const ta = document.createElement('textarea')
    ta.value = t
    ta.setAttribute('readonly', '')
    ta.style.cssText = 'position:fixed;left:0;top:0;width:2px;height:2px;opacity:0'
    document.body.appendChild(ta)
    ta.focus()
    ta.select()
    ta.setSelectionRange(0, t.length)
    const ok = document.execCommand('copy')
    ta.remove()
    return ok
  } catch {
    return false
  }
}
