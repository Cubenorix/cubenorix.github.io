/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, HashRouter } from 'react-router-dom'
import App from './App'
import { StoreProvider } from './store'
import './index.css'
import './official.css'
import './server-launcher.css'

// Static preview hosts and GitHub Pages cannot rewrite every application route
// to index.html. Hash routing keeps shared links reload-safe there; Cloudflare
// Pages/Workers keep clean BrowserRouter URLs through their SPA fallback.
const staticHashHost = window.location.hostname.endsWith('.yapp.page')
  || window.location.hostname.endsWith('.github.io')
const Router = staticHashHost ? HashRouter : BrowserRouter

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <StoreProvider>
      <Router>
        <App />
      </Router>
    </StoreProvider>
  </React.StrictMode>
)
