/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import { uniqueHits } from './stats.js'
import { translationCode } from './languages.js'
import { searchSpemotes } from './spemotes.js'
import { normalizeProjectQuery } from './search-aliases.js'

// Modrinth supports browser CORS. Using its official endpoint directly keeps the
// catalogue functional on static preview hosts as well as on Cloudflare Pages.
const API = 'https://api.modrinth.com/v2'
const searchPageCache = new Map()

function cachedModrinthSearch(params) {
  const key = String(params)
  const now = Date.now()
  const old = searchPageCache.get(key)
  if (old && old.data && now - old.at < 5 * 60_000) return Promise.resolve(old.data)
  if (old?.pending) return old.pending
  const pending = fetch(`${API}/search?${key}`)
    .then((r) => {
      if (!r.ok) throw new Error('search failed')
      return r.json()
    })
    .then((data) => {
      searchPageCache.delete(key)
      searchPageCache.set(key, { data, at: Date.now() })
      while (searchPageCache.size > 12) searchPageCache.delete(searchPageCache.keys().next().value)
      return data
    })
    .catch((error) => {
      searchPageCache.delete(key)
      throw error
    })
  searchPageCache.set(key, { pending, at: now })
  return pending
}

let publicStatsCache = null
let publicStatsPending = null

function spigotRow(p) {
  return {
    slug: 'spigot-' + (p.id || p.name),
    title: p.name,
    description: p.tag || '',
    body: p.tag || p.name || '',
    url: 'https://www.spigotmc.org/resources/' + p.id,
    icon_url: p.icon?.url ? 'https://www.spigotmc.org/' + p.icon.url : '/sources/spigot.svg',
    sources: ['spigot'], project_type: 'plugin', author: p.author?.name,
    downloads: p.downloads || 0, likes: p.likes || 0, external: true,
  }
}

function hangarRow(p) {
  const slug = p.namespace?.slug || p.name
  return {
    slug: 'hangar-' + slug,
    title: p.name,
    description: p.description || '',
    body: p.description || '',
    url: `https://hangar.papermc.io/${p.namespace?.owner}/${slug}`,
    icon_url: p.avatarUrl,
    sources: ['hangar'], project_type: 'plugin', author: p.namespace?.owner,
    downloads: p.stats?.downloads || 0, follows: p.stats?.stars || 0, external: true,
  }
}

export async function getLiveCatalogStats() {
  if (publicStatsCache && Date.now() - publicStatsCache.at < 10 * 60_000) return publicStatsCache
  if (publicStatsPending) return publicStatsPending
  publicStatsPending = (async () => {
    try {
      const r = await fetch('/api/live', { headers: { Accept: 'application/json' } })
      if (r.ok && String(r.headers.get('content-type') || '').includes('application/json')) {
        const j = await r.json()
        if (Number(j.total) > 200_000) {
          publicStatsCache = { ...j, at: Number(j.at) || Date.now() }
          return publicStatsCache
        }
      }
    } catch {}
    const [mr, sp, hg] = await Promise.all([
      cachedModrinthSearch(new URLSearchParams({ query: '', limit: '1', offset: '0', index: 'relevance' })).catch(() => ({ total_hits: 0 })),
      fetch('https://api.spiget.org/v2/resources?size=1&page=1&sort=-downloads')
        .then((r) => ({ total: Number(r.headers.get('x-page-count') || r.headers.get('x-total') || 0) }))
        .catch(() => ({ total: 0 })),
      fetch('https://hangar.papermc.io/api/v1/projects?limit=1&offset=0')
        .then((r) => r.json()).catch(() => ({})),
    ])
    const by = {
      modrinth: Number(mr.total_hits) || 0,
      spigot: Number(sp.total) || 0,
      hangar: Number(hg?.pagination?.count) || 0,
    }
    const total = Object.values(by).reduce((sum, n) => sum + n, 0)
    publicStatsCache = { total, by, sources: Object.values(by).filter(Boolean).length, at: Date.now(), live: total > 0 }
    return publicStatsCache
  })().finally(() => { publicStatsPending = null })
  return publicStatsPending
}

function allocatePage(limit, counts) {
  const sum = counts.reduce((a, b) => a + b, 0) || 1
  const exact = counts.map((n) => (limit * n) / sum)
  const out = exact.map(Math.floor)
  let left = limit - out.reduce((a, b) => a + b, 0)
  const order = exact.map((n, i) => [n - Math.floor(n), i]).sort((a, b) => b[0] - a[0])
  for (let i = 0; i < left; i += 1) out[order[i % order.length][1]] += 1
  return out
}

export async function searchAllLiveProjects({ limit = 100, offset = 0, index = 'downloads' } = {}) {
  const stats = await getLiveCatalogStats()
  const counts = [Number(stats.by?.modrinth) || 0, Number(stats.by?.spigot) || 0, Number(stats.by?.hangar) || 0]
  const searchableTotal = counts.reduce((a, b) => a + b, 0)
  const [mrLimit, spLimit, hgLimit] = allocatePage(Math.min(100, Math.max(1, limit)), counts)
  const globalPage = Math.floor(offset / Math.max(1, limit))
  const mrOffset = globalPage * mrLimit
  const spPage = globalPage + 1
  const hgOffset = globalPage * hgLimit
  const mrParams = new URLSearchParams({ query: '', limit: String(mrLimit), offset: String(mrOffset), index })
  const [mr, sp, hg] = await Promise.all([
    mrLimit ? cachedModrinthSearch(mrParams).catch(() => ({ hits: [] })) : { hits: [] },
    spLimit ? fetch(`https://api.spiget.org/v2/resources?size=${spLimit}&page=${spPage}&sort=-downloads`).then((r) => r.json()).catch(() => []) : [],
    hgLimit ? fetch(`https://hangar.papermc.io/api/v1/projects?limit=${hgLimit}&offset=${hgOffset}`).then((r) => r.json()).catch(() => ({ result: [] })) : { result: [] },
  ])
  const groups = [mr.hits || [], (Array.isArray(sp) ? sp : []).map(spigotRow), (hg.result || []).map(hangarRow)]
  const hits = []
  while (hits.length < limit && groups.some((g) => g.length)) {
    for (const group of groups) if (group.length && hits.length < limit) hits.push(group.shift())
  }
  cacheHits(hits)
  return { hits, total_hits: searchableTotal || Number(mr.total_hits) || 0, sources: ['modrinth', 'spigot', 'hangar'], by: stats.by }
}

const WORD_TYPE = {
  mod: 'mod', мод: 'mod', моды: 'mod',
  plugin: 'plugin', плагин: 'plugin', плагины: 'plugin',
  shader: 'shader', шейдер: 'shader', шейдеры: 'shader',
  map: 'map', карта: 'map', карты: 'map',
  skin: 'skin', скин: 'skin', скины: 'skin',
  schematic: 'schematic', схема: 'schematic', схемы: 'schematic',
  datapack: 'datapack', датапак: 'datapack',
  resourcepack: 'resourcepack', ресурспак: 'resourcepack', текстура: 'texture',
  modpack: 'modpack', модпак: 'modpack', сборка: 'modpack',
  cosmetic: 'cosmetic', cosmetics: 'cosmetic', косметика: 'cosmetic', плащ: 'cosmetic', плащи: 'cosmetic',
}

export function parseQuery(raw) {
  const normalized = normalizeProjectQuery(raw)
  const parts = String(normalized || '').split(/[+\s]+/).map((s) => s.trim()).filter(Boolean)
  const loaders = new Set(['forge', 'fabric', 'quilt', 'neoforge', 'babric', 'rift', 'paper', 'spigot', 'folia', 'purpur'])
  const types = new Set(['mod', 'modpack', 'resourcepack', 'shader', 'datapack', 'plugin', 'map', 'skin', 'schematic', 'texture', 'cosmetic'])
  const out = { q: [], versions: [], loaders: [], type: null, extra: [], addon: false }
  for (const p of parts) {
    const low = p.toLowerCase()
    if (/^(?:1\.\d|2[6-9]\.\d|\d{2}w)/.test(low)) out.versions.push(p)
    else if (loaders.has(low)) out.loaders.push(low)
    else if (types.has(low)) out.type = low
    else if (WORD_TYPE[low]) out.type = WORD_TYPE[low]
    else if (['addon', 'addons', 'аддон', 'аддоны'].includes(low)) out.addon = true
    else if (['emote', 'emotes', 'эмоции', 'эмоут'].includes(low)) out.extra.push('emote')
    else out.q.push(p)
  }
  return out
}

export function rankHits(hits, q) {
  const n = String(q || '').toLowerCase().trim()
  return [...(hits || [])].sort((a, b) => {
    const at = String(a.title || '').toLowerCase()
    const bt = String(b.title || '').toLowerCase()
    const ae = n && at === n ? 3 : n && at.startsWith(n) ? 2 : n && at.includes(n) ? 1 : 0
    const be = n && bt === n ? 3 : n && bt.startsWith(n) ? 2 : n && bt.includes(n) ? 1 : 0
    if (be !== ae) return be - ae
    return (Number(b.downloads) || 0) - (Number(a.downloads) || 0)
  })
}

const hitCache = new Map()
try {
  const raw = sessionStorage.getItem('cubexus.hits') || sessionStorage.getItem('cubenix.hits')
  if (raw) JSON.parse(raw).forEach(([k, v]) => { if (k && v) hitCache.set(k, v) })
} catch {}
export function cacheHits(hits) {
  for (const h of hits || []) {
    if (h?.slug) hitCache.set(h.slug, h)
  }
  try {
    sessionStorage.setItem('cubexus.hits', JSON.stringify([...hitCache].slice(-180)))
  } catch {}
}
export function cachedHit(slug) {
  return hitCache.get(slug) || null
}

function withTime(promise, ms, fallback) {
  let t
  const timeout = new Promise((resolve) => { t = setTimeout(() => resolve(fallback), ms) })
  return Promise.race([promise, timeout]).finally(() => clearTimeout(t))
}

export async function searchOthers({ query = '', type = 'all', limit = 20, offset = 0 } = {}) {
  if (!query || String(query).trim().length < 2) return { hits: [], total_hits: 0 }
  try {
    const params = new URLSearchParams({ q: query, type, limit: String(limit), offset: String(offset) })
    const r = await withTime(fetch('/api/agg-search?' + params), 16000, null)
    if (!r || !r.ok) return { hits: [], total_hits: 0 }
    const d = await r.json()
    cacheHits(d.hits)
    return d
  } catch {
    return { hits: [], total_hits: 0 }
  }
}

export async function searchProjects({ query = '', limit = 20, offset = 0, index = 'relevance', facets = [], type = '' } = {}) {
  const parsed = parseQuery(query)
  if (parsed.addon) {
    return searchAddons({ query: parsed.q.join(' '), limit, offset, version: parsed.versions[0], loader: parsed.loaders[0] })
  }
  let q = parsed.q.join(' ')
  try {
    const mode = JSON.parse(localStorage.getItem('cubexus.v1') || localStorage.getItem('cubenix.v1') || '{}').searchMode
    if (mode === 'exact' && q && !q.startsWith('"')) q = `"${q}"`
  } catch {}
  if (type === 'all' && !q && !parsed.versions.length && !parsed.loaders.length && !facets.length) {
    return searchAllLiveProjects({ limit, offset, index: index === 'relevance' ? 'downloads' : index })
  }
  const f = [...facets]
  if (parsed.type) f.push([`project_type:${parsed.type}`])
  if (type === 'cosmetic' && !f.flat().includes('project_type:mod')) {
    f.push(['project_type:mod'])
    f.push(['categories:cosmetic'])
  }
  if (parsed.versions.length) f.push(parsed.versions.map((v) => `versions:${v}`))
  if (parsed.loaders.length) f.push(parsed.loaders.map((l) => `categories:${l}`))
  const params = new URLSearchParams({
    query: q,
    limit: String(Math.min(100, Math.max(Number(limit) || 20, 40))),
    offset: String(offset),
    index,
  })
  if (f.length) params.set('facets', JSON.stringify(f))

  const wantMr = !type || ['all', 'mod', 'modpack', 'resourcepack', 'shader', 'datapack', 'plugin', 'library', 'optimization', 'cosmetic'].includes(type)
  const othersType = type && type !== 'library' && type !== 'optimization' ? type : 'all'

  const [mr, extra] = await Promise.all([
    wantMr
      ? withTime(
        cachedModrinthSearch(params).catch(() => ({ hits: [], total_hits: 0 })),
        10000,
        { hits: [], total_hits: 0 },
      )
      : Promise.resolve({ hits: [], total_hits: 0 }),
    q
      ? searchOthers({ query: q.replace(/"/g, ''), type: othersType, limit: 40, offset })
      : Promise.resolve({ hits: [], total_hits: 0 }),
  ])
  const merged = uniqueHits([...(extra.hits || []), ...(mr.hits || [])])
  const hits = rankHits(merged, String(q || '').replace(/"/g, ''))
  cacheHits(hits)
  return {
    hits,
    total_hits: (Number(mr.total_hits) || 0) + (Number(extra.total_hits) || 0),
    sources: [...new Set(hits.flatMap((h) => h.sources || (h.external ? [] : ['modrinth'])))],
  }
}

export async function getProject(id) {
  const cached = hitCache.get(id)
  try {
    const r = await fetch(`${API}/project/${encodeURIComponent(id)}`)
    if (r.ok) {
      const p = await r.json()
      if (p && p.title) return p
    }
  } catch {}
  if (cached) return { ...cached, body: cached.body || cached.description }
  try {
    const r = await fetch('/api/agg-get?slug=' + encodeURIComponent(id))
    if (r.ok) {
      const p = await r.json()
      if (p && !p.missing) return p
    }
  } catch {}
  const guess = String(id).replace(/^(curseforge|pmc|inside|github|hangar|spigot|poggit|tenmc|mcmaps|create|rumc|polymart|sponge|smithed|modpackindex|mcpedl|mcbase|resourcepack|builtbybit|mcmodcn|minecraftforum|shadersmods|minecraftshader|minecraftmax|schematicsgg|minecraftschematics|mcbuild|minecraftstorage|mcpehub|minebbs)-/i, ' ').replace(/-/g, ' ').trim()
  if (guess && guess !== id) {
    const extra = await searchOthers({ query: guess, type: 'all', limit: 12 })
    const hit = (extra.hits || []).find((h) => h.slug === id) || (extra.hits || [])[0]
    if (hit) return { ...hit, body: hit.body || hit.description }
  }
  throw new Error('project not found')
}

export async function quickSearch({ query = '', limit = 5, facets = [] } = {}) {
  const params = new URLSearchParams({
    query: String(query || ''),
    limit: String(limit),
    index: 'relevance',
  })
  if (facets.length) params.set('facets', JSON.stringify(facets))
  const r = await withTime(
    fetch(`${API}/search?${params}`).then((x) => (x.ok ? x.json() : { hits: [] })).catch(() => ({ hits: [] })),
    4000,
    { hits: [] },
  )
  return r && Array.isArray(r.hits) ? r : { hits: [] }
}

export async function getVersions(id) {
  const r = await withTime(fetch(`${API}/project/${encodeURIComponent(id)}/version`), 10000, null)
  if (!r || !r.ok) return []
  const data = await r.json()
  return Array.isArray(data) ? data : []
}

export async function getVersion(id) {
  if (!id) return null
  const r = await withTime(fetch(`${API}/version/${encodeURIComponent(id)}`), 10000, null)
  if (!r || !r.ok) return null
  const data = await r.json()
  return data && typeof data === 'object' ? data : null
}

export async function getTeam(id) {
  const r = await fetch(`${API}/project/${encodeURIComponent(id)}/members`)
  if (!r.ok) return []
  return r.json()
}

export async function autocomplete(q) {
  const query = normalizeProjectQuery(q)
  if (!query || query.length < 2) return []
  try {
    const [mr, extra] = await Promise.all([
      rawSearch({ query, limit: 8, index: 'relevance' }).catch(() => ({ hits: [] })),
      searchOthers({ query, type: 'all', limit: 8 }),
    ])
    const seen = new Set()
    const out = []
    for (const h of [...(extra.hits || []), ...(mr.hits || [])]) {
      if (!h?.slug || seen.has(h.slug)) continue
      seen.add(h.slug)
      out.push(h)
      if (out.length >= 10) break
    }
    return out
  } catch {
    return []
  }
}

function rawSearch({ query, limit, offset, index, facets }) {
  const params = new URLSearchParams({
    query: query || '',
    limit: String(limit || 20),
    offset: String(offset || 0),
    index: index || 'relevance',
  })
  if (facets?.length) params.set('facets', JSON.stringify(facets))
  return cachedModrinthSearch(params)
}

export async function searchAddons({ query = '', limit = 20, offset = 0, version, loader } = {}) {
  const q = String(query || '').replace(/addons?|аддоны?/gi, '').trim()
  if (!q) return { hits: [], total_hits: 0, parent: null }
  const parentRes = await rawSearch({ query: q, limit: 8, facets: [['project_type:mod']] }).catch(() => ({ hits: [] }))
  const hits0 = parentRes.hits || []
  const ql = q.toLowerCase()
  const parent = hits0.find((h) => h.slug === ql || String(h.title).toLowerCase() === ql)
    || hits0.find((h) => String(h.slug).includes(ql.replace(/\s+/g, '-')))
    || hits0[0]
  const parentSlug = parent?.slug || q
  const parentTitle = parent?.title || q
  const parentId = parent?.project_id || parent?.id
  const facets = [['project_type:mod']]
  if (version) facets.push([`versions:${version}`])
  if (loader) facets.push([`categories:${String(loader).toLowerCase()}`])

  const [byCat, byAddon, byName] = await Promise.all([
    rawSearch({ query: '', limit: 40, facets: [...facets, [`categories:${parentSlug}`]] }).catch(() => ({ hits: [] })),
    rawSearch({ query: `${parentTitle} addon`, limit: 40, facets }).catch(() => ({ hits: [] })),
    rawSearch({ query: parentTitle, limit: 40, facets }).catch(() => ({ hits: [] })),
  ])

  const needle = [parentSlug.replace(/-/g, ' '), parentTitle.toLowerCase(), parentSlug]
  const map = new Map()
  for (const h of [...(byCat.hits || []), ...(byAddon.hits || []), ...(byName.hits || [])]) {
    if (!h?.slug || h.slug === parentSlug) continue
    const blob = `${h.title} ${h.description || ''} ${(h.categories || []).join(' ')}`.toLowerCase()
    const fromCat = (byCat.hits || []).some((x) => x.slug === h.slug)
    const related = fromCat || needle.some((n) => n && blob.includes(String(n).toLowerCase())) || /addon|дополн|аддон/.test(blob)
    if (!related) continue
    if (!map.has(h.slug)) map.set(h.slug, { ...h, project_type: 'addon', addon_of: parentSlug, addon_of_title: parentTitle })
  }

  let list = [...map.values()]
  const check = list.slice(0, 10)
  const verified = new Set()
  await Promise.all(check.map(async (h) => {
    try {
      const vs = await getVersions(h.slug)
      const deps = (vs || []).flatMap((v) => v.dependencies || [])
      if (deps.some((d) => d.project_id === parentId || d.project_id === parentSlug)) verified.add(h.slug)
    } catch {}
  }))
  if (verified.size) list = list.filter((h) => verified.has(h.slug) || (h.categories || []).includes(parentSlug))
  list.sort((a, b) => (b.downloads || 0) - (a.downloads || 0))
  const slice = list.slice(offset, offset + limit)
  return { hits: slice, total_hits: list.length, parent: parent ? { slug: parentSlug, title: parentTitle, icon_url: parent.icon_url } : null }
}

export async function getCatalogStats() {
  const types = ['mod', 'modpack', 'resourcepack', 'shader', 'datapack', 'plugin']
  const rows = await Promise.all(types.map(async (t) => {
    const d = await rawSearch({ query: '', limit: 1, facets: [[`project_type:${t}`]] }).catch(() => ({ total_hits: 0 }))
    return [t, d.total_hits || 0]
  }))
  const by = Object.fromEntries(rows)
  return { source: 'modrinth', total: rows.reduce((a, [, n]) => a + n, 0), ...by }
}

export async function searchEmotes({ query = '', limit = 20, offset = 0 } = {}) {
  const q = query.trim() || 'emote animation'
  const [rp, mods, plugins, other] = await Promise.all([
    rawSearch({ query: q, limit: 100, facets: [['project_type:resourcepack']] }).catch(() => ({ hits: [] })),
    rawSearch({ query: `${q} emotecraft`, limit: 100, facets: [['project_type:mod']] }).catch(() => ({ hits: [] })),
    rawSearch({ query: 'emotecraft', limit: 30, facets: [['project_type:plugin']] }).catch(() => ({ hits: [] })),
    searchOthers({ query: q, type: 'emote', limit: 40, offset: 0 }).catch(() => ({ hits: [] })),
  ])
  const map = new Map()
  const spemotes = searchSpemotes(query)
  for (const h of [...spemotes, ...(plugins.hits || []), ...(mods.hits || []), ...(rp.hits || []), ...(other.hits || [])]) {
    if (!h?.slug) continue
    const row = { ...h, project_type: h.project_type === 'resourcepack' ? 'emote' : (h.project_type || 'emote') }
    const prev = map.get(h.slug)
    map.set(h.slug, prev ? { ...prev, ...row, sources: [...new Set([...(prev.sources || []), ...(row.sources || [])])] } : row)
  }
  const list = [...map.values()].sort((a, b) => Number(Boolean(b.featured)) - Number(Boolean(a.featured)) || (b.downloads || 0) - (a.downloads || 0))
  return { hits: list.slice(offset, offset + limit), total_hits: list.length, sources: [...new Set(list.flatMap((x) => x.sources || []))] }
}

export async function searchTextures({ query = '', limit = 20, offset = 0, resolution } = {}) {
  const facets = [['project_type:resourcepack']]
  if (resolution) facets.push([`categories:${resolution}`])
  return rawSearch({ query: query || 'texture', limit, offset, facets })
}

export function cdnProxy(url) {
  try {
    const u = new URL(url)
    // The official Modrinth CDN is CORS-enabled, so this also works when the
    // frontend is served from a static preview without Cubexus Functions.
    if (u.protocol === 'https:' && (u.hostname.includes('cdn.modrinth.com') || u.hostname.includes('cdn-raw.modrinth.com'))) return u.href
  } catch {}
  return ''
}

export function mediaUrl(url) {
  if (!url) return ''
  if (url.startsWith('data:')) return url
  if (url.startsWith('/') && !url.startsWith('//')) return url
  try {
    const u = new URL(url)
    // Images do not need the relay. Keeping the genuine source URL avoids
    // broken artwork on static hosts and still preserves source provenance.
    if (u.protocol === 'https:') return u.href
  } catch {}
  return ''
}

export function fileApi(url, name) {
  const n = String(name || 'cubexus-file').replace(/[^\w.\-+]+/g, '_').slice(0, 120)
  return '/api/file?url=' + encodeURIComponent(url) + '&name=' + encodeURIComponent(n)
}

function isZipArchive(bytes) {
  return bytes?.length >= 4
    && bytes[0] === 0x50
    && bytes[1] === 0x4b
    && ((bytes[2] === 0x03 && bytes[3] === 0x04)
      || (bytes[2] === 0x05 && bytes[3] === 0x06)
      || (bytes[2] === 0x07 && bytes[3] === 0x08))
}

// Returns a real JAR/ZIP payload for the pack builder. On static hosts
// /api/file may resolve to index.html, so the official Modrinth CDN is tried
// directly first and every response is checked for the ZIP/JAR PK signature.
export async function fetchArchiveBlob(file, maxBytes = 250 * 1024 * 1024) {
  if (!file?.url) throw new Error('missing file URL')
  const name = String(file.filename || 'mod.jar').replace(/[^\w.\-+]+/g, '_').slice(0, 120)
  const direct = cdnProxy(file.url)
  const endpoints = [...new Set([direct, fileApi(file.url, name)].filter(Boolean))]
  let lastError = 'download failed'
  for (const endpoint of endpoints) {
    const ctrl = new AbortController()
    const timer = setTimeout(() => ctrl.abort(), 90_000)
    try {
      const r = await fetch(endpoint, {
        signal: ctrl.signal,
        credentials: endpoint.startsWith('/') ? 'same-origin' : 'omit',
      })
      if (!r.ok) throw new Error('HTTP ' + r.status)
      const type = String(r.headers.get('content-type') || '').toLowerCase()
      if (type.includes('text/html') || type.includes('application/json')) throw new Error('not a binary file')
      const announced = Number(r.headers.get('content-length') || 0)
      if (announced > maxBytes) throw new Error('file too large')
      const blob = await r.blob()
      if (!blob.size || blob.size > maxBytes) throw new Error('invalid file size')
      const magic = new Uint8Array(await blob.slice(0, 4).arrayBuffer())
      if (!isZipArchive(magic)) throw new Error('not a JAR/ZIP archive')
      return blob
    } catch (error) {
      lastError = String(error?.message || error)
    } finally {
      clearTimeout(timer)
    }
  }
  throw new Error(lastError)
}

export function goDl(url, name) {
  const n = String(name || 'mod.jar').replace(/[^\w.\-+]+/g, '_').slice(0, 120)
  return '/go-dl?url=' + encodeURIComponent(url) + '&name=' + encodeURIComponent(n)
}

export function saveBlob(blob, filename) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.style.display = 'none'
  a.href = url
  a.download = filename || 'cubexus-file'
  a.rel = 'noopener'
  document.body.appendChild(a)
  a.click()
  setTimeout(() => { a.remove(); URL.revokeObjectURL(url) }, 12000)
}

function clickSameOrigin(href, filename) {
  const a = document.createElement('a')
  a.href = href
  a.download = filename || 'cubexus-file'
  a.rel = 'noopener'
  a.style.display = 'none'
  document.body.appendChild(a)
  a.click()
  setTimeout(() => a.remove(), 4000)
}

export async function downloadWithProgress(file, onProgress) {
  if (!file?.url) throw new Error('no file')
  const name = String(file.filename || 'download.jar').replace(/[^\w.\-+]+/g, '_').slice(0, 120)
  onProgress(8)
  const api = fileApi(file.url, name)
  const proxied = cdnProxy(file.url)
  const endpoints = [api, proxied].filter(Boolean)
  for (const ep of endpoints) {
    try {
      const ctrl = new AbortController()
      const t = setTimeout(() => ctrl.abort(), 60000)
      const res = await fetch(ep, { signal: ctrl.signal, credentials: 'same-origin' })
      clearTimeout(t)
      if (!res.ok) continue
      const ctype = String(res.headers.get('content-type') || '')
      if (ctype.includes('application/json') || ctype.includes('text/html')) continue
      const total = Number(res.headers.get('content-length') || 0)
      if (total && total > 250 * 1024 * 1024) continue
      const reader = res.body.getReader()
      const chunks = []
      let rec = 0
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        chunks.push(value)
        rec += value.length
        if (rec > 250 * 1024 * 1024) throw new Error('too large')
        if (total) onProgress(Math.min(99, Math.round((rec / total) * 100)))
        else onProgress(Math.min(92, 10 + chunks.length * 2))
      }
      onProgress(100)
      const blob = new Blob(chunks, { type: 'application/octet-stream' })
      if (blob.size < 64) continue
      saveBlob(blob, name)
      return { ok: true, blob, filename: name, objectUrl: URL.createObjectURL(blob), sourceUrl: api }
    } catch {
      continue
    }
  }
  onProgress(100)
  clickSameOrigin(file.url, name)
  return { ok: true, filename: name, sourceUrl: file.url }
}

const cache = new Map()

function guessFrom(text) {
  if (/[ієїґ]/i.test(text)) return 'uk'
  if (/[а-яё]/i.test(text)) return 'ru'
  if (/[ぁ-んァ-ン]/.test(text)) return 'ja'
  if (/[가-힣]/.test(text)) return 'ko'
  if (/[一-鿿]/.test(text)) return 'zh-Hans'
  if (/[äöüß]/i.test(text)) return 'de'
  if (/[àâçéèêëîïôùûœ]/i.test(text)) return 'fr'
  if (/[ñáéíóúü¿¡]/i.test(text)) return 'es'
  return 'en'
}

const waiters = []
let inflight = 0
function takeSlot() {
  if (inflight >= 5) return new Promise((ok) => waiters.push(ok))
  inflight += 1
  return Promise.resolve()
}
function freeSlot() {
  inflight = Math.max(0, inflight - 1)
  const next = waiters.shift()
  if (next) { inflight += 1; next() }
}

function memoryCode(code) {
  const c = String(code || 'en').toLowerCase()
  if (c === 'zh-hans' || c === 'zh-cn') return 'zh-CN'
  if (c === 'iw') return 'he'
  if (c === 'fil') return 'tl'
  return c.split('-')[0]
}

function translationPieces(text, max = 440) {
  const out = []
  let rest = String(text || '').trim()
  while (rest.length > max) {
    const probe = rest.slice(0, max + 1)
    const stops = [probe.lastIndexOf('\n'), probe.lastIndexOf('. '), probe.lastIndexOf('! '), probe.lastIndexOf('? '), probe.lastIndexOf(' ')]
    let cut = Math.max(...stops)
    if (cut < Math.floor(max * 0.55)) cut = max
    else cut += 1
    out.push(rest.slice(0, cut).trim())
    rest = rest.slice(cut).trim()
  }
  if (rest) out.push(rest)
  return out.slice(0, 4)
}

async function googleDictionaryPart(part, to, from) {
  const params = new URLSearchParams({ client: 'dict-chrome-ex', sl: memoryCode(from), tl: memoryCode(to), q: part })
  const r = await fetch('https://clients5.google.com/translate_a/t?' + params, { headers: { Accept: 'application/json' } })
  if (!r.ok) throw new Error('dictionary translation unavailable')
  const j = await r.json()
  const out = Array.isArray(j)
    ? j.filter((x) => typeof x === 'string').join(' ').trim()
    : (j?.sentences || []).map((x) => x?.trans || '').join('').trim()
  if (!out) throw new Error('empty dictionary translation')
  return out
}

async function myMemoryPart(part, to, from) {
  const pair = `${memoryCode(from)}|${memoryCode(to)}`
  const u = 'https://api.mymemory.translated.net/get?q=' + encodeURIComponent(part) + '&langpair=' + encodeURIComponent(pair)
  const r = await fetch(u, { headers: { Accept: 'application/json' } })
  if (!r.ok) throw new Error('translation unavailable')
  const j = await r.json()
  const out = String(j?.responseData?.translatedText || '').trim()
  if (Number(j?.responseStatus || 200) >= 400 || !out || /MYMEMORY WARNING|QUERY LENGTH LIMIT/i.test(out)) throw new Error('translation quota')
  return out
}

async function translateInBrowser(s, to, from) {
  const translated = []
  for (const part of translationPieces(s)) {
    try {
      translated.push(await googleDictionaryPart(part, to, from))
    } catch {
      translated.push(await myMemoryPart(part, to, from))
    }
  }
  return translated.join(' ')
}

function cacheId(key) {
  let h = 2166136261
  for (let i = 0; i < key.length; i += 1) h = Math.imul(h ^ key.charCodeAt(i), 16777619)
  return 'cx-tr-' + (h >>> 0).toString(36)
}

function savedTranslation(key) {
  try { return localStorage.getItem(cacheId(key)) || '' } catch { return '' }
}

function saveTranslation(key, value) {
  try { localStorage.setItem(cacheId(key), String(value).slice(0, 5000)) } catch {}
}

async function translateOnce(s, to, from) {
  const key = to + '|' + from + '|' + s
  if (cache.has(key)) return cache.get(key)
  const saved = savedTranslation(key)
  if (saved) { cache.set(key, saved); return saved }
  await takeSlot()
  try {
    let out = ''
    try {
      const r = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ q: s.slice(0, 900), to, from }),
      })
      if (r.ok && String(r.headers.get('content-type') || '').includes('application/json')) {
        const j = await r.json()
        if (j.engine !== 'rate' && j.engine !== 'none') out = String(j.text || '').replace(/MYMEMORY WARNING:.*/i, '').trim()
      }
    } catch {}
    // Static previews do not have /api/translate. The browser fallback has CORS
    // enabled and uses the visitor's own public quota instead of a shared edge IP.
    if (!out || out === s) out = await translateInBrowser(s, to, from)
    if (!out) return s
    cache.set(key, out)
    saveTranslation(key, out)
    return out
  } catch {
    return s
  } finally {
    freeSlot()
  }
}

export async function localize(text, lang = 'ru', { preview = false } = {}) {
  const { holdProtect, giveProtect, htmlToMd, plainPreview } = await import('./text')
  const raw = preview ? plainPreview(text, 400) : htmlToMd(text)
  if (!raw) return ''
  const { out: s, bag } = holdProtect(raw)
  let done = s
  if (lang === 'gc' || lang === 'morse') {
    const { toSGA, toMorse } = await import('./i18n')
    const from = guessFrom(s)
    const en = from === 'en' ? s : await translateOnce(s, 'en', from)
    done = lang === 'gc' ? toSGA(en) : toMorse(en)
  } else {
    const to = translationCode(lang)
    const from = guessFrom(s)
    if (!(from === to || (to === 'en' && from === 'en') || (to === 'zh-CN' && from === 'zh-Hans'))) {
      if (!(to === 'ru' && /[а-яё]/i.test(s) && !/[a-z]{4,}/i.test(s)) && !(to === 'uk' && /[а-яёієїґ]/i.test(s) && !/[a-z]{4,}/i.test(s))) {
        done = await translateOnce(s, to, from === 'zh-Hans' ? 'zh-Hans' : from)
      }
    }
  }
  return giveProtect(done, bag)
}

export async function localizeBody(text, lang = 'ru') {
  const { splitForTranslate } = await import('./md')
  const { htmlToMd } = await import('./text')
  const s = htmlToMd(text)
  if (!s) return ''
  const chunks = splitForTranslate(s)
  const out = []
  for (const c of chunks) {
    if (c.t === 'code') { out.push(c.v); continue }
    out.push(await localize(c.v, lang))
  }
  return out.join('\n\n')
}

export function autoRu(text) {
  return String(text || '')
}
