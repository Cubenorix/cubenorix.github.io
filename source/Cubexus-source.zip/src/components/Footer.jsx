/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import { Link } from 'react-router-dom'
import { useStore } from '../store'
import { t } from '../i18n'
import { YEARS } from '../data'
import { SUPPORT_BOT_TELEGRAM } from '../data/community'

export default function Footer() {
  const { lang } = useStore()
  const cols = [
    {
      h: t(lang, 'footer.catalog'),
      l: [
        ['/catalog?type=mod', t(lang, 'cat.mods')],
        ['/catalog?type=addon', t(lang, 'cat.addons')],
        ['/catalog?type=shader', t(lang, 'cat.shaders')],
        ['/catalog?type=plugin', t(lang, 'cat.plugins')],
        ['/catalog?type=map', t(lang, 'cat.maps')],
        ['/catalog?type=skin', t(lang, 'cat.skins')],
      ],
    },
    {
      h: t(lang, 'footer.play'),
      l: [
        ['/servers', t(lang, 'nav.servers')],
        ['/hosting', t(lang, 'nav.hosting')],
        ['/wiki', t(lang, 'nav.wiki')],
        ['/generators', t(lang, 'nav.generators')],
        ['/guides', t(lang, 'nav.guides')],
        ['/forum', t(lang, 'nav.forum')],
      ],
    },
    {
      h: 'Cubexus',
      l: [
        ['/about', t(lang, 'footer.about')],
        ['/top', t(lang, 'nav.top')],
        ['/how', t(lang, 'footer.how')],
        ['/add', t(lang, 'nav.add')],
        ['/connection', t(lang, 'nav.conn')],
        ['/reviews', t(lang, 'footer.reviews')],
        ['/community', t(lang, 'nav.community')],
        ['/bridge', t(lang, 'footer.bridge')],
        ['/hash', t(lang, 'footer.hash')],
      ],
    },
    {
      h: t(lang, 'footer.legal'),
      l: [
        ['/rules', t(lang, 'footer.rules')],
        ['/terms', t(lang, 'footer.terms')],
        ['/privacy', t(lang, 'footer.privacy')],
        ['/license', t(lang, 'pages.license')],
        ['/dmca', t(lang, 'footer.dmca')],
        ['/authors', t(lang, 'footer.authors')],
        ['/disclaimer', t(lang, 'footer.disc')],
      ],
    },
  ]

  return (
    <footer className="relative z-10 mt-0">
        <div className="foot-bg relative">
        <div className="foot-glow" />
        <div className="max-w-7xl mx-auto px-4 py-12 relative">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-8">
            <div className="flex items-center gap-3">
              <img src="/logo.png?v=4" alt="Cubexus" className="logo-img" width="44" height="44" />
              <div>
                <div className="font-outfit text-xl text-white">Cubexus</div>
                <div className="text-xs text-white/40">{t(lang, 'footer.tag')}</div>
              </div>
            </div>
            <div className="sm:ml-auto flex flex-wrap gap-2">
              <a href="https://t.me/Cubenix" target="_blank" rel="me noopener noreferrer" className="footer-official-link">
                <img src="/social/telegram.svg" alt="" width="18" height="18" />
                <span>{t(lang, 'comm.verified')} · @Cubenix</span>
              </a>
              <a href={SUPPORT_BOT_TELEGRAM} target="_blank" rel="noopener noreferrer" className="footer-proof-link">Техподдержка · @CubexusSupportBot</a>
              <a href="/official/" className="footer-proof-link">{t(lang, 'comm.checkTitle')}</a>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
            {cols.map((c) => (
              <div key={c.h}>
                <div className="text-white/40 text-xs uppercase tracking-wider mb-3">{c.h}</div>
                <div className="space-y-2">
                  {c.l.map(([to, n]) => <Link key={to} to={to} className="block text-white/65 hover:text-orange-soft">{n}</Link>)}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-10 pt-5 border-t border-white/10 text-xs text-white/35 flex flex-col md:flex-row gap-2">
            <span>© {YEARS} Cubexus Team · бренд и оригинальный контент защищены</span>
            <span className="md:ml-auto"><Link to="/license" className="hover:text-orange-soft">Код: AGPL-3.0-or-later</Link> · <a href="/source-code.html" className="hover:text-orange-soft">Исходники</a> · {t(lang, 'footer.unofficial')}</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
