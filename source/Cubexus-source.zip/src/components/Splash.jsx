/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import { useEffect, useState } from 'react'
import { t } from '../i18n'

function bootLang() {
  try {
    return JSON.parse(localStorage.getItem('cubexus.v1') || localStorage.getItem('cubenix.v1') || '{}').lang || 'ru'
  } catch { return 'ru' }
}

export default function Splash() {
  const [on, setOn] = useState(() => {
    try { return sessionStorage.getItem('cx.splash') !== '1' } catch { return true }
  })
  const [out, setOut] = useState(false)
  const [pct, setPct] = useState(8)
  const [line, setLine] = useState('Cubexus')

  useEffect(() => {
    if (!on) return
    const lang = bootLang()
    const lines = ['Cubexus', t(lang, 'ui.splash1'), t(lang, 'ui.splash2'), t(lang, 'ui.splash3')]
    let i = 0
    const t1 = setInterval(() => {
      i += 1
      setPct((p) => Math.min(100, p + 18 + Math.random() * 14))
      if (lines[i]) setLine(lines[i])
    }, 380)
    const t2 = setTimeout(() => {
      setPct(100)
      setOut(true)
      try { sessionStorage.setItem('cx.splash', '1') } catch {}
      setTimeout(() => setOn(false), 520)
    }, 1680)
    return () => { clearInterval(t1); clearTimeout(t2) }
  }, [on])

  if (!on) return null
  return (
    <div className={'cx-splash' + (out ? ' out' : '')} aria-hidden="true">
      <div className="cx-splash-card">
        <img src="/logo.png?v=6" alt="" className="cx-splash-logo" width="88" height="88" />
        <div className="cx-splash-name">Cubexus</div>
        <div className="cx-splash-line">{line}</div>
        <div className="cx-splash-bar"><i style={{ width: pct + '%' }} /></div>
      </div>
    </div>
  )
}
