/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Icon } from './SearchBox'
import { isSkin, skin3d } from '../skin'
import { useStore } from '../store'
import { catName, t } from '../i18n'
import Translated from './Translated'
import { plainPreview } from '../text'
import VerifyBadge from './VerifyBadge'
import { verifyLevel } from '../stats'
import { getVersions } from '../api'
import { formatNumber } from '../languages'

const TYPE_ID = {
  mod: 'mods', addon: 'addons', library: 'library', optimization: 'optimization',
  modpack: 'modpacks', resourcepack: 'resourcepacks', shader: 'shaders', datapack: 'datapacks',
  plugin: 'plugins', map: 'maps', schematic: 'schematics', skin: 'skins', core: 'cores',
  bedrock: 'bedrock', world: 'worlds', emote: 'emotes', cosmetic: 'cosmetics', texture: 'textures', model: 'models',
  config: 'configs',
}

export default function ProjectCard({ p, compact }) {
  const { lang } = useStore()
  if (!p) return null
  const desc = plainPreview(p.description || p.body || '', 280)
  const srcs = (p.sources || []).map((s) => (typeof s === 'string' ? s : s.id || s.platform)).filter(Boolean).slice(0, 3)
  const type = catName(lang, TYPE_ID[p.project_type] || p.project_type, p.project_type)
  const level = verifyLevel({ downloads: p.downloads, likes: p.follows || p.likes || 0 })
  const cats = (p.categories || []).filter((c) => !['forge', 'fabric', 'quilt', 'neoforge', 'bukkit', 'paper', 'spigot', 'folia', 'purpur', 'sponge'].includes(String(c).toLowerCase())).slice(0, 3)
  const loaders = (p.loaders || p.categories || []).filter((c) => ['forge', 'fabric', 'quilt', 'neoforge', 'paper', 'spigot'].includes(String(c).toLowerCase())).slice(0, 3)
  const games = (p.versions || p.game_versions || []).filter((v) => /^\d/.test(String(v))).slice(-3).reverse()
  const updated = p.date_modified || p.updated || p.date_published || ''
  const icon = compact ? 'icon w-8 h-8 rounded-lg' : 'icon w-[72px] h-[72px] rounded-2xl'
  const CardLink = p.external ? 'a' : Link
  const linkProps = p.external
    ? { href: p.url, target: '_blank', rel: 'noopener noreferrer' }
    : { to: '/project/' + p.slug }
  return (
    <CardLink {...linkProps} className={`cx-card ${compact ? 'compact' : ''}`}>
      <div className="icon-wrap shrink-0">
        <Icon src={p.icon_url} letter={p.title} className={`${icon}${p.icon_url ? ' icon-glow' : ''}`} />
        {level ? <span className="verify-br"><VerifyBadge level={level} /></span> : null}
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2 min-w-0">
          <h3 className={`font-semibold leading-tight truncate ${compact ? 'text-[14px]' : 'text-[17px]'}`}>
            {p.title}
          </h3>
        </div>
        {!compact && p.addon_of_title ? <p className="text-[11px] text-orange-soft mt-1">{t(lang, 'ui.addonOf')} {p.addon_of_title}</p> : null}
        {!compact ? <Translated className="text-[13px] text-white/50 mt-1 leading-5 line-clamp-2 block" text={desc} /> : null}
        {!compact ? (
          <div className="flex flex-wrap items-center gap-1.5 mt-2">
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-orange/10 text-orange-soft">{type}</span>
            {srcs.map((s) => (
              <span key={s} className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-white/45">{s}</span>
            ))}
            {p.author ? <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-white/45">{p.author}</span> : null}
            {loaders.map((c) => (
              <span key={c} className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-white/45 font-mono">{c}</span>
            ))}
            {cats.map((c) => (
              <span key={c} className="text-[10px] px-2 py-0.5 rounded-full bg-white/5 text-white/40">{c}</span>
            ))}
            {games.map((v) => <span key={v} className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-400/5 text-emerald-200/55 font-mono">MC {v}</span>)}
            {updated ? <span className="text-[10px] text-white/30" title={String(updated)}>{new Date(updated).getFullYear() || ''}</span> : null}
            {p.downloads > 0 ? <span className="ml-auto font-mono text-[11px] text-white/35">{formatNumber(p.downloads, lang)}</span> : null}
            {!p.external ? <CardDownload slug={p.slug} title={p.title} lang={lang} /> : null}
          </div>
        ) : null}
      </div>
    </CardLink>
  )
}

function CardDownload({ slug, title, lang }) {
  const [href, setHref] = useState('')
  const warm = () => {
    if (href || !slug) return
    getVersions(slug).then((vs) => {
      const files = (vs && vs[0] && vs[0].files) || []
      const f = files.find((x) => x && x.primary) || files[0]
      if (!f?.url) return
      const name = String(f.filename || title || 'mod.jar').replace(/[^\w.+\-]+/g, '_').slice(0, 120)
      setHref('/api/file?url=' + encodeURIComponent(f.url) + '&name=' + encodeURIComponent(name))
    }).catch(() => {})
  }
  if (href) {
    return (
      <a className="card-dl" href={href} onClick={(e) => e.stopPropagation()} onMouseDown={(e) => e.stopPropagation()}>
        {t(lang, 'project.download')}
      </a>
    )
  }
  return (
    <button
      type="button"
      className="card-dl"
      onMouseEnter={warm}
      onFocus={warm}
      onMouseDown={(e) => { e.preventDefault(); e.stopPropagation() }}
      onClick={(e) => { e.preventDefault(); e.stopPropagation(); window.location.assign('/project/' + encodeURIComponent(slug) + '#dl') }}
    >
      {t(lang, 'project.download')}
    </button>
  )
}

export function CardSkeleton() {
  return (
    <div className="cx-card pointer-events-none">
      <div className="skel w-[72px] h-[72px] rounded-2xl shrink-0" />
      <div className="flex-1 space-y-2">
        <div className="skel h-5 w-2/3" />
        <div className="skel h-3 w-full" />
        <div className="skel h-3 w-1/2" />
      </div>
    </div>
  )
}
