/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
import { Component } from 'react'

export default class ErrorBoundary extends Component {
  constructor(p) {
    super(p)
    this.state = { err: null }
  }
  static getDerivedStateFromError(err) {
    return { err }
  }
  componentDidUpdate(prev) {
    if (prev.resetKey !== this.props.resetKey && this.state.err) {
      this.setState({ err: null })
    }
  }
  render() {
    if (!this.state.err) return this.props.children
    return (
      <div className="relative z-10 max-w-xl mx-auto mt-16 glass p-8">
        <h2 className="font-outfit text-2xl">{t(bootLang(), 'ui.pageFail')}</h2>
        <p className="text-white/60 mt-2 text-sm font-mono">{String(this.state.err.message || this.state.err)}</p>
        <p className="text-white/40 text-xs mt-2">{t(bootLang(), 'ui.pageFailHint')}</p>
        <div className="flex gap-2 mt-4">
          <button className="btn btn-primary px-5 py-2" onClick={() => { this.setState({ err: null }); window.location.reload() }}>{t(bootLang(), 'ui.retry')}</button>
          <button className="btn btn-ghost px-5 py-2" onClick={() => { window.location.href = '/builds' }}>{t(bootLang(), 'nav.builds')}</button>
          <button className="btn btn-ghost px-5 py-2" onClick={() => { window.location.href = '/' }}>{t(bootLang(), 'ui.home')}</button>
        </div>
      </div>
    )
  }
}
