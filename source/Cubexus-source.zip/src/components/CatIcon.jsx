/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
function Svg({ children, className = '' }) {
  return (
    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" className={className} aria-hidden stroke="currentColor" strokeLinecap="round" strokeLinejoin="round">
      {children}
    </svg>
  )
}

const ICONS = {
  mods: <path d="M11 27 V15 L20 10 L29 15 V27 L20 32 Z M11 15 L20 20 L29 15 M20 20 V32" strokeWidth="2.2" />,
  addons: <path d="M9 18 h9 v13 H9 Z M22 9 h9 v22 h-9 Z M13 18 V11 h8" strokeWidth="2.2" />,
  library: <path d="M9 8 h6 v24 H9 Z M17 11 h6 v21 h-6 Z M25 14 h6 v18 h-6 Z" strokeWidth="2.2" />,
  optimization: <path d="M8 27 L16 14 L22 22 L32 9 M32 9 h-7 M32 9 v7" strokeWidth="2.2" />,
  resourcepacks: <path d="M8 10 h24 v20 H8 Z M8 16 h24 M14 16 v14 M14 22 h18" strokeWidth="2.2" />,
  datapacks: <path d="M13 8 h9 l7 7 v17 H13 Z M22 8 v7 h7 M17 21 h8 M17 26 h6" strokeWidth="2.2" />,
  shaders: <><circle cx="20" cy="20" r="7" strokeWidth="2.2" /><path d="M20 6 v5 M20 29 v5 M6 20 h5 M29 20 h5 M10 10 l3.5 3.5 M26.5 26.5 L30 30 M30 10 l-3.5 3.5 M13.5 26.5 L10 30" strokeWidth="2" /></>,
  textures: <path d="M8 10 h10 v10 H8 Z M22 10 h10 v10 H22 Z M8 22 h10 v10 H8 Z M22 22 h10 v10 H22 Z" strokeWidth="2" />,
  emotes: <><circle cx="20" cy="20" r="11" strokeWidth="2.2" /><path d="M14 17 h3 M23 17 h3 M14 25 c3 3.5 9 3.5 12 0" strokeWidth="2.2" /></>,
  cosmetics: <><path d="M13 8 h14 l4 8 -4 16 H13 L9 16 Z" strokeWidth="2.2" /><path d="M14 9 c1 6 11 6 12 0 M12 18 h16" strokeWidth="2" /></>,
  models: <path d="M20 7 L32 14 V27 L20 34 L8 27 V14 Z M8 14 L20 21 L32 14 M20 21 V34" strokeWidth="2.2" />,
  configs: <><circle cx="20" cy="20" r="6" strokeWidth="2.2" /><path d="M20 8 v4 M20 28 v4 M8 20 h4 M28 20 h4 M11 11 l3 3 M26 26 l3 3 M29 11 l-3 3 M14 26 l-3 3" strokeWidth="2" /></>,
  modpacks: <path d="M8 16 L20 9 L32 16 V30 L20 36 L8 30 Z M8 16 L20 22 L32 16 M20 22 V36" strokeWidth="2.2" />,
  plugins: <path d="M12 10 h16 v20 H12 Z M17 10 V6 M23 10 V6 M16 20 h8 M16 25 h5" strokeWidth="2.2" />,
  cores: <><rect x="9" y="8" width="22" height="24" rx="3" strokeWidth="2.2" /><path d="M14 14 h4 M14 19 h12 M14 24 h8" strokeWidth="2" /></>,
  bedrock: <path d="M8 14 L20 8 L32 14 V26 L20 32 L8 26 Z M8 14 L20 20 L32 14 M20 20 V32" strokeWidth="2.2" />,
  servers: <><rect x="8" y="9" width="24" height="8" rx="2" strokeWidth="2.2" /><rect x="8" y="21" width="24" height="8" rx="2" strokeWidth="2.2" /><circle cx="13" cy="13" r="1.4" fill="currentColor" stroke="none" /><circle cx="13" cy="25" r="1.4" fill="currentColor" stroke="none" /></>,
  maps: <path d="M8 12 L16 9 L24 13 L32 10 V28 L24 31 L16 27 L8 30 Z M16 9 V27 M24 13 V31" strokeWidth="2.2" />,
  worlds: <><circle cx="20" cy="20" r="11" strokeWidth="2.2" /><path d="M9 20 h22 M20 9 c4 4 4 18 0 22 M20 9 c-4 4-4 18 0 22" strokeWidth="1.8" /></>,
  schematics: <path d="M8 29 L20 8 L32 29 Z M14 29 V22 H26 V29 M20 8 V16" strokeWidth="2.2" />,
  builds: <path d="M20 7 L24 15 H32 L26 21 L28 30 L20 25 L12 30 L14 21 L8 15 H16 Z" strokeWidth="2.2" />,
  skins: <><rect x="14" y="7" width="12" height="12" rx="2" strokeWidth="2.2" /><path d="M12 32 V21 h16 v11 M16 21 v5 M24 21 v5" strokeWidth="2.2" /></>,
  guides: <path d="M10 8 h20 v24 H10 Z M16 14 h8 M16 20 h8 M16 26 h5" strokeWidth="2.2" />,
  blocks: <path d="M20 8 L32 15 V29 L20 36 L8 29 V15 Z M8 15 L20 22 L32 15 M20 22 V36" strokeWidth="2.2" />,
  recipes: <path d="M9 18 h22 v14 H9 Z M14 18 V12 H26 V18 M16 25 h8" strokeWidth="2.2" />,
  commands: <path d="M6 10 h28 v20 H6 Z M12 17 l4 3 -4 3 M18 23 h8" strokeWidth="2.2" />,
  dev: <path d="M14 12 L8 20 L14 28 M26 12 L32 20 L26 28 M22 10 L18 30" strokeWidth="2.2" />,
}

export default function CatIcon({ id, className = '' }) {
  return <Svg className={className}>{ICONS[id] || ICONS.mods}</Svg>
}
