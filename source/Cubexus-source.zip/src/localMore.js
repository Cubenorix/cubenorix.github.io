/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
const cover = Object.freeze({ default: '/no-icon.png' })

function item(type, x) {
  return {
    project_type: type,
    icon_url: x.icon_url || cover[type] || cover.default,
    downloads: x.downloads || 0,
    sources: x.sources || ['pmc'],
    ...x,
  }
}

export const MORE = {
  map: [
    item('map', { slug: 'parkour-city-neon', title: 'Parkour City Neon', author: 'DashMaps', description: 'Паркур по неоновому городу, 40 чекпоинтов.', url: 'https://www.planetminecraft.com/', sources: ['pmc'] }),
    item('map', { slug: 'rpg-village-start', title: 'RPG Village Start', author: 'QuestForge', description: 'Стартовая деревня для RPG: NPC, квесты, данж под храмом.', url: 'https://www.planetminecraft.com/', sources: ['pmc', 'inside'] }),
    item('map', { slug: 'airship-spawn', title: 'Airship Spawn', author: 'SkyDock', description: 'Спавн на дирижабле, якоря-порталы вниз.', url: 'https://www.minecraftmaps.com/', sources: ['mcmaps', 'pmc'] }),
    item('map', { slug: 'redstone-museum', title: 'Redstone Museum', author: 'Circuit', description: 'Музей механизмов 1.21: двери, лифты, фермы.', url: 'https://www.planetminecraft.com/', sources: ['pmc'] }),
    item('map', { slug: 'ocean-monument-raid', title: 'Ocean Monument Raid', author: 'Tide', description: 'Рейд монумента с кастомным лутом.', url: 'https://minecraft-inside.ru/', sources: ['inside'] }),
    item('map', { slug: 'snow-kingdom', title: 'Snow Kingdom', author: 'FrostLab', description: 'Снежное королевство, замок и деревня.', url: 'https://www.planetminecraft.com/', sources: ['pmc', 'tenmc'] }),
    item('map', { slug: 'subway-spawn', title: 'Subway Spawn', author: 'MetroBuild', description: 'Спавн в метро, ветки на мини-игры.', url: 'https://www.planetminecraft.com/', sources: ['pmc'] }),
    item('map', { slug: 'treehouse-network', title: 'Treehouse Network', author: 'Canopy', description: 'Сеть домов на деревьях, мосты и лифты.', url: 'https://www.planetminecraft.com/', sources: ['pmc'] }),
    item('map', { slug: 'desert-temple-plus', title: 'Desert Temple Plus', author: 'SandArch', description: 'Расширенный храм: ловушки, босс, секретные залы.', url: 'https://10minecraft.ru/', sources: ['tenmc', 'inside'] }),
    item('map', { slug: 'mini-games-lobby', title: 'Mini-games Lobby', author: 'Arcade', description: 'Лобби на 8 мини-игр, NPC и голограммы.', url: 'https://www.planetminecraft.com/', sources: ['pmc', 'minebbs'] }),
    item('map', { slug: 'steampunk-port', title: 'Steampunk Port', author: 'Brass', description: 'Порт в стиле стимпанк, краны и дирижабли.', url: 'https://www.planetminecraft.com/', sources: ['pmc'] }),
    item('map', { slug: 'nether-spawn-bridge', title: 'Nether Spawn Bridge', author: 'Fastway', description: 'Спавн-мост в Незере, 4 дороги изо льда.', url: 'https://www.planetminecraft.com/', sources: ['pmc'] }),
    item('map', { slug: 'fantasy-spawn-oaks', title: 'Fantasy Oaks Spawn', author: 'Leaf', description: 'Фэнтези-спавн среди дубов, эльфы и порталы.', url: 'https://www.planetminecraft.com/', sources: ['pmc', 'bbsmc'] }),
    item('map', { slug: 'prison-spawn-v4', title: 'Prison Spawn v4', author: 'BarCraft', description: 'Спавн тюрьмы: шахты, магазин, престиж.', url: 'https://www.planetminecraft.com/', sources: ['pmc'] }),
    item('map', { slug: 'skywars-12isles', title: 'SkyWars 12 Isles', author: 'MiniGamesLab', description: '12 островов SkyWars, центр с сундуком.', url: 'https://www.planetminecraft.com/', sources: ['pmc'] }),
  ],
  schematic: [
    item('schematic', { slug: 'auto-brewer-1-21', title: 'Auto Brewer 1.21', author: 'RedstonePro', description: 'Автоварка зелий, схема WorldEdit.', url: 'https://www.planetminecraft.com/', sources: ['pmc'] }),
    item('schematic', { slug: 'iron-farm-compact', title: 'Iron Farm Compact', author: 'Shulker', description: 'Компактная ферма железа 1.21.', url: 'https://github.com/', sources: ['github', 'pmc'] }),
    item('schematic', { slug: 'create-steam-engine', title: 'Create Steam Engine', author: 'Cogsmith', description: 'Паровой двигатель Create, .schem.', url: 'https://createmod.com/ru/', sources: ['create'] }),
    item('schematic', { slug: 'create-encased-fan-tunnel', title: 'Create Fan Tunnel', author: 'Cogsmith', description: 'Туннель с вентиляторами Create.', url: 'https://createmod.com/ru/', sources: ['create', 'pmc'] }),
    item('schematic', { slug: 'sugarcane-farm-tile', title: 'Sugarcane Farm Tile', author: 'FarmGrid', description: 'Модуль фермы тростника 9×9.', url: 'https://www.planetminecraft.com/', sources: ['pmc'] }),
    item('schematic', { slug: 'guardian-farm-schem', title: 'Guardian Farm', author: 'Tide', description: 'Ферма стражей, схема + чертёж.', url: 'https://github.com/', sources: ['github', 'pmc'] }),
    item('schematic', { slug: 'litematica-castle-gate', title: 'Castle Gate', author: 'KeepMaps', description: 'Ворота замка .litematic.', url: 'https://www.planetminecraft.com/', sources: ['pmc'] }),
    item('schematic', { slug: 'modern-interior-kit', title: 'Modern Interior Kit', author: 'CubeCAD', description: 'Набор комнат: кухня, зал, спальня.', url: 'https://www.planetminecraft.com/', sources: ['pmc', 'inside'] }),
    item('schematic', { slug: 'xp-mob-dropper', title: 'XP Mob Dropper', author: 'RedstonePro', description: 'Дропер мобов на опыт, 1.21.', url: 'https://www.planetminecraft.com/', sources: ['pmc'] }),
    item('schematic', { slug: 'create-train-loop', title: 'Create Train Loop', author: 'Railman', description: 'Кольцо поездов Create с станциями.', url: 'https://createmod.com/ru/', sources: ['create'] }),
    item('schematic', { slug: 'bamboo-farm-auto', title: 'Bamboo Auto Farm', author: 'FarmGrid', description: 'Автоферма бамбука.', url: 'https://www.planetminecraft.com/', sources: ['pmc'] }),
    item('schematic', { slug: 'enderman-farm-1-21', title: 'Enderman Farm 1.21', author: 'VoidArch', description: 'Ферма эндерменов на платформе Энда.', url: 'https://github.com/', sources: ['github', 'pmc'] }),
    item('schematic', { slug: 'create-factory-m', title: 'Фабрика', author: 'Animavesta', description: 'Схема фабрики Create с createmod.com.', url: 'https://createmod.com/ru/schematics/factory-m', sources: ['create'] }),
    item('schematic', { slug: 'create-brick-factory', title: 'Кирпичный завод', author: 'Schmuck', description: 'Кирпичный завод Create.', url: 'https://createmod.com/ru/schematics/brick-factory-j', sources: ['create'] }),
    item('schematic', { slug: 'create-factory-building', title: 'Здание завода', author: 'Ringsaturn2000', description: 'Корпус завода Create.', url: 'https://createmod.com/ru/schematics/factory-building-create', sources: ['create'] }),
    item('schematic', { slug: 'create-mass-dye', title: 'Завод массовой окраски', author: 'Alpen_glow', description: 'Окраска Create.', url: 'https://createmod.com/ru/schematics/mass-dyeing-factory', sources: ['create'] }),
    item('schematic', { slug: 'create-engine-plant', title: 'Завод сборки двигателей', author: 'CreateLab', description: 'Сборка двигателей Create.', url: 'https://createmod.com/ru/', sources: ['create'] }),
    item('schematic', { slug: 'create-brass-tunnel', title: 'Латунный туннель', author: 'Cogsmith', description: 'Туннель Create, .nbt/.schem.', url: 'https://createmod.com/ru/', sources: ['create'] }),
    item('schematic', { slug: 'create-crushing-line', title: 'Линия дробления', author: 'Cogsmith', description: 'Дробилки Create в ряд.', url: 'https://createmod.com/ru/', sources: ['create'] }),
    item('schematic', { slug: 'create-depot-hub', title: 'Хаб депо', author: 'Railman', description: 'Депо поездов Create.', url: 'https://createmod.com/ru/', sources: ['create'] }),
    item('schematic', { slug: 'create-windmill-farm', title: 'Ферма ветряков', author: 'Cogsmith', description: 'Поле ветряков Create.', url: 'https://createmod.com/ru/', sources: ['create'] }),
    item('schematic', { slug: 'create-vault-bank', title: 'Банк хранилищ', author: 'Shulker', description: 'Стена Item Vault Create.', url: 'https://createmod.com/ru/', sources: ['create'] }),
  ],
  emote: [
    item('emote', { slug: 'emotecraft-official', title: 'Emotecraft — официальный проект', author: 'KosmX', description: 'Клиент Fabric/Forge/NeoForge и серверный плагин. Клавиша B открывает колесо; свои файлы .emote — в .minecraft/emotes.', url: 'https://modrinth.com/plugin/emotecraft', sources: ['emotecraft', 'modrinth'] }),
    item('emote', { slug: 'emotecraft-github', title: 'Emotecraft — исходники и релизы', author: 'KosmX', description: 'Официальный репозиторий движка анимаций, документация и проверяемые релизы.', url: 'https://github.com/KosmX/emotes', sources: ['emotecraft-github', 'github'] }),
    item('emote', { slug: 'emotecraft-paper', title: 'Emotecraft для Paper / Folia', author: 'dima_dencep', description: 'Серверная часть Emotecraft на официальном Hangar PaperMC.', url: 'https://hangar.papermc.io/dima_dencep/emotecraft', sources: ['emotecraft', 'hangar'] }),
    item('emote', { slug: 'emotecraft-inside', title: 'Emotecraft на Minecraft Inside', author: 'KosmX', description: 'Русская страница с версиями и инструкцией. Для безопасности Cubexus рекомендует сверять файл с официальными Modrinth/GitHub.', url: 'https://minecraft-inside.ru/mods/150286-emotecraft.html', sources: ['inside', 'emotecraft'] }),
    item('emote', { slug: 'emotecraft-custom-folder', title: 'Пользовательские .emote-анимации', author: 'Emotecraft', description: 'Открой настройки → Open emotes folder или помести авторские .emote в .minecraft/emotes. Ищи пакеты в каталоге ниже.', url: 'https://docs.zigythebird.com/emotecraft/gettingstarted/installing/', sources: ['emotecraft'] }),
    item('emote', { slug: 'minecraftcapes-emotes', title: 'MinecraftCapes: плащи и эмоции', author: 'MinecraftCapes', description: 'Косметический источник с бесплатными плащами; работает через отдельный клиентский мод.', url: 'https://minecraftcapes.net/', sources: ['minecraftcapes'] }),
    item('emote', { slug: 'essential-emotes', title: 'Essential: эмоции и косметика', author: 'Essential', description: 'Внешний каталог эмоций Essential. Учётная запись и покупки остаются у источника.', url: 'https://essential.gg/cosmetics', sources: ['essential'] }),
    item('emote', { slug: 'bedrock-emotes-hub', title: 'Bedrock Emotes', author: 'MCPEDL', description: 'Эмоции и анимационные наборы Bedrock на MCPEDL.', url: 'https://mcpedl.com/', sources: ['mcpedl'] }),
  ],
  cosmetic: [
    item('cosmetic', { slug: 'minecraftcapes', title: 'MinecraftCapes', author: 'MinecraftCapes', description: 'Бесплатные пользовательские плащи и уши; видны игрокам с клиентским модом.', url: 'https://minecraftcapes.net/', sources: ['minecraftcapes'] }),
    item('cosmetic', { slug: 'cosmetica', title: 'Cosmetica', author: 'eyezah', description: 'Бесплатные плащи, элайтры, аксессуары, анимированные текстуры и каталог предпросмотра.', url: 'https://modrinth.com/mod/cosmetica', sources: ['cosmetica', 'modrinth'] }),
    item('cosmetic', { slug: 'labymod-cosmetics', title: 'LabyMod Cosmetics', author: 'LabyMod', description: 'Каталог косметики клиента LabyMod; покупки выполняются только на стороне источника.', url: 'https://www.labymod.net/page/cosmetics', sources: ['labymod'] }),
    item('cosmetic', { slug: 'essential-cosmetics', title: 'Essential Cosmetics', author: 'Essential', description: 'Косметика и эмоции клиента Essential; аккаунт и покупки остаются у источника.', url: 'https://essential.gg/cosmetics', sources: ['essential'] }),
    item('cosmetic', { slug: 'mineskin-tool', title: 'MineSkin', author: 'MineSkin', description: 'Генератор подписанных данных текстуры и инструмент работы со скинами.', url: 'https://mineskin.org/', sources: ['mineskin'] }),
  ],
  model: [
    item('model', { slug: 'free-chair-oak', title: 'Oak Chair', author: 'PropKit', description: 'Бесплатная модель стула, Blockbench.', url: 'https://www.planetminecraft.com/', sources: ['pmc'], free: true, safe: true }),
    item('model', { slug: 'free-lamp-modern', title: 'Modern Lamp', author: 'PropKit', description: 'Лампа, JSON-модель, без малвари.', url: 'https://www.planetminecraft.com/', sources: ['pmc'], free: true, safe: true }),
    item('model', { slug: 'free-crate', title: 'Wood Crate', author: 'PropKit', description: 'Ящик 16³, бесплатно.', url: 'https://www.planetminecraft.com/', sources: ['pmc'], free: true, safe: true }),
    item('model', { slug: 'bb-lantern', title: 'Lantern Prop', author: 'Blockbench', description: 'Фонарь, JSON, Blockbench.', url: 'https://www.blockbench.net/', sources: ['blockbench', 'pmc'], free: true, safe: true }),
    item('model', { slug: 'bb-sword-stand', title: 'Sword Stand', author: 'PropKit', description: 'Стойка для меча, бесплатно.', url: 'https://www.planetminecraft.com/', sources: ['pmc', 'blockbench'], free: true, safe: true }),
  ],
  config: [
    item('config', { slug: 'paper-survival', title: 'Paper Survival', author: 'Admincraft', description: 'paper-global.yml под выживание.', url: 'https://papermc.io/', sources: ['hangar'] }),
    item('config', { slug: 'purpur-anarchy', title: 'Purpur Anarchy', author: 'Admincraft', description: 'Настройки Purpur под анархию.', url: 'https://purpurmc.org/', sources: ['hangar'] }),
  ],
  extra: [
    item('mod', { slug: 'optifine', title: 'OptiFine HD', author: 'sp614x', description: 'Оптимизация клиента, HD-текстуры, шейдеры. На Modrinth нет — официально optifine.net, зеркала Minecraft Inside / 10Minecraft.', url: 'https://optifine.net/downloads', sources: ['inside', 'tenmc', 'github'], downloads: 0 }),
    item('mod', { slug: 'shine-vfx', title: 'Shine: VFX', author: 'catadmirer', description: 'Пользовательский плагин визуальных эффектов. CurseForge shine-vfx — на Modrinth снят.', url: 'https://www.curseforge.com/minecraft/mc-mods/shine-vfx', sources: ['curseforge'], downloads: 0, icon_url: '/sources/curseforge.svg' }),
  ],
}

export function allLocal(LOCAL_CONTENT) {
  const out = { ...LOCAL_CONTENT }
  for (const [k, arr] of Object.entries(MORE)) {
    if (k === 'extra') continue
    out[k] = [...(out[k] || []), ...arr]
  }
  out.mod = [...(out.mod || []), ...MORE.extra]
  for (const list of Object.values(out)) {
    for (const x of list) {
      if (!x.icon_url) x.icon_url = cover[x.project_type] || cover.default
      if (!x.project_type) x.project_type = 'map'
    }
  }
  return out
}

export function searchLocalAll(LOCAL, q, type) {
  const query = String(q || '').toLowerCase()
  const bags = []
  if (type && type !== 'all' && LOCAL[type]) bags.push(...LOCAL[type])
  else {
    for (const arr of Object.values(LOCAL)) bags.push(...arr)
    bags.push(...MORE.extra)
  }
  if (type === 'mod' || type === 'all' || !type) bags.push(...MORE.extra)
  let list = bags
  if (query) {
    list = bags.filter((x) => (x.title + ' ' + (x.description || '') + ' ' + (x.author || '') + ' ' + (x.slug || '')).toLowerCase().includes(query))
  }
  const seen = new Set()
  return list.filter((x) => {
    if (seen.has(x.slug)) return false
    seen.add(x.slug)
    return true
  })
}
