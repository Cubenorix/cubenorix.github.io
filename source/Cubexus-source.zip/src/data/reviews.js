/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
export const SITE_REVIEWS = []

export const CREATOR = {
  nick: 'BLAGUK_qwe8',
  name: 'ВладикМайн',
  brand: '®VLAGUK_qwe8',
  server: 'mc.7cubes.ru:25565',
}
