/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * Локальный кеш метаданных проектов в Cloudflare D1 (задачи 7 и 9).
 *
 * Зачем: меньше запросов к API источников, живые данные даже когда источник
 * недоступен (last-good), основа для суточного инкрементального обновления
 * по полю updated_at.
 *
 * Модуль безопасен по умолчанию: если база не привязана (env.DB == null)
 * или произошла ошибка — вызовы возвращают нейтральный результат, и сайт
 * продолжает работать как раньше, только через живые API.
 *
 * Таблицы создаёт миграция migrations/0002_metadata_cache.sql.
 */

const SCHEMA_OK = new WeakSet() // env.DB, для которых миграция уже проверена
const MAX_BATCH = 200

function norm(hit) {
  if (!hit?.slug) return null
  return {
    slug: String(hit.slug).slice(0, 120),
    source: (hit.sources && hit.sources[0]) || String(hit.sources || '') || 'unknown',
    title: String(hit.title || '').slice(0, 300),
    author: String(hit.author || '').slice(0, 200),
    description: String(hit.description || hit.body || '').slice(0, 2000),
    icon_url: String(hit.icon_url || '').slice(0, 600),
    url: String(hit.url || '').slice(0, 600),
    project_type: String(hit.project_type || '').slice(0, 40),
    downloads: Number(hit.downloads) || 0,
    likes: Number(hit.likes || hit.follows) || 0,
    versions: JSON.stringify(hit.versions || []).slice(0, 4000),
    source_updated_at: hit.updated_at ? String(hit.updated_at).slice(0, 40) : null,
  }
}

function rowToHit(row) {
  let versions = []
  try { versions = JSON.parse(row.versions || '[]') } catch {}
  return {
    slug: row.slug,
    title: row.title,
    author: row.author || '',
    description: row.description || '',
    body: row.description || '',
    icon_url: row.icon_url || '',
    url: row.url || '',
    sources: [row.source],
    project_type: row.project_type || '',
    downloads: row.downloads || 0,
    likes: row.likes || 0,
    follows: row.likes || 0,
    versions,
    updated_at: row.source_updated_at || null,
    external: true,
    fromCache: true,
    cachedAt: row.fetched_at,
  }
}

async function ensureSchema(db) {
  if (!db || SCHEMA_OK.has(db)) return true
  try {
    await db.prepare('SELECT slug FROM project_meta LIMIT 1').first()
    SCHEMA_OK.add(db)
    return true
  } catch {
    return false
  }
}

/** Сохранить пачку хитов поиска (write-through, не блокирует ответ при ошибке). */
export async function metaPutMany(db, hits) {
  if (!db || !Array.isArray(hits) || !hits.length) return 0
  if (!(await ensureSchema(db))) return 0
  const rows = hits.map(norm).filter(Boolean).slice(0, MAX_BATCH)
  if (!rows.length) return 0
  try {
    const stmt = db.prepare(
      `INSERT INTO project_meta
        (slug, source, title, author, description, icon_url, url, project_type, downloads, likes, versions, source_updated_at, fetched_at)
       VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13)
       ON CONFLICT(slug) DO UPDATE SET
        source = excluded.source,
        title = excluded.title,
        author = excluded.author,
        description = excluded.description,
        icon_url = excluded.icon_url,
        url = excluded.url,
        project_type = excluded.project_type,
        downloads = excluded.downloads,
        likes = excluded.likes,
        versions = excluded.versions,
        source_updated_at = excluded.source_updated_at,
        fetched_at = excluded.fetched_at`,
    )
    const now = new Date().toISOString()
    const batch = rows.map((r) => stmt.bind(r.slug, r.source, r.title, r.author, r.description, r.icon_url, r.url, r.project_type, r.downloads, r.likes, r.versions, r.source_updated_at, now))
    await db.batch(batch)
    return rows.length
  } catch {
    return 0
  }
}

/** Метаданные одного проекта по slug. */
export async function metaGet(db, slug) {
  if (!db || !slug) return null
  if (!(await ensureSchema(db))) return null
  try {
    const row = await db.prepare('SELECT * FROM project_meta WHERE slug = ?1 LIMIT 1').bind(String(slug).slice(0, 120)).first()
    return row ? rowToHit(row) : null
  } catch {
    return null
  }
}

/** Last-good выдача поиска из кеша, когда живой источник недоступен. */
export async function metaSearch(db, query, type = 'all', limit = 24) {
  if (!db) return []
  if (!(await ensureSchema(db))) return []
  const q = String(query || '').trim()
  if (q.length < 2) return []
  try {
    const like = '%' + q.toLowerCase().replace(/[%_]/g, '') + '%'
    const bind = [like, Math.min(100, Math.max(1, Number(limit) || 24))]
    let sql = 'SELECT * FROM project_meta WHERE (LOWER(title) LIKE ?1 OR LOWER(description) LIKE ?1 OR LOWER(slug) LIKE ?1)'
    if (type && type !== 'all') {
      sql += ' AND (project_type = ?3 OR ?3 = "appearance" AND project_type IN ("skin","emote","cosmetic","model"))'
      bind.push(String(type).slice(0, 40))
    }
    sql += ' ORDER BY downloads DESC LIMIT ?2'
    const { results } = await db.prepare(sql).bind(...bind).all()
    return (results || []).map(rowToHit)
  } catch {
    return []
  }
}

/**
 * Инкрементальное обновление (задача 9): выбирает записи с устаревшим
 * fetched_at и возвращает список slug для освежения живым запросом.
 * Вызывается из /api/maintenance (внешний cron раз в сутки).
 */
export async function metaStaleSlugs(db, { olderThanHours = 24, limit = 100 } = {}) {
  if (!db) return []
  if (!(await ensureSchema(db))) return []
  const cutoff = new Date(Date.now() - olderThanHours * 3600_000).toISOString()
  try {
    const { results } = await db
      .prepare('SELECT slug FROM project_meta WHERE fetched_at < ?1 ORDER BY fetched_at ASC LIMIT ?2')
      .bind(cutoff, Math.min(200, Math.max(1, Number(limit) || 100)))
      .all()
    return (results || []).map((r) => r.slug)
  } catch {
    return []
  }
}

/** Пометить slug как обновлённый (если живой запрос вернул «не найдено»). */
export async function metaTouch(db, slug) {
  if (!db) return
  try {
    await db.prepare('UPDATE project_meta SET fetched_at = ?2 WHERE slug = ?1').bind(String(slug).slice(0, 120), new Date().toISOString()).run()
  } catch {}
}

export async function metaStats(db) {
  if (!db) return { enabled: false }
  if (!(await ensureSchema(db))) return { enabled: false, migrated: false }
  try {
    const row = await db.prepare('SELECT COUNT(*) AS n, MAX(fetched_at) AS latest FROM project_meta').first()
    return { enabled: true, records: row?.n || 0, latest: row?.latest || null }
  } catch {
    return { enabled: false }
  }
}
