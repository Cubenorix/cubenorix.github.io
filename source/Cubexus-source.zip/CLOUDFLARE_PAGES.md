# Cubexus on Cloudflare Pages

`trycloudflare.com` is only a temporary preview and has no uptime guarantee. The stable free path is an account-backed Cloudflare Pages project named **cubexus**, which requests `https://cubexus.pages.dev` (subject to availability).

For real accounts, also follow `AUTH_SETUP.md`: create the D1 database, apply `migrations/0001_auth.sql`, bind `CUBEXUS_DB` and store `AUTH_PEPPER` as a Pages secret. Until those bindings exist, `/api/auth/status` reports `configured: false` and registration stays safely disabled.

## One-time setup

1. Create/sign in to your Cloudflare account. Do not share the password with anyone.
2. From this project directory run:

   ```bash
   npm ci
   npm test
   CUBEXUS_ORIGIN=https://cubexus.pages.dev npm run build
   npx wrangler login
   npx wrangler pages project create cubexus --production-branch main
   npx wrangler pages deploy dist --project-name cubexus
   ```

3. In Cloudflare **Workers & Pages → cubexus → Deployments**, verify the production deployment.
4. If `cubexus.pages.dev` is already occupied in that account, choose another project slug in the create/deploy commands; the Cubexus product name does not change. Set `CUBEXUS_ORIGIN` to the exact HTTPS origin Cloudflare assigned before building.

`CUBEXUS_ORIGIN` rewrites canonical URLs, sitemap entries, structured data, official-site records and in-app public links in `dist/`. Do not publish a build whose canonical host points to a temporary deployment. In PowerShell, set it with `$env:CUBEXUS_ORIGIN='https://cubexus.pages.dev'` before `npm run build`.

## Google Search Console (owner action)

Google crawling, favicon display, indexing and ranking are not guaranteed. Once the account-backed Pages URL is stable:

1. Add a **URL-prefix property** for the exact production origin, for example `https://cubexus.pages.dev/`.
2. Use Google's HTML-file or HTML-tag verification method. Put the exact verification file in `public/` (or the exact meta tag in `index.html`), rebuild with the production `CUBEXUS_ORIGIN`, deploy, and then click **Verify**. Never invent a verification token.
3. Submit `https://cubexus.pages.dev/sitemap.xml` in **Sitemaps** and monitor processing errors.
4. In **URL Inspection**, test the homepage and the direct pages `/projects/create/` and `/projects/sodium/`, then request indexing if Google reports that they are eligible.
5. Keep the same hostname, favicon paths and canonical URLs. Do not create duplicate doorway pages, hidden text or keyword-stuffed copies.

The deployed root must return the genuine `/favicon.ico`, `/favicon-48.png`, `/favicon-192.png` and `/logo-512.png` files with HTTP 200. Google may still choose a different search presentation.

## What is included

- `dist/` — Vite production application.
- `functions/[[path]].js` — Pages Functions for Modrinth proxying, bounded aggregation, live statistics, locale/country hint, skin lookup, translation, safe image/file relay and health checks.
- `wrangler.toml` — Pages output and compatibility date only; it contains no account ID or secret.

The Pages Function keeps catalogue fan-out bounded at five providers and rejects arbitrary proxy hosts. User-selected language remains stored locally and overrides automatic country/browser detection.

Launcher manifests are included as public draft JSON. Large launcher/modpack/Java archives must not be placed in the Pages build: create the R2 binding `LAUNCHER_ASSETS` and follow `LAUNCHER_BACKEND.md`. Until the binding and verified objects exist, `/downloads/launcher/*`, `/downloads/modpacks/*` and `/downloads/java/*` fail closed instead of returning SPA HTML.

## Optional custom domain

After Pages is stable, add a non-`.ru` domain from **Custom domains**. The default free `pages.dev` host is sufficient now. A named Cloudflare Tunnel is an alternative only when a persistent origin server is available; Pages is simpler and more stable for this project.
