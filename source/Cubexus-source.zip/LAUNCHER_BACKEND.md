# Cubexus Launcher backend — safe draft

The launcher endpoints are prepared, but executable archives are intentionally **not fabricated or published**. The current manifests say `status: "draft"` and `enabled: false` until reviewed binaries, licenses, hashes and signatures exist.

A URL hidden from the site navigation is not a secret. Desktop launchers must be able to read update manifests, so these JSON endpoints are public by design. Never place bot tokens, Hugging Face tokens, signing private keys, Cloudflare credentials or user passwords in them.

## Public launcher API

- `/api/launcher-update.json` — installer update policy. The installer must do nothing while `enabled` is false or a download URL is null.
- `/api/mc-versions.json` — reviewed snapshot generated from Mojang's official `version_manifest_v2.json`. Each record points to Mojang metadata and includes the required Java major version when Mojang declares it.
- `/api/modpacks.json` — empty until Cubexus has an authorized, tested pack archive.
- `/api/java-runtimes.json` — empty until redistribution rights and exact hashes are reviewed.
- `/api/featured-mods.json` — public recommended Modrinth slugs.
- `/api/launcher-assets.json` — inventory contract for binary assets.

The unlinked `/launcher-lab` page is an internal status panel, not an authentication barrier.

## Why binaries do not belong in the Yapp ZIP

The anonymous Yapp upload is temporary and the current upload UI limits the whole site archive to about 5 MB. Cloudflare Pages also limits an individual static file to 25 MiB. Launcher and Java archives commonly exceed those limits. Use a private Cloudflare R2 bucket bound to Pages Functions as `LAUNCHER_ASSETS`; the prepared `/downloads/*` handler streams reviewed objects and never turns a missing ZIP into the SPA HTML page.

Example binding to add to `wrangler.toml` after the owner creates the bucket:

```toml
[[r2_buckets]]
binding = "LAUNCHER_ASSETS"
bucket_name = "cubexus-launcher-assets"
```

Owner commands:

```bash
npx wrangler r2 bucket create cubexus-launcher-assets
npx wrangler r2 object put cubexus-launcher-assets/launcher/Cubexus-win-1.0.1.zip --file ./release/Cubexus-win-1.0.1.zip
npx wrangler r2 object put cubexus-launcher-assets/modpacks/cubexus-boost-1.20.4.zip --file ./release/cubexus-boost-1.20.4.zip
```

Do not upload a Java runtime until its vendor license permits the intended redistribution and the archive source is recorded.

## Mandatory release checks

For every launcher, modpack or runtime asset:

1. Obtain it from the authorized build/vendor source.
2. Scan it and inspect archive paths; reject `..`, absolute paths, symlinks and unexpected executables.
3. Record byte size and SHA-256 in `launcher-assets.json` and the relevant manifest.
4. Sign the canonical update metadata with an offline Ed25519 private key. Embed only the public key in the launcher.
5. Make the launcher verify HTTPS, exact SHA-256, size and signature **before extraction or execution**.
6. Extract into a new temporary directory with zip-slip protection and an unpacked-size limit, then switch versions atomically.
7. Keep the previous launcher/instance version for rollback.
8. Test on a clean Windows VM and, when offered, clean macOS/Linux systems.
9. Change `enabled` to true only after every referenced URL returns the expected binary and never HTML/JSON.

Never use claims such as “200+ FPS” without a defined machine, settings and reproducible benchmark. Pack descriptions must be factual and all bundled mods/configs must permit redistribution.

## Updating Minecraft metadata

Run manually, review the diff, then rebuild:

```bash
python3 scripts/generate_mc_versions.py
```

It is intentionally not part of `npm run build`, so a normal production build cannot silently alter launcher compatibility.

## Activation order

1. Stable account-backed `cubexus.pages.dev` deployment.
2. R2 binding and tested download streaming.
3. Reviewed launcher archive and public verification key.
4. Hash/signature verification in the installer.
5. Populate the update manifest and only then set `enabled: true`.
6. Publish the launcher link on the visible site after a final smoke test.
