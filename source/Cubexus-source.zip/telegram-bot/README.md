# Cubexus Support Bot

Separate Cloudflare Worker for `@Cubenorixsupportbot`. It implements `/start`, `/help`, `/support`, `/site`, `/rules`, `/search`, `/build`, `/status`, plus explicit-consent `/ask` and `/privacy` commands.

## Security first

The bot token and Hugging Face token previously pasted into chat must be revoked. Do not reuse them. Create replacements and enter them only into Wrangler's interactive secret prompt. No token belongs in this directory, `.env`, screenshots, build output or the website.

```bash
cd telegram-bot
npm install
npx wrangler login
npx wrangler secret put TELEGRAM_BOT_TOKEN
npx wrangler secret put TELEGRAM_WEBHOOK_SECRET
npx wrangler secret put HF_TOKEN
npx wrangler deploy
```

Generate the webhook secret locally, for example:

```bash
openssl rand -hex 32
```

Paste the same value into the `TELEGRAM_WEBHOOK_SECRET` Wrangler prompt and keep it temporarily in your local password manager for the setup command. Do not send it in chat.

After deployment, configure Telegram from your own terminal:

```bash
read -rsp 'New BotFather token: ' TELEGRAM_BOT_TOKEN; echo; export TELEGRAM_BOT_TOKEN
read -rsp 'Webhook secret: ' TELEGRAM_WEBHOOK_SECRET; echo; export TELEGRAM_WEBHOOK_SECRET
export BOT_WORKER_URL='https://cubexus-support-bot.<your-subdomain>.workers.dev'
npm run setup
unset TELEGRAM_BOT_TOKEN TELEGRAM_WEBHOOK_SECRET
```

Using hidden prompts avoids placing the secrets directly in shell history.

The setup script verifies that the token belongs to `@Cubenorixsupportbot`, registers the command menu and sets a webhook protected by Telegram's secret header.

## AI support

AI is disabled by default (`AI_ENABLED = "false"`). `/ask` is the only command that sends user text to Hugging Face, and it states that disclosure before use. Other commands never send their text to Hugging Face. The Worker refuses obvious bot/HF tokens and password-shaped messages.

After reviewing Hugging Face billing/provider availability, change `AI_ENABLED` to `true`, keep `HF_TOKEN` as a Worker secret, choose `HF_MODEL`, redeploy and add a Cloudflare rate-limiting rule. The in-memory 8 requests/10 minutes limit is only a secondary safeguard and is not globally durable.

`/support` follows the selected email-only design: it does not persist tickets and directs users to `https://t.me/Cubenorixsupportbot`.

## Public origin

`PUBLIC_ORIGIN` currently points at the short-term Yapp URL. Change it to `https://cubexus.pages.dev` when the stable Pages deployment exists, then redeploy. No bot backend can run on static Yapp.
