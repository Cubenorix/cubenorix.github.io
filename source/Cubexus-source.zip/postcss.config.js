/*
 * Cubexus - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubexus Team
 * SPDX-License-Identifier: AGPL-3.0-or-later
 */
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
