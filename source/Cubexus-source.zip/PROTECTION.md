# Cubexus protection and truthful-publication policy

Version 2.0 — 2026-08-23

## Implemented

- AGPL-3.0-or-later for original program code, with the full unmodified license.
- SPDX/copyright notices in original source files.
- Separate protection of the Cubexus brand, official imported logo, trade dress and original editorial content.
- Explicit exclusion of third-party mods, files, metadata, screenshots and marks from Cubexus licensing claims.
- Public `/license/`, `/source-code.html`, corresponding-source ZIP and SHA-256.
- Official identity records linking `cubenorix.github.io` and `t.me/Cubenix`.
- Versioned Terms, Privacy, author rules and rights-complaint procedure.
- Required legal checkboxes in registration.
- Server-side Cloudflare D1 account code with password hashing, HttpOnly sessions, Origin checks, rate limits and account deletion.
- Live catalogue numbers with visible source breakdown rather than a fabricated fixed total.

## Intentionally not implemented

### Copy/right-click/text-selection blocking

JavaScript `copy` and `contextmenu` blockers and `user-select:none` do not protect source code or establish copyright. A visitor can disable JavaScript, use developer tools, fetch the HTML or take a screenshot. Those blockers also harm keyboard users, accessibility tools, quoting, bug reports and normal browser behavior.

Cubexus instead uses clear licensing, public provenance, dated evidence, official-address records and platform complaint procedures.

### “Secret text for search robots”

Hidden keyword blocks containing unverified project counts, technologies or platform claims are not used. They can mislead users and search engines and may damage indexing. Crawlable metadata and JSON-LD contain only current, supportable facts.

### False security/privacy promises

Cubexus does not claim that every file is “100% safe”, that VirusTotal checks every download, that passwords are “encrypted”, that regular audits occur, or that every complaint is resolved in 24–48 hours unless those statements become demonstrably true. Passwords are described accurately as salted server-side hashes.

### Fake authentication

Microsoft OAuth, email verification, reset mail and 2FA are not simulated. The interface labels unavailable features honestly and enables real accounts only when D1 and required secrets are configured.

## Enforcement note

AGPL allows copying and modification of covered code when its conditions are followed. It does not permit a closed modified network fork that withholds corresponding source, and it does not grant the right to impersonate the official Cubexus service. Brand/content claims and AGPL compliance should be documented separately in any platform complaint.
