# Telegram technical-support bot

Implementation: `telegram-bot/` — a separate Cloudflare Worker for `@CubexusSupportBot`.

The previously pasted Telegram and Hugging Face tokens are compromised and intentionally absent from the project. Revoke both, then follow `telegram-bot/README.md`. New secrets must be entered only through `wrangler secret put` or the owner's local environment for the one-time webhook setup.

The website links to the public bot username, but truthful backend status remains “prepared, awaiting owner deployment” until the Worker is deployed and Telegram's webhook is configured.
