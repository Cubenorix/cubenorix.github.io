/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 *
 * Единая точка исходящих запросов к внешним API (задачи 8 и 10):
 *  - всегда ставит описательный User-Agent с сайтом и контактом поддержки;
 *  - ограничивает исходящую нагрузку: максимум 250 запросов за 90 секунд
 *    (~167 в минуту — ниже лимита Modrinth 300/мин), равномерно, с очередью.
 *
 * Лимитер работает на каждое изолят воркера. На практике у Cubenorixx один-два
 * изолята, поэтому суммарная нагрузка остаётся существенно ниже лимитов
 * источников; очередь сглаживает пики, а не копит бесконечный хвост.
 */

export const USER_AGENT =
  (typeof globalThis !== 'undefined' && globalThis.CUBENORIXX_USER_AGENT) ||
  'Cubenorix/1.0 (+https://cubenorixx.romantic-buffalo.workers.dev; support: @Cubenorixsupportbot)'

const WINDOW_MS = 90_000
const MAX_PER_WINDOW = 250
const BURST = 25

const bucket = {
  timestamps: [],
  queue: [],
  draining: false,
}

function sweep(now) {
  const cutoff = now - WINDOW_MS
  const ts = bucket.timestamps
  let i = 0
  while (i < ts.length && ts[i] <= cutoff) i++
  if (i > 0) ts.splice(0, i)
}

function reserveSlot() {
  return new Promise((resolve) => {
    bucket.queue.push(resolve)
    drain()
  })
}

async function drain() {
  if (bucket.draining) return
  bucket.draining = true
  try {
    while (bucket.queue.length) {
      const now = Date.now()
      sweep(now)
      if (bucket.timestamps.length < MAX_PER_WINDOW || bucket.timestamps.length === 0) {
        // Плавный темп: не более одного «мгновенного» пика BURST, дальше — по окну.
        if (bucket.timestamps.length >= BURST) {
          const oldest = bucket.timestamps[0]
          const wait = Math.max(0, oldest + WINDOW_MS - now)
          if (wait > 0) {
            await sleep(Math.min(wait, WINDOW_MS))
            continue
          }
        }
        bucket.timestamps.push(now)
        bucket.queue.shift()(true)
      } else {
        const oldest = bucket.timestamps[0]
        const wait = Math.max(1, oldest + WINDOW_MS - now)
        await sleep(Math.min(wait, 2000))
      }
    }
  } finally {
    bucket.draining = false
  }
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms))
}

/**
 * fetch с учётом лимита и с описательным User-Agent.
 * Совместим с сигнатурой fetch(url, init); init.signal поддерживается.
 */
export async function egressFetch(url, init = {}) {
  const signal = init.signal
  if (signal?.aborted) throw new Error('aborted')
  await reserveSlot()
  if (signal?.aborted) throw new Error('aborted')
  const headers = new Headers(init.headers || {})
  if (!headers.has('user-agent')) headers.set('user-agent', USER_AGENT)
  return fetch(url, { ...init, headers })
}

/** Текущее состояние лимитера — для диагностики (/api/health). */
export function egressStats() {
  const now = Date.now()
  sweep(now)
  return {
    windowMs: WINDOW_MS,
    maxPerWindow: MAX_PER_WINDOW,
    usedInWindow: bucket.timestamps.length,
    queued: bucket.queue.length,
    userAgent: USER_AGENT,
  }
}
