/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { aggGetCached, aggSearch, homeExtra, liveIndex } from '../agg-middleware.js'
import { handleAuth } from './_auth.js'
import { egressFetch, egressStats, USER_AGENT } from '../egress.js'
import { metaPutMany, metaStaleSlugs, metaStats, metaTouch } from '../metadata-cache.js'

const ALLOWED = [
  'api.modrinth.com', 'cdn.modrinth.com', 'cdn-raw.modrinth.com', 'forgecdn.net', 'mediafilez.forgecdn.net',
  'hangarcdn.papermc.io', 'github.com', 'githubusercontent.com', 'papermc.io', 'hangar.papermc.io',
  'mcpedl.com', 'minecraft-inside.ru', 'smithed.net', 'mc-heads.net', 'crafatar.com', 'minotar.net',
  'textures.minecraft.net', 'minecraft.net', 'minecraftservices.com', 'mojang.com', 'sessionserver.mojang.com',
  'curseforge.com', 'spigotmc.org', 'polymart.org', 'poggit.pmmp.io', 'purpurmc.org', 'geysermc.org',
]

function allowed(raw) {
  try {
    const url = new URL(raw)
    if (url.protocol !== 'https:') return false
    const host = url.hostname.toLowerCase()
    return ALLOWED.some((x) => host === x || host.endsWith('.' + x))
  } catch { return false }
}

function json(value, init = {}) {
  const headers = new Headers(init.headers || {})
  headers.set('content-type', 'application/json; charset=utf-8')
  headers.set('x-content-type-options', 'nosniff')
  return new Response(JSON.stringify(value), { ...init, headers })
}

function cleanName(value, fallback = 'cubenorixx-file') {
  return String(value || fallback).replace(/[^\w.\-+]+/g, '_').slice(0, 120) || fallback
}

async function proxy(url, request, extraHeaders = {}) {
  const headers = new Headers(request.headers)
  headers.delete('cookie')
  headers.delete('host')
  // Описательный User-Agent с сайтом и контактом поддержки (задача 10).
  headers.set('user-agent', USER_AGENT)
  for (const [key, value] of Object.entries(extraHeaders)) headers.set(key, value)
  // Исходящий прокси тоже соблюдает лимит 250 req / 90 с (задача 8).
  return egressFetch(url, { method: request.method, headers, body: ['GET', 'HEAD'].includes(request.method) ? undefined : request.body, redirect: 'follow' })
}

async function launcherDownload({ env, request, path, next }) {
  const raw = path.slice('/downloads/'.length)
  let key = ''
  try { key = decodeURIComponent(raw) } catch { return new Response('bad path', { status: 400 }) }
  if (!key || key.includes('..') || key.includes('\\') || key.startsWith('/') || !/^(launcher|modpacks|java)\/[A-Za-z0-9._/+\-]+$/.test(key)) {
    if (key === 'README.txt') return next()
    return new Response('launcher asset not found', { status: 404, headers: { 'content-type': 'text/plain; charset=utf-8', 'x-content-type-options': 'nosniff' } })
  }
  if (!env.LAUNCHER_ASSETS) {
    return new Response('launcher asset storage is not configured', { status: 503, headers: { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' } })
  }
  const object = request.method === 'HEAD'
    ? await env.LAUNCHER_ASSETS.head(key)
    : await env.LAUNCHER_ASSETS.get(key, { range: request.headers })
  if (!object) return new Response('launcher asset not found', { status: 404 })
  const headers = new Headers()
  object.writeHttpMetadata?.(headers)
  headers.set('etag', object.httpEtag || object.etag)
  headers.set('accept-ranges', 'bytes')
  headers.set('cache-control', 'public, max-age=3600, immutable')
  headers.set('content-disposition', `attachment; filename="${cleanName(key.split('/').pop(), 'cubenorixx-download')}"`)
  headers.set('x-content-type-options', 'nosniff')
  headers.set('access-control-allow-origin', '*')
  if (object.range) {
    const end = object.range.offset + object.range.length - 1
    headers.set('content-range', `bytes ${object.range.offset}-${end}/${object.size}`)
    headers.set('content-length', String(object.range.length))
  } else if (object.size != null) headers.set('content-length', String(object.size))
  return new Response(request.method === 'HEAD' ? null : object.body, { status: object.range ? 206 : 200, headers })
}

async function serverStatus(url) {
  const raw = String(url.searchParams.get('host') || '').trim()
  const requestedPort = Number(raw.split(':')[1] || 25565)
  if (!/^[A-Za-z0-9.-]{1,253}(?::\d{1,5})?$/.test(raw) || requestedPort < 1 || requestedPort > 65535) return json({ online: false, error: 'host' }, { status: 400 })
  const start = Date.now()
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 6500)
  let response
  try {
    response = await fetch(`https://api.mcsrvstat.us/3/${encodeURIComponent(raw)}`, { signal: controller.signal, headers: { 'user-agent': USER_AGENT } })
  } finally {
    clearTimeout(timer)
  }
  if (!response.ok) return json({ online: false, status: response.status, host: raw, ms: Date.now() - start }, { status: 502 })
  const data = await response.json()
  return json({
    online: Boolean(data.online),
    host: raw,
    hostname: data.hostname || raw.split(':')[0],
    ip: data.ip || '',
    port: Number(data.port) || Number(raw.split(':')[1]) || 25565,
    version: data.version || '',
    protocol: data.protocol && typeof data.protocol === 'object'
      ? [data.protocol.name, data.protocol.version != null ? `#${data.protocol.version}` : ''].filter(Boolean).join(' ')
      : (data.protocol ?? null),
    software: data.software || '',
    players: Number(data.players?.online) || 0,
    max: Number(data.players?.max) || 0,
    motd: Array.isArray(data.motd?.clean) ? data.motd.clean.join(' ') : '',
    ms: Date.now() - start,
    checkedAt: Date.now(),
  }, { headers: { 'cache-control': 'public, max-age=30, stale-while-revalidate=120' } })
}

async function skin(url) {
  const nick = String(url.searchParams.get('nick') || '').trim()
  if (!/^[A-Za-z0-9_]{2,16}$/.test(nick)) return json({ ok: false, error: 'nick' }, { status: 400 })
  let profile = null
  for (const endpoint of [
    `https://api.mojang.com/users/profiles/minecraft/${encodeURIComponent(nick)}`,
    `https://api.minecraftservices.com/minecraft/profile/lookup/name/${encodeURIComponent(nick)}`,
  ]) {
    try {
      const response = await fetch(endpoint, { headers: { 'user-agent': USER_AGENT } })
      if (response.ok) { profile = await response.json(); break }
    } catch {}
  }
  if (!profile?.id) return json({ ok: false, error: 'not-found', nick }, { status: 404 })
  const id = String(profile.id).replace(/-/g, '')
  const name = profile.name || nick
  return json({
    ok: true, nick: name, uuid: id,
    avatar: `https://mc-heads.net/avatar/${id}/128`,
    body: `https://mc-heads.net/body/${id}/256`,
    player: `https://mc-heads.net/player/${id}/256`,
    namemc: `https://namemc.com/profile/${encodeURIComponent(name)}`,
  }, { headers: { 'cache-control': 'public, max-age=900' } })
}

export async function onRequest({ request, next, env }) {
  const url = new URL(request.url)
  const path = url.pathname
  try {
    if (path.startsWith('/downloads/')) return launcherDownload({ env, request, path, next })
    if (path.startsWith('/api/auth/')) return handleAuth({ env, request, path })
    if (path === '/api/mcping') return serverStatus(url)
    if (path === '/api/locale') {
      const country = String(request.cf?.country || request.headers.get('cf-ipcountry') || '').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 2)
      return json({ country, browser: String(request.headers.get('accept-language') || '').slice(0, 180), source: country ? 'edge' : 'browser' }, { headers: { 'cache-control': 'private, max-age=300' } })
    }
    if (path === '/api/ok' || path === '/api/ok.json') return json({ ok: true, app: 'cubenorixx', t: Date.now() }, { headers: { 'cache-control': 'no-store' } })
    if (path.startsWith('/mr-api/')) {
      const target = 'https://api.modrinth.com/' + path.slice('/mr-api/'.length) + url.search
      return proxy(target, request, { accept: 'application/json' })
    }
    if (path.startsWith('/mr-cdn/')) {
      return proxy('https://cdn.modrinth.com/' + path.slice('/mr-cdn/'.length) + url.search, request)
    }
    if (path === '/api/agg-search' || path === '/api/search') {
      const data = await aggSearch({ q: url.searchParams.get('q') || '', type: url.searchParams.get('type') || 'all', limit: Number(url.searchParams.get('limit') || 24), offset: Number(url.searchParams.get('offset') || 0) }, { env })
      return json(data, { headers: { 'cache-control': 'public, max-age=60, stale-while-revalidate=600' } })
    }
    if (path === '/api/agg-get') {
      const slug = url.searchParams.get('slug') || ''
      const row = await aggGetCached(slug, { env })
      return json(row || { missing: true })
    }
    // Локальный кеш метаданных (задача 7): статистика для диагностики.
    if (path === '/api/health') {
      const stats = await metaStats(env?.DB).catch(() => ({ enabled: false }))
      return json({ ok: true, metaCache: stats, egress: egressStats(), at: Date.now() }, { headers: { 'cache-control': 'no-store' } })
    }
    // Суточное инкрементальное обновление (задача 9). Вызывать внешним cron:
    //   curl -H "Authorization: Bearer <MAINTENANCE_TOKEN>" https://<домен>/api/maintenance
    if (path === '/api/maintenance') {
      const token = String(request.headers.get('authorization') || '').replace(/^Bearer\s+/i, '')
      if (env?.MAINTENANCE_TOKEN && token !== env.MAINTENANCE_TOKEN) {
        return json({ ok: false, error: 'unauthorized' }, { status: 401 })
      }
      if (!env?.DB) return json({ ok: false, error: 'database not bound', hint: 'bind D1 as CUBENORIXX_DB and apply migrations/0002_metadata_cache.sql' }, { status: 503 })
      const slugs = await metaStaleSlugs(env.DB, { olderThanHours: 24, limit: 100 })
      let refreshed = 0
      for (const slug of slugs.slice(0, 50)) {
        try {
          const source = String(slug).split('-')[0]
          const q = slug.replace(/^[a-z]+-/, '').replace(/-/g, ' ')
          const data = await aggSearch({ q, type: source === 'spigot' ? 'plugin' : 'all', limit: 5, offset: 0 }, { env })
          if (data?.hits?.length) refreshed += data.hits.length
          else await metaTouch(env.DB, slug)
        } catch {}
      }
      const stats = await metaStats(env.DB).catch(() => ({}))
      return json({ ok: true, refreshed, stats }, { headers: { 'cache-control': 'no-store' } })
    }
    if (path === '/api/live') return json(await liveIndex(), { headers: { 'cache-control': 'public, max-age=15, stale-while-revalidate=120' } })
    if (path === '/api/home') return json(await homeExtra(), { headers: { 'cache-control': 'public, max-age=30, stale-while-revalidate=180' } })
    if (path === '/api/skin') return skin(url)
    if (path === '/api/ping') {
      const target = url.searchParams.get('url') || 'https://api.modrinth.com/v2/'
      if (!allowed(target)) return json({ ok: false, error: 'host' }, { status: 400 })
      const start = Date.now()
      const response = await fetch(target, { method: 'HEAD', redirect: 'follow', headers: { 'user-agent': USER_AGENT } })
      return json({ ok: response.ok, status: response.status, ms: Date.now() - start, target, at: Date.now() }, { headers: { 'cache-control': 'private, max-age=15' } })
    }
    if (path === '/api/img') {
      const target = url.searchParams.get('url') || ''
      if (!allowed(target)) return new Response('blocked', { status: 400 })
      const response = await fetch(target, { headers: { 'user-agent': USER_AGENT }, redirect: 'follow' })
      if (!response.ok) return new Response('upstream', { status: response.status })
      const headers = new Headers(response.headers)
      headers.set('cache-control', 'public, max-age=86400')
      headers.set('x-content-type-options', 'nosniff')
      return new Response(response.body, { status: response.status, headers })
    }
    if (path === '/api/file') {
      const target = url.searchParams.get('url') || ''
      if (!allowed(target)) return new Response('blocked', { status: 400 })
      const response = await fetch(target, { headers: { 'user-agent': USER_AGENT }, redirect: 'follow' })
      if (!response.ok) return new Response('upstream', { status: response.status })
      const headers = new Headers(response.headers)
      headers.set('content-type', 'application/octet-stream')
      headers.set('content-disposition', `attachment; filename="${cleanName(url.searchParams.get('name'))}"`)
      headers.set('x-content-type-options', 'nosniff')
      return new Response(response.body, { status: response.status, headers })
    }
    if (path === '/api/translate' && request.method === 'POST') {
      const body = await request.json().catch(() => ({}))
      const q = String(body.q || '').slice(0, 1500)
      const to = String(body.to || 'en').replace('ua', 'uk')
      const from = String(body.from || 'auto').replace('ua', 'uk')
      if (!q) return json({ text: '', engine: 'none' })
      const endpoint = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(from)}&tl=${encodeURIComponent(to)}&dt=t&q=${encodeURIComponent(q)}`
      const result = await fetch(endpoint, { headers: { 'user-agent': USER_AGENT } })
      if (!result.ok) return json({ text: q, engine: 'none' })
      const data = await result.json()
      const text = (data?.[0] || []).map((x) => x?.[0] || '').join('').trim() || q
      return json({ text, engine: 'gtx' }, { headers: { 'cache-control': 'private, max-age=86400' } })
    }
    if (path === '/go-dl') return Response.redirect(new URL('/take.html' + url.search, url), 302)
  } catch (error) {
    return json({ ok: false, error: String(error?.message || error) }, { status: 502 })
  }
  return next()
}
