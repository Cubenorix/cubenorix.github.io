/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 *
 * Точка входа Worker: API-пути обрабатывает та же логика, что и Pages Functions
 * (functions/[[path]].js), всё остальное отдаётся как статика из dist (ASSETS).
 */

import { onRequest } from './functions/[[path]].js'

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url)
    const isApi =
      url.pathname.startsWith('/api/') ||
      url.pathname.startsWith('/mr-api/') ||
      url.pathname.startsWith('/mr-cdn/') ||
      url.pathname === '/go-dl'

    if (!isApi) {
      try {
        const asset = await env.ASSETS.fetch(request)
        if (asset.status !== 404) return asset
      } catch {}
    }

    return onRequest({
      request,
      env,
      params: {},
      next: async () => env.ASSETS.fetch(new Request(request.url, request)),
    })
  },
}
