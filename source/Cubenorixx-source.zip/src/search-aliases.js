/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */

const ALIASES = new Map()
const add = (canonical, values) => values.forEach((value) => ALIASES.set(value, canonical))

add('create', [
  'create', 'craete', 'creat', 'crete', 'crate',
  'крейд', 'крейт', 'крэйт', 'креэйт', 'криэйт', 'креат', 'креейт',
])
add('sodium', [
  'sodium', 'sodiom', 'sodum', 'soduim',
  'соудим', 'содиум', 'содиюм', 'содум', 'соудиум', 'содиом',
])
add('jei', ['jei', 'just enough items', 'джей', 'джеи', 'джей и ай', 'джаст инаф айтемс'])
add('iris', ['iris', 'iris shaders', 'ирис', 'ирис шейдеры'])
add('fabric api', ['fabric api', 'фабрик апи', 'фабрик api'])
add('optifine', ['optifine', 'optifayn', 'оптифайн', 'оптифайн мод'])

const NOISE = new Set([
  'скачать', 'скачиваю', 'загрузить', 'мод', 'моды', 'mod', 'mods', 'для', 'на',
  'minecraft', 'майнкрафт', 'майн', 'mc', 'java', 'последняя', 'версия', 'latest',
])

export function normalizeProjectQuery(raw) {
  const original = String(raw || '').trim()
  if (!original) return ''
  const simple = original
    .toLowerCase()
    .replace(/ё/g, 'е')
    .replace(/[^\p{L}\p{N}]+/gu, ' ')
    .trim()
  if (ALIASES.has(simple)) return ALIASES.get(simple)
  const meaningful = simple.split(/\s+/).filter((word) => word && !NOISE.has(word)).join(' ')
  return ALIASES.get(meaningful) || original
}

export const SEARCH_ALIAS_GROUPS = Object.freeze({
  create: ['Create мод', 'мод Create', 'Криэйт', 'Крейд мод'],
  sodium: ['Sodium мод', 'мод Sodium', 'Содиум', 'Соудим мод'],
  jei: ['JEI', 'Just Enough Items', 'Джеи мод'],
  iris: ['Iris Shaders', 'Ирис шейдеры'],
  'fabric-api': ['Fabric API', 'Фабрик АПИ'],
  optifine: ['OptiFine', 'ОптиФайн'],
})
