/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */

export const LEGAL_VERSIONS = {
  terms: '2026-08-23',
  privacy: '2026-08-23',
  contentRules: '2026-08-23',
}

async function request(path, options = {}) {
  const response = await fetch(path, {
    credentials: 'same-origin',
    ...options,
    headers: {
      accept: 'application/json',
      ...(options.body ? { 'content-type': 'application/json' } : {}),
      ...(options.headers || {}),
    },
  })
  const type = response.headers.get('content-type') || ''
  if (!type.includes('application/json')) {
    const error = new Error('auth-not-configured')
    error.code = 'auth-not-configured'
    error.status = 503
    throw error
  }
  const data = await response.json().catch(() => ({}))
  if (!response.ok) {
    const error = new Error(data.error || 'request-failed')
    error.code = data.error || 'request-failed'
    error.status = response.status
    error.fields = data.fields || []
    error.retryAfter = data.retryAfter || 0
    throw error
  }
  return data
}

export const getAuthStatus = () => request('/api/auth/status')
export const getCurrentUser = () => request('/api/auth/me')
export const registerAccount = (payload) => request('/api/auth/register', { method: 'POST', body: JSON.stringify(payload) })
export const loginAccount = (payload) => request('/api/auth/login', { method: 'POST', body: JSON.stringify(payload) })
export const logoutAccount = () => request('/api/auth/logout', { method: 'POST', body: '{}' })
export const updateAccountProfile = (payload) => request('/api/auth/profile', { method: 'PATCH', body: JSON.stringify(payload) })
export const deleteAccount = (payload) => request('/api/auth/delete', { method: 'POST', body: JSON.stringify(payload) })

export function authErrorText(error) {
  const code = error?.code || error?.message || ''
  if (code === 'auth-not-configured') return 'Настоящие аккаунты подготовлены для Cloudflare Pages + D1, но база ещё не подключена. На временном Yapp регистрация намеренно отключена.'
  if (code === 'account-exists') return 'Такой email или логин уже зарегистрирован.'
  if (code === 'username-exists') return 'Этот логин уже занят.'
  if (code === 'invalid-credentials') return 'Неверный email или пароль.'
  if (code === 'rate-limit') return `Слишком много попыток. Повторите через ${Math.max(1, Number(error.retryAfter || 60))} сек.`
  if (code === 'origin') return 'Запрос заблокирован проверкой безопасности. Обновите страницу.'
  if (code === 'invalid') {
    const map = {
      email: 'email', username: 'логин (3–24 буквы, цифры, _ или -)', password: 'пароль (12–128 символов)',
      terms: 'условия', privacy: 'политику конфиденциальности', contentRules: 'правила публикации', age: 'возрастное подтверждение',
      nick: 'Minecraft-ник', youtube: 'ссылку YouTube',
    }
    return 'Проверьте: ' + (error.fields || []).map((x) => map[x] || x).join(', ') + '.'
  }
  return 'Не удалось выполнить запрос. Повторите позже.'
}
