/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { NavLink } from 'react-router-dom'
import { useStore } from '../store'

const ITEMS = [
  { to: '/', mark: '⌂', label: 'Главная', end: true },
  { to: '/catalog', mark: '▣', label: 'Каталог' },
  { to: '/builds', mark: '⧉', label: 'Сборки' },
  { to: '/wiki', mark: '▤', label: 'Вики' },
  { to: '/reviews', mark: '★', label: 'Отзывы' },
  { to: '/community', mark: '◈', label: 'Сообщество' },
  { to: '/servers', mark: '◉', label: 'Серверы' },
]

export default function Dock() {
  const { user } = useStore()
  return (
    <aside className="cx-dock" aria-label="меню">
      <NavLink to="/" end className="dock-logo" title="Cubenorixx">
        <img src="/logo.png?v=5" alt="Cubenorixx" width="32" height="32" />
      </NavLink>
      {ITEMS.slice(1).map((it) => (
        <NavLink key={it.to} to={it.to} title={it.label} className={({ isActive }) => 'dock-btn' + (isActive ? ' on' : '')}>
          <span>{it.mark}</span>
        </NavLink>
      ))}
      <div className="dock-gap" />
      <NavLink to={user ? '/profile' : '/login'} title={user ? user.username : 'Войти'} className={({ isActive }) => 'dock-btn' + (isActive ? ' on' : '')}>
        <span>{user ? (user.username || '?')[0].toUpperCase() : '→'}</span>
      </NavLink>
    </aside>
  )
}
