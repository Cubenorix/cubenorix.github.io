/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
export default function Background() {
  return <div className="bg-canvas" aria-hidden />
}
