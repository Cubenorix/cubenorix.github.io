/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
const FILES = {
  cubenorixx: '/logo.png?v=5',
  modrinth: '/sources/modrinth.svg',
  curseforge: '/sources/curseforge.svg',
  github: '/sources/github.svg',
  spigot: '/sources/spigot.svg',
  hangar: '/sources/hangar.png',
  poggit: '/sources/poggit.png',
  pmc: '/sources/pmc.png',
  create: '/sources/create.png',
  rumc: '/sources/rumc.png',
  mcmaps: '/sources/mcmaps.png',
  polymart: '/sources/polymart.png',
  mojang: '/sources/mojang.svg',
  papermc: '/sources/papermc.svg',
  purpur: '/sources/purpur.svg',
  fabric: '/sources/fabric.svg',
  forge: '/sources/forge.svg',
  neoforge: '/sources/neoforge.svg',
  quilt: '/sources/quilt.svg',
  spemotes: '/sources/spemotes.png',
}

export const REAL_LOGOS = new Set(Object.keys(FILES))

export default function SourceLogo({ id, name, size = 36, color }) {
  const src = FILES[id]
  if (src) {
    return (
      <img
        src={src}
        alt=""
        width={size}
        height={size}
        className="source-logo shrink-0"
        data-no-translate="true"
        style={{ width: size, height: size, objectFit: 'contain' }}
      />
    )
  }
  const words = String(id || name || '?').replace(/[^a-z0-9]+/gi, ' ').trim().split(/\s+/).filter(Boolean)
  const letter = (words.length > 1 ? words.map((part) => part[0]).join('') : (words[0] || '?').slice(0, 2)).slice(0, 2).toUpperCase()
  return (
    <span
      className="source-logo source-dot shrink-0 grid place-items-center font-extrabold"
      data-no-translate="true"
      style={{
        width: size,
        height: size,
        background: color || '#2a2a30',
        color: '#12080a',
        fontSize: Math.max(11, size * 0.42),
      }}
      title={name || id}
      aria-hidden
    >
      {letter}
    </span>
  )
}
