/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { Link } from 'react-router-dom'
import { useStore } from '../store'
import { t } from '../i18n'

function face(name) {
  const ch = String(name || '?')[0].toUpperCase()
  return (
    <div className="rev-face" aria-hidden>{ch}</div>
  )
}

export default function ReviewCard({ r, compact }) {
  if (!r) return null
  const name = r.display || r.user
  const head = r.nick
    ? '/api/img?url=' + encodeURIComponent('https://mc-heads.net/avatar/' + encodeURIComponent(r.nick) + '/64')
    : ''
  return (
    <article className={'rev-card' + (compact ? ' compact' : '')}>
      <div className="rev-who">
        {head ? <img src={head} alt="" className="rev-face" onError={(e) => { e.currentTarget.style.display = 'none' }} /> : face(name)}
        <div className="min-w-0">
          <div className="rev-name truncate">{r.brand || name}</div>
          <div className="rev-sub truncate">{r.brand && name !== r.brand ? name : (r.user || '')}</div>
        </div>
        <div className="rev-stars" aria-label={r.stars + ' ' + 'of 5'}>{'★'.repeat(r.stars || 0)}{'☆'.repeat(5 - (r.stars || 0))}</div>
      </div>
      <p className="rev-text">{r.text}</p>
    </article>
  )
}

export function ReviewList({ items, empty }) {
  const { lang } = useStore()
  if (!items?.length) return <p className="text-white/45 text-sm">{empty || t(lang, 'review.empty')}</p>
  return <div className="rev-grid">{items.map((r) => <ReviewCard key={r.id} r={r} />)}</div>
}

export function ReviewsTeaser({ items, to = '/reviews' }) {
  const { lang } = useStore()
  const top = [...(items || [])].sort((a, b) => (b.stars - a.stars) || ((b.up || 0) - (a.up || 0))).slice(0, 3)
  return (
    <section className="mt-12">
      <div className="flex items-end justify-between mb-4">
        <h2 className="font-outfit text-xl">{t(lang, 'review.title')}</h2>
        <Link to={to} className="text-sm text-orange-soft">{t(lang, 'review.all')}</Link>
      </div>
      <ReviewList items={top} empty={t(lang, 'review.emptyHome')} />
    </section>
  )
}
