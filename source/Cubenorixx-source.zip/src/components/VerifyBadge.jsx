/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { VERIFY } from '../stats'
import { VerifyMark } from './Marks'

export default function VerifyBadge({ level, className = '' }) {
  const v = VERIFY[level]
  if (!v) return null
  return (
    <span className={`inline-flex items-center align-middle ${className}`} title={`${v.title} · ${v.hint}`}>
      <VerifyMark level={level} size={18} />
    </span>
  )
}
