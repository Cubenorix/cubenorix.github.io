/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { useEffect, useRef, useState } from 'react'
import { localize, localizeBody } from '../api'
import { renderMd } from '../md'
import { plainPreview } from '../text'
import { useStore } from '../store'

export default function Translated({ text, className, as: Tag = 'span', preview = true }) {
  const { lang } = useStore()
  const src = preview ? plainPreview(text, 400) : String(text || '')
  const [out, setOut] = useState(src)
  const [wait, setWait] = useState(false)
  const [visible, setVisible] = useState(!preview)
  const node = useRef(null)

  // A 100-card page should not start 100 translation requests at once. Translate
  // previews only as they approach the viewport; the original text is visible
  // immediately, so scrolling never exposes an empty placeholder.
  useEffect(() => {
    if (!preview || visible) return
    if (!('IntersectionObserver' in window)) { setVisible(true); return }
    const io = new IntersectionObserver((entries) => {
      if (entries.some((entry) => entry.isIntersecting)) {
        setVisible(true)
        io.disconnect()
      }
    }, { rootMargin: '700px 0px' })
    if (node.current) io.observe(node.current)
    return () => io.disconnect()
  }, [preview, visible])

  useEffect(() => {
    let alive = true
    setOut(src)
    if (!src || !visible) { setWait(false); return }
    setWait(lang !== 'gc' && lang !== 'morse' && lang !== 'ru')
    localize(src, lang, { preview }).then((next) => {
      if (!alive) return
      setOut(next)
      setWait(false)
    })
    return () => { alive = false }
  }, [src, lang, preview, visible])
  return <Tag ref={node} className={(className || '') + (lang === 'gc' ? ' sga' : '') + (lang === 'morse' ? ' morse' : '') + (wait ? ' opacity-70' : '')}>{out}</Tag>
}

export function BodyMd({ text }) {
  const { lang } = useStore()
  const src = String(text || '')
  const [html, setHtml] = useState('')
  useEffect(() => {
    let alive = true
    setHtml('')
    if (!src) return
    localizeBody(src, lang).then((t) => {
      if (!alive) return
      setHtml(renderMd(t || src))
    })
    return () => { alive = false }
  }, [src, lang])
  if (!html) return <p className="text-white/45">…</p>
  return <div className={'md' + (lang === 'gc' ? ' sga' : '') + (lang === 'morse' ? ' morse' : '')} dangerouslySetInnerHTML={{ __html: html }} />
}

export function Tx({ text, as: Tag = 'span', className, children }) {
  const src = text != null ? String(text) : (typeof children === 'string' ? children : '')
  return <Translated text={src} as={Tag} className={className} preview={false} />
}
