/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { Link } from 'react-router-dom'
import { useStore } from '../store'
import { t } from '../i18n'
import { YEARS, SITE_VERSION, BUILD_DATE } from '../data'
import { SUPPORT_BOT_TELEGRAM, SUPPORT_BOT_USERNAME } from '../data/community'

export default function Footer() {
  const { lang } = useStore()
  const cols = [
    {
      h: t(lang, 'footer.catalog'),
      l: [
        ['/catalog?type=mod', t(lang, 'cat.mods')],
        ['/catalog?type=modpack', t(lang, 'cat.modpacks')],
        ['/catalog?type=addon', t(lang, 'cat.addons')],
        ['/catalog?type=shader', t(lang, 'cat.shaders')],
        ['/catalog?type=plugin', t(lang, 'cat.plugins')],
        ['/catalog?type=appearance', t(lang, 'cat.appearance')],
      ],
    },
    {
      h: t(lang, 'footer.play'),
      l: [
        ['/servers', t(lang, 'nav.servers')],
        ['/hosting', t(lang, 'nav.hosting')],
        ['/wiki', t(lang, 'nav.wiki')],
        ['/generators', t(lang, 'nav.generators')],
        ['/guides', t(lang, 'nav.guides')],
        ['/forum', t(lang, 'nav.forum')],
      ],
    },
    {
      h: 'Cubenorixx',
      l: [
        ['/about', t(lang, 'footer.about')],
        ['/top', t(lang, 'nav.top')],
        ['/how', t(lang, 'footer.how')],
        ['/add', t(lang, 'nav.add')],
        ['/connection', t(lang, 'nav.conn')],
        ['/reviews', t(lang, 'footer.reviews')],
        ['/community', t(lang, 'nav.community')],
        ['/bridge', t(lang, 'footer.bridge')],
        ['/hash', t(lang, 'footer.hash')],
      ],
    },
    {
      h: t(lang, 'footer.legal'),
      l: [
        ['/rules', t(lang, 'footer.rules')],
        ['/terms', t(lang, 'footer.terms')],
        ['/privacy', t(lang, 'footer.privacy')],
        ['/dmca', t(lang, 'footer.dmca')],
        ['/authors', t(lang, 'footer.authors')],
        ['/disclaimer', t(lang, 'footer.disc')],
      ],
    },
  ]

  return (
    <footer className="relative z-10 mt-0">
        <div className="foot-bg relative">
        <div className="foot-glow" />
        <div className="max-w-7xl mx-auto px-4 py-12 relative">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 mb-8">
            <div className="flex items-center gap-3">
              <img src="/logo.png?v=4" alt="Cubenorixx" className="logo-img" width="44" height="44" />
              <div>
                <div className="font-outfit text-xl text-white">Cubenorixx</div>
                <div className="text-xs text-white/40">{t(lang, 'footer.tag')}</div>
              </div>
            </div>
            <div className="sm:ml-auto flex flex-wrap gap-2">
              <a href="https://t.me/Cubenorix" target="_blank" rel="me noopener noreferrer" className="footer-official-link">
                <img src="/social/telegram.svg" alt="" width="18" height="18" />
                <span>{t(lang, 'comm.verified')} · @Cubenorix</span>
              </a>
              <a href={SUPPORT_BOT_TELEGRAM} target="_blank" rel="noopener noreferrer" className="footer-official-link" aria-label="Техническая поддержка Cubenorixx в Telegram">
                <img src="/social/telegram.svg" alt="" width="18" height="18" />
                <span>{t(lang, 'footer.support')} · @{SUPPORT_BOT_USERNAME}</span>
              </a>
              <a href="/official/" className="footer-proof-link">{t(lang, 'comm.checkTitle')}</a>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-sm">
            {cols.map((c) => (
              <div key={c.h}>
                <div className="text-white/40 text-xs uppercase tracking-wider mb-3">{c.h}</div>
                <div className="space-y-2">
                  {c.l.map(([to, n]) => <Link key={to} to={to} className="block text-white/65 hover:text-orange-soft">{n}</Link>)}
                </div>
              </div>
            ))}
          </div>
          <div className="mt-10 pt-5 border-t border-white/10 text-xs text-white/35 flex flex-col gap-2">
            <p className="text-white/45 leading-5">{t(lang, 'footer.disclaimerFull')}</p>
            <span>© {YEARS} Cubenorixx Team · бренд и оригинальный контент защищены</span>
            <span className="md:ml-auto flex flex-wrap items-center gap-2">
              <span className="footer-beta-badge" title={t(lang, 'beta.title')}>{SITE_VERSION}</span>
              <span>{t(lang, 'stats.updated')}: {BUILD_DATE}</span>
              <span>·</span>
              <span>{t(lang, 'footer.unofficial')}</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  )
}
