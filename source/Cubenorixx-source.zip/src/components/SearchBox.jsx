/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { useEffect, useRef, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { Search } from 'lucide-react'
import { autocomplete, mediaUrl } from '../api'
import { useStore } from '../store'
import { t } from '../i18n'
import { normalizeProjectQuery } from '../search-aliases'

export default function SearchBox({ compact, initial = '', big }) {
  const { lang, pushHistory, db } = useStore()
  const [sp] = useSearchParams()
  const fromUrl = sp.get('q') || initial
  const [q, setQ] = useState(fromUrl)
  const [open, setOpen] = useState(false)
  const [hits, setHits] = useState([])
  const [hi, setHi] = useState(-1)
  const nav = useNavigate()
  const tmr = useRef()
  const box = useRef(null)

  useEffect(() => {
    if (fromUrl && fromUrl !== q) setQ(fromUrl)
  }, [fromUrl])

  useEffect(() => {
    if (q.trim().length < 2) {
      setHits([])
      return
    }
    clearTimeout(tmr.current)
    tmr.current = setTimeout(async () => {
      try { setHits(await autocomplete(q)) } catch { setHits([]) }
    }, 180)
    return () => clearTimeout(tmr.current)
  }, [q])

  useEffect(() => {
    const onDown = (e) => {
      if (!box.current?.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onDown)
    document.addEventListener('touchstart', onDown)
    return () => {
      document.removeEventListener('mousedown', onDown)
      document.removeEventListener('touchstart', onDown)
    }
  }, [])

  const go = (query) => {
    const raw = (query ?? q).trim()
    const v = normalizeProjectQuery(raw)
    if (!v) {
      setOpen(false)
      nav('/catalog')
      return
    }
    pushHistory(raw)
    setQ(v)
    setOpen(false)
    const type = sp.get('type')
    const qs = new URLSearchParams({ q: v, page: '1' })
    if (/addon|аддон/i.test(raw)) qs.set('type', 'addon')
    else if (type) qs.set('type', type)
    nav('/catalog?' + qs.toString())
  }

  const hist = (db.history || []).filter((h) => !q || String(h).toLowerCase().includes(q.toLowerCase())).slice(0, 4)
  const show = open && (hits.length > 0 || hist.length > 0 || q.trim().length >= 2)

  const onKey = (e) => {
    const list = [...hist.map((h) => ({ kind: 'h', v: h })), ...hits.slice(0, 8).map((h) => ({ kind: 'p', v: h }))]
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setHi((i) => Math.min(list.length - 1, i + 1))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setHi((i) => Math.max(-1, i - 1))
    } else if (e.key === 'Enter') {
      const cur = list[hi]
      if (cur?.kind === 'p') { setOpen(false); nav('/project/' + cur.v.slug); return }
      go(cur?.kind === 'h' ? cur.v : q)
    } else if (e.key === 'Escape') setOpen(false)
  }

  return (
    <div className="relative" ref={box}>
      <div className={`flex items-center gap-2 ${big ? 'glass p-2' : ''}`}>
        <input
          className={`field ${compact ? 'py-2 text-sm' : 'py-3'}`}
          placeholder={t(lang, 'hero.searchPh')}
          aria-label={t(lang, 'hero.searchPh')}
          value={q}
          onChange={(e) => { setQ(e.target.value); setOpen(true); setHi(-1) }}
          onFocus={() => setOpen(true)}
          onKeyDown={onKey}
        />
        <button className="btn btn-primary px-4 sm:px-5 py-3 shrink-0" onClick={() => go()}>
          <Search size={16} /> <span>{t(lang, 'hero.find')}</span>
        </button>
      </div>
      {show ? (
        <div className="search-drop absolute z-50 mt-2 w-full glass-strong p-2 text-sm">
          {hist.map((h, i) => (
            <button key={'h' + h} className={'w-full flex items-center gap-3 px-3 py-2 rounded-xl text-left ' + (hi === i ? 'bg-white/10' : 'hover:bg-white/5')} onMouseDown={(e) => e.preventDefault()} onClick={() => go(h)}>
              <span className="text-white/35">↺</span>
              <span className="truncate">{h}</span>
            </button>
          ))}
          {hits.slice(0, 8).map((h, i) => (
            <button key={h.slug} className={'w-full flex items-center gap-3 px-3 py-2 rounded-xl text-left ' + (hi === hist.length + i ? 'bg-white/10' : 'hover:bg-white/5')} onMouseDown={(e) => e.preventDefault()} onClick={() => { setOpen(false); nav('/project/' + h.slug) }}>
              <Icon src={h.icon_url} letter={h.title} />
              <span className="truncate">{h.title}</span>
              <span className="ml-auto font-mono text-[11px] text-white/40">{h.project_type}</span>
            </button>
          ))}
          {q.trim().length >= 2 && hits.length === 0 && hist.length === 0 && (
            <div className="px-3 py-2 text-white/40">{t(lang, 'ui.searching')}</div>
          )}
        </div>
      ) : null}
    </div>
  )
}

const FALLBACK_ICON = '/no-icon.png'

export function Icon({ src, letter, className = 'w-10 h-10' }) {
  const [err, setErr] = useState(false)
  const [pixel, setPixel] = useState(false)
  const url = (!src || err) ? FALLBACK_ICON : (mediaUrl(src) || src || FALLBACK_ICON)
  return (
    <img
      src={url}
      alt={letter || ''}
      loading="lazy"
      decoding="async"
      className={`${className} rounded-xl object-contain bg-transparent shrink-0 icon`}
      style={{ imageRendering: pixel ? 'pixelated' : 'auto' }}
      onLoad={(e) => { if (e.target.naturalWidth <= 64 && url !== FALLBACK_ICON) setPixel(true) }}
      onError={() => { if (url !== FALLBACK_ICON) setErr(true) }}
    />
  )
}
