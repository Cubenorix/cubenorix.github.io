/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { useMemo, useState } from 'react'

function hex(buffer) {
  return [...new Uint8Array(buffer)].map((b) => b.toString(16).padStart(2, '0')).join('')
}

function niceSize(value) {
  const n = Number(value) || 0
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
  return `${(n / 1024 / 1024).toFixed(2)} MB`
}

const TOOLS = [
  {
    id: 'mcdoctor',
    title: 'MCDoctor.ai',
    text: '/mcdoctor — latest.log; /mcdoctor advanced — глубокий разбор; /mcdoctor share <file> — выбранный latest.log, debug.log или crash-report.',
    url: 'https://mcdoctor.ai/',
    action: 'Открыть MCDoctor',
  },
  {
    id: 'dyo',
    title: 'Dig Yourself Out',
    text: 'Поддерживает logs/latest.log, logs/debug.log, crash-reports/crash-*.txt, launcher_log.txt, hs_err_pid*.log и server.properties.',
    url: 'https://www.digyourselfout.app/analyzer',
    action: 'Открыть анализатор',
  },
  {
    id: 'update',
    title: 'Modpack Update Checker',
    text: 'Проверяет опубликованную версию сборки и показывает обновление в игре. Для CI можно сверять состав через Modrinth API / packwiz.',
    url: 'https://github.com/Modpack-Update-Checker',
    action: 'GitHub проекта',
  },
  {
    id: 'bcc',
    title: 'Better Compatibility Checker',
    text: 'Сравнивает ID и версию модпака клиента и сервера. Установи на обе стороны и заполни bcc-common.toml или bcc.json.',
    url: 'https://modrinth.com/mod/better-compatibility-checker',
    action: 'Проверить версии',
  },
]

export default function DiagnosticsLab({ items = [], onLog }) {
  const [file, setFile] = useState(null)
  const [hash, setHash] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const rounds = useMemo(() => Math.ceil(Math.log2(Math.max(1, items.length))), [items.length])

  const inspect = async (picked) => {
    if (!picked) return
    setBusy(true)
    setError('')
    setHash('')
    setFile({ name: picked.name, size: picked.size, type: picked.type || 'binary' })
    try {
      if (picked.size > 256 * 1024 * 1024) throw new Error('Лимит локальной проверки — 256 MB')
      const data = await picked.arrayBuffer()
      setHash(hex(await crypto.subtle.digest('SHA-256', data)))
      if (/\.(log|txt|json|properties)$/i.test(picked.name) && onLog) {
        const text = new TextDecoder('utf-8', { fatal: false }).decode(data)
        onLog(text.slice(0, 2_000_000), picked.name)
      }
    } catch (e) {
      setError(String(e.message || e))
    } finally {
      setBusy(false)
    }
  }

  return (
    <details className="diagnostics-lab glass mt-4">
      <summary className="cursor-pointer p-4 font-outfit text-lg">Диагностика, SHA-256 и безопасная починка</summary>
      <div className="px-4 pb-4">
        <div className="diag-grid">
          {TOOLS.map((tool) => (
            <article key={tool.id} className="diag-card">
              <h3>{tool.title}</h3>
              <p>{tool.text}</p>
              <a href={tool.url} target="_blank" rel="noreferrer">{tool.action} ↗</a>
            </article>
          ))}
        </div>

        <div className="diag-hash mt-3">
          <div>
            <h3 className="font-semibold">MC Validator-подход: сначала хэш, потом доверие</h3>
            <p className="text-xs text-white/45 mt-1 leading-5">Файл читается и хэшируется локально в браузере. SHA-256 можно найти в VirusTotal; неизвестный JAR не считается безопасным автоматически. Для модов также сверяй хэш с метаданными официального источника (Modrinth и т.п.).</p>
          </div>
          <label className="btn btn-ghost px-4 py-2 cursor-pointer shrink-0">
            {busy ? 'Считаю…' : 'Выбрать JAR или лог'}
            <input type="file" className="sr-only" accept=".jar,.zip,.mrpack,.log,.txt,.json,.properties" onChange={(e) => inspect(e.target.files?.[0])} />
          </label>
        </div>
        {file ? (
          <div className="pack-log mt-2">
            <div className="pack-line"><b>{file.name}</b> · {niceSize(file.size)}</div>
            {hash ? <div className="pack-line font-mono break-all">SHA-256: {hash}</div> : null}
            {hash ? (
              <div className="flex flex-wrap gap-2 mt-2">
                <a className="tag on" href={'https://www.virustotal.com/gui/search/' + hash} target="_blank" rel="noreferrer">VirusTotal · несколько движков ↗</a>
                <button type="button" className="tag" onClick={() => navigator.clipboard?.writeText(hash)}>Копировать SHA-256</button>
              </div>
            ) : null}
            {error ? <div className="pack-line miss">{error}</div> : null}
          </div>
        ) : null}

        <div className="diag-binary mt-3">
          <h3 className="font-semibold">Управляемый двоичный поиск</h3>
          <p className="text-sm text-white/55 mt-1 leading-6">
            Сейчас {items.length} элементов. Раздели список пополам, запускай одну половину и повторяй только с проблемной частью.
            Максимум <b className="text-orange-soft">{rounds}</b> раундов вместо проверки каждого мода. Сохраняй мир и конфиги перед тестом; библиотеки и зависимости перемещай вместе с родительским модом.
          </p>
          <ol className="text-xs text-white/45 mt-2 leading-6 list-decimal pl-5">
            <li>Сделай резервную копию instance, world и config.</li>
            <li>Отключи половину подозрительных модов, не удаляя файлы.</li>
            <li>Если сбой остался — проблема в активной половине; если исчез — в отключённой.</li>
            <li>Верни обязательные зависимости и повторяй до одного мода или конфликтующей пары.</li>
          </ol>
        </div>
        <p className="text-[11px] text-white/30 mt-3">Внешняя отправка логов может раскрыть IP, UUID, пути и имена. Просмотри файл перед MCDoctor/VirusTotal. Cubenorixx не загружает выбранный файл сам.</p>
      </div>
    </details>
  )
}
