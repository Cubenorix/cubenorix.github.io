/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
}

export function rewriteMedia(url) {
  const u = String(url || '')
  try {
    const p = new URL(u)
    if (p.hostname.includes('cdn.modrinth.com')) return '/mr-cdn' + p.pathname + p.search
  } catch {}
  return u
}

function rewriteHtmlMedia(html) {
  return String(html || '').replace(
    /(src|href)=["'](https:\/\/cdn\.modrinth\.com[^"']+)["']/gi,
    (_, attr, url) => `${attr}="${rewriteMedia(url)}"`,
  )
}

export function renderMd(raw) {
  let s = String(raw || '').replace(/\r\n/g, '\n').trim()
  if (!s) return '<p class="text-white/50">—</p>'
  if (/^\s*</.test(s) && /<\/[a-zA-Z]/.test(s)) {
    return rewriteHtmlMedia(s.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/\son\w+=/gi, ' data-x='))
  }

  const hold = []
  const keep = (html) => {
    hold.push(html)
    return `\u0000H${hold.length - 1}\u0000`
  }

  s = s.replace(/```(\w*)\n([\s\S]*?)```/g, (_, _l, code) => keep(`<pre><code>${esc(code.trim())}</code></pre>`))
  s = s.replace(/`([^`\n]+)`/g, (_, c) => keep(`<code>${esc(c)}</code>`))
  s = s.replace(/!\[([^\]]*)\]\((https?:\/\/[^)\s]+)\)/g, (_, alt, url) => {
    if (/javascript:|data:/i.test(url)) return alt
    return keep(`<img src="${esc(rewriteMedia(url))}" alt="${esc(alt)}" loading="lazy" />`)
  })
  s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, (_, t, url) => {
    if (/javascript:|data:/i.test(url)) return esc(t)
    const href = rewriteMedia(url)
    return keep(`<a href="${esc(href)}" target="_blank" rel="noreferrer">${esc(t)}</a>`)
  })

  s = esc(s)
  s = s.replace(/\u0000H(\d+)\u0000/g, (_, i) => `\u0000H${i}\u0000`)

  s = s.replace(/^###### (.*)$/gm, '<h6>$1</h6>')
  s = s.replace(/^##### (.*)$/gm, '<h5>$1</h5>')
  s = s.replace(/^#### (.*)$/gm, '<h4>$1</h4>')
  s = s.replace(/^### (.*)$/gm, '<h3>$1</h3>')
  s = s.replace(/^## (.*)$/gm, '<h2>$1</h2>')
  s = s.replace(/^# (.*)$/gm, '<h1>$1</h1>')
  s = s.replace(/^&gt; (.*)$/gm, '<blockquote>$1</blockquote>')
  s = s.replace(/^---$/gm, '<hr/>')
  s = s.replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
  s = s.replace(/__([^_]+)__/g, '<b>$1</b>')
  s = s.replace(/(^|[^\w])\*([^*\n]+)\*(?!\*)/g, '$1<i>$2</i>')

  const lines = s.split('\n')
  const out = []
  let list = []
  const flushList = () => {
    if (!list.length) return
    out.push('<ul>' + list.map((x) => `<li>${x}</li>`).join('') + '</ul>')
    list = []
  }
  let para = []
  const flushPara = () => {
    if (!para.length) return
    out.push('<p>' + para.join('<br/>') + '</p>')
    para = []
  }
  for (const line of lines) {
    if (/^<h[1-6]>/.test(line) || line === '<hr/>' || /^<blockquote>/.test(line)) {
      flushList(); flushPara(); out.push(line); continue
    }
    const m = line.match(/^[-*] (.+)/) || line.match(/^\d+\. (.+)/)
    if (m) { flushPara(); list.push(m[1]); continue }
    if (!line.trim()) { flushList(); flushPara(); continue }
    flushList()
    para.push(line)
  }
  flushList(); flushPara()
  let html = out.join('\n')
  html = html.replace(/\u0000H(\d+)\u0000/g, (_, i) => hold[Number(i)] || '')
  return html
}

export function splitForTranslate(raw) {
  const s = String(raw || '')
  const parts = []
  const re = /```[\s\S]*?```/g
  let last = 0
  let m
  while ((m = re.exec(s))) {
    if (m.index > last) parts.push({ t: 'p', v: s.slice(last, m.index) })
    parts.push({ t: 'code', v: m[0] })
    last = m.index + m[0].length
  }
  if (last < s.length) parts.push({ t: 'p', v: s.slice(last) })
  const chunks = []
  for (const p of parts) {
    if (p.t === 'code') { chunks.push(p); continue }
    const paras = p.v.split(/\n{2,}/)
    let buf = ''
    for (const para of paras) {
      if ((buf + '\n\n' + para).length > 700) {
        if (buf) chunks.push({ t: 'p', v: buf })
        buf = para
      } else buf = buf ? buf + '\n\n' + para : para
    }
    if (buf) chunks.push({ t: 'p', v: buf })
  }
  return chunks.slice(0, 16)
}
