/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
export function combinedStats(sources) {
  const list = (Array.isArray(sources) ? sources : [])
    .map((s) => ({
      id: s.id || s.platform || s,
      downloads: Number(s.downloads) || 0,
      likes: Number(s.likes || s.followers) || 0,
      url: s.url,
      name: s.name || s.id,
    }))
    .filter((s) => s.downloads > 0 || s.url)
  if (!list.length) return { downloads: 0, likes: 0, primary: null }
  list.sort((a, b) => b.downloads - a.downloads)
  const primary = list[0]
  const likes = Math.max(...list.map((s) => s.likes), 0)
  if (list.length === 1) {
    return { downloads: primary.downloads, likes, primary: primary.id, sources: list }
  }
  const rest = list.slice(1).reduce((a, s) => a + s.downloads, 0) / 6
  const downloads = Math.round(primary.downloads * 0.8 + rest * 1.0045)
  return { downloads, likes, primary: primary.id, sources: list }
}

export function uniqueHits(hits) {
  const map = new Map()
  for (const h of hits || []) {
    const key = String(h.slug || h.title || '').toLowerCase().replace(/[^a-z0-9а-яё]+/gi, '')
    if (!key) continue
    const prev = map.get(key)
    if (!prev) { map.set(key, h); continue }
    const a = String(h.description || h.body || '').length
    const b = String(prev.description || prev.body || '').length
    const takeNew = (h.downloads || 0) > (prev.downloads || 0) || ((h.downloads || 0) === (prev.downloads || 0) && a > b)
    const best = takeNew ? h : prev
    const other = takeNew ? prev : h
    map.set(key, {
      ...best,
      icon_url: best.icon_url || other.icon_url,
      body: String(best.body || '').length >= String(other.body || '').length ? best.body : other.body,
      description: a >= b ? (h.description || best.description) : (prev.description || best.description),
      sources: [...new Set([...(Array.isArray(prev.sources) ? prev.sources : []), ...(Array.isArray(h.sources) ? h.sources : [])])],
      downloads: Math.max(Number(h.downloads) || 0, Number(prev.downloads) || 0),
    })
  }
  return [...map.values()]
}

export function verifyLevel({ downloads = 0, likes = 0 } = {}) {
  const d = Number(downloads) || 0
  const l = Number(likes) || 0
  if (d >= 100_000_000) return 'divine'
  if (d >= 100_000 && l >= 500) return 'legend'
  if (d >= 10_000) return 'star'
  if (d >= 1_000) return 'known'
  if (d >= 100) return 'popular'
  if (d >= 10) return 'new'
  return null
}

export function topScore(p) {
  const d = Number(p.downloads) || 0
  const likes = Number(p.follows || p.likes || 0)
  const rating = Number(p.rating || 0) || 4
  return d * 0.6 + likes * 400 * 0.3 + rating * 8000 * 0.1
}

export const VERIFY = {
  new: { title: 'Новичок', hint: '10+ загрузок', color: '#22c55e', author: 'Начинающий автор' },
  popular: { title: 'Популярный', hint: '100+ загрузок', color: '#3b82f6', author: 'Популярный автор' },
  known: { title: 'Известный', hint: '1 000+ загрузок', color: '#eab308', author: 'Известный автор' },
  star: { title: 'Звёздный', hint: '10 000+ загрузок', color: '#a855f7', author: 'Звёздный автор' },
  legend: { title: 'Легендарный', hint: '100 000 загрузок и 500 лайков', color: '#ef4444', author: 'Легендарный автор' },
  divine: { title: 'Божественный', hint: '100 000 000+ загрузок', color: '#ff6b00', author: 'Божественный автор' },
}
