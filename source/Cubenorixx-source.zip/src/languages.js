/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
export const LANGUAGE_META = [
  { id: 'ru', name: 'Русский', flag: '🇷🇺', locale: 'ru-RU', translate: 'ru' },
  { id: 'en', name: 'English', flag: '🇬🇧', locale: 'en-GB', translate: 'en' },
  { id: 'gc', name: '⊣ᔑꖎᔑᓵℸ ̣╎ᓵ ᓭℸ ̣ᔑリ↸ᔑ∷↸', flag: '🌌', locale: 'en-GB', translate: 'en', special: true },
  { id: 'ua', name: 'Українська', flag: '🇺🇦', locale: 'uk-UA', translate: 'uk' },
  { id: 'de', name: 'Deutsch', flag: '🇩🇪', locale: 'de-DE', translate: 'de' },
  { id: 'fr', name: 'Français', flag: '🇫🇷', locale: 'fr-FR', translate: 'fr' },
  { id: 'es', name: 'Español', flag: '🇪🇸', locale: 'es-ES', translate: 'es' },
  { id: 'zh-cn', name: '简体中文', flag: '🇨🇳', locale: 'zh-CN', translate: 'zh-CN' },
  { id: 'pt-br', name: 'Português (Brasil)', flag: '🇧🇷', locale: 'pt-BR', translate: 'pt' },
  { id: 'pl', name: 'Polski', flag: '🇵🇱', locale: 'pl-PL', translate: 'pl' },
  { id: 'tr', name: 'Türkçe', flag: '🇹🇷', locale: 'tr-TR', translate: 'tr' },
  { id: 'it', name: 'Italiano', flag: '🇮🇹', locale: 'it-IT', translate: 'it' },
  { id: 'cs', name: 'Čeština', flag: '🇨🇿', locale: 'cs-CZ', translate: 'cs' },
  { id: 'se', name: 'Svenska', flag: '🇸🇪', locale: 'sv-SE', translate: 'sv' },
  { id: 'nl', name: 'Nederlands', flag: '🇳🇱', locale: 'nl-NL', translate: 'nl' },
  { id: 'vi', name: 'Tiếng Việt', flag: '🇻🇳', locale: 'vi-VN', translate: 'vi' },
  { id: 'th', name: 'ไทย', flag: '🇹🇭', locale: 'th-TH', translate: 'th' },
  { id: 'ar', name: 'العربية', flag: '🇸🇦', locale: 'ar-SA', translate: 'ar', rtl: true },
  { id: 'he', name: 'עברית', flag: '🇮🇱', locale: 'he-IL', translate: 'iw', rtl: true },
  { id: 'hu', name: 'Magyar', flag: '🇭🇺', locale: 'hu-HU', translate: 'hu' },
  { id: 'ro', name: 'Română', flag: '🇷🇴', locale: 'ro-RO', translate: 'ro' },
  { id: 'el', name: 'Ελληνικά', flag: '🇬🇷', locale: 'el-GR', translate: 'el' },
  { id: 'da', name: 'Dansk', flag: '🇩🇰', locale: 'da-DK', translate: 'da' },
  { id: 'no', name: 'Norsk', flag: '🇳🇴', locale: 'nb-NO', translate: 'no' },
  { id: 'fi', name: 'Suomi', flag: '🇫🇮', locale: 'fi-FI', translate: 'fi' },
  { id: 'id', name: 'Bahasa Indonesia', flag: '🇮🇩', locale: 'id-ID', translate: 'id' },
  { id: 'fil', name: 'Filipino', flag: '🇵🇭', locale: 'fil-PH', translate: 'tl' },
  { id: 'ms', name: 'Melayu', flag: '🇲🇾', locale: 'ms-MY', translate: 'ms' },
  { id: 'bg', name: 'Български', flag: '🇧🇬', locale: 'bg-BG', translate: 'bg' },
  { id: 'hr', name: 'Hrvatski', flag: '🇭🇷', locale: 'hr-HR', translate: 'hr' },
  { id: 'sk', name: 'Slovenčina', flag: '🇸🇰', locale: 'sk-SK', translate: 'sk' },
  { id: 'sl', name: 'Slovenščina', flag: '🇸🇮', locale: 'sl-SI', translate: 'sl' },
  { id: 'et', name: 'Eesti', flag: '🇪🇪', locale: 'et-EE', translate: 'et' },
  { id: 'lv', name: 'Latviešu', flag: '🇱🇻', locale: 'lv-LV', translate: 'lv' },
  { id: 'lt', name: 'Lietuvių', flag: '🇱🇹', locale: 'lt-LT', translate: 'lt' },
  { id: 'sq', name: 'Shqip', flag: '🇦🇱', locale: 'sq-AL', translate: 'sq' },
  { id: 'bs', name: 'Bosanski', flag: '🇧🇦', locale: 'bs-BA', translate: 'bs' },
  { id: 'sr', name: 'Српски', flag: '🇷🇸', locale: 'sr-RS', translate: 'sr' },
  { id: 'mk', name: 'Македонски', flag: '🇲🇰', locale: 'mk-MK', translate: 'mk' },
  { id: 'gl', name: 'Galego', flag: '🇪🇸', locale: 'gl-ES', translate: 'gl' },
  { id: 'eu', name: 'Euskara', flag: '🇪🇸', locale: 'eu-ES', translate: 'eu' },
  { id: 'ca', name: 'Català', flag: '🇪🇸', locale: 'ca-ES', translate: 'ca' },
  { id: 'af', name: 'Afrikaans', flag: '🇿🇦', locale: 'af-ZA', translate: 'af' },
  { id: 'zu', name: 'isiZulu', flag: '🇿🇦', locale: 'zu-ZA', translate: 'zu' },
  { id: 'xh', name: 'isiXhosa', flag: '🇿🇦', locale: 'xh-ZA', translate: 'xh' },
  { id: 'sw', name: 'Kiswahili', flag: '🇰🇪', locale: 'sw-KE', translate: 'sw' },
  { id: 'am', name: 'አማርኛ', flag: '🇪🇹', locale: 'am-ET', translate: 'am' },
  { id: 'uz', name: 'Oʻzbek', flag: '🇺🇿', locale: 'uz-UZ', translate: 'uz' },
  { id: 'kk', name: 'Қазақ', flag: '🇰🇿', locale: 'kk-KZ', translate: 'kk' },
  { id: 'mn', name: 'Монгол', flag: '🇲🇳', locale: 'mn-MN', translate: 'mn' },
  { id: 'ka', name: 'ქართული', flag: '🇬🇪', locale: 'ka-GE', translate: 'ka' },
  { id: 'hy', name: 'Հայերեն', flag: '🇦🇲', locale: 'hy-AM', translate: 'hy' },
  { id: 'tk', name: 'Türkmen', flag: '🇹🇲', locale: 'tk-TM', translate: 'tk' },
  { id: 'tg', name: 'Тоҷикӣ', flag: '🇹🇯', locale: 'tg-TJ', translate: 'tg' },
  { id: 'ky', name: 'Кыргызча', flag: '🇰🇬', locale: 'ky-KG', translate: 'ky' },
  { id: 'ps', name: 'پښتو', flag: '🇦🇫', locale: 'ps-AF', translate: 'ps', rtl: true },
  { id: 'fa', name: 'فارسی', flag: '🇮🇷', locale: 'fa-IR', translate: 'fa', rtl: true },
  { id: 'ne', name: 'नेपाली', flag: '🇳🇵', locale: 'ne-NP', translate: 'ne' },
  { id: 'si', name: 'සිංහල', flag: '🇱🇰', locale: 'si-LK', translate: 'si' },
  { id: 'dv', name: 'ދިވެހި', flag: '🇲🇻', locale: 'dv-MV', translate: 'dv', rtl: true },
  { id: 'kn', name: 'ಕನ್ನಡ', flag: '🇮🇳', locale: 'kn-IN', translate: 'kn' },
  { id: 'ta', name: 'தமிழ்', flag: '🇮🇳', locale: 'ta-IN', translate: 'ta' },
  { id: 'te', name: 'తెలుగు', flag: '🇮🇳', locale: 'te-IN', translate: 'te' },
  { id: 'morse', name: '··−·−·−−· −·−− ·−−· −·−−· ··−− ··−−· ··−·−·−·· (Азбука Морзе)', flag: '🔊', locale: 'en-GB', translate: 'en', special: true },
]

const LANGUAGE_ALIASES = {
  uk: 'ua', sv: 'se', nb: 'no', nn: 'no', iw: 'he', zh: 'zh-cn', 'zh-hans': 'zh-cn',
  pt: 'pt-br', tl: 'fil', fa: 'fa', ru: 'ru', en: 'en',
}

const COUNTRY_LANGUAGE = {
  RU: 'ru', BY: 'ru', UA: 'ua', GB: 'en', US: 'en', CA: 'en', AU: 'en', NZ: 'en', IE: 'en',
  DE: 'de', AT: 'de', CH: 'de', FR: 'fr', ES: 'es', MX: 'es', AR: 'es', CO: 'es',
  BR: 'pt-br', PT: 'pt-br', PL: 'pl', TR: 'tr', IT: 'it', CZ: 'cs', SE: 'se', NL: 'nl',
  VN: 'vi', TH: 'th', SA: 'ar', AE: 'ar', IL: 'he', HU: 'hu', RO: 'ro', GR: 'el',
  DK: 'da', NO: 'no', FI: 'fi', ID: 'id', PH: 'fil', MY: 'ms', BG: 'bg', HR: 'hr',
  SK: 'sk', SI: 'sl', EE: 'et', LV: 'lv', LT: 'lt', AL: 'sq', BA: 'bs', RS: 'sr', MK: 'mk',
  ZA: 'af', KE: 'sw', ET: 'am', UZ: 'uz', KZ: 'kk', MN: 'mn', GE: 'ka', AM: 'hy',
  TM: 'tk', TJ: 'tg', KG: 'ky', AF: 'ps', IR: 'fa', NP: 'ne', LK: 'si', MV: 'dv', IN: 'hi',
}

export function detectLanguage({ languages = [], country = '' } = {}) {
  const supported = new Set(LANGUAGE_META.map((x) => x.id))
  for (const raw of Array.isArray(languages) ? languages : [languages]) {
    const code = String(raw || '').toLowerCase().replace('_', '-')
    if (!code) continue
    const base = code.split('-')[0]
    const candidate = LANGUAGE_ALIASES[code] || LANGUAGE_ALIASES[base] || code
    if (supported.has(candidate)) return candidate
    const byLocale = LANGUAGE_META.find((x) => String(x.locale || '').toLowerCase() === code || String(x.translate || '').toLowerCase() === code)
    if (byLocale) return byLocale.id
  }
  const byCountry = COUNTRY_LANGUAGE[String(country || '').toUpperCase()]
  return supported.has(byCountry) ? byCountry : 'en'
}

const CORE_KEYS = [
  'nav.home', 'nav.catalog', 'nav.builds', 'nav.more', 'auth.login', 'hero.find',
  'hero.searchPh', 'stats.content', 'stats.platforms', 'builds.zip', 'conn.title',
  'common.loading', 'stats.updated',
]

// Compact, bundled translations for the most visible controls. Full RU/EN/UA/DE/FR/ES/ZH
// dictionaries live in i18n.js; longer project descriptions use the translation relay.
const CORE_ROWS = {
  'pt-br': ['Início','Catálogo','Pacotes','Mais','Entrar','Buscar','Pesquisar','projetos','plataformas','Baixar ZIP','Minha conexão','Carregando…','Atualizado'],
  pl: ['Strona główna','Katalog','Paczki','Więcej','Zaloguj','Szukaj','Szukaj','projektów','platform','Pobierz ZIP','Moje połączenie','Ładowanie…','Zaktualizowano'],
  tr: ['Ana sayfa','Katalog','Paketler','Daha fazla','Giriş','Ara','Ara','proje','platform','ZIP indir','Bağlantım','Yükleniyor…','Güncellendi'],
  it: ['Home','Catalogo','Pacchetti','Altro','Accedi','Cerca','Cerca','progetti','piattaforme','Scarica ZIP','La mia connessione','Caricamento…','Aggiornato'],
  cs: ['Domů','Katalog','Balíčky','Více','Přihlásit','Hledat','Hledat','projektů','platforem','Stáhnout ZIP','Moje připojení','Načítání…','Aktualizováno'],
  se: ['Hem','Katalog','Paket','Mer','Logga in','Sök','Sök','projekt','plattformar','Ladda ner ZIP','Min anslutning','Laddar…','Uppdaterad'],
  nl: ['Start','Catalogus','Pakketten','Meer','Inloggen','Zoeken','Zoeken','projecten','platforms','ZIP downloaden','Mijn verbinding','Laden…','Bijgewerkt'],
  vi: ['Trang chủ','Danh mục','Gói','Thêm','Đăng nhập','Tìm','Tìm kiếm','dự án','nền tảng','Tải ZIP','Kết nối của tôi','Đang tải…','Đã cập nhật'],
  th: ['หน้าแรก','แค็ตตาล็อก','ชุดม็อด','เพิ่มเติม','เข้าสู่ระบบ','ค้นหา','ค้นหา','โปรเจกต์','แพลตฟอร์ม','ดาวน์โหลด ZIP','การเชื่อมต่อของฉัน','กำลังโหลด…','อัปเดตแล้ว'],
  ar: ['الرئيسية','الكتالوج','الحزم','المزيد','تسجيل الدخول','بحث','بحث','مشاريع','منصات','تنزيل ZIP','اتصالي','جارٍ التحميل…','تم التحديث'],
  he: ['בית','קטלוג','חבילות','עוד','כניסה','חיפוש','חיפוש','פרויקטים','פלטפורמות','הורדת ZIP','החיבור שלי','טוען…','עודכן'],
  hu: ['Kezdőlap','Katalógus','Csomagok','Továbbiak','Belépés','Keresés','Keresés','projekt','platform','ZIP letöltése','Kapcsolatom','Betöltés…','Frissítve'],
  ro: ['Acasă','Catalog','Pachete','Mai mult','Autentificare','Caută','Caută','proiecte','platforme','Descarcă ZIP','Conexiunea mea','Se încarcă…','Actualizat'],
  el: ['Αρχική','Κατάλογος','Πακέτα','Περισσότερα','Σύνδεση','Αναζήτηση','Αναζήτηση','έργα','πλατφόρμες','Λήψη ZIP','Η σύνδεσή μου','Φόρτωση…','Ενημερώθηκε'],
  da: ['Hjem','Katalog','Pakker','Mere','Log ind','Søg','Søg','projekter','platforme','Hent ZIP','Min forbindelse','Indlæser…','Opdateret'],
  no: ['Hjem','Katalog','Pakker','Mer','Logg inn','Søk','Søk','prosjekter','plattformer','Last ned ZIP','Min tilkobling','Laster…','Oppdatert'],
  fi: ['Koti','Luettelo','Paketit','Lisää','Kirjaudu','Haku','Haku','projektia','alustaa','Lataa ZIP','Yhteyteni','Ladataan…','Päivitetty'],
  id: ['Beranda','Katalog','Paket','Lainnya','Masuk','Cari','Cari','proyek','platform','Unduh ZIP','Koneksi saya','Memuat…','Diperbarui'],
  fil: ['Home','Katalogo','Mga pack','Higit pa','Mag-login','Maghanap','Maghanap','proyekto','platform','I-download ang ZIP','Aking koneksyon','Naglo-load…','Na-update'],
  ms: ['Laman utama','Katalog','Pek','Lagi','Log masuk','Cari','Cari','projek','platform','Muat turun ZIP','Sambungan saya','Memuatkan…','Dikemas kini'],
  bg: ['Начало','Каталог','Сборки','Още','Вход','Търсене','Търсене','проекта','платформи','Изтегли ZIP','Моята връзка','Зареждане…','Обновено'],
  hr: ['Početna','Katalog','Paketi','Više','Prijava','Traži','Traži','projekata','platformi','Preuzmi ZIP','Moja veza','Učitavanje…','Ažurirano'],
  sk: ['Domov','Katalóg','Balíky','Viac','Prihlásiť','Hľadať','Hľadať','projektov','platforiem','Stiahnuť ZIP','Moje pripojenie','Načítava sa…','Aktualizované'],
  sl: ['Domov','Katalog','Paketi','Več','Prijava','Išči','Išči','projektov','platform','Prenesi ZIP','Moja povezava','Nalaganje…','Posodobljeno'],
  et: ['Avaleht','Kataloog','Paketid','Veel','Logi sisse','Otsi','Otsi','projekti','platvormi','Laadi ZIP','Minu ühendus','Laadimine…','Uuendatud'],
  lv: ['Sākums','Katalogs','Pakotnes','Vairāk','Pieteikties','Meklēt','Meklēt','projekti','platformas','Lejupielādēt ZIP','Mans savienojums','Ielāde…','Atjaunināts'],
  lt: ['Pradžia','Katalogas','Paketai','Daugiau','Prisijungti','Ieškoti','Ieškoti','projektai','platformos','Atsisiųsti ZIP','Mano ryšys','Įkeliama…','Atnaujinta'],
  sq: ['Kreu','Katalogu','Paketat','Më shumë','Hyr','Kërko','Kërko','projekte','platforma','Shkarko ZIP','Lidhja ime','Duke ngarkuar…','Përditësuar'],
  bs: ['Početna','Katalog','Paketi','Više','Prijava','Traži','Traži','projekata','platformi','Preuzmi ZIP','Moja veza','Učitavanje…','Ažurirano'],
  sr: ['Почетна','Каталог','Пакети','Више','Пријава','Претрага','Претрага','пројеката','платформи','Преузми ZIP','Моја веза','Учитавање…','Ажурирано'],
  mk: ['Почетна','Каталог','Пакети','Повеќе','Најава','Пребарај','Пребарај','проекти','платформи','Преземи ZIP','Моја врска','Се вчитува…','Ажурирано'],
  gl: ['Inicio','Catálogo','Paquetes','Máis','Entrar','Buscar','Buscar','proxectos','plataformas','Descargar ZIP','A miña conexión','Cargando…','Actualizado'],
  eu: ['Hasiera','Katalogoa','Paketeak','Gehiago','Hasi saioa','Bilatu','Bilatu','proiektu','plataforma','Deskargatu ZIP','Nire konexioa','Kargatzen…','Eguneratuta'],
  ca: ['Inici','Catàleg','Paquets','Més','Inicia sessió','Cerca','Cerca','projectes','plataformes','Baixa ZIP','La meva connexió','Carregant…','Actualitzat'],
  af: ['Tuis','Katalogus','Pakkette','Meer','Meld aan','Soek','Soek','projekte','platforms','Laai ZIP af','My verbinding','Laai…','Opgedateer'],
  zu: ['Ikhaya','Ikhathalogi','Amaphakheji','Okuningi','Ngena','Sesha','Sesha','amaphrojekthi','izinkundla','Landa i-ZIP','Ukuxhumana kwami','Iyalayisha…','Kubuyekeziwe'],
  xh: ['Ekhaya','Ikhathalogu','Iipakethe','Okunye','Ngena','Khangela','Khangela','iiprojekthi','amaqonga','Khuphela i-ZIP','Uqhagamshelo lwam','Iyalayisha…','Ihlaziyiwe'],
  sw: ['Nyumbani','Katalogi','Vifurushi','Zaidi','Ingia','Tafuta','Tafuta','miradi','majukwaa','Pakua ZIP','Muunganisho wangu','Inapakia…','Imesasishwa'],
  am: ['መነሻ','ካታሎግ','ጥቅሎች','ተጨማሪ','ግባ','ፈልግ','ፈልግ','ፕሮጀክቶች','መድረኮች','ZIP አውርድ','የእኔ ግንኙነት','በመጫን ላይ…','ተዘምኗል'],
  uz: ['Bosh sahifa','Katalog','To‘plamlar','Ko‘proq','Kirish','Qidirish','Qidirish','loyihalar','platformalar','ZIP yuklash','Mening ulanishim','Yuklanmoqda…','Yangilandi'],
  kk: ['Басты бет','Каталог','Жинақтар','Тағы','Кіру','Іздеу','Іздеу','жоба','платформа','ZIP жүктеу','Менің қосылымым','Жүктелуде…','Жаңартылды'],
  mn: ['Нүүр','Каталог','Багцууд','Илүү','Нэвтрэх','Хайх','Хайх','төсөл','платформ','ZIP татах','Миний холболт','Уншиж байна…','Шинэчлэгдсэн'],
  ka: ['მთავარი','კატალოგი','პაკეტები','მეტი','შესვლა','ძიება','ძიება','პროექტი','პლატფორმა','ZIP-ის ჩამოტვირთვა','ჩემი კავშირი','იტვირთება…','განახლებულია'],
  hy: ['Գլխավոր','Կատալոգ','Փաթեթներ','Ավելին','Մուտք','Որոնել','Որոնել','նախագծեր','հարթակներ','Ներբեռնել ZIP','Իմ կապը','Բեռնվում է…','Թարմացվել է'],
  tk: ['Baş sahypa','Katalog','Bukjalar','Has köp','Giriş','Gözle','Gözle','taslamalar','platformalar','ZIP ýükläň','Meniň birikmäm','Ýüklenýär…','Täzelendi'],
  tg: ['Асосӣ','Каталог','Маҷмӯаҳо','Бештар','Воридшавӣ','Ҷустуҷӯ','Ҷустуҷӯ','лоиҳаҳо','платформаҳо','ZIP боргирӣ','Пайвасти ман','Бор шуда истодааст…','Нав карда шуд'],
  ky: ['Башкы бет','Каталог','Жыйнактар','Дагы','Кирүү','Издөө','Издөө','долбоорлор','платформалар','ZIP жүктөө','Менин байланышым','Жүктөлүүдө…','Жаңыртылды'],
  ps: ['کور','کتلاګ','بستې','نور','ننوتل','لټون','لټون','پروژې','پلیټفارمونه','ZIP ښکته کړئ','زما اړیکه','بارېږي…','تازه شو'],
  fa: ['خانه','فهرست','بسته‌ها','بیشتر','ورود','جستجو','جستجو','پروژه‌ها','پلتفرم‌ها','دانلود ZIP','اتصال من','در حال بارگذاری…','به‌روزرسانی شد'],
  ne: ['गृहपृष्ठ','क्याटलग','प्याकहरू','थप','लगइन','खोज्नुहोस्','खोज्नुहोस्','परियोजनाहरू','प्लेटफर्महरू','ZIP डाउनलोड','मेरो जडान','लोड हुँदैछ…','अद्यावधिक'],
  si: ['මුල් පිටුව','නාමාවලිය','ඇසුරුම්','තවත්','පිවිසෙන්න','සොයන්න','සොයන්න','ව්‍යාපෘති','වේදිකා','ZIP බාගන්න','මගේ සම්බන්ධතාව','පූරණය වෙමින්…','යාවත්කාලීනයි'],
  dv: ['މައި ސަފްޙާ','ކެޓަލޮގު','ޕެކެޖުތައް','އިތުރަށް','ލޮގިން','ހޯދާ','ހޯދާ','ޕްރޮޖެކްޓުތައް','ޕްލެޓްފޯމުތައް','ZIP ޑައުންލޯޑު','އަހަރެންގެ ކަނެކްޝަން','ލޯޑުވަނީ…','އަޕްޑޭޓުވެއްޖެ'],
  kn: ['ಮುಖಪುಟ','ಕ್ಯಾಟಲಾಗ್','ಪ್ಯಾಕ್‌ಗಳು','ಇನ್ನಷ್ಟು','ಲಾಗಿನ್','ಹುಡುಕಿ','ಹುಡುಕಿ','ಯೋಜನೆಗಳು','ವೇದಿಕೆಗಳು','ZIP ಡೌನ್‌ಲೋಡ್','ನನ್ನ ಸಂಪರ್ಕ','ಲೋಡ್ ಆಗುತ್ತಿದೆ…','ನವೀಕರಿಸಲಾಗಿದೆ'],
  ta: ['முகப்பு','பட்டியல்','தொகுப்புகள்','மேலும்','உள்நுழை','தேடு','தேடு','திட்டங்கள்','தளங்கள்','ZIP பதிவிறக்கு','என் இணைப்பு','ஏற்றுகிறது…','புதுப்பிக்கப்பட்டது'],
  te: ['హోమ్','కేటలాగ్','ప్యాక్‌లు','మరిన్ని','లాగిన్','వెతకండి','వెతకండి','ప్రాజెక్టులు','ప్లాట్‌ఫారమ్‌లు','ZIP డౌన్‌లోడ్','నా కనెక్షన్','లోడ్ అవుతోంది…','నవీకరించబడింది'],
}

const CORE = Object.fromEntries(Object.entries(CORE_ROWS).map(([id, values]) => [id, Object.fromEntries(CORE_KEYS.map((key, i) => [key, values[i]]))]))

export function languageMeta(id) {
  return LANGUAGE_META.find((x) => x.id === id) || LANGUAGE_META[1]
}

export function localeOf(id) {
  return languageMeta(id).locale || 'en-GB'
}

export function translationCode(id) {
  return languageMeta(id).translate || 'en'
}

export function isRTL(id) {
  return Boolean(languageMeta(id).rtl)
}

export function coreText(id, path) {
  return CORE[id]?.[path] || ''
}

export function isCoreTranslation(id, text) {
  const value = String(text || '').replace(/\s+/g, ' ').trim()
  return value ? Object.values(CORE[id] || {}).some((item) => String(item).replace(/\s+/g, ' ').trim() === value) : false
}

export function formatNumber(value, id) {
  try { return new Intl.NumberFormat(localeOf(id)).format(Number(value) || 0) }
  catch { return String(Number(value) || 0) }
}

export function formatDateTime(value, id, options = {}) {
  const date = value instanceof Date ? value : new Date(value)
  if (!Number.isFinite(date.getTime())) return '—'
  try {
    return new Intl.DateTimeFormat(localeOf(id), {
      year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit',
      ...options,
    }).format(date)
  } catch { return date.toLocaleString() }
}
