/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
// Локальные аккаунты Cubenorixx: работают на любом статическом хостинге
// (GitHub Pages). Пароль никогда не хранится в открытом виде — только
// SHA-256(salt + password). Аккаунты живут в localStorage этого устройства;
// когда подключится серверный режим (Cloudflare Worker + D1), локальные
// аккаунты можно будет перенести.

const ACCOUNTS_KEY = 'cubenorixx.accounts.v1'
const SESSION_KEY = 'cubenorixx.session.v1'

let storageImpl = null
function storage() {
  if (storageImpl) return storageImpl
  try {
    const probe = '__cx_probe__'
    globalThis.localStorage.setItem(probe, '1')
    globalThis.localStorage.removeItem(probe)
    storageImpl = globalThis.localStorage
  } catch {
    const mem = new Map()
    storageImpl = {
      getItem: (k) => (mem.has(k) ? mem.get(k) : null),
      setItem: (k, v) => mem.set(k, String(v)),
      removeItem: (k) => mem.delete(k),
    }
  }
  return storageImpl
}

export function setAuthStorage(impl) { storageImpl = impl }

export async function sha256hex(text) {
  const data = new TextEncoder().encode(text)
  const digest = await crypto.subtle.digest('SHA-256', data)
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('')
}

function randomSalt() {
  const bytes = new Uint8Array(16)
  crypto.getRandomValues(bytes)
  return [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('')
}

function readAccounts() {
  try {
    const raw = JSON.parse(storage().getItem(ACCOUNTS_KEY) || '{}')
    return raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {}
  } catch { return {} }
}

function writeAccounts(map) {
  storage().setItem(ACCOUNTS_KEY, JSON.stringify(map))
}

const USERNAME_RE = /^[A-Za-zА-Яа-яЁё0-9_-]{3,24}$/
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

function publicUser(record) {
  if (!record) return null
  const { hash, salt, ...safe } = record
  return { ...safe, role: safe.role || 'user', provider: 'local' }
}

export function localAuthUnlocked() {
  try {
    const db = JSON.parse(storage().getItem('cubenorixx.v1') || '{}')
    return Boolean(db.secretUnlocked)
  } catch { return false }
}

export function currentLocalUser() {
  try {
    const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
    if (!session?.email) return null
    const record = readAccounts()[String(session.email).toLowerCase()]
    return record ? publicUser(record) : null
  } catch { return null }
}

export async function registerLocalAccount({ username, email, password, consent = {} }) {
  const name = String(username || '').trim()
  const mail = String(email || '').trim().toLowerCase()
  const pass = String(password || '')
  if (!USERNAME_RE.test(name)) return { ok: false, error: 'Ник: 3–24 буквы, цифры, _ или -' }
  if (!EMAIL_RE.test(mail)) return { ok: false, error: 'Введите корректный e-mail.' }
  if (pass.length < 12) return { ok: false, error: 'Пароль: не менее 12 символов.' }
  if (!Object.values(consent).every(Boolean)) return { ok: false, error: 'Нужно принять все условия.' }
  const accounts = readAccounts()
  if (accounts[mail]) return { ok: false, error: 'Аккаунт с таким e-mail уже зарегистрирован на этом устройстве.' }
  const nameTaken = Object.values(accounts).some((a) => String(a.username).toLowerCase() === name.toLowerCase())
  if (nameTaken) return { ok: false, error: 'Такой ник уже занят на этом устройстве.' }
  const salt = randomSalt()
  const hash = await sha256hex(salt + pass)
  const record = {
    username: name,
    email: mail,
    salt,
    hash,
    created: new Date().toISOString(),
    consents: { ...consent, at: new Date().toISOString() },
    profile: { display: '', brand: '', nick: '', youtube: '', bio: '', custom: {} },
  }
  accounts[mail] = record
  writeAccounts(accounts)
  storage().setItem(SESSION_KEY, JSON.stringify({ email: mail, since: Date.now() }))
  return { ok: true, user: publicUser(record) }
}

export async function loginLocalAccount({ email, password }) {
  const mail = String(email || '').trim().toLowerCase()
  const pass = String(password || '')
  const record = readAccounts()[mail]
  if (!record) return { ok: false, error: 'Аккаунт не найден на этом устройстве. Зарегистрируйтесь или проверьте e-mail.' }
  const hash = await sha256hex(record.salt + pass)
  if (hash !== record.hash) return { ok: false, error: 'Неверный пароль.' }
  storage().setItem(SESSION_KEY, JSON.stringify({ email: mail, since: Date.now() }))
  return { ok: true, user: publicUser(record) }
}

export function logoutLocalAccount() {
  storage().removeItem(SESSION_KEY)
}

export function updateLocalProfile(patch) {
  const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
  if (!session?.email) return { ok: false, error: 'Сессия не найдена.' }
  const accounts = readAccounts()
  const record = accounts[session.email.toLowerCase()]
  if (!record) return { ok: false, error: 'Аккаунт не найден.' }
  const allowed = ['display', 'brand', 'nick', 'youtube', 'bio', 'custom']
  for (const key of allowed) {
    if (key in (patch || {})) record.profile[key] = patch[key]
  }
  accounts[session.email.toLowerCase()] = record
  writeAccounts(accounts)
  return { ok: true, user: publicUser(record) }
}

export function deleteLocalAccount({ password, confirm }) {
  const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
  if (!session?.email) return { ok: false, error: 'Сессия не найдена.' }
  const mail = session.email.toLowerCase()
  const record = readAccounts()[mail]
  if (!record) return { ok: false, error: 'Аккаунт не найден.' }
  const hash = sha256hex(record.salt + String(password || ''))
  return { verify: hash, record, mail }
}

export async function deleteLocalAccountAsync({ password }) {
  const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
  if (!session?.email) return { ok: false, error: 'Сессия не найдена.' }
  const mail = session.email.toLowerCase()
  const record = readAccounts()[mail]
  if (!record) return { ok: false, error: 'Аккаунт не найден.' }
  const hash = await sha256hex(record.salt + String(password || ''))
  if (hash !== record.hash) return { ok: false, error: 'Неверный пароль.' }
  const accounts = readAccounts()
  delete accounts[mail]
  writeAccounts(accounts)
  logoutLocalAccount()
  return { ok: true }
}
