/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
// Локальные аккаунты Cubenorixx: работают на любом статическом хостинге
// (GitHub Pages). Пароль никогда не хранится в открытом виде — только
// SHA-256(salt + password). Аккаунты живут в localStorage этого устройства;
// когда подключится серверный режим (Cloudflare Worker + D1), локальные
// аккаунты можно будет перенести.

const ACCOUNTS_KEY = 'cubenorixx.accounts.v1'
const SESSION_KEY = 'cubenorixx.session.v1'

let storageImpl = null
function storage() {
  if (storageImpl) return storageImpl
  try {
    const probe = '__cx_probe__'
    globalThis.localStorage.setItem(probe, '1')
    globalThis.localStorage.removeItem(probe)
    storageImpl = globalThis.localStorage
  } catch {
    const mem = new Map()
    storageImpl = {
      getItem: (k) => (mem.has(k) ? mem.get(k) : null),
      setItem: (k, v) => mem.set(k, String(v)),
      removeItem: (k) => mem.delete(k),
    }
  }
  return storageImpl
}

export function setAuthStorage(impl) { storageImpl = impl }

export async function sha256hex(text) {
  const data = new TextEncoder().encode(text)
  const digest = await crypto.subtle.digest('SHA-256', data)
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('')
}

function randomSalt() {
  const bytes = new Uint8Array(16)
  crypto.getRandomValues(bytes)
  return [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('')
}

const USERNAME_RE = /^[A-Za-z0-9_-]{3,24}$/
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

// — Встроенный аккаунт администрации —
// Это обычный аккаунт с ЗАКРЕПЛЁННЫМ логином и МАКСИМАЛЬНЫМ уровнем:
// никаких отдельных «прав» не добавляет. Создаётся автоматически на любом
// устройстве при первом обращении к хранилищу аккаунтов, поэтому владелец
// может войти с любого устройства: логин (почта или ник Cubenorix) + пароль.
// Пароль нигде не хранится открыто — только SHA-256(соль + пароль).
export const ADMIN_EMAIL = 'mc.7cubes.ru@gmail.com'
export const ADMIN_USERNAME = 'Cubenorix'
export const OFFICIAL_EMAIL = 'cubenorix.official@gmail.com'
const ADMIN_SALT = '04a48675320d1242c71c0716b0af6335'
const ADMIN_HASH = 'f395e001fce26d51f925fd9c1a09aabf446bcbc4903abd7b5a42c0cdfd68de56'
const ADMIN_CREATED = '2026-08-29T00:00:00.000Z'

function adminRecord() {
  return {
    username: ADMIN_USERNAME,
    email: ADMIN_EMAIL,
    salt: ADMIN_SALT,
    hash: ADMIN_HASH,
    created: ADMIN_CREATED,
    role: 'admin',
    level: 'max',
    consents: { termsAccepted: true, privacyAccepted: true, contentRulesAccepted: true, ageConfirmed: true, at: ADMIN_CREATED },
    profile: { display: '', brand: '', nick: '', youtube: '', bio: '', custom: {} },
  }
}

function readAccounts() {
  try {
    const raw = JSON.parse(storage().getItem(ACCOUNTS_KEY) || '{}')
    const map = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {}
    if (!map[ADMIN_EMAIL]) {
      map[ADMIN_EMAIL] = adminRecord()
      storage().setItem(ACCOUNTS_KEY, JSON.stringify(map))
    }
    return map
  } catch {
    return { [ADMIN_EMAIL]: adminRecord() }
  }
}

function writeAccounts(map) {
  storage().setItem(ACCOUNTS_KEY, JSON.stringify(map))
}

function publicUser(record) {
  if (!record) return null
  const { hash, salt, ...safe } = record
  return { ...safe, ...(safe.profile || {}), role: safe.role || 'user', provider: 'local' }
}

export function localAuthUnlocked() {
  try {
    const db = JSON.parse(storage().getItem('cubenorixx.v1') || '{}')
    return Boolean(db.secretUnlocked)
  } catch { return false }
}

export function currentLocalUser() {
  try {
    const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
    if (!session?.email) return null
    const record = readAccounts()[String(session.email).toLowerCase()]
    return record ? publicUser(record) : null
  } catch { return null }
}

export async function registerLocalAccount({ username, email, password, consent = {} }) {
  const name = String(username || '').trim()
  const mail = String(email || '').trim().toLowerCase()
  const pass = String(password || '')
  if (!USERNAME_RE.test(name)) return { ok: false, error: 'Ник: 3–24 буквы, цифры, _ или -' }
  if (!EMAIL_RE.test(mail)) return { ok: false, error: 'Введите корректный e-mail.' }
  if (pass.length < 12) return { ok: false, error: 'Пароль: не менее 12 символов.' }
  if (!Object.values(consent).every(Boolean)) return { ok: false, error: 'Нужно принять все условия.' }
  const accounts = readAccounts()
  if (accounts[mail]) return { ok: false, error: 'Аккаунт с таким e-mail уже зарегистрирован на этом устройстве.' }
  const nameTaken = Object.values(accounts).some((a) => String(a.username).toLowerCase() === name.toLowerCase())
  if (nameTaken) return { ok: false, error: 'Такой ник уже занят на этом устройстве.' }
  const salt = randomSalt()
  const hash = await sha256hex(salt + pass)
  const record = {
    username: name,
    email: mail,
    salt,
    hash,
    created: new Date().toISOString(),
    consents: { ...consent, at: new Date().toISOString() },
    profile: { display: '', brand: '', nick: '', youtube: '', bio: '', custom: {} },
  }
  accounts[mail] = record
  writeAccounts(accounts)
  storage().setItem(SESSION_KEY, JSON.stringify({ email: mail, since: Date.now() }))
  return { ok: true, user: publicUser(record) }
}

export async function loginLocalAccount({ email, password }) {
  const input = String(email || '').trim()
  const pass = String(password || '')
  const accounts = readAccounts()
  // Логин: e-mail или ник (без @ — ищем по нику, без регистра)
  let record = accounts[input.toLowerCase()]
  if (!record && !input.includes('@')) {
    const mail = Object.keys(accounts).find((m) => String(accounts[m].username).toLowerCase() === input.toLowerCase())
    if (mail) record = accounts[mail]
  }
  if (!record) return { ok: false, error: 'Аккаунт не найден на этом устройстве. Зарегистрируйтесь или проверьте e-mail.' }
  const hash = await sha256hex(record.salt + pass)
  if (hash !== record.hash) return { ok: false, error: 'Неверный пароль.' }
  storage().setItem(SESSION_KEY, JSON.stringify({ email: record.email, since: Date.now() }))
  return { ok: true, user: publicUser(record) }
}

export function logoutLocalAccount() {
  storage().removeItem(SESSION_KEY)
}

export function updateLocalProfile(patch) {
  const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
  if (!session?.email) return { ok: false, error: 'Сессия не найдена.' }
  const mail = session.email.toLowerCase()
  const accounts = readAccounts()
  const record = accounts[mail]
  if (!record) return { ok: false, error: 'Аккаунт не найден.' }
  const allowed = ['display', 'brand', 'nick', 'youtube', 'bio', 'custom']
  for (const key of allowed) {
    if (key in (patch || {})) record.profile[key] = patch[key]
  }
  // Смена логина (ника): у обычных аккаунтов — свободная (проверяем занятость),
  // у администрации логин закреплён и не меняется.
  if (record.role !== 'admin' && typeof patch?.username === 'string') {
    const name = patch.username.trim()
    if (name && name !== record.username) {
      if (!USERNAME_RE.test(name)) return { ok: false, error: 'Ник: 3–24 буквы, цифры, _ или -' }
      const taken = Object.keys(accounts).some((m) => m !== mail && String(accounts[m].username).toLowerCase() === name.toLowerCase())
      if (taken || name.toLowerCase() === ADMIN_USERNAME.toLowerCase()) return { ok: false, error: 'Такой ник уже занят на этом устройстве.' }
      record.username = name
    }
  }
  accounts[mail] = record
  writeAccounts(accounts)
  return { ok: true, user: publicUser(record) }
}

// Смена пароля: проверяем текущий, затем новая соль + хеш. Действует на этом
// устройстве (локальные аккаунты живут в localStorage).
export async function changeLocalPassword({ current, next } = {}) {
  const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
  if (!session?.email) return { ok: false, error: 'Сессия не найдена.' }
  const mail = session.email.toLowerCase()
  const accounts = readAccounts()
  const record = accounts[mail]
  if (!record) return { ok: false, error: 'Аккаунт не найден.' }
  const curHash = await sha256hex(record.salt + String(current || ''))
  if (curHash !== record.hash) return { ok: false, error: 'Текущий пароль неверен.' }
  const pass = String(next || '')
  if (pass.length < 12 || pass.length > 128) return { ok: false, error: 'Новый пароль: 12–128 символов.' }
  const salt = randomSalt()
  record.salt = salt
  record.hash = await sha256hex(salt + pass)
  record.passChangedAt = new Date().toISOString()
  accounts[mail] = record
  writeAccounts(accounts)
  return { ok: true, user: publicUser(record) }
}

export function deleteLocalAccount({ password, confirm }) {
  const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
  if (!session?.email) return { ok: false, error: 'Сессия не найдена.' }
  const mail = session.email.toLowerCase()
  const record = readAccounts()[mail]
  if (!record) return { ok: false, error: 'Аккаунт не найден.' }
  const hash = sha256hex(record.salt + String(password || ''))
  return { verify: hash, record, mail }
}

export async function deleteLocalAccountAsync() {
  const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
  if (!session?.email) return { ok: false, error: 'Сессия не найдена.' }
  const mail = session.email.toLowerCase()
  if (mail === ADMIN_EMAIL) return { ok: false, error: 'Аккаунт администрации защищён от удаления.' }
  const accounts = readAccounts()
  if (!accounts[mail]) return { ok: false, error: 'Аккаунт не найден.' }
  delete accounts[mail]
  writeAccounts(accounts)
  logoutLocalAccount()
  return { ok: true }
}
