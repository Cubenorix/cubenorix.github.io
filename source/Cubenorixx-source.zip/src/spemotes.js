/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
// Curated from the public SPEMOTES API and the Google Drive file metadata linked
// by https://spemotes.spoverlay.ru/download. Images are intentionally not copied;
// each card uses the genuine lightweight SPEMOTES favicon and original download.
const DRIVE = 'https://drive.google.com/file/d/'

const PACKS = [
  ['1e6K8KCSd3JG-KpykVHFzlTA6uEZpGyau', 'SPEMOTES ALL 2026', 'Полный актуальный архив: основной набор, танцы, природа, разное, мультивселенная, спорт, передвижение, кошмары и New Year.'],
  ['1uCT3m57LXx5XYnREywpVSLnHOr_b9ikx', 'SPEmotes 3.0 — основной пакет', 'Основной пакет пользовательских эмоций Emotecraft.'],
  ['1wLiAB1ku7PQ_NQ15F3b0sn8IlQ8sX_3j', 'SPE — Танцы 1', 'Первая часть танцевальных эмоций.'],
  ['1QhnT44iaVurJ2g3fWN3nREVXaW4qTm1U', 'SPE — Танцы 2', 'Вторая часть танцевальных эмоций.'],
  ['18Aa0ty0O0Y7WT2lY23Wl7-bX7Ct-MwCn', 'SPE — Танцы 3', 'Третья часть танцевальных эмоций.'],
  ['11sOeWzpjSUI6PumYMzslYgPMqLigMKXd', 'SPE — Танцы 4', 'Четвёртая часть танцевальных эмоций.'],
  ['1H9TLrbj7zUZHYlRkMVb0fmBx3AcpMeLV', 'SPE — Природа', 'Эмоции и анимации на природную тему.'],
  ['1HfW0NAAGNxVQwmWe2n8EJHF3Ikc-Qwhe', 'SPE — Разное 1', 'Первая часть разных эмоций.'],
  ['1wOwaDstYJD79JZH0iUdMTcOr5pPSsxKj', 'SPE — Разное 2', 'Вторая часть разных эмоций.'],
  ['1ktfxVO6KPvonFtDrkONHRLy0IOaXEnvF', 'SPE — Разное 3', 'Третья часть разных эмоций.'],
  ['1pQ6vyJQ6Z7yW0raVYvEHoIcvyHVBoUJe', 'SPE — Разное 4', 'Четвёртая часть разных эмоций.'],
  ['16TIyn4D1pnS7YfcostwRS5ASTFhcOGMA', 'SPE — Разное 5', 'Пятая часть разных эмоций.'],
  ['180fJCRuU-YtbMqP6N-a4QH-LOtAI72Ag', 'SPEMOTES ALL — архив', 'Предыдущий полный архив SPEMOTES.'],
  ['1Hv0CpDrjqO9EHsyk1PXY4iuAgMkxuoLY', 'SPE — Мультивселенная 1', 'Первая часть эмоций мультивселенной.'],
  ['1AgxMAWxE8t7uHBy3VgECNaigUZUaKsid', 'SPE — Мультивселенная 2', 'Вторая часть эмоций мультивселенной.'],
  ['1dlVCDpf5CSzZYKWhakYJPm9eE518yerk', 'SPE — Мультивселенная 3', 'Третья часть эмоций мультивселенной.'],
  ['1QlYGa87h3ZVyU4cPXQBDhvz073ahn75Y', 'SPE — Спорт', 'Спортивные эмоции и движения.'],
  ['1SSCzwnVclserzj9kMS-BWGbft7R4fUJt', 'SPE — КСЭПСП', 'Тематический набор КСЭПСП.'],
  ['1ND0pvmx19I2htApIuhqwR2MA-nq9NTJ9', 'SPE — КСЭПСП 2', 'Вторая часть тематического набора КСЭПСП.'],
  ['1rvBpmrqqv8fyUuT7whzafEYMyRClaXoU', 'SPE — Передвижение', 'Анимации ходьбы и передвижения.'],
  ['1nuUYJO8jl6byPcJFrgWdJEH3SQCNGJnw', 'SPE — Передвижение 2', 'Вторая часть анимаций передвижения.'],
  ['14q0vBXvSKYVzJjazrSuGS5aq1yC2AzR0', 'SPE — Кошмары', 'Мрачные эмоции из серии «Кошмары».'],
  ['1b-7-veV8WA5uRJO7wMQHOASj4ofsZgY8', 'SPE — Кошмары 2', 'Вторая часть серии «Кошмары».'],
  ['1TAvWFBSjw3t9b40oV2kb70b56p6yFVFH', 'SPE — Nightmares 3', 'Третья часть серии Nightmares.'],
  ['1LOKA1euUyRK9_OwUehSZEoyDnENiMg0U', 'SPE — New Year 2025', 'Новогодний архив эмоций 2025 от spoverlay.'],
  ['1Zpeew4_pUgaBrsI8-4DTA4L-IZNtg-RJ', 'SPE — New Year 2026', 'Новогодний архив эмоций 2026 от spoverlay.'],
]

export const SPEMOTES_PACKS = PACKS.map(([id, title, description], i) => ({
  slug: `spemotes-${i + 1}-${id.slice(0, 6).toLowerCase()}`,
  title,
  description: `${description} Оригинальная загрузка SPEMOTES by spoverlay для Emotecraft.`,
  body: description,
  url: `${DRIVE}${id}/view`,
  icon_url: '/sources/spemotes.png',
  sources: ['spemotes'],
  project_type: 'emote',
  author: 'spoverlay',
  external: true,
  featured: true,
  pack_number: i + 1,
}))

export function searchSpemotes(query = '') {
  const q = String(query || '').trim().toLocaleLowerCase()
  if (!q) return SPEMOTES_PACKS
  return SPEMOTES_PACKS.filter((p) => `${p.title} ${p.description}`.toLocaleLowerCase().includes(q))
}
