/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
const NICK_RE = /^[A-Za-z0-9_]{2,16}$/

export function skinNick(p) {
  const author = String(p?.author || p?.nick || '').trim()
  if (NICK_RE.test(author) && !/skinner|voidwear|buildlab|pmc/i.test(author)) return author
  const title = String(p?.title || p?.slug || '').replace(/[-_]+/g, ' ')
  const word = title.split(/\s+/).find((w) => NICK_RE.test(w) && w.length >= 3)
  if (word) return word
  const slug = String(p?.slug || '').replace(/[^A-Za-z0-9_]/g, '').slice(0, 16)
  if (NICK_RE.test(slug)) return slug
  return 'Steve'
}

export function skin3d(p, kind = 'player') {
  const nick = skinNick(p)
  const path = kind === 'body' ? '/body/' : kind === 'avatar' ? '/avatar/' : '/player/'
  return '/api/img?url=' + encodeURIComponent('https://mc-heads.net' + path + encodeURIComponent(nick) + (kind === 'avatar' ? '/64' : ''))
}

export function isSkin(p) {
  return String(p?.project_type || '') === 'skin' || String(p?.type || '') === 'skin'
}
