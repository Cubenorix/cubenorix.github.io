/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { CheckCircle2, Database, ShieldCheck } from 'lucide-react'
import { useStore } from '../store'
import { t } from '../i18n'

export default function Auth({ mode }) {
  const { login, register, resetPassword, notify, lang, authStatus, authReady } = useStore()
  const nav = useNavigate()
  const [hasAcc, setHasAcc] = useState(mode === 'login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [username, setUsername] = useState('')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const [consent, setConsent] = useState({ termsAccepted: false, privacyAccepted: false, contentRulesAccepted: false, ageConfirmed: false })

  const configured = Boolean(authReady && authStatus?.configured)
  const submit = async (event) => {
    event.preventDefault()
    if (!configured || busy) return
    setBusy(true)
    setErr('')
    const result = hasAcc
      ? await login(email, password)
      : await register(username, email, password, consent)
    setBusy(false)
    if (!result.ok) setErr(result.error)
    else nav('/profile')
  }

  const setCheck = (key) => setConsent((value) => ({ ...value, [key]: !value[key] }))

  return (
    <div className="relative z-10 max-w-lg mx-auto px-4 pt-12 pb-16">
      <div className="glass p-6 sm:p-8">
        <img src="/logo.png?v=5" className="w-14 h-14 mx-auto logo-img" alt="" />
        <h1 className="font-outfit text-3xl text-center mt-3">{hasAcc ? t(lang, 'auth.login') : t(lang, 'auth.register')}</h1>
        <p className="text-center text-white/50 text-sm mt-2">
          {hasAcc ? 'Серверная сессия Cubenorixx на всех ваших устройствах.' : 'Настоящий серверный аккаунт — не пароль в localStorage.'}
        </p>

        <div className={`auth-readiness ${configured ? 'ready' : ''}`}>
          {configured ? <CheckCircle2 size={18} /> : <Database size={18} />}
          <div>
            <strong>{configured ? 'Сервер аккаунтов подключён' : authReady ? 'Ожидается Cloudflare D1' : 'Проверяем сервер аккаунтов…'}</strong>
            <span>{configured ? 'Пароль хешируется на сервере; сессия хранится в защищённой HttpOnly cookie.' : 'Регистрация откроется после подключения базы аккаунтов. Сайт полностью работает без аккаунта: ищите, собирайте и скачивайте свободно.'}</span>
          </div>
        </div>

        <div className="flex gap-2 mt-5">
          <button type="button" className={'tag flex-1 justify-center' + (hasAcc ? ' on' : '')} onClick={() => { setHasAcc(true); setErr('') }}>{t(lang, 'auth.login')}</button>
          <button type="button" className={'tag flex-1 justify-center' + (!hasAcc ? ' on' : '')} onClick={() => { setHasAcc(false); setErr('') }}>{t(lang, 'auth.register')}</button>
        </div>

        <form className="mt-5 space-y-3" onSubmit={submit}>
          {!hasAcc && (
            <label className="auth-field-label">
              <span>{t(lang, 'auth.username')}</span>
              <input className="field" autoComplete="username" placeholder="3–24 буквы, цифры, _ или -" value={username} onChange={(e) => setUsername(e.target.value)} required minLength={3} maxLength={24} pattern="[A-Za-zА-Яа-яЁё0-9_-]{3,24}" />
            </label>
          )}
          <label className="auth-field-label">
            <span>{t(lang, 'auth.email')}</span>
            <input className="field" type="email" autoComplete="email" placeholder="name@example.com" value={email} onChange={(e) => setEmail(e.target.value)} required maxLength={254} />
          </label>
          <label className="auth-field-label">
            <span>{t(lang, 'auth.password')}</span>
            <input className="field" type="password" autoComplete={hasAcc ? 'current-password' : 'new-password'} placeholder={hasAcc ? 'Ваш пароль' : 'Не менее 12 символов'} value={password} onChange={(e) => setPassword(e.target.value)} required minLength={hasAcc ? 1 : 12} maxLength={128} />
          </label>

          {!hasAcc && (
            <div className="auth-consents">
              <Consent checked={consent.termsAccepted} onChange={() => setCheck('termsAccepted')}>
                Принимаю <Link to="/terms" target="_blank">Условия использования</Link>.
              </Consent>
              <Consent checked={consent.privacyAccepted} onChange={() => setCheck('privacyAccepted')}>
                Прочитал(а) <Link to="/privacy" target="_blank">Политику конфиденциальности</Link>.
              </Consent>
              <Consent checked={consent.contentRulesAccepted} onChange={() => setCheck('contentRulesAccepted')}>
                Буду публиковать только своё содержимое или материалы, на которые у меня есть разрешение, и принимаю <Link to="/authors" target="_blank">правила для авторов</Link>.
              </Consent>
              <Consent checked={consent.ageConfirmed} onChange={() => setCheck('ageConfirmed')}>
                Я достиг(ла) возраста самостоятельного согласия в своей юрисдикции либо получил(а) согласие законного представителя.
              </Consent>
            </div>
          )}

          {err && <div className="auth-error" role="alert">{err}</div>}
          <button className="btn btn-primary w-full py-3" disabled={!configured || busy || (!hasAcc && !Object.values(consent).every(Boolean))}>
            <ShieldCheck size={17} /> {busy ? 'Подождите…' : hasAcc ? t(lang, 'auth.login') : t(lang, 'auth.create')}
          </button>
        </form>

        {hasAcc && (
          <button type="button" className="text-sm text-white/50 mt-3" onClick={async () => {
            const result = await resetPassword(email)
            notify(result.ok ? result.hint : result.error, result.ok ? 'ok' : 'err')
          }}>{t(lang, 'auth.forgot')}</button>
        )}
        <p className="text-center text-sm mt-4 text-white/50">
          <button type="button" className="text-orange-soft" onClick={() => setHasAcc((value) => !value)}>{hasAcc ? t(lang, 'auth.noAcc') : t(lang, 'auth.hasAcc')}</button>
        </p>
        <p className="text-center text-[11px] leading-5 text-white/30 mt-4">Cubenorixx не хранит пароль в браузере и не имитирует вход Microsoft. Серверная авторизация работает с открытым исходным кодом.</p>
      </div>
    </div>
  )
}

function Consent({ checked, onChange, children }) {
  return (
    <label className="auth-consent-row">
      <input type="checkbox" checked={checked} onChange={onChange} required />
      <span>{children}</span>
    </label>
  )
}
