/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { useEffect, useRef, useState } from 'react'
import { SOURCES, SERVERS } from '../data'
import { useStore } from '../store'
import { t } from '../i18n'

export default function Connection() {
  const { lang } = useStore()
  const [ip, setIp] = useState(null)
  const [src, setSrc] = useState(() => SOURCES.map((s) => ({ ...s, ok: null, ms: 0 })))
  const [srv, setSrv] = useState([])
  const [cx, setCx] = useState(null)
  const cursor = useRef(0)
  const round = useRef(0)

  useEffect(() => {
    let stop = false
    fetch('/api/ip').then((r) => r.json()).then(setIp).catch(() => setIp({ error: true }))

    async function tick() {
      if (stop) return
      const start = performance.now()
      try {
        const response = await fetch('https://api.modrinth.com/v2/search?limit=1')
        if (!response.ok) throw new Error('catalogue unavailable')
        if (!stop) setCx(Math.round(performance.now() - start))
      } catch {
        if (!stop) setCx(-1)
      }
      const from = cursor.current
      const batch = SOURCES.slice(from, from + 6)
      cursor.current = (from + 6) % Math.max(SOURCES.length, 1)
      const rows = await Promise.all(batch.map(async (s) => {
        if (String(s.url || '').startsWith('/')) return { ...s, ok: true, ms: Math.max(0, Math.round(performance.now() - start)) }
        try {
          const r = await fetch('/api/ping?url=' + encodeURIComponent(s.url))
          const j = await r.json()
          return { ...s, ok: j.ok, ms: j.ms }
        } catch {
          return { ...s, ok: false, ms: -1 }
        }
      }))
      if (stop) return
      setSrc((prev) => {
        const map = new Map(prev.map((x) => [x.id, x]))
        for (const row of rows) map.set(row.id, row)
        return SOURCES.map((s) => map.get(s.id) || { ...s, ok: null, ms: 0 })
      })
      if (round.current % 3 === 0) {
        const servers = await Promise.all(SERVERS.map(async (s) => {
          try {
            const host = s.ip.split(':')[0]
            const r = await fetch('/api/mcping?host=' + encodeURIComponent(host))
            const j = await r.json()
            return { ...s, ok: !!j.online, ms: j.ms, players: j.players }
          } catch {
            return { ...s, ok: false, ms: -1 }
          }
        }))
        if (!stop) setSrv(servers)
      }
      round.current += 1
    }
    tick()
    const id = setInterval(tick, 8000)
    return () => { stop = true; clearInterval(id) }
  }, [])

  const worst = src.filter((s) => s.ok === false).length
  const status = cx == null ? '…' : cx < 0 || worst > 10 ? '—' : 'ok'

  return (
    <div className="relative z-10 max-w-4xl mx-auto px-4 pt-10">
      <h1 className="font-outfit text-4xl font-bold">{t(lang, 'conn.title')}</h1>
      <div className="glass p-4 mt-6 flex flex-wrap items-center gap-4 text-sm text-white/60">
        <span><i className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-400 mr-2" />доступно</span>
        <span><i className="inline-block w-2.5 h-2.5 rounded-full bg-yellow-400 mr-2" />медленно / проверяется</span>
        <span><i className="inline-block w-2.5 h-2.5 rounded-full bg-red-500 mr-2" />недоступно</span>
        <span className="ml-auto text-xs">Проверки распределены и кэшируются, чтобы не перегружать источники.</span>
      </div>
      <div className="glass p-6 mt-4 grid md:grid-cols-2 gap-4">
        <div><div className="text-white/40 text-xs">{t(lang, 'conn.status')}</div><div className="text-2xl text-orange-soft">{status}</div></div>
        <div><div className="text-white/40 text-xs">{t(lang, 'conn.pingCx')}</div><div className="font-mono text-2xl text-orange-soft">{cx == null ? '…' : cx < 0 ? 'fail' : cx + ' ms'}</div></div>
        <div><div className="text-white/40 text-xs">{t(lang, 'conn.ip')}</div><div className="font-mono">{ip?.ip || '—'} · {ip?.country_name || ip?.country || ''} {ip?.city || ''}</div></div>
        <div><div className="text-white/40 text-xs">{t(lang, 'conn.isp')}</div><div>{ip?.org || ip?.asn || '—'}</div></div>
      </div>
      <h2 className="font-outfit text-xl mt-8 mb-3">{t(lang, 'conn.sources')}</h2>
      <div className="space-y-2">
        {src.map((s) => (
          <div key={s.id} className="glass px-4 py-3 flex items-center gap-3">
            <span className={`w-2.5 h-2.5 rounded-full ${s.ok == null ? 'bg-white/20' : s.ok ? 'bg-emerald-400' : 'bg-red-500'}`} />
            <span className="flex-1 notranslate" data-no-translate="true">{s.name}</span>
            <span className="font-mono text-sm text-white/50">{s.ms} ms</span>
          </div>
        ))}
      </div>
      <h2 className="font-outfit text-xl mt-8 mb-3">{t(lang, 'conn.servers')}</h2>
      <div className="space-y-2">
        {srv.map((s) => (
          <div key={s.ip} className="glass px-4 py-3 flex items-center gap-3">
            <span className={`w-2.5 h-2.5 rounded-full ${s.ok ? 'bg-emerald-400' : 'bg-yellow-400'}`} />
            <span className="flex-1 notranslate" data-no-translate="true">{s.name} <span className="font-mono text-xs text-white/40">{s.ip}</span></span>
            <span className="font-mono text-sm">{s.players != null ? s.players : (s.ms + ' ms')}</span>
          </div>
        ))}
      </div>
    </div>
  )
}
