/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import JSZip from 'jszip'
import { quickSearch, searchProjects, getVersions, saveBlob, fetchArchiveBlob } from '../api'
import {
  analyze, rebuild, enrich, optiPlan, parseCrash, findMod, labelDeps,
  parseParts, parseBuildSpec, mapLimit, splitTasks, MAX_PACK_ITEMS, MAX_PACK_CONCURRENCY,
} from '../packfix'
import { useStore } from '../store'
import { Icon } from '../components/SearchBox'
import { MC_VERSIONS, LOADERS } from '../data'
import { t } from '../i18n'
import { Tx } from '../components/Translated'
import ProjectCard from '../components/ProjectCard'
import DiagnosticsLab from '../components/DiagnosticsLab'

function pickHit(hits, part) {
  const low = String(part || '').toLowerCase()
  return (hits || []).find((h) => String(h.slug).toLowerCase() === low || String(h.title).toLowerCase() === low)
    || (hits || []).find((h) => String(h.slug).toLowerCase().includes(low) || String(h.title).toLowerCase().startsWith(low))
    || (hits || [])[0]
    || null
}

function lineOf(i) {
  return (i.slug || i.title || '') + (i.pin ? ' ' + i.pin : (i.version ? ' ' + i.version : ''))
}

function packFileName(item, kind = 'mod') {
  const fallbackExt = ['mod', 'plugin'].includes(kind) ? '.jar' : '.zip'
  const raw = String(item?.file?.filename || item?.fileName || item?.slug || 'cubenorixx-file')
    .split(/[\\/]/).pop()
    .replace(/[^\w.\-+]+/g, '_')
    .slice(0, 150)
  return /\.(?:jar|zip|mrpack)$/i.test(raw) ? raw : raw + fallbackExt
}

export default function Builds() {
  const { user, db, saveBuild, notify, bump, lang } = useStore()
  const [sp] = useSearchParams()
  const sharedMods = String(sp.get('mods') || '').trim().slice(0, 5000)
  const sharedVersion = String(sp.get('mc') || '')
  const sharedLoader = String(sp.get('loader') || '').toLowerCase()
  const [zipReady, setZipReady] = useState(null)
  const [raw, setRaw] = useState(() => sharedMods || 'create + sodium + lithium + iris + jei')
  const [items, setItems] = useState([])
  const [busy, setBusy] = useState(false)
  const [status, setStatus] = useState('')
  const [pack, setPack] = useState(null)
  const [name, setName] = useState('Cubenorixx-Pack')
  const [kind, setKind] = useState('mod')
  const [version, setVersion] = useState(() => MC_VERSIONS.includes(sharedVersion) ? sharedVersion : '1.21.1')
  const [loader, setLoader] = useState(() => LOADERS.includes(sharedLoader) ? sharedLoader : 'neoforge')
  const [loaderVer, setLoaderVer] = useState(() => String(sp.get('loadver') || '21.1.228'))
  const [crash, setCrash] = useState('')
  const [q, setQ] = useState('')
  const [tab, setTab] = useState('builder')
  const [packs, setPacks] = useState([])
  const [packPage, setPackPage] = useState(1)
  const [packTotal, setPackTotal] = useState(0)
  const [packQuery, setPackQuery] = useState('')
  const [packSearch, setPackSearch] = useState('')
  const [packLoading, setPackLoading] = useState(false)
  const [workerTasks, setWorkerTasks] = useState([])
  const [problems, setProblems] = useState([])
  const [fixLog, setFixLog] = useState([])
  const buildSpec = parseBuildSpec(raw)
  const taskPlan = workerTasks.length ? workerTasks : (buildSpec.parallel ? splitTasks(buildSpec.parts.length) : [])

  useEffect(() => {
    setZipReady(null)
    setWorkerTasks([])
  }, [raw, version, loader, kind, name])

  useEffect(() => {
    let alive = true
    setPackLoading(true)
    searchProjects({
      query: packSearch,
      limit: 24,
      offset: (packPage - 1) * 24,
      index: packSearch ? 'relevance' : 'downloads',
      type: 'modpack',
      facets: [['project_type:modpack']],
    })
      .then((d) => {
        if (!alive) return
        setPacks((d.hits || []).filter((x) => x.project_type === 'modpack').slice(0, 24))
        setPackTotal(Number(d.total_hits) || 0)
      })
      .catch(() => { if (alive) { setPacks([]); setPackTotal(0) } })
      .finally(() => { if (alive) setPackLoading(false) })
    return () => { alive = false }
  }, [packPage, packSearch])

  const resolve = async () => {
    const spec = parseBuildSpec(raw)
    const parts = spec.parts
    if (!parts.length) {
      setFixLog(['Напиши моды через + или с новой строки. Пример: create 6.0.10 + jei + sodium'])
      return
    }
    setBusy(true)
    setWorkerTasks(spec.parallel ? splitTasks(parts.length) : [])
    setStatus(`Ищем ${parts.length} · ${spec.parallel ? `${Math.min(MAX_PACK_CONCURRENCY, parts.length)} задач` : 'бережный режим'}…`)
    setFixLog([])
    const facets = [[`project_type:${kind}`]]
    if (version) facets.push([`versions:${version}`])
    if (loader) facets.push([`categories:${loader}`])

    const planned = spec.parallel ? splitTasks(parts.length) : []
    const found = await mapLimit(parts, spec.parallel ? MAX_PACK_CONCURRENCY : 4, async (part, index) => {
      const taskId = planned.find((x) => index + 1 >= x.from && index + 1 <= x.to)?.id
      if (taskId) setWorkerTasks((rows) => rows.map((x) => x.id === taskId ? { ...x, active: part.q } : x))
      try {
        const data = await quickSearch({ query: part.q, limit: 5, facets })
        const hit = pickHit(data.hits, part.q)
        if (!hit) return { slug: part.q, title: part.q, missing: true, ok: false, pin: part.pin }
        return enrich(hit, version, loader, part.pin)
      } catch {
        return { slug: part.q, title: part.q, ok: false, missing: true, pin: part.pin }
      } finally {
        if (taskId) setWorkerTasks((rows) => rows.map((x) => x.id === taskId ? { ...x, done: Math.min(x.total, x.done + 1), active: '' } : x))
      }
    })

    const loaders = found.flatMap((i) => i.loaders || [])
    const clash = loaders.includes('fabric') && (loaders.includes('forge') || loaders.includes('neoforge'))
    const next = found.map((i) => ({ ...i, clash }))
    const named = await labelDeps(next)
    setItems(named)
    const probs = analyze(named, version, loader, loaderVer)
    setProblems(probs)
    setFixLog([
      spec.parallel ? `Параллельный режим: до ${MAX_PACK_CONCURRENCY} запросов/скачиваний одновременно.` : 'Бережный режим: файлы скачиваются по одному.',
      spec.truncated ? `Лимит ${MAX_PACK_ITEMS}: лишние позиции не добавлены.` : '',
      ...named.filter((i) => i.pinMissing).map((i) => `Нет точной версии: ${i.title || i.slug} ${i.pin}`),
      'Только поиск. Зависимости не добавлял. Для починки жми «Исправить сборку».',
      clash ? 'В списке смешаны Fabric и Forge/NeoForge.' : '',
    ].filter(Boolean))
    setStatus((found.filter((i) => i.ok).length) + ' из ' + parts.length + (probs.length ? ' · есть проблемы' : ' · ок'))
    setBusy(false)
  }

  const fixAll = async () => {
    if (busy) return
    setBusy(true)
    setStatus('Собираю с нуля…')
    setFixLog(['Читаю список…'])
    try {
      let game = version
      let load = loader
      let core = loaderVer
      let text = String(raw || '').trim()
      const extraLog = []

      if (crash.trim()) {
        const info = parseCrash(crash)
        if (info.game) { game = info.game; setVersion(info.game) }
        if (info.loader) { load = info.loader; setLoader(info.loader) }
        if (info.loaderVer) { core = info.loaderVer; setLoaderVer(info.loaderVer) }
        const miss = info.missing.filter((m) => !['neoforge', 'forge', 'minecraft', 'fabricloader', 'fabric-api'].includes(String(m.id).toLowerCase()))
        const nfNeed = info.missing.find((m) => m.id === 'neoforge' || m.id === 'forge')
        if (info.game || info.loader) extraLog.push('Из краша: MC ' + (info.game || '—') + ' · ' + (info.loader || '') + ' ' + (info.loaderVer || '') + (info.java ? ` · Java ${info.java}` : '') + ` · ${info.format}`)
        for (const issue of info.issues || []) extraLog.push(`${issue.kind}: ${issue.text}`)
        if (miss.length) {
          const add = miss.map((m) => m.id).join(' + ')
          text = text ? (text + ' + ' + add) : add
          extraLog.push('Из краша в список: ' + miss.map((m) => m.id).join(', '))
        }
        if (nfNeed) {
          extraLog.push((nfNeed.by || 'мод') + ' хочет ' + nfNeed.id + ' ' + nfNeed.range + ', сейчас ' + (nfNeed.actual || info.loaderVer) + '. Это ядро, не мод — обнови лоадер или возьми более старый мод.')
        }
      }

      if (!parseParts(text).length && items.length) {
        text = items.map(lineOf).join(' + ')
      }
      if (!parseParts(text).length) {
        setFixLog(['Пустой список. Напиши моды: create 6.0.10 + sodium'])
        setStatus('нет списка')
        setBusy(false)
        return
      }

      const repairSpec = parseBuildSpec(text)
      setWorkerTasks(repairSpec.parallel ? splitTasks(repairSpec.parts.length) : [])
      const res = await rebuild(text, game, load)
      const named = await labelDeps(res.items)
      if (repairSpec.parallel) setWorkerTasks((rows) => rows.map((x) => ({ ...x, done: x.total, active: '' })))
      setItems(named)
      const prefix = parseBuildSpec(text).parallel ? '# ' : ''
      setRaw(prefix + named.map(lineOf).join(' + '))
      if (res.loader && res.loader !== load) setLoader(res.loader)
      const probs = analyze(named, game, res.loader || load, core)
      setProblems(probs)
      setFixLog([...extraLog, ...(res.log || [])])
      setStatus('Готово: ' + named.filter((i) => i.ok).length)
    } catch (e) {
      setFixLog(['Авто упало: ' + String(e.message || e)])
      setStatus('Авто не вышло')
    }
    setBusy(false)
  }

  const applyOpti = async () => {
    if (busy) return
    setKind('mod')
    setName('Cubenorixx-Opti')
    setBusy(true)
    setStatus('Смотрю сборку…')
    const plan = optiPlan(items, loader)
    const add = plan.add.slice(0, 8)
    if (!add.length && items.length) {
      setFixLog(['Оптимизация уже стоит: ' + (plan.keep.join(', ') || '—') + (plan.skip.length ? '. Пропустил из‑за конфликта: ' + plan.skip.join(', ') : '')])
      setBusy(false)
      setStatus('Уже оптимизировано')
      return
    }
    setStatus('Подбираю оптимизацию…')
    const facets = [['project_type:mod']]
    if (version) facets.push([`versions:${version}`])
    if (loader) facets.push([`categories:${loader}`])
    const extra = await Promise.all(add.map(async (part) => {
      try {
        const data = await quickSearch({ query: part, limit: 5, facets })
        const hit = pickHit(data.hits, part)
        if (!hit) return null
        return enrich(hit, version, loader)
      } catch { return null }
    }))
    const have = new Set(items.map((i) => String(i.slug || '').toLowerCase()))
    const more = extra.filter((x) => x && x.ok && !have.has(String(x.slug).toLowerCase()))
    const next = [...items, ...more]
    setItems(next)
    setRaw((buildSpec.parallel ? '# ' : '') + next.map((i) => i.slug || i.title).join(' + '))
    setProblems(analyze(next, version, loader, loaderVer))
    setFixLog([
      more.length ? 'Добавил: ' + more.map((x) => x.title).join(', ') : (items.length ? 'Новых модов нет' : 'Собрал пакет оптимизации: ' + add.join(', ')),
      plan.keep.length ? 'Уже были: ' + plan.keep.join(', ') : '',
      plan.skip.length ? 'Пропустил из‑за конфликта: ' + plan.skip.join(', ') : '',
    ].filter(Boolean))
    setStatus('+' + more.length)
    setBusy(false)
  }

  const zipIt = async () => {
    if (zipReady?.blob) {
      saveBlob(zipReady.blob, zipReady.name)
      notify(t(lang, 'toast.downloaded'))
      return
    }
    if (!items.length || pack) return
    const spec = parseBuildSpec(raw)
    const concurrency = spec.parallel ? MAX_PACK_CONCURRENCY : 1
    const mods = items.filter((i) => i.ok).slice(0, MAX_PACK_ITEMS)
    if (!mods.length) {
      setFixLog(['Нет совместимых файлов для ZIP. Проверь версии модов, Minecraft и загрузчик.'])
      return
    }
    const planned = spec.parallel ? splitTasks(mods.length) : []
    setWorkerTasks(planned)
    setPack({ pct: 4, now: 0, total: mods.length, name: `метаданные · ${concurrency} поток(ов)` })
    const zip = new JSZip()
    await mapLimit(mods, concurrency, async (i, index) => {
      const taskId = planned.find((x) => index + 1 >= x.from && index + 1 <= x.to)?.id
      if (taskId) setWorkerTasks((rows) => rows.map((x) => x.id === taskId ? { ...x, active: i.title || i.slug } : x))
      try {
        if (!i.file?.url) {
          const vs = await getVersions(i.slug)
          const v = i.pin
            ? (vs || []).find((x) => String(x.version_number || '').replace(/^v/i, '').toLowerCase() === String(i.pin).replace(/^v/i, '').toLowerCase())
            : (vs || []).find((x) => (x.game_versions || []).includes(version) && (x.loaders || []).includes(loader))
              || (vs || []).find((x) => (x.loaders || []).includes(loader))
              || vs?.[0]
          i.file = v?.files?.find((f) => f.primary) || v?.files?.[0]
          i.version = v?.version_number || i.version
          i.versionId = v?.id || i.versionId
          i.games = v?.game_versions || i.games || []
          i.loaders = v?.loaders || i.loaders || []
          i.dependencies = v?.dependencies || i.dependencies || []
        }
        i.hashes = i.file?.hashes || i.hashes || {}
        i.fileSize = i.file?.size || i.fileSize || 0
      } catch {}
      finally {
        if (taskId) setWorkerTasks((rows) => rows.map((x) => x.id === taskId ? { ...x, active: '' } : x))
      }
    })
    const generated = new Date().toISOString()
    const projectItems = mods.map((i) => ({
      slug: i.slug,
      projectId: i.project_id || i.id || null,
      title: i.title,
      author: i.author || null,
      sourceUrl: i.sourceUrl || (i.slug ? `https://modrinth.com/project/${i.slug}` : null),
      version: i.version || null,
      versionId: i.versionId || null,
      pinned: i.pin || null,
      gameVersions: i.games || (i.game ? [i.game] : []),
      loaders: i.loaders || [],
      file: i.file ? { filename: i.file.filename, url: i.file.url, size: i.file.size || 0, hashes: i.file.hashes || {} } : null,
      dependencies: i.dependencies || [],
      license: i.license || null,
    }))
    const cubenorixxProject = {
      schema: 'https://cubenorixx.pages.dev/schemas/project-v2.json',
      format: 2,
      app: 'Cubenorixx',
      generated,
      pack: { name, kind, minecraft: version, loader, loaderVersion: loaderVer || null },
      execution: { requested: spec.parts.length, parallel: spec.parallel, concurrency, limit: MAX_PACK_ITEMS },
      items: projectItems,
    }
    const manifest = {
      format: 2,
      name, version, loader, loaderVersion: loaderVer || null, kind, generated,
      requested: spec.parts.length,
      parallel: spec.parallel,
      concurrency,
      files: projectItems,
    }
    const loaderKey = loader === 'fabric' ? 'fabric-loader' : (loader === 'quilt' ? 'quilt-loader' : loader)
    const mrIndex = {
      formatVersion: 1,
      game: 'minecraft',
      versionId: name,
      name,
      summary: `Exported by Cubenorixx · ${mods.length} projects`,
      files: mods.filter((i) => i.file?.url).map((i) => ({
        path: `mods/${packFileName(i, kind)}`,
        hashes: i.file.hashes || {},
        env: { client: 'required', server: 'required' },
        downloads: [i.file.url],
        fileSize: i.file.size || 0,
      })),
      dependencies: { minecraft: version, ...(loaderVer ? { [loaderKey]: loaderVer } : {}) },
    }
    zip.file('cubenorixx-project.json', JSON.stringify(cubenorixxProject, null, 2))
    zip.file('manifest.json', JSON.stringify(manifest, null, 2))
    zip.file('modrinth.index.json', JSON.stringify(mrIndex, null, 2))
    zip.file('README.txt', `Cubenorixx ready mod pack\n\n${name}\nMinecraft ${version}\n${loader} ${loaderVer || ''}\n${mods.length} projects\n\nГОТОВЫЕ МОДЫ: открой папку mods — внутри находятся настоящие .jar файлы. Скопируй их в .minecraft/mods.\nREAL MOD FILES: open the mods folder and copy its .jar files to .minecraft/mods.\n\nMetadata files in the archive root preserve project IDs, exact versions, hashes, dependencies and source URLs for re-import into Cubenorixx.\n`)
    zip.file('LINKS.txt', mods.map((i) => `${i.title} ${i.version || ''}\n${i.sourceUrl || `https://modrinth.com/project/${i.slug}`}\n${i.file?.url || ''}\nSHA-256: ${i.file?.hashes?.sha256 || 'not supplied by source'}`).join('\n\n'))
    let downloaded = 0
    let finished = 0
    let failed = 0
    const queue = mods.filter((i) => i.file?.url)
    const downloadPlan = spec.parallel ? splitTasks(queue.length) : []
    if (spec.parallel) setWorkerTasks(downloadPlan)
    const usedNames = new Map()
    await mapLimit(queue, concurrency, async (i, index) => {
      const taskId = downloadPlan.find((x) => index + 1 >= x.from && index + 1 <= x.to)?.id
      if (taskId) setWorkerTasks((rows) => rows.map((x) => x.id === taskId ? { ...x, active: i.file?.filename || i.title } : x))
      const original = packFileName(i, kind)
      const seen = usedNames.get(original) || 0
      usedNames.set(original, seen + 1)
      const prefix = String(i.slug || 'mod').replace(/[^\w.-]+/g, '_')
      const fname = seen ? `${prefix}-${seen + 1}-${original}` : original
      try {
        const blob = await fetchArchiveBlob({ ...i.file, filename: fname })
        zip.file('mods/' + fname, blob, { binary: true, compression: 'STORE' })
        downloaded += 1
      } catch {
        failed += 1
      } finally {
        finished += 1
        if (taskId) setWorkerTasks((rows) => rows.map((x) => x.id === taskId ? { ...x, done: Math.min(x.total, x.done + 1), active: '' } : x))
        setPack({
          pct: Math.min(92, Math.round((finished / Math.max(queue.length, 1)) * 86) + 6),
          now: finished,
          total: queue.length,
          name: fname,
        })
      }
    })
    if (!downloaded) {
      setPack(null)
      setZipReady(null)
      setFixLog((prev) => [
        'ZIP не создан: ни один настоящий JAR/ZIP не был получен. Метаданные без модов больше не выдаются как готовая сборка.',
        'Проверь Minecraft, загрузчик и версии модов, затем нажми «Исправить сборку» и скачай снова.',
        ...prev,
      ])
      return
    }
    setPack({ pct: 96, now: downloaded, total: queue.length, name: 'ZIP…' })
    const blob = await zip.generateAsync({ type: 'blob', compression: 'STORE' })
    const outName = (name || 'Cubenorixx-Pack').replace(/[^a-zа-яё0-9._-]+/gi, '-').replace(/-+/g, '-') + '.zip'
    setPack({ pct: 100, now: downloaded, total: queue.length, name: outName })
    saveBlob(blob, outName)
    setZipReady({ blob, name: outName })
    bump('builds')
    if (user) saveBuild({ id: crypto.randomUUID(), name, items: projectItems, icon_url: '/no-icon.png', minecraft: version, loader, loaderVersion: loaderVer, created: Date.now() })
    setFixLog((prev) => [
      `Готовая сборка: ${downloaded} настоящих JAR/ZIP в папке mods · режим ${spec.parallel ? `до ${MAX_PACK_CONCURRENCY} одновременно` : 'по одному'}`,
      failed ? `Не удалось скачать: ${failed}. Их ссылки сохранены в LINKS.txt; остальные моды находятся в mods/.` : 'Все доступные моды добавлены в mods/.',
      ...prev,
    ])
    notify(t(lang, 'toast.downloaded'))
    setTimeout(() => setPack(null), 1200)
  }

  const eatCrash = async () => {
    const info = parseCrash(crash)
    if (!info.missing.length && !info.game && !(info.issues || []).length) {
      setFixLog(['Не распознал формат. Поддерживаются latest.log, debug.log, crash-report, launcher_log.txt и hs_err_pid*.log.'])
      return
    }
    if (info.game) setVersion(info.game)
    if (info.loader) setLoader(info.loader)
    if (info.loaderVer) setLoaderVer(info.loaderVer)
    setKind('mod')
    setBusy(true)
    setStatus('Читаю краш…')
    const game = info.game || version
    const load = info.loader || loader
    const miss = info.missing.filter((m) => !['neoforge', 'forge', 'minecraft'].includes(String(m.id).toLowerCase()))
    const nfNeed = info.missing.find((m) => m.id === 'neoforge' || m.id === 'forge')
    const extra = await mapLimit(miss.slice(0, MAX_PACK_ITEMS), MAX_PACK_CONCURRENCY, (m) => findMod(m.id, game, load))
    const have = new Set(items.map((i) => String(i.slug || '').toLowerCase()))
    const more = extra.filter((x) => x && x.ok && !have.has(String(x.slug).toLowerCase()))
    const next = [...items, ...more]
    setItems(next)
    setRaw((buildSpec.parallel ? '# ' : '') + next.map((i) => i.slug || i.title).join(' + '))
    const probs = analyze(next, game, load, info.loaderVer || loaderVer)
    for (const issue of info.issues || []) probs.unshift({ kind: issue.kind === 'duplicate' || issue.kind === 'mixin' ? 'conflict' : 'version', text: issue.text })
    if (nfNeed) {
      probs.unshift({
        kind: 'version',
        text: (nfNeed.by || 'мод') + ' хочет ' + nfNeed.id + ' ' + nfNeed.range + ', у тебя ' + (nfNeed.actual || info.loaderVer) + '. Ядро, не мод.',
      })
    }
    setProblems(probs)
    setFixLog([
      (info.loaderVer || info.game) ? ('Формат: ' + info.format + ' · Ядро: ' + (info.loader || '—') + ' ' + (info.loaderVer || '') + ' · MC ' + (info.game || '—') + (info.java ? ' · Java ' + info.java : '')) : '',
      ...(info.issues || []).map((x) => `${x.kind}: ${x.text}`),
      more.length ? ('Из краша добавил: ' + more.map((x) => x.title + ' ' + (x.version || '')).join(', ')) : 'Новых модов из краша нет',
      nfNeed ? ('NeoForge/Forge — ядро. Нужен ' + nfNeed.range + ', сейчас ' + (nfNeed.actual || info.loaderVer) + '. Обнови лоадер или поставь более старый мод.') : '',
    ].filter(Boolean))
    setStatus('краш: +' + more.length)
    setBusy(false)
  }

  const importProject = async (picked) => {
    if (!picked) return
    setBusy(true)
    setStatus('Импортирую метаданные…')
    try {
      let data
      if (/\.(zip|mrpack)$/i.test(picked.name)) {
        const archive = await JSZip.loadAsync(picked)
        const names = ['cubenorixx-project.json', 'manifest.json', 'modrinth.index.json']
        const entry = names.map((n) => archive.file(n)).find(Boolean)
        if (!entry) throw new Error('В ZIP нет cubenorixx-project.json, manifest.json или modrinth.index.json')
        data = JSON.parse(await entry.async('text'))
      } else {
        data = JSON.parse(await picked.text())
      }
      const packMeta = data.pack || data
      const rawRows = Array.isArray(data.items) ? data.items : (Array.isArray(data.files) ? data.files : [])
      const normalized = rawRows.slice(0, MAX_PACK_ITEMS).map((row, index) => {
        const f = row.file && typeof row.file === 'object'
          ? row.file
          : (row.downloads?.[0] ? { filename: String(row.path || '').split('/').pop(), url: row.downloads[0], size: row.fileSize || 0, hashes: row.hashes || {} } : null)
        const fallback = String(row.path || f?.filename || `imported-${index + 1}`).replace(/^.*\//, '').replace(/\.jar$/i, '')
        return {
          slug: row.slug || row.projectId || fallback,
          id: row.projectId || row.id || '',
          project_id: row.projectId || row.project_id || '',
          title: row.title || row.slug || fallback,
          author: row.author || '',
          sourceUrl: row.sourceUrl || '',
          version: row.version || '',
          versionId: row.versionId || '',
          pin: row.pinned || row.version || '',
          game: (row.gameVersions || [])[0] || packMeta.minecraft || data.version || version,
          games: row.gameVersions || [],
          loaders: row.loaders || (packMeta.loader ? [packMeta.loader] : []),
          file: f,
          hashes: f?.hashes || row.hashes || {},
          dependencies: row.dependencies || [],
          ok: Boolean(f?.url || row.slug || row.projectId),
          imported: true,
        }
      })
      const nextVersion = packMeta.minecraft || data.version || data.dependencies?.minecraft || version
      const nextLoader = packMeta.loader || data.loader || Object.keys(data.dependencies || {}).find((x) => x !== 'minecraft')?.replace('-loader', '') || loader
      const nextLoaderVer = packMeta.loaderVersion || data.loaderVersion || data.dependencies?.[Object.keys(data.dependencies || {}).find((x) => x !== 'minecraft')] || loaderVer
      if (packMeta.name || data.name) setName(packMeta.name || data.name)
      setVersion(nextVersion)
      setLoader(nextLoader)
      setLoaderVer(nextLoaderVer)
      setItems(normalized)
      const parallel = Boolean(data.execution?.parallel ?? data.parallel)
      setRaw((parallel ? '# ' : '') + normalized.map((x) => `${x.slug}${x.pin ? ` ${x.pin}` : ''}`).join(' + '))
      setWorkerTasks(parallel ? splitTasks(normalized.length) : [])
      setProblems(analyze(normalized, nextVersion, nextLoader, nextLoaderVer))
      setFixLog([
        `Импортировано ${normalized.length} позиций из ${picked.name}.`,
        'Сохранены project ID, version ID, ссылки источников, зависимости и SHA-хэши, если они были в архиве.',
        rawRows.length > MAX_PACK_ITEMS ? `Лимит ${MAX_PACK_ITEMS}: остаток не импортирован.` : '',
      ].filter(Boolean))
      setStatus(`Импорт: ${normalized.length}`)
    } catch (e) {
      setFixLog(['Импорт не удался: ' + String(e.message || e)])
      setStatus('Ошибка импорта')
    } finally {
      setBusy(false)
    }
  }

  const dropItem = (slug) => {
    const next = items.filter((i) => i.slug !== slug)
    setItems(next)
    setRaw((buildSpec.parallel ? '# ' : '') + next.map(lineOf).join(' + '))
    setProblems(analyze(next, version, loader, loaderVer))
    setZipReady(null)
  }

  const shown = items.filter((i) => !q || (i.title + i.slug).toLowerCase().includes(q.toLowerCase()))

  return (
    <div className="relative z-10 max-w-4xl mx-auto px-4 pt-10">
      <h1 className="font-outfit text-4xl font-bold">{t(lang, 'builds.title')}</h1>
      <p className="text-white/60 mt-2">{t(lang, 'builds.lead')}</p>
      <div className="flex gap-2 mt-4">
        <button className={`tag ${tab === 'builder' ? 'on' : ''}`} onClick={() => setTab('builder')}>{t(lang, 'builds.builder')}</button>
        <button className={`tag ${tab === 'ready' ? 'on' : ''}`} onClick={() => setTab('ready')}>{t(lang, 'builds.packs')}</button>
      </div>
      {tab === 'ready' && (
        <div className="mt-6">
          <div className="glass p-4 mb-4">
            <div className="flex flex-wrap items-end justify-between gap-3">
              <div>
                <h2 className="font-outfit text-2xl">Все сборки мира</h2>
                <p className="text-sm text-white/45 mt-1">{packLoading ? 'Обновляю каталог…' : `${packTotal.toLocaleString()} модпаков · страница ${packPage} из ${Math.max(1, Math.ceil(packTotal / 24))}`}</p>
              </div>
              <form className="flex gap-2 w-full sm:w-auto" onSubmit={(e) => { e.preventDefault(); setPackPage(1); setPackSearch(packQuery.trim()) }}>
                <input className="field sm:w-72" value={packQuery} onChange={(e) => setPackQuery(e.target.value)} placeholder="Название, автор, тема…" />
                <button className="btn btn-primary px-5">Найти</button>
              </form>
            </div>
          </div>
          {packLoading ? <div className="glass p-8 text-center text-white/45">Загружаю страницу…</div> : (
            <div className="catalog-list">{packs.map((p) => <ProjectCard key={p.slug} p={p} />)}</div>
          )}
          <div className="flex items-center justify-center gap-3 mt-5">
            <button className="btn btn-ghost px-5 py-2" disabled={packPage <= 1 || packLoading} onClick={() => { setPackPage((p) => Math.max(1, p - 1)); window.scrollTo({ top: 0, behavior: 'smooth' }) }}>← Назад</button>
            <span className="font-mono text-orange-soft">{packPage} / {Math.max(1, Math.ceil(packTotal / 24))}</span>
            <button className="btn btn-ghost px-5 py-2" disabled={packPage >= Math.max(1, Math.ceil(packTotal / 24)) || packLoading} onClick={() => { setPackPage((p) => p + 1); window.scrollTo({ top: 0, behavior: 'smooth' }) }}>Вперёд →</button>
          </div>
        </div>
      )}
      {tab === 'builder' && (
      <div>
      <div className="glass p-4 mt-4">
        <div className="font-outfit text-lg">{t(lang, 'builds.fix')}</div>
        <p className="text-sm text-white/55 mt-1 leading-6">{t(lang, 'builds.fixLead')}</p>
      </div>
      <button className="glass p-4 text-left hover:border-orange/40 mt-3 w-full" onClick={applyOpti} disabled={busy}>
        <div className="font-outfit text-lg">{t(lang, 'builds.opt')}</div>
        <div className="text-sm text-white/50">{t(lang, 'builds.optLead')}</div>
      </button>
      <div className="grid md:grid-cols-4 gap-2 mt-4">
        <select className="field" value={kind} onChange={(e) => setKind(e.target.value)}>
          {['mod','plugin','modpack','shader','datapack','resourcepack'].map((k) => <option key={k} className="bg-[#12122A]" value={k}>{k}</option>)}
        </select>
        <select className="field font-mono" value={version} onChange={(e) => setVersion(e.target.value)}>
          {MC_VERSIONS.filter((v) => !v.includes('…')).slice().reverse().map((v) => <option key={v} className="bg-[#12122A]">{v}</option>)}
        </select>
        <select className="field" value={loader} onChange={(e) => setLoader(e.target.value)}>
          {LOADERS.map((l) => <option key={l} className="bg-[#12122A]">{l}</option>)}
        </select>
        <input className="field font-mono" placeholder={t(lang, 'builds.corePh')} value={loaderVer} onChange={(e) => setLoaderVer(e.target.value)} />
      </div>
      <input className="field mt-2" placeholder={t(lang, 'builds.searchIn')} value={q} onChange={(e) => setQ(e.target.value)} />
      <textarea
        className="field mt-3 min-h-[110px] font-mono"
        value={raw}
        onChange={(e) => setRaw(e.target.value)}
        placeholder={'create + jei + sodium\ncreate 6.0.10 + jei 19.21.0.247 + sodium 0.6.13\n# create + jei + sodium  ← до 12 одновременно'}
      />
      <div className={`pack-mode ${buildSpec.parallel ? 'turbo' : ''}`}>
        <div>
          <b>{buildSpec.parallel ? `# Параллельно · до ${MAX_PACK_CONCURRENCY}` : 'Бережно · по одному'}</b>
          <span>{buildSpec.parts.length}/{MAX_PACK_ITEMS} модов</span>
        </div>
        <p>
          Без версии выбирается совместимый свежий файл. Запись <code>mod 1.2.3</code> требует именно эту версию.
          Символ <code>#</code> в самом начале включает параллельный поиск и скачивание.
        </p>
      </div>
      {buildSpec.parallel && taskPlan.length ? (
        <div className="task-board" aria-live="polite">
          <div className="task-board-head">
            <b>{buildSpec.parts.length} элементов разделено на {taskPlan.length} задач</b>
            <span>до {MAX_PACK_CONCURRENCY} одновременно · не последовательная очередь</span>
          </div>
          <div className="task-grid">
            {taskPlan.map((task) => (
              <div key={task.id} className={'task-cell ' + (task.done >= task.total ? 'done' : (task.active ? 'active' : ''))}>
                <span>#{task.id}</span>
                <b>{task.done}/{task.total}</b>
                <small title={task.active || `позиции ${task.from}–${task.to}`}>{task.active || `${task.from}–${task.to}`}</small>
              </div>
            ))}
          </div>
        </div>
      ) : null}
      <details className="mt-2">
        <summary className="text-xs text-white/40 cursor-pointer">{t(lang, 'builds.crashLog')}</summary>
        <textarea className="field mt-2 min-h-[72px] font-mono text-xs" placeholder="architectury [13.0.8,) MISSING …" value={crash} onChange={(e) => setCrash(e.target.value)} />
      </details>
      <div className="flex gap-2 mt-3 flex-wrap items-center">
        <button className="btn btn-primary px-6 py-3" onClick={fixAll} disabled={busy}>{busy ? t(lang, 'builds.fixing') : t(lang, 'builds.fix')}</button>
        <button className="btn btn-ghost px-5 py-2" onClick={resolve} disabled={busy}>{busy ? t(lang, 'builds.picking') : t(lang, 'builds.pick')}</button>
        <button className="btn btn-ghost px-5 py-2" onClick={eatCrash} disabled={busy || !crash.trim()}>{t(lang, 'builds.readCrash')}</button>
        <input className="field max-w-xs" value={name} onChange={(e) => setName(e.target.value)} />
        <label className="btn btn-ghost px-5 py-2 cursor-pointer">
          Импорт проекта
          <input type="file" className="sr-only" accept=".json,.zip,.mrpack" onChange={(e) => { importProject(e.target.files?.[0]); e.target.value = '' }} />
        </label>
        <button className="btn btn-primary px-6 py-3" onClick={zipIt} disabled={!items.length || !!pack}>
          {pack ? t(lang, 'builds.zipping') : (zipReady ? t(lang, 'builds.zipAgain') : t(lang, 'builds.zip'))}
        </button>
        {status ? <span className="text-xs text-white/45 font-mono">{status}</span> : null}
      </div>
      <p className="text-[11px] text-white/35 mt-2">{t(lang, 'builds.coreNote')}</p>
      {problems.length ? (
        <div className="pack-warn">
          {problems.slice(0, 8).map((p, i) => (
            <div key={i} className={'pack-line ' + p.kind}>
              <Tx text={p.text} />
              {p.slug ? <a className="problem-link" href={'/project/' + encodeURIComponent(p.slug)}>Открыть проект{p.version ? ` · v${p.version}` : ''} →</a> : null}
            </div>
          ))}
          {problems.length > 8 ? <div className="text-xs text-white/40">{t(lang, 'builds.more')} {problems.length - 8}</div> : null}
        </div>
      ) : null}
      {fixLog.length ? (
        <div className="pack-log">
          {fixLog.map((s, i) => <div key={i} className="pack-line"><Tx text={s} /></div>)}
        </div>
      ) : null}
      {pack ? (
        <div className="zip-anim">
          <div className="flex justify-between text-xs text-white/55 mb-1">
            <span className="truncate pr-3">{pack.name}</span>
            <span className="font-mono shrink-0">{pack.now}/{pack.total} · {pack.pct}%</span>
          </div>
          <div className="progress"><div style={{ width: pack.pct + '%' }} /></div>
        </div>
      ) : null}
      <DiagnosticsLab items={items} onLog={(text, fileName) => { setCrash(text); setFixLog([`${fileName} загружен локально в поле диагностики. Нажми «Разобрать краш».`]); setStatus('лог готов') }} />
      <div className="mt-6 space-y-2">
        {shown.map((i) => (
          <div key={i.slug} className="glass p-3 flex items-center gap-3">
            <span className={`w-3 h-3 rounded-full ${i.ok && !i.clash ? 'bg-emerald-400' : 'bg-red-500'}`} />
            <Icon src={i.icon_url} letter={i.title} className="w-10 h-10" />
            <div className="min-w-0 flex-1">
              <div className="font-semibold truncate">{i.title} {i.dep && <span className="text-xs text-white/40">требование</span>}</div>
              <div className="font-mono text-xs text-white/50">{i.version || '—'} · {(i.loaders || [])[0] || loader} · {i.game || version}</div>
            </div>
            <button type="button" className="tag" onClick={() => dropItem(i.slug)}>✕</button>
          </div>
        ))}
      </div>
      {user && db.builds.length > 0 && (
        <div className="mt-10">
          <h2 className="font-outfit text-2xl mb-3">{t(lang, 'builds.saved')}</h2>
          {db.builds.map((b) => (
            <div key={b.id} className="glass p-3 mb-2 flex items-center gap-3">
              <Icon src={b.icon_url} letter={b.name || 'B'} className="w-12 h-12" />
              <span>{b.name} · {b.items?.length || 0} {b.status === 'accepted' && '√'}</span>
            </div>
          ))}
        </div>
      )}
      </div>
      )}
    </div>
  )
}

