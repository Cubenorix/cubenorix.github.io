/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { SOURCES, LOCAL_CONTENT } from '../data'
import SourceLogo from '../components/SourceLogo'
import ProjectCard from '../components/ProjectCard'
import { allLocal } from '../localMore'
import { useStore } from '../store'
import { t } from '../i18n'
import { formatNumber } from '../languages'

const LIVE_HINT = {
  api: 'Живой API — карточки и счётчик обновляются сами.',
  search: 'Поиск по запросу. Своего счётчика проектов нет — в сумму на главной не входит.',
  skin: 'Только ник игрока: Mojang отдаёт UUID и скин.',
  core: 'Официальная страница ядра / загрузчика. Не каталог модов.',
  directory: 'Справочный каталог: открываем карточки источника без массового обхода.',
  tool: 'Инструмент или документация, а не источник файлов.',
  local: 'Наш поиск и передача файла.',
}

export default function SourcePage() {
  const { lang } = useStore()
  const { id } = useParams()
  const s = SOURCES.find((x) => x.id === id)
  const [count, setCount] = useState(null)
  useEffect(() => {
    if (!s || s.live !== 'api') return
    fetch('/api/live').then((r) => r.json()).then((j) => {
      const n = j?.by?.[s.id]
      if (n) setCount(n)
    }).catch(() => {})
  }, [s])
  if (!s) {
    return (
      <div className="relative z-10 max-w-xl mx-auto mt-16 glass p-8">
        <h1 className="font-outfit text-2xl">{t(lang, 'pages.sourceMiss')}</h1>
        <Link to="/" className="btn btn-primary inline-flex mt-4 px-5 py-2">{t(lang, 'ui.home')}</Link>
      </div>
    )
  }
  const local = Object.values(allLocal(LOCAL_CONTENT)).flat().filter((x) => (x.sources || []).includes(s.id)).slice(0, 12)
  return (
    <div className="relative z-10 max-w-4xl mx-auto px-4 pt-10 pb-16">
      <div className="glass p-6 sm:p-8 flex flex-col sm:flex-row gap-5 items-start">
        <SourceLogo id={s.id} name={s.name} color={s.color} size={64} />
        <div className="min-w-0 flex-1">
          <h1 className="font-outfit text-3xl font-bold" style={{ color: s.color }}>{s.name}</h1>
          <p className="text-orange-soft text-sm mt-1">{s.types}</p>
          <p className="text-white/60 mt-3 leading-7">{s.desc || s.types}</p>
          <p className="text-xs text-white/40 mt-3">{LIVE_HINT[s.live] || ''}{count ? ' · ' + formatNumber(count, lang) : ''}</p>
          <div className="flex flex-wrap gap-2 mt-5">
            <a className="btn btn-primary px-5 py-2" href={s.url} target="_blank" rel="noreferrer">{t(lang, 'pages.openSite')}</a>
            <Link className="btn btn-ghost px-5 py-2" to={'/catalog?q=&type=all'}>{t(lang, 'project.toCatalog')}</Link>
          </div>
        </div>
      </div>
      {local.length > 0 && (
        <div className="mt-8 grid md:grid-cols-2 gap-3">
          {local.map((p) => <ProjectCard key={p.slug} p={p} />)}
        </div>
      )}
    </div>
  )
}
