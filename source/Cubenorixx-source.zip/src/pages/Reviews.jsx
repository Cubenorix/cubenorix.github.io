/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { useMemo, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { useStore } from '../store'
import ReviewCard from '../components/ReviewCard'
import { t } from '../i18n'
export default function Reviews() {
  const { user, db, addReview, notify, lang } = useStore()
  const [sp] = useSearchParams()
  const slug = sp.get('slug') || 'cubenorixx'
  const [stars, setStars] = useState(0)
  const [sort, setSort] = useState('best')
  const [text, setText] = useState('')
  const [mark, setMark] = useState(5)

  const all = useMemo(() => {
    const local = [...(db.reviews?.[slug] || [])]
    const seen = new Set()
    return local.filter((r) => {
      if (!r?.id || seen.has(r.id)) return false
      seen.add(r.id)
      return true
    })
  }, [db.reviews, slug])

  let list = all.filter((r) => !stars || r.stars === stars)
  if (sort === 'new') list = [...list].sort((a, b) => (b.at || 0) - (a.at || 0))
  else if (sort === 'low') list = [...list].sort((a, b) => (a.stars || 0) - (b.stars || 0))
  else list = [...list].sort((a, b) => (b.stars - a.stars) || ((b.up || 0) - (a.up || 0)))

  const send = (e) => {
    e.preventDefault()
    if (!user) return
    if (!text.trim()) return
    addReview(slug, mark, text.trim(), '—', 0)
    setText('')
    notify(t(lang, 'toast.saved'))
  }

  return (
    <div className="relative z-10 max-w-5xl mx-auto px-4 pt-8 pb-16">
      <h1 className="font-outfit text-3xl">{t(lang, 'review.title')}</h1>
      <p className="text-white/50 mt-2">{slug === 'cubenorixx' ? t(lang, 'review.aboutCx') : t(lang, 'review.aboutP') + ' ' + slug}</p>

      <div className="flex flex-wrap gap-2 mt-5">
        <button className={'tag' + (stars === 0 ? ' on' : '')} onClick={() => setStars(0)}>{t(lang, 'catalog.all')}</button>
        {[5, 4, 3, 2, 1].map((n) => (
          <button key={n} className={'tag' + (stars === n ? ' on' : '')} onClick={() => setStars(n)}>{n}★</button>
        ))}
        <select className="field w-auto py-2 text-sm" value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="best" className="bg-[#12122A]">{t(lang, 'review.firstBest')}</option>
          <option value="new" className="bg-[#12122A]">{t(lang, 'review.firstNew')}</option>
          <option value="low" className="bg-[#12122A]">{t(lang, 'review.firstLow')}</option>
        </select>
      </div>

      <p className="font-mono text-xs text-white/35 mt-3 mb-4">{list.length}</p>
      <div className="rev-grid">
        {list.map((r) => <ReviewCard key={r.id} r={r} />)}
      </div>
      {!list.length && <p className="text-white/45 mt-6">{t(lang, 'review.emptyHome')}</p>}

      <div className="glass p-5 mt-10">
        <h2 className="font-outfit text-xl mb-3">{t(lang, 'review.write')}</h2>
        {user ? (
          <form onSubmit={send} className="space-y-3">
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((n) => (
                <button type="button" key={n} className={'star text-2xl ' + (n <= mark ? 'on' : '')} onClick={() => setMark(n)}>★</button>
              ))}
            </div>
            <textarea className="field min-h-[96px]" value={text} onChange={(e) => setText(e.target.value)} placeholder={t(lang, 'review.ph')} maxLength={400} />
            <button className="btn btn-primary px-5 py-2">{t(lang, 'review.publish')}</button>
          </form>
        ) : (
          <p className="text-white/55">{t(lang, 'review.needLogin')} <Link className="text-orange-soft" to="/login">{t(lang, 'auth.login')}</Link></p>
        )}
      </div>
    </div>
  )
}
