/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { useEffect, useState } from 'react'
import { Link, useParams, useSearchParams } from 'react-router-dom'
import { HOSTINGS, FILTERS, SERVERS, SERVER_LISTS, GUIDES, WIKI, FORUM_THREADS } from '../data'
import { BodyMd, Tx } from '../components/Translated'
import { useStore } from '../store'
import { t } from '../i18n'
import { WIKI_EXTRA } from '../wiki'
import { formatNumber } from '../languages'
import { LEGAL_TEXTS } from '../legal-content'

async function fetchJsonTimed(url, timeout = 7000) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeout)
  try {
    const response = await fetch(url, { signal: controller.signal, headers: { Accept: 'application/json' } })
    const type = response.headers.get('content-type') || ''
    if (!response.ok || !type.includes('application/json')) throw new Error('status unavailable')
    return response.json()
  } finally {
    clearTimeout(timer)
  }
}

export function Servers() {
  const [q, setQ] = useState('')
  const [checks, setChecks] = useState({})
  const [checking, setChecking] = useState(false)
  const [checkedAt, setCheckedAt] = useState(0)
  const list = SERVERS.filter((s) => `${s.name} ${s.ip} ${s.type} ${s.description} ${(s.features || []).join(' ')}`.toLowerCase().includes(q.toLowerCase()))

  const refresh = async () => {
    if (checking) return
    setChecking(true)
    const rows = await Promise.all(SERVERS.map(async (server) => {
      const endpoint = '/api/mcping?host=' + encodeURIComponent(server.ip)
      try {
        let raw
        try {
          raw = await fetchJsonTimed(endpoint, 7000)
        } catch {
          raw = await fetchJsonTimed('https://api.mcsrvstat.us/3/' + encodeURIComponent(server.ip), 7000)
        }
        return [server.ip, {
          online: Boolean(raw.online),
          players: Number(raw.players?.online ?? raw.players) || 0,
          max: Number(raw.players?.max ?? raw.max) || 0,
          version: raw.version || '',
          protocol: raw.protocol && typeof raw.protocol === 'object'
            ? [raw.protocol.name, raw.protocol.version != null ? `#${raw.protocol.version}` : ''].filter(Boolean).join(' ')
            : (raw.protocol ?? null),
          software: raw.software || '',
          motd: Array.isArray(raw.motd?.clean) ? raw.motd.clean.join(' ') : (raw.motd || ''),
          port: Number(raw.port) || Number(server.ip.split(':')[1]) || 25565,
          ms: Number(raw.ms) || null,
        }]
      } catch {
        return [server.ip, { unavailable: true }]
      }
    }))
    setChecks(Object.fromEntries(rows))
    setCheckedAt(Date.now())
    setChecking(false)
  }

  useEffect(() => { refresh() }, [])

  return (
    <Page titleKey="pages.servers">
      <div className="glass p-4 mb-4 flex flex-wrap items-center gap-3">
        <div className="min-w-0 flex-1">
          <p className="text-white/65"><Tx text="Первый слот — mc.7cubes.ru:25565. Категории и заявленные версии отделены от живой технической проверки, чтобы не выдавать устаревшие данные за факты." /></p>
          <p className="text-xs text-white/35 mt-1">Статус: MCSRVSTAT через Cubenorixx API; это проверка доступности адреса, а не одобрение администрации, правил или магазина сервера.</p>
        </div>
        <button type="button" className="btn btn-ghost px-4 py-2" onClick={refresh} disabled={checking}>
          {checking ? 'Проверяем…' : 'Обновить статус'}
        </button>
      </div>
      <input className="field mb-4" aria-label="Поиск сервера" placeholder="Название, адрес, режим или описание" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="grid lg:grid-cols-2 gap-4">
        {list.map((s) => {
          const live = checks[s.ip]
          const main = s.ip.split(':')[0]
          const port = Number(s.ip.split(':')[1]) || 25565
          return (
            <article key={s.ip} className={`glass p-5 server-detail-card ${s === SERVERS[0] && !q ? 'border-orange/50 shadow-glow' : ''}`}>
              <div className="flex items-start gap-3">
                <div className="min-w-0 flex-1">
                  {s === SERVERS[0] && !q && <div className="text-[10px] uppercase tracking-wider text-orange-soft mb-1">Основной слот Cubenorixx</div>}
                  <div className="flex flex-wrap items-center gap-2">
                    <h2 className="font-outfit text-2xl">{s.name}</h2>
                    <span className={`server-live ${live?.online ? 'on' : live?.unavailable ? 'unknown' : 'off'}`}>
                      {live?.online ? 'онлайн' : live?.unavailable ? 'нет данных' : checking && !live ? 'проверка' : 'офлайн'}
                    </span>
                  </div>
                  <div className="font-mono text-orange-soft break-all">{s.ip}</div>
                  {s.bedrock && <div className="font-mono text-xs text-white/55 mt-1">Bedrock: {s.bedrock}</div>}
                </div>
                <CopyIp ip={s.ip} />
              </div>

              <p className="text-sm text-white/60 leading-6 mt-4">{s.description}</p>
              <div className="flex flex-wrap gap-1.5 mt-3">
                {(s.features || []).map((feature) => <span className="tag" key={feature}>{feature}</span>)}
              </div>

              <dl className="server-tech-grid mt-4">
                <div><dt>Редакция</dt><dd>{s.edition || 'Java'}</dd></div>
                <div><dt>Режим</dt><dd>{s.type}</dd></div>
                <div><dt>Хост</dt><dd>{main}</dd></div>
                <div><dt>Порт Java</dt><dd>{live?.port || port}</dd></div>
                <div><dt>Заявленная версия</dt><dd>{s.version}</dd></div>
                <div><dt>Ответ сервера</dt><dd>{live?.version || '—'}</dd></div>
                <div><dt>Игроки</dt><dd>{live?.online ? `${live.players} / ${live.max || '—'}` : '—'}</dd></div>
                <div><dt>Протокол / ПО</dt><dd>{[live?.protocol, live?.software].filter(Boolean).join(' · ') || '—'}</dd></div>
              </dl>
              {live?.motd && <p className="server-motd mt-3">{live.motd}</p>}
              <div className="text-[11px] text-white/30 mt-3">
                {s.since ? `Заявленный год основания: ${s.since}. ` : ''}
                {checkedAt ? `Последняя проверка в ${new Date(checkedAt).toLocaleTimeString()}.` : 'Ожидаем техническую проверку.'}
              </div>
            </article>
          )
        })}
      </div>
      {!list.length && <div className="glass p-8 text-center text-white/45">По этому запросу серверов нет.</div>}
      <h2 className="font-outfit text-2xl mt-10 mb-3"><Tx text="Независимые списки и проверка серверов" /></h2>
      <div className="grid md:grid-cols-2 gap-3">
        {SERVER_LISTS.map((s) => (
          <a key={s.url} href={s.url} target="_blank" rel="noreferrer" className="glass p-4 hover:border-orange/40">
            <div className="text-orange-soft">{s.name}</div>
            <div className="text-sm text-white/50 mt-1">{s.note}</div>
          </a>
        ))}
      </div>
    </Page>
  )
}

const LAUNCHER_ENDPOINTS = [
  ['/api/launcher-update.json', 'Обновление лаунчера'],
  ['/api/mc-versions.json', 'Версии Minecraft'],
  ['/api/modpacks.json', 'Собственные сборки'],
  ['/api/java-runtimes.json', 'Среды Java'],
  ['/api/featured-mods.json', 'Рекомендуемые моды'],
  ['/api/launcher-assets.json', 'Инвентарь бинарных файлов'],
]

export function LauncherLab() {
  const [rows, setRows] = useState({})
  useEffect(() => {
    let alive = true
    Promise.all(LAUNCHER_ENDPOINTS.map(async ([path]) => {
      try {
        const response = await fetch(path, { headers: { Accept: 'application/json' } })
        if (!response.ok || !(response.headers.get('content-type') || '').includes('application/json')) throw new Error('not-json')
        const data = await response.json()
        const count = Array.isArray(data) ? data.length : Array.isArray(data.versions) ? data.versions.length : null
        const draft = !Array.isArray(data) && (data.status === 'draft' || data.enabled === false)
        return [path, { ok: true, draft, count, data }]
      } catch {
        return [path, { ok: false }]
      }
    })).then((result) => { if (alive) setRows(Object.fromEntries(result)) })
    return () => { alive = false }
  }, [])
  return (
    <Page title="Launcher Lab">
      <div className="glass p-5 border-amber-400/20 mb-5">
        <div className="text-xs uppercase tracking-widest text-amber-300">Внутренний черновик · не секретное хранилище</div>
        <p className="text-white/65 mt-2 leading-7">Эта страница не включена в навигацию и sitemap, но любой известный URL можно открыть. Здесь нет ключей или закрытых файлов. Публичный лаунчер будет читать JSON, а крупные проверенные архивы должны отдаваться из Cloudflare R2.</p>
        <p className="text-sm text-white/40 mt-2">До появления подписанных архивов установщик обязан уважать <code>enabled=false</code> и не предлагать загрузку.</p>
      </div>
      <div className="space-y-2">
        {LAUNCHER_ENDPOINTS.map(([path, label]) => {
          const row = rows[path]
          const state = !row ? 'draft' : !row.ok ? 'error' : row.draft ? 'draft' : 'ready'
          const text = !row ? 'проверка' : !row.ok ? 'ошибка' : row.draft ? 'черновик' : 'готово'
          return (
            <div className="launcher-endpoint" key={path}>
              <div className="min-w-0">
                <div className="font-semibold">{label}{row?.count != null ? ` · ${row.count}` : ''}</div>
                <a href={path} className="block mt-1" target="_blank" rel="noopener noreferrer"><code>{path}</code></a>
              </div>
              <span className={`launcher-state ${state}`}>{text}</span>
            </div>
          )
        })}
      </div>
      <div className="glass p-5 mt-5 text-sm text-white/55 leading-7">
        Инструкция по R2, SHA-256, Ed25519, безопасной распаковке и порядку активации находится в <code>LAUNCHER_BACKEND.md</code>. Бинарные файлы намеренно не выдуманы.
      </div>
    </Page>
  )
}

export function Hosting() {
  const [f, setF] = useState([])
  const toggle = (x) => setF((a) => a.includes(x) ? a.filter((i) => i !== x) : [...a, x])
  const list = HOSTINGS.filter((h) => {
    if (f.includes('Бесплатные') && h.price !== 'free') return false
    if (f.includes('Платные (до $5)') && !(h.price !== 'free' && h.price <= 5)) return false
    if (f.includes('Платные ($5–15)') && !(h.price > 5 && h.price <= 15)) return false
    if (f.includes('Платные ($15+)') && !(h.price > 15)) return false
    if (f.includes('С поддержкой модов') && !h.mods) return false
    if (f.includes('С поддержкой плагинов') && !h.plugins) return false
    if (f.includes('С DDoS-защитой') && !h.ddos) return false
    return true
  })
  return (
    <Page titleKey="pages.hosting">
      <div className="flex flex-wrap gap-2 mb-4">{FILTERS.hosting.map((x) => <button key={x} className={`tag ${f.includes(x)?'bg-orange/30':''}`} onClick={() => toggle(x)}>{x}</button>)}</div>
      <div className="grid md:grid-cols-2 gap-3">
        {list.map((h) => (
          <a key={h.name} href={h.url} target="_blank" rel="noreferrer" className="glass p-5 hover:border-orange/40">
            <div className="font-outfit text-xl">{h.name}</div>
            <div className="text-orange-soft font-mono">{h.price === 'free' ? 'FREE' : `от $${h.price}/мес`}</div>
            <p className="text-sm text-white/60 mt-2">{h.note}</p>
            <div className="text-xs mt-2 text-white/40">{h.mods && 'моды '}{h.plugins && 'плагины '}{h.ddos && 'DDoS'}</div>
          </a>
        ))}
      </div>
    </Page>
  )
}

export function Guides() {
  return (
    <Page titleKey="pages.guides">
      <div className="grid md:grid-cols-2 gap-3">
        {GUIDES.map((g) => (
          <Link key={g.id} to={'/guides/' + g.id} className="glass p-5 hover:border-orange/40">
            <div className="font-outfit text-lg">{g.title}</div>
            <div className="text-xs text-white/40 font-mono">{g.minutes} мин</div>
          </Link>
        ))}
      </div>
    </Page>
  )
}

export function GuideDetail() {
  const { id } = useParams()
  const g = GUIDES.find((x) => x.id === id)
  const body = GUIDE_BODY[id] || 'Откройте соответствующий раздел Cubenorixx, скачайте файл с CDN источника и следуйте шагам ниже.'
  return (
    <Page title={g?.title || ''}>
      <article className="glass p-6 whitespace-pre-wrap leading-7 text-white/80">{body}</article>
    </Page>
  )
}

const GUIDE_BODY = {
  mods: `1. Установите Fabric / Forge / NeoForge / Quilt под вашу версию Minecraft.\n2. Скачайте мод в Cubenorixx — файл придёт с CDN источника и не хранится у нас дольше 5 минут.\n3. Положите .jar в папку .minecraft/mods.\n4. Проверьте зависимости на карточке проекта (зелёный — ок, красный — конфликт).\n5. Запустите игру тем же загрузчиком.`,
  shaders: `Нужен Iris (Fabric) или Oculus (Forge) + совместимый Sodium/Embeddium.\nСкачайте шейдерпак → .minecraft/shaderpacks → в настройках видео выберите пак.`,
  fps: `Сборка оптимизации: Sodium + Lithium + Starlight/Phosphor + FerriteCore + ImmediatelyFast + EntityCulling.\nВ видеонастройках: Fabulous только если нужно, render distance 8–12, VSync выкл если монитор даёт больше 60.`,
  server: `Выберите ядро: Vanila / Paper / Purpur / Fabric / Forge / Folia.\nСкачайте .jar, примите eula.txt=true, откройте порт 25565.\nЛибо возьмите хостинг в разделе Хостинг.`,
}

export function Generators() {
  const [tab, setTab] = useState('cmd')
  const [title, setTitle] = useState('Hello Cubenorixx')
  const [desc, setDesc] = useState('Собрал первую сборку')
  const [color, setColor] = useState('#FF6B00')
  const [sel, setSel] = useState('@a')
  const [kind, setKind] = useState('execute')
  const [item, setItem] = useState('minecraft:diamond_sword')
  const [entity, setEntity] = useState('minecraft:zombie')
  const [score, setScore] = useState('kills')
  const hex = color.replace('#', '')
  const adv = `{
  "display": {
    "icon": { "item": "minecraft:orange_wool" },
    "title": { "text": ${JSON.stringify(title)}, "color": "gold" },
    "description": { "text": ${JSON.stringify(desc)} },
    "frame": "challenge",
    "announce_to_chat": true
  },
  "parent": "minecraft:story/root",
  "criteria": { "tick": { "trigger": "minecraft:tick" } }
}`
  const fly = `/title ${sel} title {"text":${JSON.stringify(title)},"color":"${color}","bold":true}`
  const sign = `/give @p oak_sign{BlockEntityTag:{front_text:{messages:['{"text":"${title}","color":"#${hex}"}','{"text":"${desc}"}','{"text":"Cubenorixx"}','{"text":""}']}}} 1`
  const chat = `/tellraw ${sel} {"text":"${title} — ${desc}","color":"#${hex}","bold":true}`
  const cmds = {
    execute: `/execute as ${sel} at @s if score @s ${score} matches 10.. if block ~ ~-1 ~ minecraft:gold_block run give @s ${item} 1`,
    give: `/give ${sel} ${item}${String.fromCharCode(91)}minecraft:enchantments={levels:{"minecraft:sharpness":5,"minecraft:unbreaking":3}}${String.fromCharCode(93)} 1`,
    summon: `/summon ${entity} ~ ~ ~ {CustomName:'{"text":"${title}","color":"gold"}',Health:40f,HandItems:[{id:"${item}",Count:1b},{}]}`,
    data: `/data merge entity ${sel} {NoAI:1b,Glowing:1b,CustomNameVisible:1b,CustomName:'{"text":"${title}"}'}`,
    score: `/scoreboard objectives add ${score} dummy "${title}"\n/scoreboard players add ${sel} ${score} 1\n/scoreboard objectives setdisplay sidebar ${score}`,
    bossbar: `/bossbar add cubenorixx:main {"text":"${title}","color":"gold"}\n/bossbar set cubenorixx:main max 100\n/bossbar set cubenorixx:main value 64\n/bossbar set cubenorixx:main players ${sel}\n/bossbar set cubenorixx:main color yellow`,
    particle: `/particle minecraft:dust{color:[1.0,0.42,0.0],scale:1.4} ~ ~1 ~ 0.4 0.6 0.4 0 40 force ${sel}`,
    loot: `/loot give ${sel} loot minecraft:chests/end_city_treasure`,
    attr: `/attribute ${sel} minecraft:generic.scale base set 1.25`,
    tick: `/tick rate 40`,
    rotate: `/rotate ${sel} facing entity @p eyes`,
    selector: `${sel}[distance=..12,gamemode=survival,scores={${score}=1..},sort=nearest,limit=1]`,
  }
  const map = { adv, fly, sign, chat, cmd: cmds[kind] }
  const copy = (t) => navigator.clipboard.writeText(t)
  return (
    <Page titleKey="pages.generators">
      <div className="flex gap-2 mb-4 flex-wrap">
        {[['cmd','Команды (про)'],['adv','Достижения'],['fly','Летающий текст'],['sign','Надписи'],['chat','Текст в чате']].map(([k, n]) => (
          <button key={k} className={`tag ${tab===k?'bg-orange/30':''}`} onClick={() => setTab(k)}>{n}</button>
        ))}
      </div>
      <div className="grid md:grid-cols-2 gap-3">
        <div className="space-y-2">
          {tab === 'cmd' && (
            <>
              <select className="field" value={kind} onChange={(e) => setKind(e.target.value)}>
                {Object.keys(cmds).map((k) => <option key={k} className="bg-[#12122A]" value={k}>{k}</option>)}
              </select>
              <select className="field" value={sel} onChange={(e) => setSel(e.target.value)}>
                {['@p','@a','@s','@r','@e','@e[type=minecraft:armor_stand]'].map((s) => <option key={s} className="bg-[#12122A]">{s}</option>)}
              </select>
              <input className="field font-mono" value={item} onChange={(e) => setItem(e.target.value)} placeholder="item id" />
              <input className="field font-mono" value={entity} onChange={(e) => setEntity(e.target.value)} placeholder="entity id" />
              <input className="field font-mono" value={score} onChange={(e) => setScore(e.target.value)} placeholder="scoreboard" />
            </>
          )}
          <input className="field" value={title} onChange={(e) => setTitle(e.target.value)} />
          <input className="field" value={desc} onChange={(e) => setDesc(e.target.value)} />
          <input type="color" value={color} onChange={(e) => setColor(e.target.value)} />
        </div>
        <pre className="glass p-4 overflow-auto text-xs font-mono whitespace-pre-wrap">{map[tab]}</pre>
      </div>
      <button className="btn btn-primary mt-4 px-5 py-2" onClick={() => copy(map[tab])}>Скопировать</button>
    </Page>
  )
}

const WIKI_TABS = [
  ['blocks', 'Блоки'],
  ['items', 'Предметы'],
  ['mobs', 'Мобы'],
  ['mechanics', 'Механики'],
  ['versions', 'Версии'],
  ['biomes', 'Биомы'],
  ['commands', 'Команды'],
  ['recipes', 'Рецепты'],
]

function paceLine(perDay) {
  if (!perDay || perDay <= 0) return 'темп пока не посчитали'
  if (perDay >= 1) {
    const n = Math.max(1, Math.round(perDay))
    return `примерно ${n} ${n === 1 ? 'проект' : n < 5 ? 'проекта' : 'проектов'} в день`
  }
  const week = perDay * 7
  if (week >= 1) {
    const n = Math.max(1, Math.round(week))
    return `примерно ${n} ${n === 1 ? 'проект' : n < 5 ? 'проекта' : 'проектов'} в неделю`
  }
  const month = perDay * 30
  const n = Math.max(1, Math.round(month))
  return `примерно ${n} ${n === 1 ? 'проект' : n < 5 ? 'проекта' : 'проектов'} в месяц`
}

function SiteWiki() {
  const { lang } = useStore()
  const [live, setLive] = useState(null)
  const [pace, setPace] = useState('')
  useEffect(() => {
    let ok = true
    Promise.all([
      fetch('/api/live').then((r) => r.json()).catch(() => ({})),
      fetch('https://api.modrinth.com/v2/search?limit=40&index=newest').then((r) => r.json()).catch(() => ({})),
    ]).then(([lv, nw]) => {
      if (!ok) return
      setLive(lv)
      const hits = nw.hits || []
      const ts = hits.map((h) => Date.parse(h.date_created || '')).filter((n) => Number.isFinite(n)).sort((a, b) => a - b)
      if (ts.length >= 4) {
        const days = Math.max((ts[ts.length - 1] - ts[0]) / 86400000, 1 / 24)
        setPace(paceLine(ts.length / days))
      }
    })
    return () => { ok = false }
  }, [])
  const total = Number(live?.total) || 0
  const by = live?.by || {}
  return (
    <div className="space-y-4 mb-8">
      <div className="glass p-5 leading-7">
        <h2 className="font-outfit text-2xl mb-2">Cubenorixx</h2>
        <p className="text-white/70">Пишешь название — получаешь файл. Остальное вокруг: чтобы не прыгать по десяти сайтам и чтобы другим тоже было проще.</p>
        <p className="text-white/70 mt-2">Неофициально. Minecraft — Mojang. Файлы не наши: CX-Pass тянет с CDN источника и не кладёт в базу.</p>
      </div>
      <div className="grid sm:grid-cols-3 gap-3">
        <div className="stat-cell">
          <div className="font-outfit text-2xl text-orange-soft">{total ? formatNumber(total, lang) : '—'}</div>
          <div className="text-white/50 text-sm mt-1">сейчас в индексе</div>
        </div>
        <div className="stat-cell">
          <div className="font-outfit text-lg text-orange-soft leading-snug">{pace || 'считаем…'}</div>
          <div className="text-white/50 text-sm mt-1">новые на Modrinth</div>
        </div>
        <div className="stat-cell">
          <div className="font-outfit text-2xl text-orange-soft">{live?.sources || '—'}</div>
          <div className="text-white/50 text-sm mt-1">живых API в сумме</div>
        </div>
      </div>
      <p className="text-white/45 text-sm">Цифра обновляется с площадок. Не «нарисовали 350к». Если Modrinth 152к, а Spigot ещё 90к — складываем живое, не выдумываем.</p>
      {!!Object.keys(by).length && (
        <div className="flex flex-wrap gap-2">
          {Object.entries(by).map(([k, n]) => (
            <span key={k} className="tag">{k} · {formatNumber(n, lang)}</span>
          ))}
        </div>
      )}
    </div>
  )
}

export function Wiki() {
  const [sp, setSp] = useSearchParams()
  const tab = sp.get('tab') || 'site'
  const [q, setQ] = useState('')
  const pack = { ...WIKI, ...WIKI_EXTRA }
  const data = (pack[tab] || []).filter((x) => JSON.stringify(x).toLowerCase().includes(q.toLowerCase()))
  return (
    <Page titleKey="pages.wiki">
      <p className="text-white/55 mb-5 max-w-2xl"><Tx text="Сначала сайт. Потом блоки, мобы, команды. Картинки чужой вики в РФ часто мёртвые — текст свой." /></p>
      {tab === 'site' && <SiteWiki />}
      <div className="flex flex-wrap gap-2 mb-3">
        {WIKI_TABS.map(([k, n]) => <button key={k} className={'tag' + (tab === k ? ' on' : '')} onClick={() => setSp({ tab: k })}>{n}</button>)}
      </div>
      {tab !== 'site' && (
        <>
          <input className="field mb-4" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Поиск: варден, /give, 1.21" />
          <div className="grid md:grid-cols-2 gap-3">
            {data.map((x) => (
              <div key={x.id || x.cmd || x.out} className="wiki-card">
                <div className="wiki-ico">{String(x.name || x.cmd || x.out || '?')[0]}</div>
                <div>
                  <div className="font-outfit text-lg">{x.name || x.cmd || x.out}</div>
                  <p className="text-white/60 text-sm mt-1 leading-6">{x.desc || x.in}</p>
                </div>
              </div>
            ))}
          </div>
          {!data.length && <p className="text-white/45 mt-6">Ничего нет по этому запросу.</p>}
        </>
      )}
    </Page>
  )
}

export function Forum() {
  return (
    <Page titleKey="pages.forum">
      <div className="space-y-2">
        {FORUM_THREADS.map((t) => (
          <div key={t.id} className="glass p-4 flex items-center gap-3">
            <div className="flex-1">
              <div className="font-semibold">{t.title}</div>
              <div className="text-xs text-white/40">{t.author} · источник {t.source} · {t.replies} ответов</div>
            </div>
            <span className="tag">{t.source}</span>
          </div>
        ))}
      </div>
    </Page>
  )
}

export function Developers() {
  const [tab, setTab] = useState('api')
  const sample = `GET /api/search?q=sodium&type=all&limit=20
GET /api/agg-get?slug=curseforge-shine-vfx
GET /api/file?url=https://cdn.modrinth.com/...&name=mod.jar
GET /mr-api/v2/project/{id}
GET /mr-api/v2/project/{id}/version`
  return (
    <Page title="Для разработчиков">
      <div className="flex flex-wrap gap-2 mb-4">
        {['api','sdk','tutorials','templates','examples','materials','deploy'].map((k) => (
          <button key={k} className={`tag ${tab===k?'bg-orange/30':''}`} onClick={() => setTab(k)}>{k}</button>
        ))}
      </div>
      <pre className="glass p-4 font-mono text-sm overflow-auto">{sample}</pre>
      <p className="mt-4 text-white/60">SDK: REST + WebSocket пинг. Deployment: Docker + Nginx + GitHub Actions.</p>
    </Page>
  )
}

export function HashSearch() {
  const [h, setH] = useState('')
  const [res, setRes] = useState(null)
  const go = async () => {
    try {
      const r = await fetch('https://api.modrinth.com/v2/version_file/' + h + '?algorithm=sha1')
      if (!r.ok) throw new Error('not found')
      setRes(await r.json())
    } catch { setRes({ error: 'Файл не найден в Modrinth по SHA-1' }) }
  }
  return (
    <Page titleKey="pages.hash">
      <div className="flex gap-2">
        <input className="field font-mono" value={h} onChange={(e) => setH(e.target.value)} placeholder="sha1 файла .jar" />
        <button className="btn btn-primary px-5" onClick={go}>Найти</button>
      </div>
      {res && <pre className="glass p-4 mt-4 text-xs overflow-auto">{JSON.stringify(res, null, 2)}</pre>}
    </Page>
  )
}

export function Legal() {
  const { page } = useParams()
  const titles = {
    about: 'pages.about',
    how: 'pages.how',
    rules: 'pages.rules',
    terms: 'pages.terms',
    privacy: 'pages.privacy',
    dmca: 'footer.dmca',
    authors: 'pages.authors',
    disclaimer: 'pages.disc',
    license: 'pages.license',
    extension: 'pages.ext',
    app: 'pages.app',
  }
  const texts = {
    ...LEGAL_TEXTS,
    about: `Cubenorixx (cube + phoenix) — независимый агрегатор проверенных источников Minecraft.

Один поиск вместо множества вкладок: моды, шейдеры, плагины, карты, схемы, скины и сборки. Живой объединённый каталог показывает разбивку Modrinth, Spigot и Hangar; одна публикация может присутствовать на нескольких площадках.

Файлы берутся с разрешённых CDN источников. Cubenorixx не присваивает сторонние проекты и не меняет их лицензии.

Официальные адреса: https://cubenorixx.romantic-buffalo.workers.dev/ и https://t.me/Cubenorix.
Неофициально: Minecraft — Mojang Studios.`,
    how: `Как пользоваться
1. Откройте карточку проекта.
2. Выберите версию Minecraft и загрузчик.
3. Проверьте источник, зависимости и лицензию.
4. Нажмите «Скачать» либо откройте официальную площадку.

Каталог
Количество показывается по живым ответам источников с разбивкой. Мы не выдаём сумму записей разных площадок за точное число уникальных проектов.

Сборщик
Готовый ZIP должен содержать настоящие JAR-файлы из разрешённого CDN, а не только метаданные. Лимит — 200 проектов, параллельно — не более 12 операций.

Аккаунты
Серверная регистрация подготовлена для Cloudflare Pages + D1. На статическом Yapp она отключена: пароль нельзя безопасно хранить в HTML или localStorage.`,
    extension: 'Расширение Cubenorixx в разработке.',
    app: 'Нативного клиента Cubenorixx пока нет. Не устанавливайте приложения, которые выдают себя за официальный Cubenorixx без ссылки с официального сайта.',
  }
  return (
    <Page titleKey={titles[page] || ''} title={page || 'Legal'}>
      <div className="glass p-6 leading-7 text-white/80">
        <BodyMd text={texts[page] || ''} />
      </div>
    </Page>
  )
}

function CopyIp({ ip }) {
  const { lang } = useStore()
  return (
    <button className="btn btn-primary ml-auto px-4 py-2" onClick={() => navigator.clipboard.writeText(ip)}>
      {t(lang, 'ui.copyIp')}
    </button>
  )
}

function Page({ title, titleKey, children }) {
  const { lang } = useStore()
  const heading = titleKey ? t(lang, titleKey) : title
  return (
    <div className="relative z-10 max-w-5xl mx-auto px-4 pt-10">
      <h1 className="font-outfit text-4xl font-bold mb-6">{heading}</h1>
      {children}
    </div>
  )
}
