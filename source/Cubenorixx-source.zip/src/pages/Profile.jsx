/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { useEffect, useRef, useState } from 'react'
import { Link, Navigate, useNavigate } from 'react-router-dom'
import { useStore } from '../store'
import { ACHIEVEMENTS } from '../data'
import { t } from '../i18n'
import { StatusMark } from '../components/Marks'

const TAB_KEYS = [
  ['stats', 'profile.stats'],
  ['achv', 'Ачивки'],
  ['team', 'Команда 🛡'],
  ['preview', 'Как видят другие 👁'],
  ['builds', 'profile.builds'],
  ['fav', 'profile.fav'],
  ['reviews', 'profile.reviews'],
  ['uploads', 'Мои проекты 📦'],
  ['notify', 'Уведомления 🔔'],
  ['style', 'Кастомизация ✨'],
  ['settings', 'Настройки ⚙'],
]

// «Nitro, но бесплатно»: акценты и баннеры профиля
export const ACCENTS = {
  orange: { name: 'Cubenorixx', color: '#ff7a1a', grad: 'linear-gradient(135deg,#FFB347,#FF6B00)' },
  green: { name: 'Modrinth', color: '#00af54', grad: 'linear-gradient(135deg,#4ade80,#00af54)' },
  violet: { name: 'Аметист', color: '#a78bfa', grad: 'linear-gradient(135deg,#c4b5fd,#7c3aed)' },
  blue: { name: 'Алмаз', color: '#60a5fa', grad: 'linear-gradient(135deg,#93c5fd,#2563eb)' },
  red: { name: 'Красная пыль', color: '#f87171', grad: 'linear-gradient(135deg,#fca5a5,#dc2626)' },
  gold: { name: 'Золото', color: '#fbbf24', grad: 'linear-gradient(135deg,#fde68a,#d97706)' },
  cyan: { name: 'Незерит', color: '#22d3ee', grad: 'linear-gradient(135deg,#67e8f9,#0891b2)' },
  pink: { name: 'Розовый слайм', color: '#f472b6', grad: 'linear-gradient(135deg,#f9a8d4,#db2777)' },
}

export const BANNERS = {
  sunset: { name: 'Закат', css: 'linear-gradient(120deg,#3b1d0f 0%,#7c3aed 45%,#ff7a1a 100%)' },
  moon: { name: 'Тёмная сторона Луны', css: 'linear-gradient(120deg,#0b0b1e 0%,#1e1b4b 50%,#4c1d95 100%)' },
  ender: { name: 'Край', css: 'linear-gradient(120deg,#0f051f 0%,#2d1b4e 55%,#d946ef 130%)' },
  nether: { name: 'Незер', css: 'linear-gradient(120deg,#3f0d0d 0%,#7f1d1d 55%,#f97316 130%)' },
  forest: { name: 'Джунгли', css: 'linear-gradient(120deg,#052e16 0%,#14532d 55%,#84cc16 130%)' },
  ice: { name: 'Ледяные пики', css: 'linear-gradient(120deg,#0c4a6e 0%,#155e75 55%,#a5f3fc 140%)' },
}

const REPORT_REASONS = [
  ['spam', 'Спам и реклама'],
  ['fraud', 'Мошенничество и обман'],
  ['abuse', 'Оскорбления и травля'],
  ['content', 'Запрещённый контент (читы, вирусы, 18+)'],
  ['impersonation', 'Выдаёт себя за другого/администрацию'],
  ['other', 'Другое'],
]

export default function Profile() {
  const { user, db, logout, deleteAccount, updateProfile, addUpload, unlocked, notify, setCustom, setNotifications, setNewsSubscribed, setTeam, pushReport, lang } = useStore()
  const nav = useNavigate()
  const fileRef = useRef(null)
  const [tab, setTab] = useState('stats')
  const [up, setUp] = useState({ title: '', description: '', type: 'mod', github: '' })
  const [virus, setVirus] = useState({ state: 'idle', note: '' })
  const [form, setForm] = useState({ username: '', display: '', brand: '', nick: '', youtube: '', bio: '' })
  const [deletion, setDeletion] = useState({ password: '', confirm: '' })
  const [saving, setSaving] = useState(false)
  const [report, setReport] = useState({ open: false, reason: 'spam', details: '' })
  const [teamForm, setTeamForm] = useState({ name: '', tag: '', about: '', colorId: 'orange' })
  const [inviteName, setInviteName] = useState('')
  const GH_RE = /^https:\/\/github\.com\/[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+\/?$/
  const ghOk = GH_RE.test(up.github.trim())
  const BAD_SIGNS = /\.exe\b|\.bat\b|\.scr\b|\.msi\b|keygen|crack|hack\\?hvat|cheat|miner|rat\b|token.?grab/i

  const runVirusScan = () => {
    if (!ghOk) { setVirus({ state: 'failed', note: 'Сначала укажите корректную ссылку на GitHub (https://github.com/автор/репозиторий).' }); return }
    setVirus({ state: 'scanning', note: '' })
    setTimeout(() => {
      const scanText = up.title + ' ' + up.description + ' ' + up.github
      if (BAD_SIGNS.test(scanText)) {
        setVirus({ state: 'failed', note: '⚠ Обнаружены подозрительные признаки (читы/кряки/майнеры/исполняемые файлы). Публикация запрещена. Уберите их и повторите проверку.' })
      } else {
        setVirus({ state: 'passed', note: '✓ Проверка пройдена: подозрительных признаков не найдено. Ссылка на GitHub приложена к проекту.' })
      }
    }, 2200)
  }

  useEffect(() => {
    if (!user) return
    setForm({
      username: user.username || '', display: user.display || '', brand: user.brand || '',
      nick: user.nick || '', youtube: user.youtube || '', bio: user.bio || '',
    })
  }, [user])
  if (!user) return <Navigate to="/login" replace />
  const TABS = TAB_KEYS.map(([key, label]) => [key, t(lang, label)])
  const un = unlocked()
  const custom = { ...(db.custom || {}) }
  const accent = ACCENTS[custom.accent] || ACCENTS.orange
  const banner = BANNERS[custom.banner] || BANNERS.sunset
  const avatarMode = custom.avatar || 'letter'
  const nickName = form.nick || user.nick || ''
  const avatarSrc = avatarMode === 'custom' && custom.avatarData ? custom.avatarData
    : avatarMode === 'nick' && nickName ? 'https://mc-heads.net/avatar/' + encodeURIComponent(nickName) + '/80' : ''
  const displayName = user.brand || user.display || user.username

  const pickAvatar = (file) => {
    if (!file) return
    if (!file.type.startsWith('image/')) return notify('Нужна картинка (PNG/JPG/WebP)', 'err')
    if (file.size > 3 * 1024 * 1024) return notify('Файл больше 3 МБ — выберите меньше', 'err')
    const img = new Image()
    img.onload = () => {
      const c = document.createElement('canvas')
      c.width = 128; c.height = 128
      const ctx = c.getContext('2d')
      const side = Math.min(img.width, img.height)
      ctx.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, 128, 128)
      setCustom({ avatar: 'custom', avatarData: c.toDataURL('image/jpeg', 0.85) })
      notify('Аватар установлен ✨', 'ok')
    }
    img.onerror = () => notify('Не удалось прочитать картинку', 'err')
    img.src = URL.createObjectURL(file)
  }

  const save = async (event) => {
    event.preventDefault()
    setSaving(true)
    const result = await updateProfile({
      username: form.username.trim() || user.username,
      display: form.display.trim(),
      brand: form.brand.trim(),
      nick: form.nick.trim(),
      youtube: form.youtube.trim(),
      bio: form.bio.trim(),
      custom,
    })
    setSaving(false)
    notify(result.ok ? t(lang, 'ui.saved') : result.error, result.ok ? 'ok' : 'err')
  }

  const badges = [
    db.registered && { icon: '🚀', title: 'Пионер Cubenorixx' },
    db.secretUnlocked && { icon: '🌑', title: 'Тёмная сторона Луны' },
    { icon: '✨', title: 'Кастомизация — бесплатно' },
    un.length >= 5 && { icon: '🏆', title: '5+ ачивок' },
    db.team && { icon: '🛡', title: 'Команда: ' + db.team.name },
  ].filter(Boolean)

  const submitReport = () => {
    if (!report.details.trim() && report.reason === 'other') return notify('Опишите проблему', 'err')
    pushReport({ target: user.username, reason: report.reason, details: report.details.trim().slice(0, 500) })
    setReport({ open: false, reason: 'spam', details: '' })
    notify('Жалоба отправлена модераторам 🛡', 'ok')
  }

  const createTeam = () => {
    const name = teamForm.name.trim()
    const tag = teamForm.tag.trim()
    if (name.length < 3 || name.length > 24) return notify('Название команды: 3–24 символа', 'err')
    if (!/^[A-Za-z0-9_]{2,6}$/.test(tag)) return notify('Тег: 2–6 латинских букв/цифр', 'err')
    if (tag.toLowerCase() === 'cx') return notify('Тег CX зарезервирован администрацией', 'err')
    setTeam({
      name, tag, about: teamForm.about.trim().slice(0, 200),
      colorId: teamForm.colorId, createdAt: Date.now(),
      owner: user.username,
      members: [{ name: user.username, role: 'owner' }],
      invites: [],
    })
    notify(`Команда «${name}» создана 🛡`, 'ok')
  }

  const inviteMember = () => {
    const name = inviteName.trim()
    if (!/^[A-Za-z0-9_-]{3,24}$/.test(name)) return notify('Ник: 3–24 латинских буквы/цифр', 'err')
    if ((db.team?.members || []).some((m) => m.name.toLowerCase() === name.toLowerCase())) return notify('Уже в команде', 'err')
    if ((db.team?.invites || []).some((i) => i.name.toLowerCase() === name.toLowerCase())) return notify('Приглашение уже отправлено', 'err')
    setTeam({ ...db.team, invites: [...(db.team.invites || []), { name, at: Date.now() }] })
    setInviteName('')
    notify(`Приглашение отправлено: ${name} ✉️`, 'ok')
  }

  const teamColor = ACCENTS[db.team?.colorId] || accent

  const Avatar = ({ size = 64 }) => avatarSrc
    ? <img src={avatarSrc} alt="" style={{ width: size, height: size }} className="rounded-2xl object-cover" />
    : <div className="rounded-2xl grid place-items-center font-outfit" style={{ width: size, height: size, fontSize: size * 0.4, background: accent.grad }}>{user.username[0].toUpperCase()}</div>

  const publicCard = (
    <div className="rounded-3xl overflow-hidden border border-white/10 profile-banner" style={{ background: banner.css }}>
      <div className="p-5 flex flex-wrap items-center gap-4">
        <Avatar size={72} />
        <div className="min-w-0">
          <h2 className="font-outfit text-2xl truncate" style={{ color: accent.color, textShadow: '0 1px 8px rgba(0,0,0,.6)' }}>{displayName}</h2>
          <div className="text-white/70 text-sm drop-shadow">@{user.username} · {user.role === 'creator' ? t(lang, 'ui.author') : user.role}</div>
          <div className="flex flex-wrap gap-1.5 mt-1.5">
            {badges.map((b) => <span key={b.title} className="tag" style={{ fontSize: '.7rem' }}>{b.icon} {b.title}</span>)}
          </div>
        </div>
      </div>
      {(form.bio || user.bio) && <p className="px-5 pb-4 text-sm text-white/75 whitespace-pre-line">{form.bio || user.bio}</p>}
      <div className="px-5 pb-5 grid grid-cols-2 sm:grid-cols-4 gap-2">
        {Object.entries(db.stats).map(([k, v]) => (
          <div key={k} className="bg-black/30 rounded-xl p-2.5 text-center">
            <div className="font-mono text-lg" style={{ color: accent.color }}>{v}</div>
            <div className="text-[10px] text-white/50">{k}</div>
          </div>
        ))}
      </div>
      {db.team && (
        <div className="mx-5 mb-5 p-3 rounded-2xl bg-black/30 border border-white/10">
          <span className="tag" style={{ fontSize: '.72rem', borderColor: teamColor.color }}>{teamColor.name && '🛡'} [{db.team.tag}] {db.team.name}</span>
          {db.team.about && <p className="text-xs text-white/55 mt-2">{db.team.about}</p>}
          <div className="text-[11px] text-white/40 mt-1.5">Участников: {(db.team.members || []).length} · Приглашено: {(db.team.invites || []).length}</div>
        </div>
      )}
    </div>
  )

  return (
    <div className="relative z-10 max-w-5xl mx-auto px-4 pt-8 pb-16">
      <div className="atlas-strip glass p-5 flex flex-wrap items-center gap-4 profile-banner" style={{ background: banner.css }}>
        <Avatar size={64} />
        <div className="min-w-0">
          <h1 className="font-outfit text-2xl truncate" style={{ color: accent.color, textShadow: '0 1px 8px rgba(0,0,0,.6)' }}>{displayName}</h1>
          <div className="text-white/70 text-sm drop-shadow">{user.display && user.brand ? user.display : user.username} · {user.role === 'creator' ? t(lang, 'ui.author') : user.role}{user.provider === 'local' ? ' · локальный' : ''}</div>
          {user.youtube && <a className="text-orange-soft text-sm" href={user.youtube} target="_blank" rel="noreferrer">YouTube</a>}
          <div className="flex flex-wrap gap-1.5 mt-1.5">
            {badges.map((b) => (
              <span key={b.title} className="tag" title={'Бейдж: ' + b.title} style={{ fontSize: '.72rem' }}>{b.icon} {b.title}</span>
            ))}
          </div>
        </div>
        <button className="btn btn-ghost ml-auto px-4" onClick={async () => { await logout(); nav('/') }}>{t(lang, 'auth.logout')}</button>
      </div>

      <div className="flex flex-wrap gap-2 mt-4">
        {TABS.map(([k, n]) => <button key={k} className={'tag' + (tab === k ? ' on' : '')} onClick={() => setTab(k)}>{n}</button>)}
      </div>

      <div className="glass p-6 mt-4">
        {tab === 'stats' && (
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {Object.entries(db.stats).map(([k, v]) => (
              <div key={k} className="bg-white/5 rounded-2xl p-4">
                <div className="font-mono text-2xl text-orange-soft">{v}</div>
                <div className="text-xs text-white/50">{k}</div>
              </div>
            ))}
          </div>
        )}

        {tab === 'achv' && (
          <>
            <p className="text-sm text-white/50 mb-3">Открыто {un.length} из {ACHIEVEMENTS.length}. Ачивки — бесплатные и навсегда: больше, чем в Discord Nitro, и за красиво сделанный профиль не платим. 💜</p>
            <div className="grid sm:grid-cols-2 gap-2">
              {ACHIEVEMENTS.map((a) => {
                const cur = a.flag ? (db[a.flag] ? 1 : 0) : (db.stats[a.stat] || 0)
                const goal = a.flag ? 1 : a.n
                const done = cur >= goal
                return (
                  <div key={a.id} className={`p-3 rounded-2xl border ${done ? 'border-orange/50 bg-orange/10' : 'border-white/5 opacity-60'}`}>
                    <div className="flex items-center justify-between gap-2">
                      <div className="font-semibold">{done ? '🏆 ' : '🔒 '}{a.title}</div>
                      <div className="font-mono text-xs text-white/50">{cur} / {goal}</div>
                    </div>
                    <div className="h-1.5 rounded-full bg-white/10 mt-2 overflow-hidden">
                      <div className="h-full rounded-full" style={{ width: Math.min(100, (cur / goal) * 100) + '%', background: accent.grad }} />
                    </div>
                  </div>
                )
              })}
            </div>
          </>
        )}

        {tab === 'preview' && (
          <div className="space-y-4">
            <p className="text-sm text-white/55">Так ваш профиль видят другие игроки: баннер, аватар, ник с акцентом, бейджи, статистика и команда. Меняйте всё во вкладке «Кастомизация» — превью обновится сразу.</p>
            {publicCard}
            <div className="flex flex-wrap items-center gap-3 p-4 rounded-2xl border border-white/10">
              <div className="text-sm text-white/55 min-w-0">Кто-то нарушает правила? Жалоба уходит модераторам Cubenorixx.</div>
              <button type="button" className="btn btn-ghost px-4 py-2 text-sm ml-auto" onClick={() => setReport({ ...report, open: true })}>🚩 Пожаловаться на пользователя</button>
            </div>
            {(db.reports || []).length > 0 && (
              <details className="text-sm text-white/50">
                <summary className="cursor-pointer">Мои жалобы ({db.reports.length})</summary>
                <div className="space-y-2 mt-2">
                  {db.reports.map((r) => (
                    <div key={r.id} className="p-3 rounded-xl border border-white/10 text-xs">
                      <b>🚩 {REPORT_REASONS.find(([id]) => id === r.reason)?.[1] || r.reason}</b> → @{r.target}
                      {r.details && <p className="text-white/45 mt-1">{r.details}</p>}
                      <span className="text-white/30">статус: {r.status === 'sent' ? 'отправлено модераторам' : r.status}</span>
                    </div>
                  ))}
                </div>
              </details>
            )}
          </div>
        )}

        {tab === 'team' && (
          !db.team ? (
            <div className="max-w-lg space-y-3">
              <p className="text-sm text-white/55">Создайте команду: приглушайте друзей, играйте вместе и показывайте тег на профиле. Приглашения отправляются по нику.</p>
              <label className="block text-sm text-white/50">Название команды
                <input className="field mt-1" placeholder="Ночные Строители" value={teamForm.name} onChange={(e) => setTeamForm({ ...teamForm, name: e.target.value })} />
              </label>
              <label className="block text-sm text-white/50">Тег (2–6 символов, виден рядом с ником)
                <input className="field mt-1" placeholder="NSB" value={teamForm.tag} onChange={(e) => setTeamForm({ ...teamForm, tag: e.target.value })} />
              </label>
              <label className="block text-sm text-white/50">Описание
                <textarea className="field mt-1 min-h-[64px]" placeholder="Строим по ночам, выживаем днём" value={teamForm.about} onChange={(e) => setTeamForm({ ...teamForm, about: e.target.value })} />
              </label>
              <div>
                <div className="text-sm text-white/50 mb-2">Цвет команды</div>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(ACCENTS).map(([id, a]) => (
                    <button key={id} type="button" onClick={() => setTeamForm({ ...teamForm, colorId: id })}
                      className={'w-9 h-9 rounded-xl border-2 ' + (teamForm.colorId === id ? 'border-white' : 'border-transparent')}
                      style={{ background: a.grad }} title={a.name} aria-label={a.name} />
                  ))}
                </div>
              </div>
              <button type="button" className="btn btn-primary px-5 py-2" onClick={createTeam}>🛡 Создать команду</button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl border border-white/10 flex flex-wrap items-center gap-3">
                <div className="w-12 h-12 rounded-2xl grid place-items-center font-outfit font-bold" style={{ background: teamColor.grad }}>{db.team.tag}</div>
                <div className="min-w-0">
                  <div className="font-outfit text-lg">🛡 {db.team.name}</div>
                  <div className="text-xs text-white/45">{db.team.about || 'Без описания'} · создана {new Date(db.team.createdAt).toLocaleDateString('ru-RU')}</div>
                </div>
                <button type="button" className="btn btn-ghost px-3 py-1.5 text-xs ml-auto text-[#ff9aaa]" onClick={() => { setTeam(null); notify('Команда распущена', 'ok') }}>Распустить</button>
              </div>
              <div>
                <div className="text-sm text-white/50 mb-2">Участники ({(db.team.members || []).length})</div>
                <div className="space-y-1.5">
                  {(db.team.members || []).map((m) => (
                    <div key={m.name} className="flex items-center gap-2 p-2.5 rounded-xl border border-white/10 text-sm">
                      <span className="font-semibold">{m.name}</span>
                      <span className="tag" style={{ fontSize: '.68rem' }}>{m.role === 'owner' ? '👑 Лидер' : 'Участник'}</span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-sm text-white/50 mb-2">Пригласить игрока</div>
                <div className="flex gap-2 max-w-md">
                  <input className="field" placeholder="Ник игрока" value={inviteName} onChange={(e) => setInviteName(e.target.value)} />
                  <button type="button" className="btn btn-primary px-4 whitespace-nowrap" onClick={inviteMember}>✉️ Пригласить</button>
                </div>
                {(db.team.invites || []).length > 0 && (
                  <div className="space-y-1.5 mt-3">
                    {db.team.invites.map((i) => (
                      <div key={i.name} className="flex items-center gap-2 p-2.5 rounded-xl border border-dashed border-white/15 text-sm">
                        <span>{i.name}</span>
                        <span className="tag" style={{ fontSize: '.68rem' }}>⏳ Ожидает ответа</span>
                        <button type="button" className="text-xs text-white/40 hover:text-white/80 ml-auto" onClick={() => setTeam({ ...db.team, invites: db.team.invites.filter((x) => x.name !== i.name) })}>Отменить</button>
                      </div>
                    ))}
                  </div>
                )}
                <p className="text-xs text-white/35 mt-2">Сейчас приглашения видны только вам. Когда заработает серверная часть — игроки получат их на своей странице и смогут принять.</p>
              </div>
            </div>
          )
        )}

        {tab === 'builds' && (db.builds.length ? db.builds.map((b) => <div key={b.id} className="py-2 border-b border-white/5">{b.name}</div>) : <p className="text-white/45">{t(lang, 'ui.noBuilds')}</p>)}

        {tab === 'fav' && (db.favorites.length ? db.favorites.map((f) => <Link key={f.slug} to={'/project/' + f.slug} className="block py-2 hover:text-orange-soft">{f.title}</Link>) : <p className="text-white/45">{t(lang, 'ui.empty')}</p>)}

        {tab === 'reviews' && (
          <div className="space-y-3">
            {Object.entries(db.reviews || {}).flatMap(([slug, arr]) => (arr || []).filter((r) => r.user === user.username).map((r) => (
              <div key={r.id} className="border-b border-white/5 pb-2">
                <div className="text-orange-soft">{'★'.repeat(r.stars || 0)}</div>
                <div className="text-xs text-white/40">{slug}</div>
                <p>{r.text}</p>
              </div>
            )))}
            <Link to="/reviews" className="text-orange-soft text-sm">{t(lang, 'review.all')}</Link>
          </div>
        )}

        {tab === 'uploads' && (
          <>
            <p className="text-sm text-white/55 mb-3">Публикация проекта: обязательна <b>ссылка на GitHub</b> (открытый код) и <b>проверка на вирусы</b>. Без них кнопка не активируется.</p>
            <form onSubmit={(e) => {
              e.preventDefault()
              if (!up.title.trim() || !ghOk || virus.state !== 'passed') return
              addUpload({ ...up, github: up.github.trim(), virusChecked: true, virusAt: Date.now() })
              setUp({ title: '', description: '', type: 'mod', github: '' })
              setVirus({ state: 'idle', note: '' })
              notify('Проект отправлен на модерацию', 'ok')
            }} className="space-y-3">
              <input className="field" placeholder={t(lang, 'profile.name')} value={up.title} onChange={(e) => { setUp({ ...up, title: e.target.value }); setVirus({ state: 'idle', note: '' }) }} />
              <textarea className="field min-h-[80px]" placeholder={t(lang, 'profile.about')} value={up.description} onChange={(e) => { setUp({ ...up, description: e.target.value }); setVirus({ state: 'idle', note: '' }) }} />
              <select className="field" value={up.type} onChange={(e) => setUp({ ...up, type: e.target.value })}>
                {['mod', 'plugin', 'datapack', 'resourcepack', 'map', 'modpack', 'schematic'].map((tpe) => <option key={tpe} className="bg-[#12122A]" value={tpe}>{tpe}</option>)}
              </select>
              <label className="block text-sm text-white/50">Ссылка на GitHub (обязательно)
                <input className="field mt-1" placeholder="https://github.com/автор/репозиторий" value={up.github} onChange={(e) => { setUp({ ...up, github: e.target.value }); setVirus({ state: 'idle', note: '' }) }} />
              </label>
              <div className="p-3 rounded-2xl border border-white/10">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm text-white/60">🛡 Проверка на вирусы:</span>
                  {virus.state === 'idle' && <span className="text-sm text-white/40">не запускалась</span>}
                  {virus.state === 'scanning' && <span className="text-sm text-yellow-300">сканируем…</span>}
                  {virus.state === 'passed' && <span className="text-sm text-green-400">✓ пройдена</span>}
                  {virus.state === 'failed' && <span className="text-sm text-red-400">⚠ не пройдена</span>}
                  <button type="button" className="btn btn-ghost px-3 py-1.5 text-sm ml-auto" disabled={virus.state === 'scanning'} onClick={runVirusScan}>
                    {virus.state === 'scanning' ? 'Сканируем…' : 'Запустить проверку'}
                  </button>
                </div>
                {virus.note && <p className={'text-xs mt-2 ' + (virus.state === 'passed' ? 'text-green-400/80' : 'text-red-400/80')}>{virus.note}</p>}
                <p className="text-[11px] text-white/30 mt-1.5">Предварительная локальная проверка по эвристикам; полную антивирусную проверку модератор выполнит при подключении VirusTotal API.</p>
              </div>
              <button className="btn btn-primary px-4 py-2" disabled={!up.title.trim() || !ghOk || virus.state !== 'passed'} title={!ghOk ? 'Нужна корректная ссылка на GitHub' : virus.state !== 'passed' ? 'Сначала пройдите проверку на вирусы' : ''}>
                {t(lang, 'profile.send')}
              </button>
              <div className="text-sm space-y-2 mt-4">
                {db.uploads.map((u) => (
                  <div key={u.id} className="border-b border-white/5 pb-2">
                    <b>{u.title}</b> <StatusMark status={u.status === 'accepted' ? 'accepted' : 'review'} />
                    {u.github && <a className="text-orange-soft text-xs ml-2" href={u.github} target="_blank" rel="noreferrer">GitHub ↗</a>}
                    {u.virusChecked && <span className="tag ml-1" style={{ fontSize: '.7rem' }}>🛡 Антивирус ✓</span>}
                  </div>
                ))}
              </div>
            </form>
          </>
        )}

        {tab === 'notify' && (() => {
          const N = db.notifications || {}
          const rows = [
            ['news', '📰 Новости Cubenorixx', 'Релизы сайта, новые разделы и важные объявления'],
            ['replies', '💬 Ответы на комментарии', 'Когда кто-то отвечает под вашим комментарием'],
            ['uploads', '📦 Статусы моих проектов', 'Одобрение/отклонение опубликованных проектов'],
            ['features', '✨ Анонсы новых функций', 'Первыми узнавать о фичах и кастомизациях'],
            ['digest', '📧 Ежемесячный дайджест', 'Одно письмо в месяц с лучшими проектами'],
          ]
          return (
            <div className="space-y-4 max-w-xl">
              <div className="flex flex-wrap items-center gap-3 p-4 rounded-2xl border border-white/10">
                <div className="min-w-0">
                  <div className="font-semibold">Подписка на новости проекта</div>
                  <div className="text-xs text-white/45">Главные объявления Cubenorixx без спама. Дополнительно можно включить канал в Telegram.</div>
                </div>
                <button
                  type="button"
                  className={'btn px-4 py-2 ml-auto text-sm ' + (db.newsSubscribed ? 'btn-ghost' : 'btn-primary')}
                  onClick={() => { setNewsSubscribed(!db.newsSubscribed); notify(db.newsSubscribed ? 'Подписка отключена' : 'Вы подписаны на новости Cubenorixx 📰', 'ok') }}
                >
                  {db.newsSubscribed ? 'Вы подписаны ✓' : 'Подписаться'}
                </button>
                <a className="text-orange-soft text-sm" href="https://t.me/Cubenorix" target="_blank" rel="noreferrer">Telegram-канал ↗</a>
              </div>
              {rows.map(([key, title, desc]) => (
                <label key={key} className="flex items-start gap-3 p-3 rounded-2xl border border-white/5 cursor-pointer hover:border-white/15 transition-colors">
                  <input
                    type="checkbox"
                    className="mt-1 accent-[#ff7a1a]"
                    checked={Boolean(N[key])}
                    onChange={(e) => setNotifications({ [key]: e.target.checked })}
                  />
                  <span>
                    <b className="text-sm">{title}</b>
                    <span className="block text-xs text-white/45">{desc}</span>
                  </span>
                </label>
              ))}
              <p className="text-xs text-white/35">Настройки применяются мгновенно и сохраняются на этом устройстве. Email-уведомления заработают после подключения почтового провайдера.</p>
            </div>
          )
        })()}

        {tab === 'style' && (
          <div className="space-y-6">
            <p className="text-sm text-white/55">Всё, что у других платит Nitro — у нас бесплатно и сразу: цвет ника, баннер профиля, аватар и бейджи. Настройки применяются мгновенно.</p>
            <div>
              <div className="text-sm text-white/50 mb-2">Цвет акцента (ник, аватар, прогресс ачивок)</div>
              <div className="flex flex-wrap gap-2">
                {Object.entries(ACCENTS).map(([id, a]) => (
                  <button key={id} type="button" onClick={() => setCustom({ accent: id })}
                    className={'w-11 h-11 rounded-2xl border-2 grid place-items-center ' + (custom.accent === id ? 'border-white' : 'border-transparent')}
                    style={{ background: a.grad }} title={a.name} aria-label={a.name}>
                    {custom.accent === id ? '✓' : ''}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div className="text-sm text-white/50 mb-2">Баннер профиля</div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {Object.entries(BANNERS).map(([id, b]) => (
                  <button key={id} type="button" onClick={() => setCustom({ banner: id })}
                    className={'h-16 rounded-2xl border-2 text-xs font-semibold text-white/90 ' + (custom.banner === id ? 'border-white' : 'border-transparent')}
                    style={{ background: b.css }}>
                    {b.name}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <div className="text-sm text-white/50 mb-2">Аватар</div>
              <div className="flex flex-wrap items-center gap-2">
                <button type="button" className={'tag' + (avatarMode === 'letter' ? ' on' : '')} onClick={() => setCustom({ avatar: 'letter' })}>Буква {user.username[0]}</button>
                <button type="button" className={'tag' + (avatarMode === 'nick' ? ' on' : '')} onClick={() => setCustom({ avatar: 'nick' })}>Лицо из Minecraft{nickName ? ` (${nickName})` : ' — укажите ник в настройках'}</button>
                <button type="button" className={'tag' + (avatarMode === 'custom' ? ' on' : '')} onClick={() => fileRef.current?.click()}>Своя картинка 🖼</button>
                <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { pickAvatar(e.target.files?.[0]); e.target.value = '' }} />
                {avatarMode === 'custom' && custom.avatarData && (
                  <>
                    <img src={custom.avatarData} alt="" className="w-9 h-9 rounded-xl object-cover border border-white/20" />
                    <button type="button" className="text-xs text-white/40 hover:text-white/80" onClick={() => setCustom({ avatar: 'letter', avatarData: '' })}>Убрать свою аву</button>
                  </>
                )}
              </div>
              <p className="text-xs text-white/35 mt-2">Своя картинка обрезается в квадрат 128×128 и хранится на вашем устройстве. Лицо из Minecraft подтягивается по нику с mc-heads.net.</p>
            </div>
            <div>
              <div className="text-sm text-white/50 mb-2">Бейджи</div>
              <div className="flex flex-wrap gap-1.5">
                {badges.map((b) => <span key={b.title} className="tag">{b.icon} {b.title}</span>)}
                <span className="tag opacity-40">🎁 Свои бейджи — скоро</span>
              </div>
            </div>
          </div>
        )}

        {tab === 'settings' && (
          <form className="space-y-6 max-w-2xl" onSubmit={save}>
            <div>
              <h3 className="font-outfit text-lg mb-3">Основное</h3>
              <div className="grid sm:grid-cols-2 gap-3">
                <label className="block text-sm text-white/50">{t(lang, 'profile.loginName')}
                  <input className="field mt-1" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} />
                </label>
                <label className="block text-sm text-white/50">{t(lang, 'profile.display')}
                  <input className="field mt-1" value={form.display} onChange={(e) => setForm({ ...form, display: e.target.value })} />
                </label>
                <label className="block text-sm text-white/50">Игровой ник (для лица-аватара)
                  <input className="field mt-1" value={form.nick} onChange={(e) => setForm({ ...form, nick: e.target.value })} />
                </label>
                <label className="block text-sm text-white/50">{t(lang, 'profile.brand')}
                  <input className="field mt-1" value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} placeholder="®VLAGUK_qwe8" />
                </label>
              </div>
            </div>
            <div>
              <h3 className="font-outfit text-lg mb-3">Профиль</h3>
              <label className="block text-sm text-white/50">{t(lang, 'profile.bio')}
                <textarea className="field mt-1 min-h-[80px]" value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} placeholder="Пара слов о себе — видно другим в превью профиля" />
              </label>
              <label className="block text-sm text-white/50 mt-3">YouTube-канал
                <input className="field mt-1" value={form.youtube} onChange={(e) => setForm({ ...form, youtube: e.target.value })} placeholder="https://youtube.com/@ваш-канал" />
              </label>
            </div>
            <div className="flex flex-wrap gap-3">
              <button className="btn btn-primary px-5 py-2" disabled={saving}>{saving ? 'Сохраняем…' : t(lang, 'profile.save')}</button>
              <button type="button" className="btn btn-ghost px-5 py-2" onClick={() => setTab('preview')}>👁 Как видят другие</button>
            </div>
            <p className="text-xs text-white/35 leading-5">{user.provider === 'local' ? 'Локальный аккаунт: данные хранятся на этом устройстве, пароль — только хеш SHA-256.' : 'Двухфакторная аутентификация появится после подключения почтового канала.'}</p>
            <details className="auth-delete-box">
              <summary>Удалить аккаунт и сессию</summary>
              <p>Операция необратима. Введите пароль и слово DELETE.</p>
              <input className="field" type="password" autoComplete="current-password" placeholder="Текущий пароль" value={deletion.password} onChange={(e) => setDeletion({ ...deletion, password: e.target.value })} />
              <input className="field" placeholder="DELETE" value={deletion.confirm} onChange={(e) => setDeletion({ ...deletion, confirm: e.target.value })} />
              <button type="button" className="btn btn-ghost px-4 py-2 text-[#ff9aaa]" onClick={async () => {
                if (deletion.confirm !== 'DELETE') return notify('Введите слово DELETE для подтверждения', 'err')
                const result = await deleteAccount(deletion.password, deletion.confirm)
                if (!result.ok) return notify(result.error, 'err')
                notify('Аккаунт удалён')
                nav('/')
              }}>Удалить аккаунт</button>
            </details>
          </form>
        )}
      </div>

      {report.open && (
        <div className="fixed inset-0 z-50 bg-black/70 grid place-items-center p-4" onClick={(e) => { if (e.target === e.currentTarget) setReport({ ...report, open: false }) }}>
          <div className="glass p-6 max-w-md w-full space-y-3">
            <h3 className="font-outfit text-xl">🚩 Жалоба на пользователя</h3>
            <p className="text-xs text-white/45">Жалоба на <b>@{user.username}</b> (в превью — ваш профиль; на чужих профилях будет их ник). Её увидят только модераторы.</p>
            <select className="field" value={report.reason} onChange={(e) => setReport({ ...report, reason: e.target.value })}>
              {REPORT_REASONS.map(([id, name]) => <option key={id} value={id} className="bg-[#12122A]">{name}</option>)}
            </select>
            <textarea className="field min-h-[80px]" placeholder="Подробности (необязательно, до 500 символов)" value={report.details} maxLength={500} onChange={(e) => setReport({ ...report, details: e.target.value })} />
            <div className="flex gap-2 justify-end">
              <button type="button" className="btn btn-ghost px-4 py-2 text-sm" onClick={() => setReport({ ...report, open: false })}>Отмена</button>
              <button type="button" className="btn btn-primary px-4 py-2 text-sm" onClick={submitReport}>Отправить жалобу</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
