/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { useEffect, useMemo } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { fileApi } from '../api'
import { useStore } from '../store'
import { t } from '../i18n'

export default function Get() {
  const { lang } = useStore()
  const [sp] = useSearchParams()
  const src = sp.get('src') || ''
  const name = String(sp.get('name') || 'cubenorixx-file').replace(/[^\w.+\-]+/g, '_').slice(0, 120)
  const take = useMemo(() => (src ? '/take.html?url=' + encodeURIComponent(src) + '&name=' + encodeURIComponent(name) : ''), [src, name])
  const zip = useMemo(() => (src ? fileApi(src, name.replace(/\.jar$/i, '.zip')) : ''), [src, name])

  useEffect(() => {
    if (take) window.location.replace(take)
  }, [take])

  return (
    <div className="relative z-10 max-w-lg mx-auto px-4 pt-16 pb-20">
      <div className="glass p-6">
        <h1 className="font-outfit text-2xl">{t(lang, 'project.getting')}</h1>
        <p className="text-white/55 mt-2 break-all font-mono text-sm">{name}</p>
        {take ? (
          <div className="mt-6 space-y-2">
            <a className="btn btn-primary dl-btn" href={take} target="_blank" rel="noopener">Скачать</a>
            <a className="btn btn-ghost dl-btn" href={zip} target="_blank" rel="noopener">Скачать .zip</a>
          </div>
        ) : (
          <p className="text-white/50 mt-4">{t(lang, 'project.noFile')}</p>
        )}
        <Link to="/catalog" className="btn btn-ghost mt-5 px-4 py-2 text-sm">{t(lang, 'project.toCatalog')}</Link>
      </div>
    </div>
  )
}
