/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { findAcrossPlatforms } from '../aggregator'
import { useStore } from '../store'
import { t } from '../i18n'
import { Tx } from '../components/Translated'
import SourceLogo from '../components/SourceLogo'
import { Icon } from '../components/SearchBox'

export default function Add() {
  const { user, addAggregated, notify, lang } = useStore()
  const nav = useNavigate()
  const [url, setUrl] = useState('')
  const [busy, setBusy] = useState(false)
  const [res, setRes] = useState(null)

  const run = async (e) => {
    e.preventDefault()
    setBusy(true)
    setRes(null)
    const r = await findAcrossPlatforms(url)
    setRes(r)
    setBusy(false)
  }

  const save = () => {
    if (!res?.merged) return
    addAggregated(res.merged)
    notify('Проект добавлен в Cubenorixx')
    nav('/project/' + res.merged.slug)
  }

  return (
    <div className="relative z-10 max-w-3xl mx-auto px-4 pt-10">
      <h1 className="font-outfit text-4xl font-bold">{t(lang, 'pages.add')}</h1>
      <p className="text-white/60 mt-2"><Tx text="Ссылка с площадки. Cubenorixx сверит дубли и возьмёт лучшее описание." /></p>
      <form className="mt-6 glass p-4 space-y-3" onSubmit={run}>
        <input className="field" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://modrinth.com/mod/sodium" required />
        <label className="text-sm text-white/50"><Tx text="Или файл" />
          <input type="file" className="field mt-1" accept=".jar,.zip,.litematic,.schem,.mcpack" />
        </label>
        <button className="btn btn-primary px-5 py-3" disabled={busy}>{busy ? t(lang, 'ui.searching') : t(lang, 'nav.add')}</button>
      </form>
      {!user && <p className="text-xs text-white/40 mt-2">Сохранение в кабинет — после <Link to="/login" className="text-orange-soft">входа</Link>.</p>}

      {res && !res.ok && <div className="glass p-4 mt-4 text-[#ff8aa0]">{res.error}</div>}

      {res?.merged && (
        <div className="mt-8 space-y-4">
          <div className="glass p-5 flex gap-4">
            <Icon src={res.merged.icon_url} letter={res.merged.title} className="w-16 h-16" />
            <div>
              <div className="text-xs text-orange-soft">Основной источник: {res.best?.platformName} · {res.best?.score} баллов</div>
              <h2 className="font-outfit text-2xl">{res.merged.title}</h2>
              <p className="text-sm text-white/70 line-clamp-4 mt-1">{String(res.merged.description || '').slice(0, 400)}</p>
            </div>
          </div>
          <h3 className="font-outfit text-xl">Найдено на платформах</h3>
          {res.platforms.map((p) => (
            <div key={p.platform} className="glass px-4 py-3 flex items-center gap-3">
              <SourceLogo id={p.platform} name={p.platformName} color={p.color} size={32} />
              <div className="flex-1">
                <div>{p.platformName}</div>
                <div className="text-xs text-white/45">{p.online ? 'площадка отвечает' : 'нет связи'} · {p.found ? 'проект есть' : 'для добавления не найден'} · {p.probeMs || 0} ms</div>
                <a className="text-xs text-white/40 truncate block" href={p.url} target="_blank" rel="noreferrer">{p.url}</a>
              </div>
              <div className="font-mono text-orange-soft">{p.score}</div>
            </div>
          ))}
          <button className="btn btn-primary px-6 py-3" onClick={save}>Создать страницу Cubenorixx</button>
        </div>
      )}
    </div>
  )
}
