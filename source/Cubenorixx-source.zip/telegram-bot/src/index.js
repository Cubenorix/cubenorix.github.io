/*
 * Cubenorixx Support Bot — Cloudflare Worker
 * Copyright (C) 2025-2026 Cubenorixx Team
 */

const BOT_COMMANDS = [
  ['start', 'Начать работу с ботом'],
  ['help', 'Помощь и частые вопросы'],
  ['support', 'Связаться с поддержкой'],
  ['site', 'Ссылка на сайт'],
  ['rules', 'Правила чата'],
  ['search', 'Поиск мода'],
  ['build', 'Создать сборку'],
  ['status', 'Статус сайта и источников'],
  ['ask', 'Задать технический вопрос ИИ'],
  ['privacy', 'Конфиденциальность бота'],
]

const memoryLimits = new Map()

function html(value) {
  return String(value || '').replace(/[&<>]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[ch])
}

function publicOrigin(env) {
  const raw = String(env.PUBLIC_ORIGIN || 'https://cubenorixx.romantic-buffalo.workers.dev').replace(/\/$/, '')
  return /^https:\/\/[A-Za-z0-9.-]+(?::\d+)?$/.test(raw) ? raw : 'https://cubenorixx.romantic-buffalo.workers.dev'
}

function routeUrl(env, path) {
  const origin = publicOrigin(env)
  const hostname = new URL(origin).hostname
  const hashRouted = hostname.endsWith('.yapp.page') || hostname.endsWith('.github.io')
  return hashRouted ? `${origin}/#${path}` : `${origin}${path}`
}

function normalizeQuery(value) {
  const source = String(value || '').trim()
  const normalized = source.toLowerCase().replace(/ё/g, 'е').replace(/[._/\\-]+/g, ' ').replace(/\s+/g, ' ')
  const aliases = [
    ['create', /(?:^|\s)(?:create|creat|crate|кре+й?т|криэ+й?т|крейт|крейд)(?:\s|$)/i],
    ['sodium', /(?:^|\s)(?:sodium|sodiom|sodi?um|содиум|содиом|соудиум|соудим)(?:\s|$)/i],
    ['jei', /(?:^|\s)(?:jei|jeu|just enough items|джей|джеи)(?:\s|$)/i],
    ['iris', /(?:^|\s)(?:iris|ирис)(?:\s|$)/i],
  ]
  for (const [canonical, pattern] of aliases) {
    if (!pattern.test(` ${normalized} `)) continue
    if (canonical === 'create' && /(?:^|\s)crate(?:\s|$)/.test(normalized) && !/(?:мод|mod|скач|download|minecraft|майнкрафт)/.test(normalized)) continue
    return canonical
  }
  return source
}

function hasSecret(text) {
  return /\b\d{6,}:[A-Za-z0-9_-]{25,}\b|\bhf_[A-Za-z0-9]{20,}\b|\b(?:password|пароль)\s*[:=]/i.test(String(text || ''))
}

async function sameSecret(a, b) {
  if (!a || !b) return false
  const enc = new TextEncoder()
  const [left, right] = await Promise.all([
    crypto.subtle.digest('SHA-256', enc.encode(String(a))),
    crypto.subtle.digest('SHA-256', enc.encode(String(b))),
  ])
  const x = new Uint8Array(left)
  const y = new Uint8Array(right)
  let diff = x.length ^ y.length
  for (let i = 0; i < Math.min(x.length, y.length); i += 1) diff |= x[i] ^ y[i]
  return diff === 0
}

function allowAi(userId) {
  const key = String(userId || 'unknown')
  const now = Date.now()
  const old = memoryLimits.get(key)
  const row = !old || old.resetAt <= now ? { hits: 0, resetAt: now + 10 * 60_000 } : old
  row.hits += 1
  memoryLimits.set(key, row)
  if (memoryLimits.size > 2000) memoryLimits.delete(memoryLimits.keys().next().value)
  return row.hits <= 8
}

async function telegram(env, method, payload) {
  if (!env.TELEGRAM_BOT_TOKEN) throw new Error('Telegram bot is not configured')
  const response = await fetch(`https://api.telegram.org/bot${env.TELEGRAM_BOT_TOKEN}/${method}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  })
  const data = await response.json().catch(() => ({}))
  if (!response.ok || !data.ok) throw new Error('Telegram API request failed')
  return data.result
}

function send(env, chatId, text, extra = {}) {
  return telegram(env, 'sendMessage', {
    chat_id: chatId,
    text: String(text).slice(0, 4096),
    parse_mode: 'HTML',
    disable_web_page_preview: true,
    ...extra,
  })
}

async function searchMods(env, query) {
  const q = normalizeQuery(query)
  if (!q) return 'Использование: <code>/search sodium</code>'
  const params = new URLSearchParams({ query: q, limit: '8', index: 'relevance' })
  const response = await fetch(`https://api.modrinth.com/v2/search?${params}`, {
    headers: { accept: 'application/json', 'user-agent': 'Cubenorixsupportbot/1.0 (https://t.me/Cubenorixsupportbot)' },
  })
  if (!response.ok) return 'Поиск Modrinth временно недоступен. Попробуйте позже.'
  const data = await response.json()
  const needle = q.toLowerCase()
  const hits = [...(data.hits || [])].sort((a, b) => {
    const score = (row) => {
      const title = String(row.title || '').toLowerCase()
      const slug = String(row.slug || '').toLowerCase()
      return title === needle || slug === needle ? 3 : title.startsWith(needle) ? 2 : title.includes(needle) ? 1 : 0
    }
    return score(b) - score(a) || Number(b.downloads || 0) - Number(a.downloads || 0)
  }).slice(0, 5)
  if (!hits.length) return `По запросу <b>${html(q)}</b> ничего не найдено.`
  const lines = hits.map((item, index) => {
    const link = routeUrl(env, `/project/${encodeURIComponent(item.slug)}`)
    const summary = String(item.description || '').replace(/\s+/g, ' ').slice(0, 120)
    return `${index + 1}. <a href="${link}"><b>${html(item.title)}</b></a>\n${html(summary)}${summary.length >= 120 ? '…' : ''}`
  })
  return `<b>Найдено для «${html(q)}»</b>\n\n${lines.join('\n\n')}`
}

async function endpointStatus(name, url) {
  const start = Date.now()
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), 7000)
  try {
    const response = await fetch(url, { method: 'GET', signal: controller.signal, headers: { accept: 'application/json', 'user-agent': 'Cubenorixsupportbot/1.0' } })
    return { name, ok: response.ok, code: response.status, ms: Date.now() - start }
  } catch {
    return { name, ok: false, code: 0, ms: Date.now() - start }
  } finally {
    clearTimeout(timer)
  }
}

async function statusText(env) {
  const origin = publicOrigin(env)
  const rows = await Promise.all([
    endpointStatus('Cubenorixx', `${origin}/api/ok.json`),
    endpointStatus('Modrinth', 'https://api.modrinth.com/v2/'),
    endpointStatus('Spigot', 'https://api.spiget.org/v2/resources?size=1&page=1&sort=-downloads'),
    endpointStatus('Hangar', 'https://hangar.papermc.io/api/v1/projects?limit=1&offset=0'),
  ])
  return '<b>Статус Cubenorixx и источников</b>\n\n' + rows.map((row) => `${row.ok ? '🟢' : '🔴'} <b>${row.name}</b> — ${row.ok ? `HTTP ${row.code}` : 'нет ответа'} · ${row.ms} мс`).join('\n') + '\n\nПроверка показывает доступность HTTP, а не полную работоспособность каждой загрузки.'
}

async function aiAnswer(env, question) {
  if (String(env.AI_ENABLED || '').toLowerCase() !== 'true' || !env.HF_TOKEN) {
    return 'ИИ-помощник пока выключен владельцем. Используйте <code>/help</code> или напишите на https://t.me/Cubenorixsupportbot.'
  }
  if (hasSecret(question)) {
    return 'Похоже, сообщение содержит пароль или токен. Я не отправляю такие данные внешнему ИИ. Отзовите раскрытый секрет и создайте новый; новый секрет не присылайте в чат.'
  }
  const model = String(env.HF_MODEL || 'openai/gpt-oss-120b:fastest')
  const response = await fetch('https://router.huggingface.co/v1/chat/completions', {
    method: 'POST',
    headers: { authorization: `Bearer ${env.HF_TOKEN}`, 'content-type': 'application/json' },
    body: JSON.stringify({
      model,
      stream: false,
      max_tokens: 500,
      temperature: 0.25,
      messages: [
        {
          role: 'system',
          content: 'Ты технический помощник Cubenorixx. Отвечай кратко и по-русски по вопросам Minecraft, модов, загрузчиков, сборок и сайта Cubenorixx. Не проси и не повторяй пароли, токены, cookie, платёжные данные или личные документы. Не выдумывай версии, ссылки, статусы и гарантии. Для аккаунтов, правовых вопросов и инцидентов направляй на https://t.me/Cubenorixsupportbot. Предупреждай, что сторонние файлы и проекты принадлежат их авторам.',
        },
        { role: 'user', content: String(question).slice(0, 1200) },
      ],
    }),
  })
  if (!response.ok) return 'ИИ-провайдер временно недоступен. Попробуйте позже или напишите на https://t.me/Cubenorixsupportbot.'
  const data = await response.json().catch(() => ({}))
  const answer = String(data?.choices?.[0]?.message?.content || '').trim()
  return answer ? html(answer).slice(0, 3900) : 'ИИ не вернул ответ. Попробуйте сформулировать вопрос иначе.'
}

function helpText() {
  return `<b>Команды Cubenorixx Support Bot</b>\n\n${BOT_COMMANDS.slice(0, 8).map(([command, description]) => `<code>/${command}</code> — ${description}`).join('\n')}\n<code>/ask вопрос</code> — ИИ-помощник; текст передаётся Hugging Face только после этой команды\n<code>/privacy</code> — обработка данных\n\nПримеры:\n<code>/search мод крейд скачать</code>\n<code>/build # create + jei + sodium</code>`
}

async function handleCommand(env, message) {
  const chatId = message.chat?.id
  const fromId = message.from?.id
  if (!chatId) return
  const text = String(message.text || '').trim()
  const [head, ...rest] = text.split(/\s+/)
  const command = head.toLowerCase().replace(/^\//, '').split('@')[0]
  const argument = rest.join(' ').trim()
  if (command === 'start') {
    return send(env, chatId, '<b>Cubenorixx Support Bot</b>\n\nЗдравствуйте! Это техподдержка Cubenorixx. Мы отвечаем в течение 24 часов. По вопросам авторских прав обращайтесь напрямую к авторам модов.\n\nКоманды: /help — список возможностей, /search — поиск проектов, /site — официальный сайт. Бот никогда не просит пароль или токен.', {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'Открыть Cubenorixx', url: publicOrigin(env) }, { text: 'Канал @Cubenorix', url: 'https://t.me/Cubenorix' }],
        ],
      },
    })
  }
  if (command === 'help') return send(env, chatId, helpText())
  if (command === 'support') return send(env, chatId, '<b>Поддержка Cubenorixx</b>\n\nПросто напишите ваш вопрос в этот чат — это и есть канал техподдержки (@Cubenorixsupportbot). Ответим в течение 24 часов.\n\nУкажите страницу, точный текст ошибки, версию Minecraft и загрузчик. Не отправляйте пароль, токен, cookie или платёжные данные. По вопросам авторских прав обращайтесь напрямую к авторам модов.')
  if (command === 'site') return send(env, chatId, `<b>Официальный сайт:</b>\n<a href="${publicOrigin(env)}">${publicOrigin(env)}</a>`)
  if (command === 'rules') return send(env, chatId, '<b>Правила чата</b>\n\n1. Без спама, угроз, оскорблений и доксинга.\n2. Не публикуйте вредоносные файлы, краки и украденные материалы.\n3. Не выдавайте себя за администрацию или автора проекта.\n4. Не отправляйте секреты и персональные данные.\n5. Соблюдайте лицензии модов и правила Telegram.\n\nПолная версия: ' + routeUrl(env, '/rules'))
  if (command === 'search') return send(env, chatId, await searchMods(env, argument))
  if (command === 'build') {
    if (!argument) return send(env, chatId, 'Использование: <code>/build create + jei + sodium</code>')
    const mods = String(argument).slice(0, 900)
    const link = routeUrl(env, `/builds?mods=${encodeURIComponent(mods)}`)
    return send(env, chatId, `<b>Сборка подготовлена к открытию</b>\n\n<a href="${link}">Открыть сборщик Cubenorixx</a>\n\nФайлы появятся только после выбора совместимых версий и успешной загрузки настоящих JAR из источника.`)
  }
  if (command === 'status') return send(env, chatId, await statusText(env))
  if (command === 'ask') {
    if (!argument) return send(env, chatId, 'Использование: <code>/ask почему Fabric не видит мод?</code>\nТекст после /ask будет передан настроенному провайдеру Hugging Face. Не включайте секреты и персональные данные.')
    if (!allowAi(fromId)) return send(env, chatId, 'Слишком много ИИ-запросов. Подождите около 10 минут или напишите на https://t.me/Cubenorixsupportbot.')
    return send(env, chatId, await aiAnswer(env, argument))
  }
  if (command === 'privacy') return send(env, chatId, '<b>Конфиденциальность</b>\n\nTelegram передаёт боту ID чата, имя пользователя и текст команды. Бот не сохраняет тикеты: /support показывает инструкцию для обращения. Текст /ask передаётся Hugging Face для формирования ответа; другие команды туда не отправляются. Не присылайте секреты. Вопросы и запросы удаления: https://t.me/Cubenorixsupportbot.')
  return send(env, chatId, 'Неизвестная команда. Используйте <code>/help</code>.')
}

async function processUpdate(env, update) {
  const message = update?.message
  if (!message?.text) return
  if (!String(message.text).startsWith('/')) {
    await send(env, message.chat?.id, 'Я отвечаю на команды. Откройте <code>/help</code>. Для ИИ-вопроса используйте <code>/ask ваш вопрос</code>.')
    return
  }
  await handleCommand(env, message)
}

export { BOT_COMMANDS, normalizeQuery, processUpdate }

export default {
  async fetch(request, env) {
    const url = new URL(request.url)
    if (request.method === 'GET' && url.pathname === '/') {
      return Response.json({
        ok: true,
        service: 'Cubenorixx Support Bot',
        username: env.BOT_USERNAME || 'Cubenorixsupportbot',
        telegramConfigured: Boolean(env.TELEGRAM_BOT_TOKEN && env.TELEGRAM_WEBHOOK_SECRET),
        aiConfigured: String(env.AI_ENABLED || '').toLowerCase() === 'true' && Boolean(env.HF_TOKEN),
      }, { headers: { 'cache-control': 'no-store' } })
    }
    if (request.method !== 'POST' || url.pathname !== '/telegram/webhook') return new Response('Not found', { status: 404 })
    const accepted = await sameSecret(request.headers.get('x-telegram-bot-api-secret-token'), env.TELEGRAM_WEBHOOK_SECRET)
    if (!accepted) return new Response('Forbidden', { status: 403 })
    const update = await request.json().catch(() => null)
    if (!update || typeof update !== 'object') return new Response('Bad request', { status: 400 })
    try {
      await processUpdate(env, update)
    } catch {
      // Telegram retries non-2xx webhook responses. Return 200 to avoid duplicate
      // user messages and duplicate paid inference calls after a send failure.
    }
    return new Response('ok', { status: 200 })
  },
}
