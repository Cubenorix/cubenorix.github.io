"""Snapshot Minecraft Forge promotions into /api/forge-promos.json.

files.minecraftforge.net does not send CORS headers, so the launcher page
cannot read it from the browser directly. We fetch it server-side at build
time and publish a same-origin copy; the page tries live first, then ours.
"""
import datetime
import json
import os
import urllib.request

URL = 'https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json'
OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'api', 'forge-promos.json')


def read_existing():
    try:
        with open(OUT, encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return {}


def main():
    existing = read_existing()
    doc = {
        'schema_version': 1,
        'source': URL,
        'generated_at': datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),
        'live': False,
        'promos': existing.get('promos') or {},
    }
    try:
        req = urllib.request.Request(URL, headers={'User-Agent': 'Cubenorixx/1.0 (+https://cubenorix.github.io)'})
        with urllib.request.urlopen(req, timeout=20) as r:
            data = json.load(r)
        promos = data.get('promos') or {}
        if promos:
            doc['promos'] = promos
            doc['live'] = True
    except Exception as e:
        print(f'forge snapshot: live fetch failed ({e}); keeping previous copy')
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, 'w', encoding='utf-8') as f:
        json.dump(doc, f, ensure_ascii=False, indent=1)
    print(f'forge promos: {len(doc["promos"])} entries, live={doc["live"]}')


if __name__ == '__main__':
    main()
