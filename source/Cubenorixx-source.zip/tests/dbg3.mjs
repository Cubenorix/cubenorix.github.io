import { chromium } from 'playwright'
const b = await chromium.launch(); const p = await b.newPage()
p.on('response', r => { if (r.url().endsWith('.js') || r.url().endsWith('.css')) console.log('LOAD:', r.url().split('/').pop(), r.status()) })
p.on('console', m => { if (m.text().includes('CX-DBG') || m.text().includes('BAR')) console.log('DBG:', m.text()) })
p.on('pageerror', e => console.log('PAGE ERR:', String(e).slice(0, 400)))
await p.goto('http://127.0.0.1:5174/#/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(4000)
console.log('h1 home:', await p.evaluate(() => document.querySelector('h1')?.textContent.trim()))
await p.goto('http://127.0.0.1:5174/#/catalog', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(5000)
const info = await p.evaluate(() => {
  const out = { bars: document.querySelectorAll('.draft-bar').length, fixed: document.querySelectorAll('.fixed').length }
  const main = document.querySelector('.page-in')
  out.mainFound = Boolean(main)
  return out
})
console.log(info)
// клик по ссылке «Каталог» в шапке как живой юзер
const link = p.locator('a[href="/catalog"]').first()
if (await link.count()) {
  await link.click({ force: true })
  await p.waitForTimeout(4000)
  console.log('after click hash:', await p.evaluate(() => location.hash))
  console.log('after click h1:', await p.evaluate(() => document.querySelector('h1')?.textContent.trim()))
  console.log('bars now:', await p.evaluate(() => document.querySelectorAll('.draft-bar').length))
}
console.log('hash:', await p.evaluate(() => location.hash))
console.log('h1:', await p.evaluate(() => [...document.querySelectorAll('h1,h2')].slice(0,4).map(x => x.textContent.trim()).join(' | ')))
const navs = await p.evaluate(() => [...document.querySelectorAll('a')].slice(0, 8).map(a => a.getAttribute('href')))
console.log('links:', navs)
await b.close()
