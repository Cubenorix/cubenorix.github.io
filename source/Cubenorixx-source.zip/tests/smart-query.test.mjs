/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
// Умный поиск по описанию: RU-интенты → английские запросы.
import test from 'node:test'
import assert from 'node:assert/strict'
import { smartQuery } from '../src/api.js'

test('smartQuery: «мод чтобы руды падали чаще» → fortune', () => {
  const s = smartQuery('мод чтобы руды падали чаще')
  assert.ok(s.queries.some((q) => q.includes('fortune')), JSON.stringify(s.queries))
})

test('smartQuery: «летающие корабли» → ship/flight', () => {
  const s = smartQuery('летающие корабли')
  assert.ok(s.queries.some((q) => /ship/.test(q)), JSON.stringify(s.queries))
})

test('smartQuery: «чтобы игра не лагала» → оптимизация', () => {
  const s = smartQuery('мод чтобы игра не лагала и фпс был выше')
  assert.ok(s.queries.some((q) => /optimization|performance|fps/.test(q)), JSON.stringify(s.queries))
})

test('smartQuery: английский запрос не трогаем (работает точный поиск)', () => {
  assert.deepEqual(smartQuery('sodium').queries, [])
  assert.deepEqual(smartQuery('shaders for 1.21').queries, [])
})

test('smartQuery: пустой запрос безопасен', () => {
  assert.deepEqual(smartQuery('').queries, [])
  assert.deepEqual(smartQuery(null).queries, [])
})
