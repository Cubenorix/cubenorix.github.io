/*
 * Cubenorixx auth worker integration test
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { handleAuth } from '../functions/_auth.js'

class FakeD1 {
  constructor() {
    this.users = new Map()
    this.sessions = new Map()
    this.rates = new Map()
  }
  prepare(sql) { return new FakeStatement(this, sql) }
}

class FakeStatement {
  constructor(db, sql) {
    this.db = db
    this.sql = sql.replace(/\s+/g, ' ').trim().toLowerCase()
    this.args = []
  }
  bind(...args) { this.args = args; return this }
  async run() {
    const [a] = this.args
    if (this.sql.startsWith('insert into auth_rate_limits')) {
      const [id, action, reset, now, , nextReset] = this.args
      const old = this.db.rates.get(id)
      this.db.rates.set(id, !old || old.reset_at <= now
        ? { id, action, hits: 1, reset_at: nextReset }
        : { ...old, hits: old.hits + 1 })
    } else if (this.sql.startsWith('insert into auth_users')) {
      const [id, email, email_norm, username, username_norm, password_hash, password_salt, password_iterations, terms_version, privacy_version, content_rules_version, accepted_at, created_at, updated_at] = this.args
      if ([...this.db.users.values()].some((u) => u.email_norm === email_norm || u.username_norm === username_norm)) throw new Error('UNIQUE constraint failed')
      this.db.users.set(id, {
        id, email, email_norm, email_verified: 0, username, username_norm,
        password_hash, password_salt, password_iterations, role: 'user', status: 'active',
        display_name: '', brand: '', minecraft_nick: '', youtube: '', bio: '',
        terms_version, privacy_version, content_rules_version, accepted_at,
        age_confirmed: 1, created_at, updated_at,
      })
    } else if (this.sql.startsWith('insert into auth_sessions')) {
      const [token_hash, user_id, created_at, expires_at] = this.args
      this.db.sessions.set(token_hash, { token_hash, user_id, created_at, expires_at })
    } else if (this.sql.startsWith('delete from auth_sessions')) {
      this.db.sessions.delete(a)
    } else if (this.sql.startsWith('update auth_users set')) {
      const [username, username_norm, display_name, brand, minecraft_nick, youtube, bio, updated_at, id] = this.args
      const row = this.db.users.get(id)
      this.db.users.set(id, { ...row, username, username_norm, display_name, brand, minecraft_nick, youtube, bio, updated_at })
    } else if (this.sql.startsWith('delete from auth_users')) {
      this.db.users.delete(a)
      for (const [key, session] of this.db.sessions) if (session.user_id === a) this.db.sessions.delete(key)
    } else throw new Error('Unhandled run SQL: ' + this.sql)
    return { success: true }
  }
  async first() {
    const [a, b] = this.args
    if (this.sql.startsWith('select hits, reset_at from auth_rate_limits')) return this.db.rates.get(a) || null
    if (this.sql.startsWith('select id from auth_users where email_norm')) {
      return [...this.db.users.values()].find((u) => u.email_norm === a || u.username_norm === b) || null
    }
    if (this.sql.includes('from auth_sessions s join auth_users')) {
      const session = this.db.sessions.get(a)
      if (!session || session.expires_at <= b) return null
      const user = this.db.users.get(session.user_id)
      return user && user.status === 'active' ? { ...user, ...session } : null
    }
    if (this.sql.startsWith('select * from auth_users where id')) return this.db.users.get(a) || null
    if (this.sql.startsWith('select * from auth_users where email_norm')) return [...this.db.users.values()].find((u) => u.email_norm === a) || null
    throw new Error('Unhandled first SQL: ' + this.sql)
  }
}

const origin = 'https://cubenorixx.pages.dev'
const env = { CUBENORIXX_DB: new FakeD1(), AUTH_PEPPER: 'integration-test-server-pepper-at-least-32-characters' }
const call = (path, method = 'GET', body, cookie = '') => handleAuth({
  env,
  path,
  request: new Request(origin + path, {
    method,
    headers: {
      ...(method !== 'GET' ? { origin } : {}),
      ...(body ? { 'content-type': 'application/json' } : {}),
      ...(cookie ? { cookie } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  }),
})

function cookiePair(response) {
  return String(response.headers.get('set-cookie') || '').split(';')[0]
}

test('Cloudflare auth flow registers, restores session, updates profile, logs in and deletes account', async () => {
  const status = await call('/api/auth/status')
  assert.equal((await status.json()).configured, true)

  const registration = await call('/api/auth/register', 'POST', {
    email: 'owner@example.com', username: 'Owner_1', password: 'correct horse battery staple',
    termsAccepted: true, privacyAccepted: true, contentRulesAccepted: true, ageConfirmed: true,
  })
  assert.equal(registration.status, 201)
  const registrationData = await registration.json()
  assert.equal(registrationData.user.email, 'owner@example.com')
  assert.match(registration.headers.get('set-cookie'), /HttpOnly; Secure; SameSite=Lax/)
  assert.equal([...env.CUBENORIXX_DB.users.values()][0].password_hash.includes('correct horse'), false)
  let cookie = cookiePair(registration)

  const me = await call('/api/auth/me', 'GET', null, cookie)
  assert.equal((await me.json()).user.username, 'Owner_1')

  const profile = await call('/api/auth/profile', 'PATCH', { username: 'Owner_2', display: 'Cubenorixx Owner', nick: 'Steve' }, cookie)
  assert.equal((await profile.json()).user.display, 'Cubenorixx Owner')

  const logout = await call('/api/auth/logout', 'POST', {}, cookie)
  assert.equal(logout.status, 200)
  const loggedOut = await call('/api/auth/me', 'GET', null, cookie)
  assert.equal(loggedOut.status, 401)

  const login = await call('/api/auth/login', 'POST', { email: 'owner@example.com', password: 'correct horse battery staple' })
  assert.equal(login.status, 200)
  cookie = cookiePair(login)

  const deletion = await call('/api/auth/delete', 'POST', { password: 'correct horse battery staple', confirm: 'DELETE' }, cookie)
  assert.equal(deletion.status, 200)
  assert.equal(env.CUBENORIXX_DB.users.size, 0)
})
