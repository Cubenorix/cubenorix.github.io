/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
// Ослабление поискового запроса: стоп-слова убираются, версии остаются.
import test from 'node:test'
import assert from 'node:assert/strict'
import { loosenQuery } from '../src/api.js'

test('loosenQuery: стоп-слова убраны, версия сохранена', () => {
  assert.equal(loosenQuery('мод sodium для 1.20.1 скачать'), 'sodium 1.20.1')
})

test('loosenQuery: точный запрос не трогает', () => {
  assert.equal(loosenQuery('sodium'), 'sodium')
  assert.equal(loosenQuery('Mod Menu'), 'mod menu')
})

test('loosenQuery: пустой/мусорный запрос не ломается', () => {
  assert.equal(loosenQuery(''), '')
  assert.equal(loosenQuery('скачать моды'), 'скачать моды') // нечего оставить — возвращаем как есть
})
