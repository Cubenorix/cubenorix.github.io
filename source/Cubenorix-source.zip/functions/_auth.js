/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */

export const AUTH_TERMS_VERSION = '2026-08-23'
export const AUTH_PRIVACY_VERSION = '2026-08-23'
export const AUTH_CONTENT_RULES_VERSION = '2026-08-23'
export const PASSWORD_ITERATIONS = 600_000
const SESSION_SECONDS = 60 * 60 * 24 * 30
const COOKIE = '__Host-cubenorixx_session'
const encoder = new TextEncoder()

function apiJson(value, init = {}) {
  const headers = new Headers(init.headers || {})
  headers.set('content-type', 'application/json; charset=utf-8')
  headers.set('cache-control', 'no-store')
  headers.set('x-content-type-options', 'nosniff')
  headers.set('referrer-policy', 'no-referrer')
  return new Response(JSON.stringify(value), { ...init, headers })
}

function bytesToBase64Url(bytes) {
  let binary = ''
  for (const byte of bytes) binary += String.fromCharCode(byte)
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
}

function base64UrlToBytes(value) {
  const normalized = String(value).replace(/-/g, '+').replace(/_/g, '/')
  const binary = atob(normalized + '='.repeat((4 - normalized.length % 4) % 4))
  return Uint8Array.from(binary, (x) => x.charCodeAt(0))
}

function randomToken(size = 32) {
  const bytes = new Uint8Array(size)
  crypto.getRandomValues(bytes)
  return bytesToBase64Url(bytes)
}

async function sha256(value) {
  return new Uint8Array(await crypto.subtle.digest('SHA-256', typeof value === 'string' ? encoder.encode(value) : value))
}

async function hmac(secret, value) {
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'])
  return new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(value)))
}

function constantTimeEqual(a, b) {
  const left = typeof a === 'string' ? base64UrlToBytes(a) : a
  const right = typeof b === 'string' ? base64UrlToBytes(b) : b
  let diff = left.length ^ right.length
  const size = Math.max(left.length, right.length)
  for (let i = 0; i < size; i += 1) diff |= (left[i % left.length] || 0) ^ (right[i % right.length] || 0)
  return diff === 0
}

export async function hashPassword(password, salt = randomToken(16), iterations = PASSWORD_ITERATIONS, pepper = '') {
  const material = await crypto.subtle.importKey('raw', encoder.encode(`${password}\u0000${pepper}`), 'PBKDF2', false, ['deriveBits'])
  const bits = await crypto.subtle.deriveBits({
    name: 'PBKDF2',
    hash: 'SHA-256',
    salt: base64UrlToBytes(salt),
    iterations,
  }, material, 256)
  return { salt, iterations, hash: bytesToBase64Url(new Uint8Array(bits)) }
}

export async function verifyPassword(password, stored, pepper = '') {
  const derived = await hashPassword(password, stored.salt, Number(stored.iterations), pepper)
  return constantTimeEqual(derived.hash, stored.hash)
}

export function validateRegistration(input) {
  const email = String(input.email || '').trim().toLowerCase()
  const username = String(input.username || '').trim()
  const password = String(input.password || '')
  const errors = []
  if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) errors.push('email')
  if (!/^[\p{L}\p{N}_-]{3,24}$/u.test(username)) errors.push('username')
  if (password.length < 12 || password.length > 128) errors.push('password')
  if (input.termsAccepted !== true) errors.push('terms')
  if (input.privacyAccepted !== true) errors.push('privacy')
  if (input.contentRulesAccepted !== true) errors.push('contentRules')
  if (input.ageConfirmed !== true) errors.push('age')
  return { ok: errors.length === 0, errors, email, username, password }
}

function configured(env) {
  return Boolean(env?.CUBENORIXX_DB && env?.AUTH_PEPPER && String(env.AUTH_PEPPER).length >= 32)
}

function originOk(request) {
  const origin = request.headers.get('origin')
  if (!origin) return false
  try { return new URL(origin).host === new URL(request.url).host } catch { return false }
}

async function readBody(request) {
  const length = Number(request.headers.get('content-length') || 0)
  if (length > 20_000) throw new Error('body-too-large')
  const text = await request.text()
  if (text.length > 20_000) throw new Error('body-too-large')
  return JSON.parse(text || '{}')
}

function cookieValue(request) {
  const source = request.headers.get('cookie') || ''
  for (const part of source.split(';')) {
    const [name, ...rest] = part.trim().split('=')
    if (name === COOKIE) return rest.join('=')
  }
  return ''
}

function sessionCookie(token, maxAge = SESSION_SECONDS) {
  return `${COOKIE}=${token}; Path=/; Max-Age=${maxAge}; HttpOnly; Secure; SameSite=Lax`
}

async function rateBucket(env, request, action, subject, limit, seconds) {
  const ip = String(request.headers.get('cf-connecting-ip') || request.headers.get('x-forwarded-for') || 'unknown').split(',')[0].trim()
  const id = bytesToBase64Url(await hmac(env.AUTH_PEPPER, `${action}\n${ip}\n${subject}`))
  const now = Math.floor(Date.now() / 1000)
  const reset = now + seconds
  await env.CUBENORIXX_DB.prepare(`
    INSERT INTO auth_rate_limits (id, action, hits, reset_at)
    VALUES (?, ?, 1, ?)
    ON CONFLICT(id) DO UPDATE SET
      hits = CASE WHEN reset_at <= ? THEN 1 ELSE hits + 1 END,
      reset_at = CASE WHEN reset_at <= ? THEN ? ELSE reset_at END
  `).bind(id, action, reset, now, now, reset).run()
  const row = await env.CUBENORIXX_DB.prepare('SELECT hits, reset_at FROM auth_rate_limits WHERE id = ?').bind(id).first()
  if (Number(row?.hits) > limit) {
    const retry = Math.max(1, Number(row.reset_at) - now)
    return apiJson({ ok: false, error: 'rate-limit', retryAfter: retry }, { status: 429, headers: { 'retry-after': String(retry) } })
  }
  return null
}

async function createSession(env, userId) {
  const token = randomToken(32)
  const tokenHash = bytesToBase64Url(await sha256(token))
  const now = Date.now()
  await env.CUBENORIXX_DB.prepare('INSERT INTO auth_sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)')
    .bind(tokenHash, userId, now, now + SESSION_SECONDS * 1000).run()
  return token
}

function publicUser(row) {
  if (!row) return null
  return {
    id: row.id,
    email: row.email,
    emailVerified: Boolean(row.email_verified),
    username: row.username,
    display: row.display_name || '',
    brand: row.brand || '',
    nick: row.minecraft_nick || '',
    youtube: row.youtube || '',
    bio: row.bio || '',
    role: row.role || 'user',
    created: row.created_at,
  }
}

async function currentSession(env, request) {
  const token = cookieValue(request)
  if (!token || token.length < 32) return null
  const tokenHash = bytesToBase64Url(await sha256(token))
  const row = await env.CUBENORIXX_DB.prepare(`
    SELECT u.*, s.token_hash, s.expires_at
    FROM auth_sessions s JOIN auth_users u ON u.id = s.user_id
    WHERE s.token_hash = ? AND s.expires_at > ? AND u.status = 'active'
  `).bind(tokenHash, Date.now()).first()
  return row || null
}

async function requireSession(env, request) {
  const row = await currentSession(env, request)
  if (!row) return { response: apiJson({ ok: false, error: 'unauthorized' }, { status: 401 }) }
  return { row }
}

function sqliteConflict(error) {
  return /UNIQUE|constraint/i.test(String(error?.message || error))
}

async function register(env, request) {
  const body = await readBody(request)
  const data = validateRegistration(body)
  if (!data.ok) return apiJson({ ok: false, error: 'invalid', fields: data.errors }, { status: 400 })
  const limited = await rateBucket(env, request, 'register', data.email, 5, 15 * 60)
  if (limited) return limited
  const existing = await env.CUBENORIXX_DB.prepare('SELECT id FROM auth_users WHERE email_norm = ? OR username_norm = ? LIMIT 1')
    .bind(data.email, data.username.toLowerCase()).first()
  if (existing) return apiJson({ ok: false, error: 'account-exists' }, { status: 409 })
  const id = crypto.randomUUID()
  const now = Date.now()
  const password = await hashPassword(data.password, undefined, PASSWORD_ITERATIONS, env.AUTH_PEPPER)
  try {
    await env.CUBENORIXX_DB.prepare(`
      INSERT INTO auth_users (
        id, email, email_norm, email_verified, username, username_norm,
        password_hash, password_salt, password_iterations, role, status,
        terms_version, privacy_version, content_rules_version, accepted_at,
        age_confirmed, created_at, updated_at
      ) VALUES (?, ?, ?, 0, ?, ?, ?, ?, ?, 'user', 'active', ?, ?, ?, ?, 1, ?, ?)
    `).bind(
      id, data.email, data.email, data.username, data.username.toLowerCase(),
      password.hash, password.salt, password.iterations,
      AUTH_TERMS_VERSION, AUTH_PRIVACY_VERSION, AUTH_CONTENT_RULES_VERSION,
      now, now, now,
    ).run()
  } catch (error) {
    if (sqliteConflict(error)) return apiJson({ ok: false, error: 'account-exists' }, { status: 409 })
    throw error
  }
  const token = await createSession(env, id)
  const row = await env.CUBENORIXX_DB.prepare('SELECT * FROM auth_users WHERE id = ?').bind(id).first()
  return apiJson({ ok: true, user: publicUser(row) }, { status: 201, headers: { 'set-cookie': sessionCookie(token) } })
}

async function login(env, request) {
  const body = await readBody(request)
  const email = String(body.email || '').trim().toLowerCase()
  const password = String(body.password || '')
  const limited = await rateBucket(env, request, 'login', email.slice(0, 254), 10, 10 * 60)
  if (limited) return limited
  const row = await env.CUBENORIXX_DB.prepare('SELECT * FROM auth_users WHERE email_norm = ? LIMIT 1').bind(email).first()
  const valid = row && row.status === 'active' && await verifyPassword(password, {
    hash: row.password_hash,
    salt: row.password_salt,
    iterations: row.password_iterations,
  }, env.AUTH_PEPPER)
  if (!valid) return apiJson({ ok: false, error: 'invalid-credentials' }, { status: 401 })
  const token = await createSession(env, row.id)
  return apiJson({ ok: true, user: publicUser(row) }, { headers: { 'set-cookie': sessionCookie(token) } })
}

async function logout(env, request) {
  const token = cookieValue(request)
  if (token) {
    const tokenHash = bytesToBase64Url(await sha256(token))
    await env.CUBENORIXX_DB.prepare('DELETE FROM auth_sessions WHERE token_hash = ?').bind(tokenHash).run()
  }
  return apiJson({ ok: true }, { headers: { 'set-cookie': sessionCookie('', 0) } })
}

async function updateProfile(env, request) {
  const auth = await requireSession(env, request)
  if (auth.response) return auth.response
  const body = await readBody(request)
  const username = String(body.username || auth.row.username).trim()
  const display = String(body.display || '').trim().slice(0, 60)
  const brand = String(body.brand || '').trim().slice(0, 60)
  const nick = String(body.nick || '').trim()
  const youtube = String(body.youtube || '').trim().slice(0, 240)
  const bio = String(body.bio || '').trim().slice(0, 600)
  if (!/^[\p{L}\p{N}_-]{3,24}$/u.test(username)) return apiJson({ ok: false, error: 'invalid', fields: ['username'] }, { status: 400 })
  if (nick && !/^[A-Za-z0-9_]{2,16}$/.test(nick)) return apiJson({ ok: false, error: 'invalid', fields: ['nick'] }, { status: 400 })
  if (youtube) {
    try {
      const host = new URL(youtube).hostname.toLowerCase()
      if (!['youtube.com', 'www.youtube.com', 'youtu.be'].includes(host)) throw new Error('host')
    } catch { return apiJson({ ok: false, error: 'invalid', fields: ['youtube'] }, { status: 400 }) }
  }
  try {
    await env.CUBENORIXX_DB.prepare(`
      UPDATE auth_users SET username = ?, username_norm = ?, display_name = ?, brand = ?, minecraft_nick = ?, youtube = ?, bio = ?, updated_at = ?
      WHERE id = ?
    `).bind(username, username.toLowerCase(), display, brand, nick, youtube, bio, Date.now(), auth.row.id).run()
  } catch (error) {
    if (sqliteConflict(error)) return apiJson({ ok: false, error: 'username-exists' }, { status: 409 })
    throw error
  }
  const row = await env.CUBENORIXX_DB.prepare('SELECT * FROM auth_users WHERE id = ?').bind(auth.row.id).first()
  return apiJson({ ok: true, user: publicUser(row) })
}

async function deleteAccount(env, request) {
  const auth = await requireSession(env, request)
  if (auth.response) return auth.response
  const body = await readBody(request)
  if (body.confirm !== 'DELETE') return apiJson({ ok: false, error: 'confirmation-required' }, { status: 400 })
  const valid = await verifyPassword(String(body.password || ''), {
    hash: auth.row.password_hash,
    salt: auth.row.password_salt,
    iterations: auth.row.password_iterations,
  }, env.AUTH_PEPPER)
  if (!valid) return apiJson({ ok: false, error: 'invalid-credentials' }, { status: 401 })
  await env.CUBENORIXX_DB.prepare('DELETE FROM auth_users WHERE id = ?').bind(auth.row.id).run()
  return apiJson({ ok: true }, { headers: { 'set-cookie': sessionCookie('', 0) } })
}

export async function handleAuth({ env, request, path }) {
  if (path === '/api/auth/status' && request.method === 'GET') {
    return apiJson({
      ok: true,
      configured: configured(env),
      emailVerification: false,
      termsVersion: AUTH_TERMS_VERSION,
      privacyVersion: AUTH_PRIVACY_VERSION,
      contentRulesVersion: AUTH_CONTENT_RULES_VERSION,
    })
  }
  if (!configured(env)) return apiJson({ ok: false, error: 'auth-not-configured' }, { status: 503 })
  if (request.method !== 'GET' && !originOk(request)) return apiJson({ ok: false, error: 'origin' }, { status: 403 })
  if (path === '/api/auth/register' && request.method === 'POST') return register(env, request)
  if (path === '/api/auth/login' && request.method === 'POST') return login(env, request)
  if (path === '/api/auth/logout' && request.method === 'POST') return logout(env, request)
  if (path === '/api/auth/profile' && request.method === 'PATCH') return updateProfile(env, request)
  if (path === '/api/auth/delete' && request.method === 'POST') return deleteAccount(env, request)
  if (path === '/api/auth/me' && request.method === 'GET') {
    const row = await currentSession(env, request)
    return row ? apiJson({ ok: true, user: publicUser(row) }) : apiJson({ ok: false, user: null, error: 'unauthorized' }, { status: 401 })
  }
  return apiJson({ ok: false, error: 'not-found' }, { status: 404 })
}
