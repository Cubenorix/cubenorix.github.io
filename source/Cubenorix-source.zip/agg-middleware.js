/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
// Все исходящие запросы идут через egressFetch: единый User-Agent (задача 10)
// и лимит 250 запросов / 90 с с очередью (задача 8).
import { egressFetch as fetch } from './egress.js'
import { metaGet, metaPutMany, metaSearch } from './metadata-cache.js'

const cache = new Map()
const projects = new Map()
const searchPromises = new Map()
let livePromise = null

function strip(s) {
  return String(s || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/!\[[^\]]*\]\([^)]+\)/g, '')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/&amp;/g, '&')
    .replace(/\s+/g, ' ')
    .trim()
}

function slugOf(platform, url, title) {
  let last = String(title || 'item').toLowerCase()
  try {
    const u = new URL(url)
    last = decodeURIComponent(u.pathname.split('/').filter(Boolean).pop() || last).replace(/\.html?$/i, '')
  } catch {}
  return (platform + '-' + last).toLowerCase().replace(/[^a-z0-9а-яё-]+/gi, '-').replace(/-+/g, '-').slice(0, 90)
}

function remember(hit) {
  if (hit?.slug) projects.set(hit.slug, { ...hit, body: hit.body || hit.description, remembered: Date.now() })
  return hit
}

function parseNum(s) {
  const m = String(s || '').replace(/,/g, '').match(/([\d.]+)\s*([KMB])?/i)
  if (!m) return 0
  const n = parseFloat(m[1])
  const u = (m[2] || '').toUpperCase()
  return Math.round(n * (u === 'K' ? 1e3 : u === 'M' ? 1e6 : u === 'B' ? 1e9 : 1))
}

async function timed(ms, fn) {
  const ctrl = new AbortController()
  const t = setTimeout(() => ctrl.abort(), ms)
  try {
    return await fn(ctrl.signal)
  } finally {
    clearTimeout(t)
  }
}

async function jina(url) {
  const text = await timed(12000, (signal) =>
    fetch('https://r.jina.ai/' + url, {
      signal,
      headers: { 'User-Agent': 'Cubenorix/1.0', Accept: 'text/plain' },
    }).then((r) => r.text()),
  )
  return text || ''
}

function parseCf(md, type) {
  const hits = []
  const simple = /\[([^\]]{3,80})\]\((https:\/\/www\.curseforge\.com\/minecraft\/(?:mc-mods|texture-packs|shaders|worlds|modpacks|bukkit-plugins|customization)\/[a-z0-9-]+)(?:\s+"[^"]*")?\)/gi
  const icons = new Map()
  const ire = /!\[Image[^\]]*:\s*([^\]]+?)\s+logo\]\((https:[^)]+)\)/gi
  let m
  while ((m = ire.exec(md))) icons.set(m[1].trim().toLowerCase(), m[2])
  const seen = new Set()
  while ((m = simple.exec(md))) {
    const title = m[1].trim()
    const url = m[2]
    if (/search\?|\/members\/|\/download|\/install|Go to /i.test(title)) continue
    if (seen.has(url)) continue
    seen.add(url)
    const slug = slugOf('curseforge', url, title)
    const icon = icons.get(title.toLowerCase()) || '/sources/curseforge.svg'
    const around = md.slice(Math.max(0, m.index - 80), m.index + 500)
    const dl = parseNum((around.match(/([\d.,]+)\s*[KMB]/) || [])[1] ? (around.match(/([\d.,]+\s*[KMB])/i) || [])[0] : '')
    const desc = strip(around.replace(title, '')).slice(0, 280)
    hits.push(remember({
      slug,
      title,
      description: desc,
      body: desc,
      url,
      icon_url: icon,
      sources: ['curseforge'],
      project_type: type || 'mod',
      author: 'CurseForge',
      downloads: dl,
      external: true,
    }))
    if (hits.length >= 24) break
  }
  return hits
}

function parsePmc(md, type) {
  const hits = []
  const re = /\[([^\]]{3,80})\]\((https:\/\/www\.planetminecraft\.com\/(?:project|skin|mob-skin|texture-pack|data-pack|mod)\/[a-z0-9-]+\/?)\)/gi
  const seen = new Set()
  let m
  while ((m = re.exec(md))) {
    const title = m[1].trim()
    const url = m[2]
    if (seen.has(url) || /login|sign|home|browse/i.test(title)) continue
    seen.add(url)
    hits.push(remember({
      slug: slugOf('pmc', url, title),
      title,
      description: title,
      body: title,
      url,
      icon_url: '/no-icon.png',
      sources: ['pmc'],
      project_type: type || 'map',
      author: 'Planet Minecraft',
      downloads: 0,
      external: true,
    }))
    if (hits.length >= 24) break
  }
  return hits
}

function parseGeneric(md, id, type, hostPart) {
  const hits = []
  const re = /\[([^\]]{3,90})\]\((https?:\/\/[^)]+)\)/gi
  const seen = new Set()
  let m
  while ((m = re.exec(md))) {
    const title = strip(m[1])
    const url = m[2].split(' ')[0]
    if (!url.includes(hostPart)) continue
    if (seen.has(url) || title.length < 3) continue
    if (/home|login|search|каталог|главн|favicon|refresh this page|troubleshooting|cookie|privacy policy/i.test(title)) continue
    seen.add(url)
    hits.push(remember({
      slug: slugOf(id, url, title),
      title: title.slice(0, 90),
      description: title,
      body: title,
      url,
      icon_url: '',
      sources: [id],
      project_type: type,
      author: id,
      downloads: 0,
      external: true,
    }))
    if (hits.length >= 10) break
  }
  return hits
}

async function curseforge(q, type) {
  const path = type === 'plugin' ? 'bukkit-plugins' : type === 'shader' ? 'shaders' : type === 'resourcepack' ? 'texture-packs' : type === 'map' ? 'worlds' : type === 'modpack' ? 'modpacks' : 'mc-mods'
  const md = await jina(`https://www.curseforge.com/minecraft/${path}/search?search=${encodeURIComponent(q)}`)
  return parseCf(md, type === 'all' ? 'mod' : type)
}

async function pmc(q, type) {
  const section = type === 'skin' ? 'skins' : (type === 'resourcepack' ? 'texture-packs' : (type === 'datapack' ? 'data-packs' : 'projects'))
  const md = await jina(`https://www.planetminecraft.com/${section}/?keywords=${encodeURIComponent(q)}`)
  return parsePmc(md, type || 'map')
}

async function github(q) {
  const j = await timed(7000, (signal) =>
    fetch('https://api.github.com/search/repositories?per_page=8&q=' + encodeURIComponent(q + ' minecraft'), {
      signal,
      headers: { 'User-Agent': 'Cubenorix/1.0', Accept: 'application/vnd.github+json' },
    }).then((r) => r.json()),
  )
  return (j.items || []).map((p) => remember({
    slug: 'github-' + p.full_name.replace(/\//g, '-'),
    title: p.name,
    description: p.description || '',
    body: p.description || '',
    url: p.html_url,
    icon_url: p.owner?.avatar_url || '/sources/github.svg',
    sources: ['github'],
    project_type: 'mod',
    author: p.owner?.login,
    downloads: p.stargazers_count || 0,
    external: true,
  }))
}

async function hangar(q) {
  const j = await timed(6000, (signal) =>
    fetch('https://hangar.papermc.io/api/v1/projects?limit=16&q=' + encodeURIComponent(q), {
      signal,
      headers: { 'User-Agent': 'Cubenorix/1.0' },
    }).then((r) => r.json()),
  )
  return (j.result || []).map((p) => remember({
    slug: 'hangar-' + (p.namespace?.slug || p.name),
    title: p.name,
    description: p.description || '',
    body: p.mainPageContent || p.description || '',
    url: `https://hangar.papermc.io/${p.namespace?.owner}/${p.namespace?.slug}`,
    icon_url: p.avatarUrl,
    sources: ['hangar'],
    project_type: 'plugin',
    author: p.namespace?.owner,
    downloads: p.stats?.downloads || 0,
    followers: p.stats?.stars || 0,
    external: true,
  }))
}

async function spiget(q) {
  const j = await timed(6000, (signal) =>
    fetch('https://api.spiget.org/v2/search/resources/' + encodeURIComponent(q) + '?size=16', {
      signal,
      headers: { 'User-Agent': 'Cubenorix/1.0' },
    }).then((r) => r.json()),
  )
  return (Array.isArray(j) ? j : []).map((p) => remember({
    slug: 'spigot-' + (p.id || p.name),
    title: p.name,
    description: p.tag || '',
    body: p.tag || p.name,
    url: 'https://www.spigotmc.org/resources/' + p.id,
    icon_url: p.icon?.url ? 'https://www.spigotmc.org/' + p.icon.url : '/sources/spigot.svg',
    sources: ['spigot'],
    project_type: 'plugin',
    author: p.author?.name,
    downloads: p.downloads || 0,
    likes: p.likes || 0,
    file: p.file?.url ? { url: 'https://api.spiget.org/v2/resources/' + p.id + '/download', filename: (p.name || 'plugin') + '.jar' } : null,
    external: true,
  }))
}

async function poggit(q) {
  const j = await timed(8000, (signal) =>
    fetch('https://poggit.pmmp.io/releases.min.json', { signal, headers: { 'User-Agent': 'Cubenorix/1.0' } }).then((r) => r.json()),
  )
  const n = q.toLowerCase()
  return (Array.isArray(j) ? j : [])
    .filter((p) => String(p.name + ' ' + (p.tagline || '')).toLowerCase().includes(n))
    .slice(0, 12)
    .map((p) => remember({
      slug: 'poggit-' + p.name,
      title: p.name,
      description: p.tagline || '',
      body: p.tagline || '',
      url: p.html_url,
      icon_url: '/sources/poggit.png',
      sources: ['poggit'],
      project_type: 'plugin',
      author: 'Poggit',
      downloads: p.downloads || 0,
      file: p.artifact_url ? { url: p.artifact_url, filename: p.name + '.phar' } : null,
      external: true,
    }))
}

async function createSearch(q) {
  const md = await jina(`https://createmod.com/ru/search?q=${encodeURIComponent(q)}`)
  const hits = []
  const re = /Featured image of ([^\]]+)\]\((https:[^)]+)\)[\s\S]{0,420}?\]\((https:\/\/createmod.com\/(?:ru\/)?schematics\/[a-z0-9-]+)\)/gi
  const seen = new Set()
  let m
  while ((m = re.exec(md))) {
    const title = m[1].trim()
    const icon = m[2]
    const url = m[3]
    if (seen.has(url)) continue
    seen.add(url)
    hits.push(remember({
      slug: slugOf('create', url, title),
      title,
      description: 'Схема Create · createmod.com',
      body: title,
      url,
      icon_url: icon || '/sources/create.png',
      sources: ['create'],
      project_type: 'schematic',
      author: 'Create Mod',
      downloads: 0,
      external: true,
    }))
    if (hits.length >= 16) break
  }
  return hits
}

async function rumcSearch(q) {
  const md = await jina(`https://ru-minecraft.ru/?s=${encodeURIComponent(q)}`)
  return parseGeneric(md, 'rumc', 'mod', 'ru-minecraft.ru')
}

async function mcmaps(q) {
  const md = await jina(`https://www.minecraftmaps.com/?s=${encodeURIComponent(q || 'survival')}`)
  return parseGeneric(md, 'mcmaps', 'map', 'minecraftmaps.com')
}

async function smithed(q) {
  const rows = await timed(7000, (signal) => fetch(
    'https://api.smithed.dev/v2/packs?search=' + encodeURIComponent(q) + '&limit=12',
    { signal, headers: { 'User-Agent': 'Cubenorix/1.0', Accept: 'application/json' } },
  ).then((r) => r.json()))
  return (Array.isArray(rows) ? rows : []).slice(0, 12).map((p) => remember({
    slug: 'smithed-' + p.id,
    title: p.displayName || p.id,
    description: 'Датапак или ресурспак Smithed',
    body: 'Датапак или ресурспак Smithed',
    url: 'https://smithed.net/packs/' + encodeURIComponent(p.id),
    icon_url: '',
    sources: ['smithed'],
    project_type: 'datapack',
    author: 'Smithed',
    downloads: 0,
    external: true,
  }))
}

async function modpackIndex(q, type = 'mod') {
  const kind = type === 'modpack' ? 'modpacks' : 'mods'
  const j = await timed(7000, (signal) => fetch(
    `https://www.modpackindex.com/api/v1/${kind}?name=${encodeURIComponent(q)}&limit=12`,
    { signal, headers: { 'User-Agent': 'Cubenorix/1.0', Accept: 'application/json' } },
  ).then((r) => r.json()))
  return (Array.isArray(j?.data) ? j.data : []).slice(0, 12).map((p) => remember({
    slug: 'modpackindex-' + (p.slug || p.id),
    title: p.name,
    description: p.summary || '',
    body: p.summary || '',
    url: p.page_url || `https://www.modpackindex.com/${type === 'modpack' ? 'modpack' : 'mod'}/${p.id}/${p.slug}`,
    icon_url: p.thumbnail_url || '',
    sources: ['modpackindex'],
    project_type: type === 'modpack' ? 'modpack' : 'mod',
    author: 'Modpack Index',
    downloads: p.download_count || 0,
    external: true,
  }))
}

async function polymart(q) {
  const j = await timed(7000, (signal) =>
    fetch('https://api.polymart.org/v1/search?query=' + encodeURIComponent(q) + '&limit=12', {
      signal,
      headers: { 'User-Agent': 'Cubenorix/1.0' },
    }).then((r) => r.json()),
  )
  const rows = j?.response?.result || []
  return rows
    .filter((p) => String(p.price || '0') === '0.00' || Number(p.price) === 0)
    .slice(0, 10)
    .map((p) => remember({
      slug: 'polymart-' + p.id,
      title: p.title,
      description: p.subtitle || '',
      body: p.subtitle || '',
      url: String(p.url || '').split('?')[0],
      icon_url: p.thumbnailURL || '',
      sources: ['polymart'],
      project_type: 'plugin',
      author: p.owner?.name,
      downloads: 0,
      external: true,
    }))
}


async function sponge(q) {
  // Ore's public JSON endpoint currently requires authorization. Its public search page
  // remains usable, so index only project links and metadata instead of faking API access.
  return siteSearch(q, 'sponge', 'plugin', 'ore.spongepowered.org', `https://ore.spongepowered.org/?q=${encodeURIComponent(q)}`)
}

function officialCores(q) {
  const n = String(q || '').toLowerCase()
  const all = [
    { slug: 'paper', title: 'Paper', url: 'https://papermc.io/software/paper', sources: ['papermc'], description: 'Ядро Paper. Только papermc.io.' },
    { slug: 'purpur', title: 'Purpur', url: 'https://purpurmc.org/downloads', sources: ['purpur'], description: 'Форк Paper. Официально purpurmc.org.' },
    { slug: 'folia', title: 'Folia', url: 'https://papermc.io/software/folia', sources: ['folia'], description: 'Региональная многопоточность PaperMC.' },
    { slug: 'velocity', title: 'Velocity', url: 'https://papermc.io/software/velocity', sources: ['velocity'], description: 'Прокси PaperMC.' },
    { slug: 'fabric-loader', title: 'Fabric Loader', url: 'https://fabricmc.net/use/installer/', sources: ['fabric'], description: 'Загрузчик Fabric. fabricmc.net.' },
    { slug: 'neoforge', title: 'NeoForge', url: 'https://neoforged.net/', sources: ['neoforge'], description: 'Преемник Forge. neoforged.net.' },
    { slug: 'forge', title: 'Minecraft Forge', url: 'https://files.minecraftforge.net/', sources: ['forge'], description: 'Классический загрузчик. files.minecraftforge.net.' },
    { slug: 'quilt', title: 'Quilt', url: 'https://quiltmc.org/en/install/', sources: ['quilt'], description: 'Форк Fabric.' },
    { slug: 'sponge', title: 'Sponge', url: 'https://spongepowered.org/downloads/', sources: ['sponge'], description: 'Платформа серверных плагинов Sponge.' },
    { slug: 'pufferfish', title: 'Pufferfish', url: 'https://github.com/pufferfish-gg/Pufferfish', sources: ['pufferfish'], description: 'Производительный форк Paper.' },
    { slug: 'leaf', title: 'Leaf', url: 'https://github.com/Winds-Studio/Leaf', sources: ['leaf'], description: 'Оптимизированный форк Paper.' },
    { slug: 'leaves', title: 'Leaves', url: 'https://leavesmc.org/', sources: ['leaves'], description: 'Форк Paper с техническими ванильными возможностями.' },
    { slug: 'cuberite', title: 'Cuberite', url: 'https://cuberite.org/', sources: ['cuberite'], description: 'Лёгкий сервер Minecraft на C++.' },
    { slug: 'powernukkitx', title: 'PowerNukkitX', url: 'https://powernukkitx.com/', sources: ['powernukkitx'], description: 'Серверное ядро Minecraft Bedrock.' },
  ]
  return all
    .filter((p) => !n || p.title.toLowerCase().includes(n) || p.slug.includes(n))
    .map((p) => remember({ ...p, project_type: 'core', author: p.sources[0], downloads: 0, external: true, body: p.description }))
}

async function siteSearch(q, id, type, host, path) {
  const md = await jina(path)
  return parseGeneric(md, id, type, host)
}

const INDEXED_SITES = [ /* скрейп-сайты отключены: только официальные API с метаданными */ ]

function hashText(value) {
  let h = 2166136261
  for (const ch of String(value || '')) h = Math.imul(h ^ ch.charCodeAt(0), 16777619)
  return h >>> 0
}

function rotatingSites(query, type, count = 2) {
  const eligible = INDEXED_SITES.filter((s) => type === 'all' ? s.types.includes('all') : s.types.includes(type))
  if (!eligible.length) return []
  // Keep fan-out bounded while gradually covering secondary indexes. The bucket changes
  // only after the response cache expires, so repeated searches do not hammer sources.
  const bucket = Math.floor(Date.now() / (15 * 60 * 1000))
  const start = hashText(`${query}|${type}|${bucket}`) % eligible.length
  return Array.from({ length: Math.min(count, eligible.length) }, (_, i) => eligible[(start + i) % eligible.length])
}

export async function liveIndex() {
  const key = 'live-index'
  const hot = cache.get(key)
  if (hot && Date.now() - hot.t < 12_000) return { ...hot.data, cached: true }
  if (livePromise) return livePromise

  livePromise = (async () => {
    const previous = cache.get('live-last-good')?.data || null
    const by = { ...(previous?.by || {}) }
    const ok = new Set()
    const set = (id, n) => {
      const value = Number(n) || 0
      if (value <= 0) return
      by[id] = value
      ok.add(id)
    }
    await Promise.all([
      timed(8000, (signal) => fetch('https://api.modrinth.com/v2/search?limit=1', { signal }).then((r) => r.json()))
        .then((d) => set('modrinth', d.total_hits)).catch(() => {}),
      timed(8000, (signal) => fetch('https://hangar.papermc.io/api/v1/projects?limit=1', { signal }).then((r) => r.json()))
        .then((d) => set('hangar', d.pagination?.count)).catch(() => {}),
      timed(8000, (signal) => fetch('https://api.spiget.org/v2/resources?size=1', { signal }))
        .then((r) => set('spigot', r.headers.get('x-total') || r.headers.get('X-Total'))).catch(() => {}),
      timed(10000, (signal) => fetch('https://poggit.pmmp.io/releases.min.json', { signal }).then((r) => r.json()))
        .then((d) => set('poggit', Array.isArray(d) ? d.length : 0)).catch(() => {}),
    ])
    const rows = Object.entries(by)
      .map(([id, n]) => ({ id, n: Number(n) || 0 }))
      .filter((row) => row.n > 0)
      .sort((a, b) => b.n - a.n)
    const sum = rows.reduce((total, row) => total + row.n, 0)
    const successful = ok.size > 0
    const data = {
      live: sum > 0,
      stale: !successful,
      relay: 'cx-pass',
      by: Object.fromEntries(rows.map((row) => [row.id, row.n])),
      total: sum,
      sources: rows.length,
      at: successful ? Date.now() : (previous?.at || Date.now()),
    }
    if (sum > 0) cache.set('live-last-good', { t: Date.now(), data })
    cache.set(key, { t: Date.now(), data })
    return data
  })().finally(() => { livePromise = null })

  return livePromise
}

export async function homeExtra() {
  const key = 'home-extra'
  const hit = cache.get(key)
  if (hit && Date.now() - hit.t < 60 * 1000) return hit.data
  const [hg, sp] = await Promise.all([
    timed(7000, (signal) => fetch('https://hangar.papermc.io/api/v1/projects?limit=12', { signal, headers: { 'User-Agent': 'Cubenorix/1.0' } }).then((r) => r.json()))
      .then((j) => (j.result || []).map((p) => remember({
        slug: 'hangar-' + (p.namespace?.slug || p.name),
        title: p.name,
        description: p.description || '',
        icon_url: p.avatarUrl,
        sources: ['hangar'],
        project_type: 'plugin',
        author: p.namespace?.owner,
        downloads: p.stats?.downloads || 0,
        external: true,
        url: `https://hangar.papermc.io/${p.namespace?.owner}/${p.namespace?.slug}`,
      }))).catch(() => []),
    timed(7000, (signal) => fetch('https://api.spiget.org/v2/resources?size=12&sort=-updateDate', { signal, headers: { 'User-Agent': 'Cubenorix/1.0' } }).then((r) => r.json()))
      .then((j) => (Array.isArray(j) ? j : []).map((p) => remember({
        slug: 'spigot-' + (p.id || p.name),
        title: p.name,
        description: p.tag || '',
        icon_url: p.icon?.url ? 'https://www.spigotmc.org/' + p.icon.url : '/sources/spigot.svg',
        sources: ['spigot'],
        project_type: 'plugin',
        downloads: p.downloads || 0,
        external: true,
        url: 'https://www.spigotmc.org/resources/' + p.id,
      }))).catch(() => []),
  ])
  const data = { hits: [...hg, ...sp].filter((x) => x && x.slug), at: Date.now() }
  cache.set(key, { t: Date.now(), data })
  return data
}

export async function aggSearch({ q, type = 'mod', limit = 20, offset = 0 }, opts = {}) {
  const query = String(q || '').trim()
  if (query.length < 2) return { hits: [], total_hits: 0, providers: [] }
  const t = type || 'all'
  const key = t + '|' + query.toLowerCase()
  const hot = cache.get(key)
  if (hot && Date.now() - hot.t < 12 * 60 * 1000) {
    return {
      hits: hot.hits.slice(offset, offset + limit),
      total_hits: hot.hits.length,
      providers: hot.providers || [],
      cached: true,
      stale: Boolean(hot.stale),
    }
  }

  const existing = searchPromises.get(key)
  if (existing) {
    const shared = await existing
    return { ...shared, hits: shared.hits.slice(offset, offset + limit), coalesced: true }
  }

  const work = (async () => {
    const jobs = []
    const providers = []
    const add = (id, job) => {
      if (jobs.length >= 5 || providers.includes(id)) return
      providers.push(id)
      jobs.push(Promise.resolve().then(job).catch(() => []))
    }
    const addSite = (site, resultType = t) => add(site.id, () => siteSearch(query, site.id, resultType === 'all' ? 'mod' : resultType, site.host, site.searchUrl(query)))
    const rotating = (count) => rotatingSites(query, t, count).forEach((site) => addSite(site))

    // Modrinth is queried separately by the client. The relay therefore contacts only a
    // small relevant batch (maximum five), never every known catalogue on each keystroke.
    if (t === 'core') {
      add('official', () => officialCores(query))
    } else if (t === 'plugin') {
      add('hangar', () => hangar(query))
      add('spigot', () => spiget(query))
      add('polymart', () => polymart(query))
      add('github', () => github(query + ' plugin'))
    } else if (t === 'bedrock') {
      add('poggit', () => poggit(query))
    } else if (t === 'emote') {
      add('github', () => github(query + ' emotecraft emote'))
    } else if (t === 'cosmetic') {
      add('github', () => github(query + ' minecraft cosmetics capes'))
    } else if (t === 'schematic') {
      add('github', () => github(query + ' litematic schematic'))
    } else if (t === 'map' || t === 'world' || t === 'skin') {
      // Нет платформ с официальным API метаданных — остаётся локальный контент и Modrinth на клиенте
    } else if (t === 'shader') {
      add('github', () => github(query + ' shader'))
    } else if (t === 'modpack') {
      add('modpackindex', () => modpackIndex(query, 'modpack'))
    } else if (t === 'all') {
      add('github', () => github(query))
      if (/paper|purpur|forge|fabric|quilt|folia|velocity|pufferfish|leaf|cuberite/i.test(query)) add('official', () => officialCores(query))
      if (hashText(query) % 2) add('hangar', () => hangar(query))
      else add('spigot', () => spiget(query))
    } else {
      add('github', () => github(query))
    }

    const parts = await Promise.all(jobs)
    const map = new Map()
    for (const row of parts.flat()) {
      if (!row?.slug) continue
      const k = String(row.title || row.slug).toLowerCase().replace(/[^a-z0-9а-яё]+/gi, '')
      if (!k) continue
      const prev = map.get(k)
      if (!prev) map.set(k, row)
      else {
        const sources = [...new Set([...(prev.sources || []), ...(row.sources || [])])]
        const better = String(row.description || '').length > String(prev.description || '').length ? row : prev
        const icon = (better.icon_url && !better.icon_url.startsWith('/sources/')) ? better.icon_url : (prev.icon_url || row.icon_url)
        map.set(k, { ...better, sources, icon_url: icon, downloads: Math.max(prev.downloads || 0, row.downloads || 0) })
      }
    }

    const fresh = [...map.values()]
    // Write-through в D1 (задача 7): сохраняем метаданные, чтобы не дёргать
    // источники повторно и держать last-good копии. Ошибки не блокируют ответ.
    if (fresh.length && opts?.env?.DB) metaPutMany(opts.env.DB, fresh).catch(() => {})
    if (!fresh.length && opts?.env?.DB) {
      // Источники пусты — пробуем last-good выдачу из локальной базы (задача 9).
      const dbHits = await metaSearch(opts.env.DB, query, t, Math.max(limit, offset + limit)).catch(() => [])
      if (dbHits.length) {
        const data = { hits: dbHits, total_hits: dbHits.length, providers: ['d1-cache'], stale: true, fromDb: true }
        cache.set(key, { t: Date.now() - 11 * 60 * 1000, hits: dbHits, providers: ['d1-cache'], stale: true })
        return data
      }
    }
    if (!fresh.length && hot?.hits?.length && Date.now() - hot.t < 24 * 60 * 60 * 1000) {
      const data = { hits: hot.hits, total_hits: hot.hits.length, providers: hot.providers || providers, stale: true }
      cache.set(key, { ...hot, stale: true })
      return data
    }
    cache.set(key, { t: Date.now(), hits: fresh, providers, stale: false })
    return { hits: fresh, total_hits: fresh.length, providers, stale: false }
  })()

  searchPromises.set(key, work)
  try {
    const data = await work
    return { ...data, hits: data.hits.slice(offset, offset + limit) }
  } finally {
    searchPromises.delete(key)
  }
}

export function aggGet(slug) {
  return projects.get(slug) || null
}

/** aggGet с обращением к D1-кешу, если в памяти нет (вызов из Worker). */
export async function aggGetCached(slug, opts = {}) {
  const mem = projects.get(slug)
  if (mem) return mem
  if (opts?.env?.DB) {
    const row = await metaGet(opts.env.DB, slug).catch(() => null)
    if (row) {
      projects.set(slug, row)
      return row
    }
  }
  return null
}

export function handleAgg(req, res, next) {
  const url = req.url || ''
  if (url.startsWith('/api/home')) {
    homeExtra()
      .then((data) => {
        res.setHeader('Content-Type', 'application/json')
        res.setHeader('Cache-Control', 'no-store')
        res.end(JSON.stringify(data))
      })
      .catch((e) => {
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify({ hits: [], error: String(e.message || e) }))
      })
    return true
  }
  if (url.startsWith('/api/live')) {
    liveIndex()
      .then((data) => {
        res.setHeader('Content-Type', 'application/json')
        res.setHeader('Cache-Control', 'public, max-age=10, stale-while-revalidate=60')
        res.setHeader('X-Cubenorix-Updated-At', String(data.at || Date.now()))
        res.end(JSON.stringify(data))
      })
      .catch((e) => {
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify({ live: false, total: 0, error: String(e.message || e) }))
      })
    return true
  }
  if (url.startsWith('/api/search') || url.startsWith('/api/agg-search')) {
    const u = new URL(url, 'http://local')
    aggSearch({
      q: u.searchParams.get('q') || '',
      type: u.searchParams.get('type') || 'all',
      limit: Number(u.searchParams.get('limit') || 24),
      offset: Number(u.searchParams.get('offset') || 0),
    })
      .then((data) => {
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify(data))
      })
      .catch((e) => {
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify({ hits: [], total_hits: 0, error: String(e.message || e) }))
      })
    return true
  }
  if (url.startsWith('/api/agg-get')) {
    const u = new URL(url, 'http://local')
    const p = aggGet(u.searchParams.get('slug') || '')
    res.setHeader('Content-Type', 'application/json')
    res.statusCode = p ? 200 : 404
    res.end(JSON.stringify(p || { missing: true }))
    return true
  }
  return false
}
