#!/usr/bin/env node
/* Configure Telegram only after the Worker is deployed. Secrets come from the
 * process environment; this script never writes or prints them. */
const token = process.env.TELEGRAM_BOT_TOKEN
const secret = process.env.TELEGRAM_WEBHOOK_SECRET
const workerUrl = String(process.env.BOT_WORKER_URL || '').replace(/\/$/, '')
if (!token || !secret || !workerUrl.startsWith('https://')) {
  console.error('Set TELEGRAM_BOT_TOKEN, TELEGRAM_WEBHOOK_SECRET and BOT_WORKER_URL in your local shell. Do not put them in source files or chat.')
  process.exit(1)
}
if (!/^[A-Za-z0-9_-]{16,256}$/.test(secret)) {
  console.error('TELEGRAM_WEBHOOK_SECRET must use 16-256 letters, digits, underscores or hyphens.')
  process.exit(1)
}
const api = async (method, payload = {}) => {
  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload),
  })
  const data = await response.json().catch(() => ({}))
  if (!response.ok || !data.ok) throw new Error(`${method} failed: ${data.description || response.status}`)
  return data.result
}
const me = await api('getMe')
if (String(me.username || '').toLowerCase() !== 'cubenorixxsupportbot') {
  console.error(`The token belongs to @${me.username || 'unknown'}, not @CubenorixSupportBot.`)
  process.exit(1)
}
await api('setMyCommands', { commands: [
  { command: 'start', description: 'Начать работу с ботом' },
  { command: 'help', description: 'Помощь и частые вопросы' },
  { command: 'support', description: 'Связаться с поддержкой' },
  { command: 'site', description: 'Ссылка на сайт' },
  { command: 'rules', description: 'Правила чата' },
  { command: 'search', description: 'Поиск мода' },
  { command: 'build', description: 'Создать сборку' },
  { command: 'status', description: 'Статус сайта и источников' },
  { command: 'ask', description: 'Задать технический вопрос ИИ' },
  { command: 'privacy', description: 'Конфиденциальность бота' },
] })
await api('setWebhook', {
  url: `${workerUrl}/telegram/webhook`,
  secret_token: secret,
  allowed_updates: ['message'],
  drop_pending_updates: true,
})
const info = await api('getWebhookInfo')
console.log(`Configured @${me.username} webhook: ${info.url}`)
console.log('Token and webhook secret were not printed or written to disk.')
