# Cubenorix

Премиальный агрегатор контента Minecraft. **cube + phoenix** — центр вселенной.

**Лицензия собственного кода:** GNU AGPL-3.0-or-later. Полный текст — `LICENSE`; разделение прав на бренд, оригинальный и сторонний контент — `NOTICE.md` и `CONTENT-LICENSE.md`.

Слоган: *Делаем Minecraft лучше для каждого игрока. Моды, шейдеры, плагины — всё, что нужно для идеальной игры. Minecraft в каждый дом.*

## Стек

React 18 · Vite · Tailwind CSS 3 · JSZip · 60 подключённых площадок/инструментов, CDN-скачивание через Cubenorix

## Запуск

```bash
npm install
npm run dev
```

Откройте http://localhost:5173

## Аккаунты

Настоящая серверная регистрация подготовлена для Cloudflare Pages + D1: PBKDF2-SHA-256, индивидуальная соль, серверный pepper, HttpOnly cookie, проверка Origin, лимиты входа, версионные согласия, профиль и удаление аккаунта. Подключение владельцем Cloudflare описано в `AUTH_SETUP.md`.

На статическом Yapp регистрация намеренно отключена. Старые демонстрационные пароли из localStorage больше не читаются и удаляются при следующем сохранении настроек.

## Что работает в этой сборке

- Живой каталог и карточки проектов с **реальными иконками** Modrinth
- Поиск с автодополнением, оператор `+`, история 10 запросов
- Скачивание файлов с CDN источника (прогресс-бар, fallback)
- Сборки до 200 модов: `create + sodium + jei`, строгие версии (`sodium 0.6.13`) и режим `#` до 12 параллельных скачиваний
- Диагностика соединения (IP, провайдер, пинг источников)
- 4 генератора команд Minecraft
- 64 языка с видимыми флагами, локализованные даты/числа, перевод динамического интерфейса, RTL, Galactic 🌌 и Morse 🔊
- Ограниченная агрегация: до 5 релевантных вторичных источников на запрос, кэш, coalescing и last-good данные
- Авторизация, кабинет, избранное, отзывы, достижения
- Все пункты навигации и футера — рабочие страницы

Неофициальный фан-сайт. Minecraft — Mojang Studios.

### 2026 catalogue and repair upgrade

- 77 classified sources, with an Emotecraft hub, 26 curated SPEMOTES packs and expanded skin/cape/cosmetic directories.
- A live combined catalogue currently exposes over 246,000 real source records from Modrinth, Spigot and Hangar; the “All” view mixes all three with usable paging.
- `100` cards per request/page with numbered navigation, lazy rendering and a visible per-source count breakdown.
- Exact dependency/version IDs and direct links are surfaced before download when the source provides them.
- Builder ZIPs contain signature-checked real `mods/*.jar` payloads, preserve Cubenorix v2/Modrinth metadata, and refuse to present a metadata-only archive as a ready pack.
- Leading `#` visibly partitions work into up to 12 tasks (for example, 40 entries become 12 task cards).
- Local SHA-256 inspection plus MCDoctor, Dig Yourself Out, VirusTotal, update-checker, compatibility-checker and guided binary-search workflows.
- First-visit language uses browser locale with edge country fallback; an explicit language choice always wins.
- Search-ready title, square Cubenorix favicon/logo, Organization/WebSite structured data, absolute sitemap, 264 crawlable project pages (including `/projects/create/`) and a crawlable official-identity page.
- Official Telegram: **https://t.me/Cubenorix** (`@Cubenorix`) in the header, home page, community page, footer, `sameAs`, `rel="me"` and `/official/` verification records.
- IndexNow submission is available through `python3 scripts/submit_indexnow.py`; Google indexing still requires ownership verification in Google Search Console.
- The source contains no hosting badge. Free Yapp injects its own “Made with yapp.page” badge; removing that requires an unbranded host such as account-backed Cloudflare Pages.

## Technical-support bot

The separate Cloudflare Worker in `telegram-bot/` implements the official `@Cubenorixsupportbot` command menu. Deployment and secret rotation are owner actions described in `TELEGRAM_BOT_SETUP.md`; no Telegram or Hugging Face token is stored in the project. AI is disabled by default and only explicit `/ask` text may be sent to Hugging Face.

## Launcher draft

Public, no-secret launcher manifests live under `public/api/`. They remain disabled/empty until genuine reviewed archives exist. `LAUNCHER_BACKEND.md` explains Mojang metadata generation, Cloudflare R2 storage, SHA-256, Ed25519 signing, safe extraction and activation. The unlinked `/launcher-lab` route is a status panel, not a security boundary.

## Disclaimer

Cubenorix — независимый некоммерческий проект, не аффилированный с Mojang Studios, Microsoft или правообладателями модов. Все ссылки ведут на официальные источники.

Cubenorix не хранит и не распространяет файлы модов: сайт работает как каталог метаданных и прокси-редирект на официальные CDN источников (Modrinth CDN, Forge CDN, Hangar CDN и другие разрешённые домены). Названия, логотипы и файлы сторонних проектов принадлежат их авторам. Minecraft является товарным знаком Mojang Studios.

Техническая поддержка: [@Cubenorixsupportbot](https://t.me/Cubenorixsupportbot) · ответы в течение 24 часов; вопросы авторских прав — напрямую авторам модов.
