/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { readFileSync } from 'fs'
import { dirname, join } from 'path'
import { fileURLToPath } from 'url'

const root = dirname(fileURLToPath(import.meta.url))
let pngCache = null
function stampPng() {
  if (pngCache) return pngCache
  try { pngCache = readFileSync(join(root, 'public', 'no-icon-256.png')) }
  catch {
    pngCache = Buffer.from(
      'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
      'base64',
    )
  }
  return pngCache
}

function findEocd(buf) {
  const min = Math.max(0, buf.length - 22 - 0xffff)
  for (let i = buf.length - 22; i >= min; i--) {
    if (buf[i] === 0x50 && buf[i + 1] === 0x4b && buf[i + 2] === 0x05 && buf[i + 3] === 0x06) return i
  }
  return -1
}

function shiftZip(zip, add) {
  const out = Buffer.from(zip)
  const eocd = findEocd(out)
  if (eocd < 0) return null
  const cdOff = out.readUInt32LE(eocd + 16)
  const total = out.readUInt16LE(eocd + 10)
  if (cdOff + 4 > out.length) return null
  out.writeUInt32LE((cdOff + add) >>> 0, eocd + 16)
  let p = cdOff
  for (let n = 0; n < total; n++) {
    if (p + 46 > out.length || out.readUInt32LE(p) !== 0x02014b50) return null
    const nameLen = out.readUInt16LE(p + 28)
    const extraLen = out.readUInt16LE(p + 30)
    const commentLen = out.readUInt16LE(p + 32)
    const loc = out.readUInt32LE(p + 42)
    out.writeUInt32LE((loc + add) >>> 0, p + 42)
    p += 46 + nameLen + extraLen + commentLen
  }
  return out
}

export function pngZip(zipBuf) {
  const png = stampPng()
  if (!zipBuf || zipBuf.length < 4 || zipBuf[0] !== 0x50 || zipBuf[1] !== 0x4b) {
    return png
  }
  const shifted = shiftZip(zipBuf, png.length)
  return Buffer.concat([png, shifted || zipBuf])
}
