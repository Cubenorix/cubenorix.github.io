# Официальный Telegram Cubenorixx

Единственный объявленный официальный Telegram-канал проекта:

- URL: **https://t.me/Cubenorix**
- Username: **@Cubenorix**
- Название канала в Telegram на момент проверки: **Cubenorix**
- Страница на сайте: `/community`
- Страница проверки адресов: `/official/`

## Где ссылка размещена

- кнопка `@Cubenorix` в шапке;
- плашка официального канала на главной;
- отдельная страница `/community`;
- футер;
- crawlable-страница `/official/`;
- `Organization.sameAs` и `<link rel="me">` в SEO-метаданных;
- `public/official.json` и `public/.well-known/cubenorixx.json`.

## Проверка подлинности

Точное написание — `t.me/Cubenorix`. Другие страницы и каналы с названием Cubenorixx не считаются официальными только из-за совпадения имени. Официальный сайт и канал должны взаимно ссылаться друг на друга; владельцу канала рекомендуется добавить `https://cubenorixx.romantic-buffalo.workers.dev/` в описание Telegram.

## Публикации

Канал подходит для:

1. новостей Cubenorixx и новых функций;
2. подборок модов, карт, шейдеров, плагинов и сборок;
3. статуса сайта и источников;
4. предупреждений о копиях и точных официальных адресах.

## Бот технической поддержки

Отдельный официальный бот: **https://t.me/Cubenorixsupportbot** (`@Cubenorixsupportbot`). Это не второй новостной канал. Подготовленный Cloudflare Worker содержит команды `/start`, `/help`, `/support`, `/site`, `/rules`, `/search`, `/build` и `/status`; фактический запуск требует безопасной замены ранее раскрытых токенов и настройки webhook владельцем по `TELEGRAM_BOT_SETUP.md`.

Неофициальный фан-сайт Minecraft. Minecraft — товарный знак Mojang Studios.
