# Cubenorix content and brand policy

Effective version: 2026-08-23  
Copyright © 2025–2026 Cubenorix Team.

## 1. Code

Original program code is covered by `AGPL-3.0-or-later` as described in `LICENSE` and `NOTICE.md`.

## 2. Cubenorix brand and original materials

Except where a file expressly states another license, the following are **not** granted under the AGPL code license:

- the Cubenorix name as a source identifier;
- the official imported Cubenorix logo and brand presentation;
- original editorial copy, policies, screenshots and promotional materials;
- any trade dress capable of making a fork look official.

All rights in those original materials are reserved by Cubenorix Team. You may make factual references required by the AGPL, but may not represent a fork as the official Cubenorix service or imply endorsement.

## 3. Third-party content

Cubenorix does not claim ownership of Minecraft, mods, plugins, maps, shaders, project descriptions, project icons, screenshots, source-platform marks or downloadable files owned by third parties. Each remains governed by its source license and applicable law. Nothing in this repository grants broader rights to those materials.

## 4. User submissions

Users retain ownership of submissions they have the right to publish. By publishing through Cubenorix they grant only the non-exclusive permission described in the current Terms of Use, necessary to store, process and display that submission through the service.

## 5. Contact

Licensing and rights questions: https://t.me/Cubenorixsupportbot
