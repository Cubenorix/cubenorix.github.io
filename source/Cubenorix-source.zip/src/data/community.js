/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
/** Единственный официальный Telegram-канал Cubenorix. */
export const OFFICIAL_TELEGRAM = 'https://t.me/Cubenorix'
export const SUPPORT_BOT_USERNAME = 'Cubenorixsupportbot'
export const SUPPORT_BOT_TELEGRAM = `https://t.me/${SUPPORT_BOT_USERNAME}`
export const SUPPORT_CONTACT = SUPPORT_BOT_TELEGRAM

export const COMMUNITY = {
  name: 'Cubenorix',
  username: 'Cubenorix',
  usernames: ['Cubenorix'],
  url: OFFICIAL_TELEGRAM,
  type: 'channel',
  lang: 'ru',
  support: SUPPORT_BOT_TELEGRAM,
  server: 'mc.7cubes.ru:25565',
  bedrock: '19132',
  youtube: 'https://www.youtube.com/@%D0%92%D0%BB%D0%B0%D0%B4%D0%B8%D0%BA%D0%9C%D0%B0%D0%B9%D0%BD%D0%B0',
}

export const TOPICS = [
  { id: 'news', name: 'Новости Cubenorix', who: 'официально', hint: 'Анонсы сайта, новые функции и важные изменения.' },
  { id: 'catalog', name: 'Каталог и сборки', who: 'релизы', hint: 'Подборки модов, карт, шейдеров, плагинов и полезных сборок.' },
  { id: 'status', name: 'Статус сервиса', who: 'оперативно', hint: 'Сообщения о доступности сайта, источников и скачивания.' },
  { id: 'safety', name: 'Безопасность', who: 'проверено', hint: 'Предупреждения о копиях и точные официальные адреса Cubenorix.' },
]

export function joinUrl() {
  return OFFICIAL_TELEGRAM
}
