/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
export const SITE_REVIEWS = []

export const CREATOR = {
  nick: 'BLAGUK_qwe8',
  name: 'ВладикМайн',
  brand: '®VLAGUK_qwe8',
  server: 'mc.7cubes.ru:25565',
}
