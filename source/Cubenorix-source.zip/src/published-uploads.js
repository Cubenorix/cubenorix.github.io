/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
// ПУБЛИЧНЫЕ проекты авторов Cubenorix. Эти записи зашиты в сам сайт, поэтому
// их видят ВСЕ посетители (не только то устройство, где прошло одобрение).
// Как проект попадает сюда: автор отправляет проект → владелец одобряет →
// в Профиль → Проекты → «Код для публикации» → код приходит в команду
// Cubenorix → проект добавляется в этот файл и публикуется с обновлением сайта.
// Когда подключим общий сервер (Worker + D1), этот список станет живой базой.

export const PUBLISHED_UPLOADS = [
  {
    id: 'pub-afk-use-jubik',
    title: 'AFK_Use-Jubik',
    description: 'Мод автора qwe8 для Minecraft 1.21.5 (Fabric). Подробности, файлы и обновления — в репозитории автора.',
    type: 'mod',
    github: 'https://github.com/khlsha-web/AFK_Use-Jubik',
    versions: ['1.21.5'],
    loaders: ['fabric'],
    categories: ['utility'],
    user: 'qwe8',
    display: 'qwe8',
    status: 'accepted',
    downloads: 3,
    likes: 0,
    at: 1788000000000,
    comments: [
      { user: 'Cubenorix', text: 'Проект принят администрацией Cubenorix. Файл доступен в репозитории автора.', at: 1788000000000 },
    ],
  },
]
