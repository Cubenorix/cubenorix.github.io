/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { useEffect, useMemo, useRef, useState } from 'react'
import { UI_LANGS } from '../i18n'
import Flag from './Flag'

export default function LangSwitch({ lang, setLang }) {
  const [open, setOpen] = useState(false)
  const [query, setQuery] = useState('')
  const box = useRef(null)
  const search = useRef(null)
  const cur = UI_LANGS.find((l) => l.id === lang) || UI_LANGS[0]
  const shown = useMemo(() => {
    const q = query.trim().toLocaleLowerCase()
    const popular = ['ru', 'en', 'ua', 'de', 'fr', 'es', 'zh-cn', 'pt-br', 'pl', 'tr', 'it', 'cs']
    const score = (l) => {
      if (l.id === lang) return -100
      const p = popular.indexOf(l.id)
      if (p >= 0) return p
      if (l.id === 'gc') return 900
      if (l.id === 'morse') return 901
      return 100
    }
    const ordered = [...UI_LANGS].sort((a, b) => score(a) - score(b) || a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }))
    if (!q) return ordered
    return ordered.filter((l) => `${l.name} ${l.id} ${l.locale || ''}`.toLocaleLowerCase().includes(q))
  }, [query, lang])

  useEffect(() => {
    const hide = (e) => { if (!box.current?.contains(e.target)) setOpen(false) }
    const keys = (e) => {
      if (e.key === 'Escape') setOpen(false)
    }
    document.addEventListener('mousedown', hide)
    document.addEventListener('touchstart', hide)
    document.addEventListener('keydown', keys)
    return () => {
      document.removeEventListener('mousedown', hide)
      document.removeEventListener('touchstart', hide)
      document.removeEventListener('keydown', keys)
    }
  }, [])

  useEffect(() => {
    if (!open) return
    setQuery('')
    requestAnimationFrame(() => search.current?.focus())
  }, [open])

  return (
    <div className="lang-switch" ref={box}>
      <button
        type="button"
        className="lang-btn"
        onClick={() => setOpen((v) => !v)}
        aria-label="Language"
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        <Flag id={cur.id} />
        <span className="lang-name">{cur.name}</span>
      </button>
      {open ? (
        <div className="lang-drop glass-strong" role="listbox" aria-label="Language">
          <div className="lang-search-wrap">
            <input
              ref={search}
              className="lang-search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={`${UI_LANGS.length} languages · search`}
              aria-label="Search language"
            />
          </div>
          <div className="lang-options">
            {shown.map((l) => (
              <button
                key={l.id}
                type="button"
                role="option"
                aria-selected={l.id === lang}
                className={'lang-opt' + (l.id === lang ? ' on' : '')}
                onClick={() => { setLang(l.id); setOpen(false) }}
              >
                <Flag id={l.id} />
                <span>{l.name}</span>
                <small>{l.id.toUpperCase()}</small>
              </button>
            ))}
          </div>
        </div>
      ) : null}
    </div>
  )
}
