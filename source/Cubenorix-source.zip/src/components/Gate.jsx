/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { useEffect } from 'react'

export default function Gate({ children }) {
  useEffect(() => {
    try {
      if (sessionStorage.getItem('cx_gate') === '1') return
    } catch {}
    ;(async () => {
      try {
        const s = await fetch('/api/gate/start').then((r) => r.json())
        await fetch('/api/gate/ok', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ nonce: s.nonce, human: true }),
        })
        try { sessionStorage.setItem('cx_gate', '1') } catch {}
      } catch {}
    })()
  }, [])
  return children
}
