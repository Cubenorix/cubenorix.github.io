/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { fileApi } from '../api'

function fileName(file, name) {
  let n = String(file?.filename || name || 'mod.jar').replace(/[^\w.+\-]+/g, '_').slice(0, 120)
  if (!/\.[a-z0-9]{1,8}$/i.test(n)) n += '.jar'
  return n
}

export function fileHref(file, name) {
  if (!file?.url) return ''
  const u = String(file.url)
  if (u.startsWith('/') && !u.startsWith('//')) return u
  return fileApi(u, fileName(file, name))
}

export function fileGo(file, name) {
  return fileHref(file, name)
}

export function fileZip(file, name) {
  return fileHref(file, name)
}

export function fileTake(file, name) {
  return fileHref(file, name)
}

export function kickDownload(href) {
  if (!href) return
  const a = document.createElement('a')
  a.href = href
  a.setAttribute('download', '')
  a.style.display = 'none'
  document.body.appendChild(a)
  a.click()
  a.remove()
}

export async function kuzyaDownload(file, name) {
  const href = fileHref(file, name)
  if (!href) return { ok: false, title: 'Нет файла', body: 'На CDN ссылки нет.' }
  kickDownload(href)
  return { ok: true, href }
}

export function KuzyaToast() {
  return null
}

export default function KuzyaButton({ file, label, className, name }) {
  const href = fileHref(file, name)
  const nm = fileName(file, name)
  if (!href) return <span className="text-sm text-white/45">Файла на CDN нет</span>
  return (
    <a className={className || 'btn btn-primary px-6 py-3'} href={href} download={nm}>
      {label || 'Скачать'}
    </a>
  )
}
