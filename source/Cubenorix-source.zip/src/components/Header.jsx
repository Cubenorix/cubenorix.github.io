/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { useEffect, useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { LogIn, Send } from 'lucide-react'
import { useStore } from '../store'
import { t } from '../i18n'
import SearchBox from './SearchBox'
import LangSwitch from './LangSwitch'

const MAIN = ['catalog', 'builds']
const MORE = [
  ['servers', '/servers'],
  ['hosting', '/hosting'],
  ['guides', '/guides'],
  ['generators', '/generators'],
  ['wiki', '/wiki'],
  ['forum', '/forum'],
  ['community', '/community'],
]
const PATH = { catalog: '/catalog', builds: '/builds' }

export default function Header() {
  const { lang, setLang, user } = useStore()
  const [on, setOn] = useState(false)
  const [more, setMore] = useState(false)
  useEffect(() => {
    const fn = () => setOn(window.scrollY > 12)
    fn()
    window.addEventListener('scroll', fn, { passive: true })
    return () => window.removeEventListener('scroll', fn)
  }, [])
  return (
    <header className={`sticky top-0 z-40 hdr ${on ? 'hdr-on' : ''}`}>
      <div className="mx-auto max-w-7xl px-4 flex items-center gap-3 h-16">
        <Link to="/" className="flex items-center gap-2 shrink-0 logo-wrap">
          <img src="/logo.png?v=3" alt="Cubenorix" className="logo-img" width="40" height="40" />
          <div className="hidden sm:block">
            <div className="font-outfit font-extrabold text-lg leading-none tracking-wide">Cubenorix</div>
          </div>
        </Link>
        <nav className="hidden lg:flex items-center gap-1 text-sm">
          {MAIN.map((k) => (
            <NavLink key={k} to={PATH[k]} className={({ isActive }) => `px-3 py-1.5 rounded-pill ${isActive ? 'text-orange-soft' : 'text-white/70 hover:text-white'}`}>
              {t(lang, 'nav.' + k)}
            </NavLink>
          ))}
          <NavLink to="/wiki" className={({ isActive }) => `px-3 py-1.5 rounded-pill ${isActive ? 'text-orange-soft' : 'text-white/70 hover:text-white'}`}>{t(lang, 'nav.wiki')}</NavLink>
          <NavLink to="/reviews" className={({ isActive }) => `px-3 py-1.5 rounded-pill ${isActive ? 'text-orange-soft' : 'text-white/70 hover:text-white'}`}>{t(lang, 'nav.reviews')}</NavLink>
          <NavLink to="/top" className={({ isActive }) => `px-3 py-1.5 rounded-pill ${isActive ? 'text-orange-soft' : 'text-white/70 hover:text-white'}`}>{t(lang, 'nav.top')}</NavLink>
          <div className="relative">
            <button className="px-3 py-1.5 text-white/70 hover:text-white" onClick={() => setMore((v) => !v)}>{t(lang, 'nav.more')}</button>
            {more && (
              <div className="absolute top-full left-0 mt-2 glass-strong p-2 min-w-[180px] z-50 pop-in">
                {MORE.map(([k, to]) => (
                  <NavLink key={k} to={to} onClick={() => setMore(false)} className="block px-3 py-2 rounded-xl text-sm text-white/75 hover:bg-white/5 hover:text-white">
                    {t(lang, 'nav.' + k)}
                  </NavLink>
                ))}
                <Link to="/add" onClick={() => setMore(false)} className="block px-3 py-2 rounded-xl text-sm text-white/75 hover:bg-white/5">{t(lang, 'nav.add')}</Link>
                <Link to="/connection" onClick={() => setMore(false)} className="block px-3 py-2 rounded-xl text-sm text-white/75 hover:bg-white/5">{t(lang, 'nav.conn')}</Link>
              </div>
            )}
          </div>
        </nav>
        <div className="flex-1 min-w-0 hidden md:block">
          <SearchBox compact />
        </div>
        <div className="flex items-center gap-2 ml-auto">
          <a
            href="https://t.me/Cubenorix"
            target="_blank"
            rel="me noopener noreferrer"
            className="header-telegram"
            aria-label="Официальный Telegram Cubenorix — @Cubenorix"
            title="Официальный Telegram · @Cubenorix"
          >
            <Send size={17} aria-hidden="true" />
            <span className="hidden xl:inline">@Cubenorix</span>
          </a>
          <LangSwitch lang={lang} setLang={setLang} />
          {user ? (
            <Link to="/profile" className="btn btn-ghost px-3 py-2 text-sm">{user.username}</Link>
          ) : (
            <Link to="/login" className="btn btn-ghost px-3 py-2 text-sm"><LogIn size={16} /> {t(lang, 'auth.login')}</Link>
          )}
        </div>
      </div>
      <div className="md:hidden max-w-7xl mx-auto px-4 pb-2">
        <SearchBox compact />
      </div>
      <div className="lg:hidden max-w-7xl mx-auto px-4 overflow-x-auto hide-scroll flex gap-2 pb-2">
        {MAIN.map((k) => (
          <NavLink key={k} to={PATH[k]} className={({ isActive }) => `whitespace-nowrap text-xs px-3 py-1 rounded-pill ${isActive ? 'tag on' : 'tag'}`}>
            {t(lang, 'nav.' + k)}
          </NavLink>
        ))}
        {MORE.map(([k, to]) => (
          <NavLink key={k} to={to} className={({ isActive }) => `whitespace-nowrap text-xs px-3 py-1 rounded-pill ${isActive ? 'tag on' : 'tag'}`}>
            {t(lang, 'nav.' + k)}
          </NavLink>
        ))}
      </div>
    </header>
  )
}
