/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { localize } from '../api'
import { isBundledTranslation } from '../i18n'
import { useStore } from '../store'

const records = new WeakMap()
const attributeRecords = new WeakMap()
const translatedCache = new Map()
const translatedPromises = new Map()
const CYRILLIC = /[А-Яа-яЁёІіЇїЄєҐґ]/
const LATIN = /[A-Za-z]/
const SKIP = 'script,style,noscript,code,pre,kbd,input,textarea,select,option,[data-no-translate],.notranslate,.lang-switch,.source-chip,.cx-card,.project-title'
const TECHNICAL = /^(?:minecraft|cubenorixx|modrinth|curseforge|github|hangar|spigotmc?|poggit|polymart|mojang|papermc|purpur|fabric|forge|neoforge|quilt|sponge|velocity|folia|optifine|geysermc|blockbench|mcreator|misode|namemc|mcpedl|smithed|zip|jar|json|sha-?1|sha-?256|api|cdn|vpn|ip|asn|uuid|url|html|css|javascript|java|bedrock|create|jei|sodium|iris|ok|ms)$/i

function clean(text) {
  return String(text || '').replace(/\s+/g, ' ').trim()
}

function looksTechnical(text) {
  const value = clean(text)
  if (!value) return true
  if (/https?:\/\/|www\.|@[\w.-]+|^[\w.-]+\.(?:jar|zip|json|png|jpg|webp|svg|toml|yml)$/i.test(value)) return true
  if (/^[\d\s.,:/+%#-]+(?:ms|kb|mb|gb|tb|fps|hz|x)?$/i.test(value)) return true
  if (TECHNICAL.test(value)) return true
  if (!/\s/.test(value) && (/^[A-Z\d_.+:/#-]{2,}$/.test(value) || /\d+\.\d+/.test(value))) return true
  return false
}

function needsTranslation(text, lang) {
  const value = clean(text)
  // Russian is the authored source locale. Keep its wording and product names intact;
  // automatic translation is for the other 63 choices.
  if (lang === 'ru' || !value || isBundledTranslation(lang, value) || looksTechnical(value)) return false
  if (lang === 'gc' || lang === 'morse') return CYRILLIC.test(value) || LATIN.test(value)
  if (CYRILLIC.test(value)) return lang !== 'ru'
  if (LATIN.test(value)) return lang !== 'en'
  return false
}

function canTrack(node, lang) {
  if (!node?.parentElement || node.parentElement.closest(SKIP)) return false
  const text = clean(node.nodeValue)
  return text.length >= 2 && text.length <= 1200 && (needsTranslation(text, lang) || records.has(node))
}

function textNodes(root, lang) {
  const out = []
  if (!root) return out
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT)
  let node
  while ((node = walker.nextNode())) {
    if (canTrack(node, lang)) out.push(node)
  }
  return out
}

async function cachedTranslation(source, lang) {
  const key = `${lang}|${source}`
  const cached = translatedCache.get(key)
  if (cached) return cached
  const pending = translatedPromises.get(key)
  if (pending) return pending
  const work = localize(source, lang, { preview: false }).then((output) => {
    const result = output || source
    // Cache unchanged technical words too (for example "Wiki"); otherwise every status
    // mutation would retry them and waste the shared translation budget.
    translatedCache.set(key, result)
    if (translatedCache.size > 1500) translatedCache.delete(translatedCache.keys().next().value)
    return result
  }).finally(() => translatedPromises.delete(key))
  translatedPromises.set(key, work)
  return work
}

async function translateNode(node, lang, active) {
  if (!node?.isConnected || !active()) return
  const current = String(node.nodeValue || '')
  let rec = records.get(node)
  if (!rec) {
    rec = { source: current, output: current, lang: '' }
    records.set(node, rec)
  } else if (rec.lang !== lang && current !== rec.output && current !== rec.source) {
    // React supplied a newly bundled value while changing languages. Trust it instead of
    // translating (for example, Polish "Strona główna" must not be guessed as English).
    if (isBundledTranslation(lang, current) || !needsTranslation(current, lang)) {
      rec.source = current
      rec.output = current
      rec.lang = lang
      return
    }
    rec.source = current
    rec.output = ''
  } else if (rec.lang === lang && current !== rec.output && current !== rec.source) {
    // Status/API text changed without a locale switch; this is a new source value.
    rec.source = current
    rec.output = ''
  }

  const source = rec.source
  rec.lang = lang
  if (!needsTranslation(source, lang)) {
    rec.output = source
    if (node.nodeValue !== source) node.nodeValue = source
    return
  }

  const output = await cachedTranslation(source, lang)
  if (!node.isConnected || !active() || rec.source !== source || rec.lang !== lang) return
  rec.output = output
  if (node.nodeValue !== rec.output) node.nodeValue = rec.output
}

function translatableAttributes(root, lang) {
  if (!root) return []
  const elements = [root, ...root.querySelectorAll('[placeholder],[title],[aria-label]')]
  const out = []
  for (const el of elements) {
    if (!(el instanceof Element) || el.closest('[data-no-translate],.notranslate,code,pre,kbd')) continue
    const known = attributeRecords.get(el)
    for (const attr of ['placeholder', 'title', 'aria-label']) {
      if (!el.hasAttribute(attr)) continue
      const value = el.getAttribute(attr) || ''
      if (needsTranslation(value, lang) || known?.has(attr)) out.push([el, attr])
    }
  }
  return out
}

async function translateAttribute(element, attr, lang, active) {
  if (!element?.isConnected || !active()) return
  const current = element.getAttribute(attr) || ''
  let map = attributeRecords.get(element)
  if (!map) {
    map = new Map()
    attributeRecords.set(element, map)
  }
  let rec = map.get(attr)
  if (!rec) {
    rec = { source: current, output: current, lang: '' }
    map.set(attr, rec)
  } else if (rec.lang !== lang && current !== rec.output && current !== rec.source) {
    if (isBundledTranslation(lang, current) || !needsTranslation(current, lang)) {
      rec.source = current
      rec.output = current
      rec.lang = lang
      return
    }
    rec.source = current
    rec.output = ''
  } else if (rec.lang === lang && current !== rec.output && current !== rec.source) {
    rec.source = current
    rec.output = ''
  }

  const source = rec.source
  rec.lang = lang
  if (!needsTranslation(source, lang)) {
    rec.output = source
    if (current !== source) element.setAttribute(attr, source)
    return
  }
  const output = await cachedTranslation(source, lang)
  if (!element.isConnected || !active() || rec.source !== source || rec.lang !== lang) return
  rec.output = output
  if (element.getAttribute(attr) !== output) element.setAttribute(attr, output)
}

export default function AutoTranslatePage() {
  const { lang } = useStore()
  const location = useLocation()

  useEffect(() => {
    let stopped = false
    let timer = 0
    const root = document.querySelector('.app-col') || document.getElementById('root')
    const active = () => !stopped
    const run = () => {
      clearTimeout(timer)
      timer = window.setTimeout(() => {
        if (stopped) return
        const nodes = textNodes(root, lang)
        const attrs = translatableAttributes(root, lang)
        // localize() owns the shared five-request queue; this layer never fans out directly.
        for (const node of nodes) translateNode(node, lang, active).catch(() => {})
        for (const [element, attr] of attrs) translateAttribute(element, attr, lang, active).catch(() => {})
      }, 35)
    }
    run()
    const observer = new MutationObserver((mutations) => {
      if (mutations.some((m) => m.type === 'characterData' || m.type === 'attributes' || m.addedNodes.length)) run()
    })
    if (root) observer.observe(root, {
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: ['placeholder', 'title', 'aria-label'],
      subtree: true,
    })
    return () => {
      stopped = true
      clearTimeout(timer)
      observer.disconnect()
    }
  }, [lang, location.pathname, location.search])

  return null
}
