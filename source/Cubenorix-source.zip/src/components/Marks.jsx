/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { t } from '../i18n'

function uiLang() {
  try {
    const raw = localStorage.getItem('cubenorixx.v1') || localStorage.getItem('cubenix.v1') || '{}'
    const lang = JSON.parse(raw).lang || 'ru'
    return lang
  } catch { return 'ru' }
}

function Svg({ size = 18, className = '', children, title }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" className={`inline-block align-[-3px] ${className}`} aria-label={title} role="img">
      {title && <title>{title}</title>}
      {children}
    </svg>
  )
}

export function StatusMark({ status, size = 18 }) {
  if (status === 'rejected' || status === 'deny') {
    return (
      <Svg size={size} title={t(uiLang(), 'verify.reject')}>
        <circle cx="12" cy="12" r="10" fill="#3a1016" stroke="#ff4d6a" strokeWidth="1.8" />
        <path d="M8 8 L16 16 M16 8 L8 16" stroke="#ff6b81" strokeWidth="2.2" strokeLinecap="round" />
      </Svg>
    )
  }
  if (status === 'review' || status === 'pending') {
    return (
      <Svg size={size} title={t(uiLang(), 'verify.pending')}>
        <circle cx="12" cy="12" r="10" fill="#2a2210" stroke="#ffb347" strokeWidth="1.8" />
        <path d="M12 7 V12 L15.5 14.5" stroke="#ffb347" strokeWidth="2" strokeLinecap="round" fill="none" />
      </Svg>
    )
  }
  return (
    <Svg size={size} title={t(uiLang(), 'verify.accept')}>
      <circle cx="12" cy="12" r="10" fill="#0d2a1c" stroke="#3dd68c" strokeWidth="1.8" />
      <path d="M7.5 12.5 L10.5 15.5 L16.5 8.5" stroke="#3dd68c" strokeWidth="2.2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  )
}

function Cube({ top, left, right, extra }) {
  return (
    <>
      <path d="M12 3.2 L20.2 7.6 L12 12 L3.8 7.6 Z" fill={top} />
      <path d="M3.8 7.6 L12 12 V20.8 L3.8 16.4 Z" fill={left} />
      <path d="M20.2 7.6 L12 12 V20.8 L20.2 16.4 Z" fill={right} />
      {extra}
    </>
  )
}

export function VerifyMark({ level, size = 18 }) {
  if (level === 'divine') {
    return (
      <Svg size={size} title={t(uiLang(), 'verify.divine')} className="badge-divine">
        <defs>
          <linearGradient id="cx-dv" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ff2d2d">
              <animate attributeName="stop-color" values="#ff2d2d;#ffb347;#3dd68c;#3b82f6;#a855f7;#ff2d2d" dur="3.2s" repeatCount="indefinite" />
            </stop>
            <stop offset="50%" stopColor="#ffb347">
              <animate attributeName="stop-color" values="#ffb347;#3dd68c;#3b82f6;#a855f7;#ff2d2d;#ffb347" dur="3.2s" repeatCount="indefinite" />
            </stop>
            <stop offset="100%" stopColor="#7c5cff">
              <animate attributeName="stop-color" values="#7c5cff;#ff2d2d;#ffb347;#3dd68c;#3b82f6;#7c5cff" dur="3.2s" repeatCount="indefinite" />
            </stop>
          </linearGradient>
        </defs>
        <Cube top="url(#cx-dv)" left="#9a1c6a" right="#1d4ed8" extra={<circle cx="12" cy="10" r="1.4" fill="#fff" />} />
      </Svg>
    )
  }
  if (level === 'legend') {
    return (
      <Svg size={size} title={t(uiLang(), 'verify.legend')} className="badge-star">
        <Cube top="#ff4d4d" left="#9a1c1c" right="#c81e1e" extra={<path d="M12 6.2 L12.7 8.4 H15 L13.2 9.7 L13.9 12 L12 10.6 L10.1 12 L10.8 9.7 L9 8.4 H11.3 Z" fill="#f5c542" />} />
      </Svg>
    )
  }
  if (level === 'star') {
    return (
      <Svg size={size} title={t(uiLang(), 'verify.star')}>
        <Cube top="#c084fc" left="#6b21a8" right="#7e22ce" />
      </Svg>
    )
  }
  if (level === 'known') {
    return (
      <Svg size={size} title={t(uiLang(), 'verify.known')}>
        <Cube top="#facc15" left="#a16207" right="#ca8a04" />
      </Svg>
    )
  }
  if (level === 'popular') {
    return (
      <Svg size={size} title={t(uiLang(), 'verify.popular')}>
        <Cube top="#60a5fa" left="#1d4ed8" right="#2563eb" />
      </Svg>
    )
  }
  if (level === 'new') {
    return (
      <Svg size={size} title="Новичок">
        <Cube top="#4ade80" left="#15803d" right="#16a34a" />
      </Svg>
    )
  }
  return null
}
