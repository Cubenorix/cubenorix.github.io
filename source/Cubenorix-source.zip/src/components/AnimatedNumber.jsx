/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { useEffect, useRef, useState } from 'react'

// Число «едет» от предыдущего значения к новому (и вниз, если проект удалили).
export default function AnimatedNumber({ value, format, className }) {
  const target = Number(value) || 0
  const [shown, setShown] = useState(target)
  const fromRef = useRef(target)
  useEffect(() => {
    const from = fromRef.current
    if (from === target) return
    const start = performance.now()
    const dur = 700
    let raf
    const step = (now) => {
      const t = Math.min(1, (now - start) / dur)
      const eased = 1 - Math.pow(1 - t, 3)
      const cur = Math.round(from + (target - from) * eased)
      setShown(cur)
      fromRef.current = cur
      if (t < 1) raf = requestAnimationFrame(step)
    }
    raf = requestAnimationFrame(step)
    return () => cancelAnimationFrame(raf)
  }, [target])
  const fmt = format || ((n) => n.toLocaleString('ru-RU'))
  return <span className={className}>{fmt(shown)}</span>
}
