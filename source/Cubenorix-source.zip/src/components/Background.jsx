/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
export default function Background() {
  return <div className="bg-canvas" aria-hidden />
}
