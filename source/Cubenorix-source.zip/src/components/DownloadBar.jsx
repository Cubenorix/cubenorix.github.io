/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { useEffect, useMemo, useState } from 'react'
import { createPortal } from 'react-dom'
import { t } from '../i18n'
import { downloadWithProgress, getProject, getVersion } from '../api'
import KuzyaButton, { fileHref } from './Kuzya'

function niceSize(n) {
  const b = Number(n) || 0
  if (b <= 0) return ''
  if (b < 1024) return b + ' B'
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB'
  return (b / (1024 * 1024)).toFixed(2) + ' MB'
}

function fileOf(v) {
  const files = Array.isArray(v?.files) ? v.files : []
  return files.find((f) => f && f.primary) || files[0] || v?.file || null
}

export default function DownloadBar({ file, label = 'Скачать', name }) {
  return <KuzyaButton file={file} label={label} name={name} className="btn btn-primary px-6 py-3" />
}

function DependencyWarnings({ version }) {
  const [rows, setRows] = useState([])
  useEffect(() => {
    let alive = true
    const deps = (version?.dependencies || []).filter((d) => ['required', 'incompatible'].includes(d.dependency_type)).slice(0, 20)
    if (!deps.length) { setRows([]); return () => { alive = false } }
    Promise.all(deps.map(async (d) => {
      let project = null
      let exact = null
      try { if (d.project_id) project = await getProject(d.project_id) } catch {}
      try { if (d.version_id) exact = await getVersion(d.version_id) } catch {}
      return {
        ...d,
        slug: project?.slug || d.project_id || '',
        title: project?.title || d.file_name || d.project_id || 'dependency',
        version: exact?.version_number || exact?.name || '',
      }
    })).then((next) => { if (alive) setRows(next) })
    return () => { alive = false }
  }, [version?.id, version?.version_number])
  if (!rows.length) return null
  return (
    <div className="dl-deps mb-3">
      <div className="text-xs font-semibold text-orange-soft mb-1">Проверь перед скачиванием</div>
      {rows.map((d, i) => {
        const bad = d.dependency_type === 'incompatible'
        const wanted = d.version
          ? `точная версия ${d.version}`
          : `совместимая с ${(version?.game_versions || []).slice(0, 3).join(', ') || 'этой версией'}${d.version_id ? ` (ID ${d.version_id})` : '; точный номер не закреплён источником'}`
        return (
          <div key={(d.project_id || d.file_name || 'dep') + i} className={'dl-dep ' + (bad ? 'bad' : 'need')}>
            <span>{bad ? 'Конфликтует с' : 'Также установить'}:</span>{' '}
            {d.slug ? <a href={'/project/' + encodeURIComponent(d.slug)}>{d.title}</a> : <b>{d.title}</b>}
            <small>{bad ? ' — не ставить вместе' : ' — ' + wanted}</small>
          </div>
        )
      })}
    </div>
  )
}

export function DownloadModal({ open, onClose, versions = [], lang = 'ru' }) {
  const loaders = useMemo(() => {
    const s = new Set()
    for (const v of versions) for (const l of v.loaders || []) s.add(l)
    return [...s]
  }, [versions])
  const games = useMemo(() => {
    const s = new Set()
    for (const v of versions) for (const g of v.game_versions || []) s.add(g)
    return [...s]
  }, [versions])
  const [loader, setLoader] = useState('')
  const [game, setGame] = useState('')

  useEffect(() => {
    if (!open) return
    if (!loader && loaders[0]) setLoader(loaders[0])
    if (!game && games[0]) setGame(games[0])
  }, [open, loaders, games])

  const filtered = versions.filter((v) => {
    if (loader && !(v.loaders || []).includes(loader)) return false
    if (game && !(v.game_versions || []).includes(game)) return false
    return true
  })
  const pick = filtered[0] || versions[0]
  const file = fileOf(pick)
  const href = fileHref(file)
  const nm = String(file?.filename || 'mod.jar')
  const [pct, setPct] = useState(0)
  const [going, setGoing] = useState(false)

  const go = async (e) => {
    if (!file?.url) return
    e.preventDefault()
    setGoing(true)
    setPct(6)
    try {
      await downloadWithProgress(file, setPct)
    } catch {
      if (href) window.location.assign(href)
    }
    setGoing(false)
  }

  if (!open) return null
  return createPortal(
    <div className="dl-pop-bg" onClick={onClose}>
      <div className="dl-pop" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <div className="font-outfit text-lg">{t(lang, 'project.download')}</div>
          <button type="button" className="btn btn-ghost px-3 py-1 text-sm" onClick={onClose}>✕</button>
        </div>
        {loaders.length > 0 && (
          <div className="mb-3">
            <div className="text-xs text-white/45 mb-1">{t(lang, 'ui.loader')}</div>
            <div className="flex flex-wrap gap-1.5">
              {loaders.map((l) => (
                <button key={l} type="button" className={'tag' + (loader === l ? ' on' : '')} onClick={() => setLoader(l)}>{l}</button>
              ))}
            </div>
          </div>
        )}
        {games.length > 0 && (
          <div className="mb-3">
            <div className="text-xs text-white/45 mb-1">{t(lang, 'ui.gameVer')}</div>
            <select className="field py-2 font-mono text-sm" value={game} onChange={(e) => setGame(e.target.value)}>
              {games.slice(0, 80).map((g) => <option key={g} value={g} className="bg-[#1c1c20]">{g}</option>)}
            </select>
          </div>
        )}
        <div className="text-sm text-white/60 mb-3">
          {pick ? (
            <>
              <span className="font-mono text-orange-soft">{pick.version_number}</span>
              {file?.filename ? <div className="truncate mt-1">{file.filename} {niceSize(file.size)}</div> : null}
            </>
          ) : t(lang, 'ui.noMatch')}
        </div>
        <DependencyWarnings version={pick} />
        {href ? (
          <>
            <a className="btn btn-primary w-full py-3" href={href} download={nm} onClick={go}>{going ? 'Качаю…' : 'Скачать'}</a>
            {going ? <div className="progress mt-3"><div style={{ width: pct + '%' }} /></div> : null}
          </>
        ) : (
          <p className="text-sm text-white/50">{t(lang, 'project.noFile')}</p>
        )}
      </div>
    </div>,
    document.body,
  )
}

export function DownloadPanel({ file, label, hint, lang = 'ru', extra, onOpen }) {
  const href = fileHref(file)
  const nm = file ? String(file.filename || 'mod.jar') : ''
  const size = niceSize(file?.size)

  if (!href && !onOpen) {
    return (
      <div className="dl-panel">
        <p className="text-sm text-white/50">{t(lang, 'project.noFile')}</p>
        {extra}
      </div>
    )
  }

  return (
    <div className="dl-panel">
      {onOpen ? (
        <button type="button" className="btn btn-primary dl-btn" onClick={onOpen}>
          {label || t(lang, 'project.download')}
        </button>
      ) : (
        <a className="btn btn-primary dl-btn" href={href} download={nm}>
          {label || t(lang, 'project.download')}
        </a>
      )}
      {nm ? (
        <div className="dl-meta">
          <div className="truncate" title={nm}>{nm}</div>
          {size ? <div className="text-white/40 font-mono">{size}</div> : null}
        </div>
      ) : null}
      {hint ? <p className="dl-hint">{hint}</p> : null}
      {extra}
    </div>
  )
}
