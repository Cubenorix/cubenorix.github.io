/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { languageMeta } from '../languages'

// Every ordinary language uses a bundled country/region SVG from the genuine
// open flag-icons set. Bundling avoids missing emoji flags on Windows and in
// sandboxed browsers. Galactic and Morse intentionally keep their own symbols.
export default function Flag({ id, className = 'lang-flag' }) {
  const meta = languageMeta(id)
  if (meta.special) {
    return <span className={`${className} lang-emoji`} aria-hidden="true">{meta.flag || '🌐'}</span>
  }
  const region = String(meta.locale || 'en-GB').split('-').at(-1).toLowerCase()
  return (
    <span className={className} aria-hidden="true">
      <img src={`/flags/${region}.svg`} alt="" width="22" height="15" loading="lazy" decoding="async" />
    </span>
  )
}
