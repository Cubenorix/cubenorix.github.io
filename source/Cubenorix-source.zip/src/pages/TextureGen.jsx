/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
// Генератор текстур-паков Cubenorix: замена символов (шрифт) на свои картинки,
// 3D-вид предметов по имени (CustomModelData, работает БЕЗ OptiFine),
// предпросмотр чата/таба/инвентаря, загрузка готового пака для дополнения,
// выгрузка одним ZIP. Всё в браузере, без сервера.
import { useEffect, useMemo, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import JSZip from 'jszip'
import { useStore } from '../store'
import { Page } from './Misc'
// saveBlob живёт в api.js (экспорт по умолчанию в packfix отсутствует)
import { t } from '../i18n'
import { saveBlob } from '../api'

const PACK_FORMATS = [
  ['1.21.5', 55], ['1.21.2 – 1.21.4', 46], ['1.21 – 1.21.1', 34],
  ['1.20.5 – 1.20.6', 32], ['1.20.2 – 1.20.4', 18], ['1.20 – 1.20.1', 15],
  ['1.19.4', 13], ['1.18.2', 8], ['1.17', 7], ['1.16.2 – 1.16.5', 6],
]
const ITEMS = ['diamond_sword', 'netherite_sword', 'diamond_pickaxe', 'netherite_pickaxe', 'diamond_axe', 'elytra', 'bow', 'crossbow', 'shield', 'stick', 'paper', 'emerald', 'diamond', 'netherite_ingot', 'golden_sword']
const DEFAULT_MC = '#FF5555'

function uid() { return Math.random().toString(36).slice(2, 9) }

function readImage(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader()
    r.onload = () => resolve(String(r.result || ''))
    r.onerror = reject
    r.readAsDataURL(file)
  })
}

// Предпросмотр чата/таба: рендерим строку с подменой символов на картинки.
function ChatPreview({ text, fontMap, symbolSize = 18 }) {
  const parts = useMemo(() => {
    const out = []
    for (const ch of String(text || '')) {
      const e = fontMap[ch]
      if (e) out.push({ img: e.dataUrl, ch })
      else out.push({ ch })
    }
    return out
  }, [text, fontMap])
  return (
    <div className="flex flex-wrap items-center gap-[1px] font-mono" style={{ lineHeight: 1 }}>
      {parts.map((p, i) => p.img
        ? <img key={i} src={p.img} alt={p.ch} style={{ height: symbolSize, width: symbolSize, objectFit: 'contain', imageRendering: 'pixelated' }} />
        : <span key={i} style={{ height: symbolSize, display: 'inline-flex', alignItems: 'center' }}>{p.ch}</span>)}
    </div>
  )
}

export default function TextureGen() {
  const { notify, lang } = useStore()
  const [mcVer, setMcVer] = useState('1.21.5')
  const [packName, setPackName] = useState('Cubenorix-Textures')
  const [packDesc, setPackDesc] = useState('Сделано в генераторе текстур-паков Cubenorix')

  // ==== Замена символов (шрифт) ====
  // { id, char, dataUrl, name }
  const [chars, setChars] = useState([{ id: uid(), char: '∆', dataUrl: '', name: '' }])
  // ==== 3D по имени предмета (CustomModelData) ====
  // { id, item, name (имя на наковальне), dataUrl, cmd }
  const [models, setModels] = useState([{ id: uid(), item: 'diamond_sword', name: '', dataUrl: '', cmd: 1 }])
  const [importing, setImporting] = useState(false)

  const fontMap = useMemo(() => {
    const m = {}
    for (const c of chars) if (c.char && c.dataUrl) m[c.char] = c
    return m
  }, [chars])

  const demoText = 'Сервер Cubenorix ∆ лучшая арена ∆ заходи!'

  const addChar = () => setChars((v) => [...v, { id: uid(), char: '', dataUrl: '', name: '' }])
  const addModel = () => setModels((v) => [...v, { id: uid(), item: 'diamond_sword', name: '', dataUrl: '', cmd: 1 }])
  const patch = (setter) => (id, kv) => setter((list) => list.map((x) => (x.id === id ? { ...x, ...kv } : x)))
  const patchChar = patch(setChars)
  const patchModel = patch(setModels)
  const dropRow = (setter) => (id) => setter((list) => list.filter((x) => x.id !== id))
  const dropChar = dropRow(setChars)
  const dropModel = dropRow(setModels)

  // ==== Сборка ZIP ====
  const nextCmd = (item) => {
    const used = models.filter((m) => m.item === item).map((m) => Number(m.cmd) || 0)
    return (used.length ? Math.max(...used) : 0) + 1
  }

  const buildZip = async () => {
    const fmt = (PACK_FORMATS.find(([v]) => v === mcVer) || [])[1] || 55
    const zip = new JSZip()
    zip.file('pack.mcmeta', JSON.stringify({ pack: { pack_format: fmt, description: packDesc || 'Cubenorix textures' } }, null, 2))
    zip.file('README.txt', [
      `Текстур-пак «${packName}» — генератор Cubenorix`,
      `Версия Minecraft: ${mcVer}`,
      '',
      'ЧТО ВНУТРИ:',
      ...(chars.some((c) => c.dataUrl) ? ['- Свои символы в чате/табе/независимо от OptiFine (файл шрифта default.json)'] : []),
      ...(models.some((m) => m.dataUrl) ? ['- 3D/картинки на предметах по ИМЕНИ (CustomModelData — работает без OptiFine)'] : []),
      '',
      models.some((m) => m.dataUrl) ? [
        'КАК ВКЛЮЧИТЬ 3D ПО ИМЕНИ (для сервера):',
        '1. Положи этот пак в ресурс-паки сервера (server-resource-packs) или раздай игрокам.',
        '2. Выдай предмет командой вида:',
        '   /give @p minecraft:diamond_sword[minecraft:custom_name=\'{"text":"<имя из генератора>"}\',minecraft:custom_model_data=1] 1',
        '   (на 1.20.4 и старше: /give @p diamond_sword{CustomModelData:1,display:{Name:\'{"text":"<имя>"}\'}} 1)',
        '3. Предмет с таким именем получит картинку из пака. OptiFine не нужен.',
      ].join('\n') : '',
    ].filter((x) => x !== '').join('\n'))

    // Шрифт: подмена символов
    const usedChars = chars.filter((c) => c.char && c.dataUrl)
    if (usedChars.length) {
      const fonts = {}
      for (const c of usedChars) {
        const path = `assets/cubenorix/font/char_${c.id}.png`
        zip.file(path, c.dataUrl.split(',')[1], { base64: true })
        const ns = 'cubenorix'
        ;(fonts[ns] = fonts[ns] || { providers: [] }).providers.push({
          type: 'bitmap',
          file: `${ns}:font/char_${c.id}.png`,
          ascent: 12,
          height: 16,
          chars: [c.char],
        })
      }
      // Перезаписываем default.json: сначала vanilla-провайдеры не трогаем —
      // Minecraft мерджит шрифты, но надёжнее добавить СВОЙ шрифт-провайдер последним.
      zip.file('assets/minecraft/font/default.json', JSON.stringify({ providers: [] }, null, 2))
      for (const [ns, body] of Object.entries(fonts)) {
        zip.file(`assets/${ns}/font/default.json`, JSON.stringify(body, null, 2))
      }
      // Ванильный default.json должен остаться: дописываем наши провайдеры в него
      const merged = { providers: [] }
      for (const [, body] of Object.entries(fonts)) merged.providers.push(...body.providers)
      zip.file('assets/minecraft/font/default.json', JSON.stringify(merged, null, 2))
    }

    // Модели: CustomModelData по имени предмета
    const usedModels = models.filter((m) => m.dataUrl && m.item)
    const byItem = {}
    for (const m of usedModels) (byItem[m.item] = byItem[m.item] || []).push(m)
    for (const [item, list] of Object.entries(byItem)) {
      const overrides = []
      for (const m of list) {
        const texBase = `item/${item}_cubenorix_${m.id}`
        zip.file(`assets/minecraft/textures/${texBase}.png`, m.dataUrl.split(',')[1], { base64: true })
        zip.file(`assets/minecraft/models/${texBase}.json`, JSON.stringify({
          parent: 'minecraft:item/handheld',
          textures: { layer0: `minecraft:${texBase}` },
        }, null, 2))
        overrides.push({ predicate: { custom_model_data: Number(m.cmd) || 1 }, model: `minecraft:${texBase}` })
      }
      zip.file(`assets/minecraft/models/item/${item}.json`, JSON.stringify({
        parent: 'minecraft:item/handheld',
        textures: { layer0: `minecraft:item/${item}` },
        overrides,
      }, null, 2))
    }

    const blob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' })
    const name = `${String(packName || 'Cubenorix-Textures').replace(/[^\w.-]+/g, '-')}.zip`
    saveBlob(blob, name)
    notify('Готово: ' + name)
  }

  // ==== Загрузка готового пака (дополнение) ====
  const importPack = async (file) => {
    if (!file) return
    setImporting(true)
    try {
      const zip = await JSZip.loadAsync(file)
      const found = { chars: [], models: [] }
      // чужие символы из font json
      for (const path of Object.keys(zip.files)) {
        if (/assets\/.*font\/.*\.json$/.test(path) && !path.includes('default')) {
          try {
            const j = JSON.parse(await zip.file(path).async('text'))
            for (const p of j.providers || []) {
              if (p.type !== 'bitmap' || !Array.isArray(p.chars)) continue
              const imgPath = String(p.file || '').replace(/^.*:/, 'assets/')
              const f = zip.file(imgPath)
              if (!f) continue
              const b64 = await f.async('base64')
              for (const ch of p.chars) found.chars.push({ id: uid(), char: ch, dataUrl: `data:image/png;base64,${b64}`, name: imgPath })
            }
          } catch {}
        }
        if (/assets\/.*models\/item\/.*\.json$/.test(path)) {
          try {
            const j = JSON.parse(await zip.file(path).async('text'))
            for (const ov of j.overrides || []) {
              const cmd = Number(ov.predicate?.custom_model_data) || 0
              if (!cmd) continue
              const mp = String(ov.model || '').replace(/^.*:/, 'assets/') + '.json'
              const mf = zip.file(mp)
              const modelJson = mf ? JSON.parse(await mf.async('text')) : {}
              const tex = String(modelJson.textures?.layer0 || '').replace(/^.*:/, 'assets/') + '.png'
              const tf = zip.file(tex)
              if (!tf) continue
              const b64 = await tf.async('base64')
              const item = (path.match(/models\/item\/([a-z_]+)\.json$/i) || [])[1] || 'diamond_sword'
              found.models.push({ id: uid(), item, name: '', dataUrl: `data:image/png;base64,${b64}`, cmd })
            }
          } catch {}
        }
      }
      if (found.chars.length) setChars((v) => [...v.filter((x) => x.dataUrl), ...found.chars])
      if (found.models.length) setModels((v) => [...v.filter((x) => x.dataUrl), ...found.models])
      notify(found.chars.length + found.models.length ? `Загрузил: символов ${found.chars.length}, моделей ${found.models.length}` : 'В паке не нашлось символов/моделей — добавляю свои сверху')
    } catch {
      notify('Не удалось прочитать ZIP — это точно ресурс-пак?', 'err')
    }
    setImporting(false)
  }

  const anyChar = chars.some((c) => c.dataUrl && c.char)
  const anyModel = models.some((m) => m.dataUrl)

  return (
    <Page titleKey="pages.generators">
      <p className="text-white/60 -mt-2 mb-4">Генератор текстур-паков: свой символ вместо любого знака (например ∆), картинки-3D на предметах по имени — <b>без OptiFine</b>. Предпросмотр как в чате/табе, выгрузка ZIP, загрузка готового пака для дополнения.</p>

      {/* ==== Настройки пака ==== */}
      <div className="glass p-4 mb-4 grid sm:grid-cols-3 gap-3">
        <label className="block text-sm text-white/50">Версия Minecraft
          <select className="field mt-1" value={mcVer} onChange={(e) => setMcVer(e.target.value)}>
            {PACK_FORMATS.map(([v]) => <option key={v} value={v} className="bg-[#1c1c20]">{v}</option>)}
          </select>
        </label>
        <label className="block text-sm text-white/50">Название пака
          <input className="field mt-1" value={packName} onChange={(e) => setPackName(e.target.value)} />
        </label>
        <label className="block text-sm text-white/50">Загрузить готовый пак (zip)
          <input type="file" accept=".zip,.mcpack" className="field mt-1" onChange={(e) => importPack(e.target.files?.[0])} disabled={importing} />
        </label>
      </div>

      {/* ==== Символы ==== */}
      <h2 className="font-outfit text-xl mb-2">Символ → твоя картинка</h2>
      <p className="text-sm text-white/45 mb-2">Напиши символ (например <span className="font-mono">∆</span>) и загрузи картинку PNG. Она заменит его в чате, табе и никах. Несколько картинок в одном символе не нужно — одна = один кадр.</p>
      <div className="space-y-2">
        {chars.map((c) => (
          <div key={c.id} className="glass p-3 flex flex-wrap items-center gap-2">
            <input className="field font-mono" style={{ width: 74, textAlign: 'center' }} value={c.char} onChange={(e) => patchChar(c.id, { char: [...e.target.value][0] || '' })} placeholder="∆" />
            <input type="file" accept="image/png,image/*" className="field" style={{ maxWidth: 260 }} onChange={async (e) => { const f = e.target.files?.[0]; if (f) patchChar(c.id, { dataUrl: await readImage(f), name: f.name }) }} />
            {c.dataUrl ? <img src={c.dataUrl} alt="" style={{ height: 32, imageRendering: 'pixelated' }} className="rounded-lg border border-white/10" /> : <span className="text-xs text-white/35">нет картинки</span>}
            <button type="button" className="tag" onClick={() => dropChar(c.id)}>Убрать</button>
          </div>
        ))}
      </div>
      <button type="button" className="btn btn-ghost px-4 py-2 mt-2" onClick={addChar}>+ ещё символ</button>

      {/* ==== Предпросмотр ==== */}
      <div className="glass p-4 mt-4">
        <div className="text-sm text-white/50 mb-2">Предпросмотр (как в чате / табе):</div>
        <div className="space-y-2">
          <div className="flex items-center gap-2"><span className="font-mono text-[#FF5555]">qwe8</span><span className="text-white/40">:</span><ChatPreview text={demoText} fontMap={fontMap} /></div>
          <div className="flex items-center gap-2"><span className="font-mono text-[#55FFFF]">Steve</span><span className="text-white/40">:</span><ChatPreview text={'Привет! ' + (chars[0]?.char || '∆') + ' новый символ работает'} fontMap={fontMap} /></div>
        </div>
        <div className="mt-3 pt-3 border-t border-white/10 text-sm text-white/50">
          В табе (список игроков):
          <div className="mt-1 flex items-center gap-2"><span className="font-mono text-white/80">qwe8 {chars[0]?.char || '∆'}</span><span className="text-white/35">← твой символ рядом с ником</span></div>
        </div>
      </div>

      {/* ==== 3D по имени ==== */}
      <h2 className="font-outfit text-xl mt-6 mb-2">Картинка на предмете по имени (3D-эффект без OptiFine)</h2>
      <p className="text-sm text-white/45 mb-2">Укажи предмет, имя (какое дадут на наковальне или командой) и картинку. Предмет с таким именем получит твою текстуру. Работает на ваниле — механика CustomModelData, OptiFine не нужен. Имя пустое = просто свой вариант предмета через команду с CustomModelData.</p>
      <div className="space-y-2">
        {models.map((m) => (
          <div key={m.id} className="glass p-3 flex flex-wrap items-center gap-2">
            <select className="field" style={{ maxWidth: 190 }} value={m.item} onChange={(e) => patchModel(m.id, { item: e.target.value })}>
              {ITEMS.map((it) => <option key={it} value={it} className="bg-[#1c1c20]">{it}</option>)}
            </select>
            <input className="field" style={{ maxWidth: 210 }} value={m.name} onChange={(e) => patchModel(m.id, { name: e.target.value })} placeholder="имя предмета (напр. Клинок Души)" />
            <input className="field font-mono" style={{ width: 86 }} type="number" min="1" value={m.cmd} onChange={(e) => patchModel(m.id, { cmd: Number(e.target.value) || 1 })} title="CustomModelData" />
            <input type="file" accept="image/png,image/*" className="field" style={{ maxWidth: 240 }} onChange={async (e) => { const f = e.target.files?.[0]; if (f) patchModel(m.id, { dataUrl: await readImage(f) }) }} />
            {m.dataUrl && <img src={m.dataUrl} alt="" style={{ height: 32, imageRendering: 'pixelated' }} className="rounded-lg border border-white/10" />}
            <button type="button" className="tag" onClick={() => dropModel(m.id)}>Убрать</button>
          </div>
        ))}
      </div>
      <button type="button" className="btn btn-ghost px-4 py-2 mt-2" onClick={addModel}>+ ещё предмет</button>

      {/* Инвентарный предпросмотр */}
      {anyModel && (
        <div className="glass p-4 mt-4">
          <div className="text-sm text-white/50 mb-2">Предпросмотр в инвентаре (слот + подсказка с именем):</div>
          <div className="flex flex-wrap gap-2">
            {models.filter((m) => m.dataUrl).slice(0, 9).map((m) => (
              <div key={m.id} className="w-14 h-14 rounded-xl bg-black/40 border border-white/15 grid place-items-center relative group">
                <img src={m.dataUrl} alt="" style={{ height: 40, imageRendering: 'pixelated' }} />
                {m.name ? <span className="absolute -top-2 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded-md bg-[#100010ee] border border-[#2a0a5e] text-[#a05aff] text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity" style={{ fontFamily: 'Minecraftia, monospace' }}>{m.name}</span> : null}
              </div>
            ))}
          </div>
          <p className="text-xs text-white/35 mt-2">Наведи на предмет — увидишь имя, по которому включается твоя текстура.</p>
        </div>
      )}

      {/* ==== Скачать ==== */}
      <div className="flex flex-wrap items-center gap-3 mt-6">
        <button className="btn btn-primary px-6 py-3" disabled={!anyChar && !anyModel} onClick={buildZip}>
          Скачать ZIP текстур-пака
        </button>
        {!anyChar && !anyModel && <span className="text-sm text-white/40">Добавь хотя бы одну картинку — и ZIP станет активным.</span>}
      </div>
      <div className="mt-6 text-xs text-white/35 space-y-1">
        <p>Как поставить: Настройки → Наборы ресурсов → Открыть папку → закинь ZIP → включи пак.</p>
        <p>Для сервера: положи ZIP в папку server-resource-packs или раздай игрокам — символы и именные предметы будут работать у всех.</p>
        <p>Ещё генераторы: <Link className="text-orange-soft" to="/generators">команды и достижения</Link>.</p>
      </div>
    </Page>
  )
}
