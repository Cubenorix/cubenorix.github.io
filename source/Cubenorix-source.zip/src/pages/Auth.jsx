/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { useEffect, useRef, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { CheckCircle2, Database, ShieldCheck } from 'lucide-react'
import { useStore } from '../store'
import { googleClientId } from '../auth-local'

const DISCORD_CID = () => {
  try { return localStorage.getItem('cubenorixx.discord_cid') || (import.meta.env?.VITE_DISCORD_CLIENT_ID || '') } catch { return import.meta.env?.VITE_DISCORD_CLIENT_ID || '' }
}
import { t } from '../i18n'

export default function Auth({ mode }) {
  const { login, register, resetPassword, notify, lang, authStatus, authReady, authConfigured, secretUnlocked, unlockSecret } = useStore()
  const nav = useNavigate()
  const { loginGoogle: loginGoogleStore, loginDiscord: loginDiscordStore } = useStore()
  const googleDiv = useRef(null)
  const googleReady = useRef(false)
  const [googleOn, setGoogleOn] = useState(false)
  const [hasAcc, setHasAcc] = useState(mode === 'login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [username, setUsername] = useState('')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const [consent, setConsent] = useState({ termsAccepted: false, privacyAccepted: false, contentRulesAccepted: false, ageConfirmed: false })
  const [regionOk, setRegionOk] = useState(false)

  const configured = Boolean(authStatus?.configured || secretUnlocked)
  const localMode = configured && !authStatus?.configured
  const submit = async (event) => {
    event.preventDefault()
    if ((!configured && !regionOk) || busy) return
    setBusy(true)
    setErr('')
    const result = hasAcc
      ? await login(email, password)
      : await register(username, email, password, consent)
    setBusy(false)
    if (!result.ok) setErr(result.error)
    else nav('/profile')
  }


  // Определяем регион по настройкам устройства (часовой пояс + язык).
  // Ничего никуда не отправляем — смотрим только локальные данные браузера.
  const guessRegion = () => {
    const ZONES = {
      'Europe/Kaliningrad': 'Россия', 'Europe/Moscow': 'Россия', 'Europe/Samara': 'Россия',
      'Europe/Volgograd': 'Россия', 'Europe/Kirov': 'Россия', 'Europe/Ulyanovsk': 'Россия',
      'Europe/Astrakhan': 'Россия', 'Europe/Saratov': 'Россия', 'Asia/Yekaterinburg': 'Россия',
      'Asia/Omsk': 'Россия', 'Asia/Novosibirsk': 'Россия', 'Asia/Barnaul': 'Россия',
      'Asia/Tomsk': 'Россия', 'Asia/Krasnoyarsk': 'Россия', 'Asia/Irkutsk': 'Россия',
      'Asia/Yakutsk': 'Россия', 'Asia/Vladivostok': 'Россия', 'Asia/Magadan': 'Россия',
      'Asia/Sakhalin': 'Россия', 'Asia/Kamchatka': 'Россия', 'Asia/Anadyr': 'Россия',
      'Europe/Kiev': 'Украина', 'Europe/Kyiv': 'Украина', 'Europe/Minsk': 'Беларусь',
      'Europe/Almaty': 'Казахстан', 'Asia/Almaty': 'Казахстан', 'Asia/Qostanay': 'Казахстан',
      'Asia/Tashkent': 'Узбекистан', 'Asia/Bishkek': 'Киргизия', 'Asia/Dushanbe': 'Таджикистан',
      'Asia/Ashgabat': 'Туркменистан', 'Asia/Baku': 'Азербайджан', 'Asia/Yerevan': 'Армения',
      'Asia/Tbilisi': 'Грузия', 'Europe/Chisinau': 'Молдова', 'Europe/Riga': 'Латвия',
      'Europe/Vilnius': 'Литва', 'Europe/Tallinn': 'Эстония', 'Europe/Warsaw': 'Польша',
      'Europe/Berlin': 'Германия', 'Europe/Paris': 'Франция', 'Europe/London': 'Великобритания',
      'Europe/Istanbul': 'Турция', 'Asia/Seoul': 'Южная Корея', 'Asia/Tokyo': 'Япония',
      'Asia/Shanghai': 'Китай', 'America/New_York': 'США', 'America/Chicago': 'США',
      'America/Denver': 'США', 'America/Los_Angeles': 'США', 'America/Sao_Paulo': 'Бразилия',
    }
    let zone = ''
    try { zone = Intl.DateTimeFormat().resolvedOptions().timeZone || '' } catch {}
    let country = ZONES[zone] || ''
    if (!country && zone) country = zone.startsWith('Europe/') ? 'Европа' : zone.startsWith('Asia/') ? 'Азия' : zone.startsWith('America/') ? 'Америка' : zone.startsWith('Africa/') ? 'Африка' : ''
    const lang = String((typeof navigator !== 'undefined' && navigator.language) || '').toLowerCase()
    if (!country && lang.startsWith('ru')) country = 'русскоязычный регион'
    return { country: country || 'не определили', zone }
  }
  const region = guessRegion()
  const [ipRegion, setIpRegion] = useState(null)
  useEffect(() => {
    let dead = false
    // Страна по IP: GeoJS (без ключа), фолбэк ipwho.is. Ничего не сохраняем и не отправляем.
    fetch('https://get.geojs.io/v1/ip/geo.json')
      .then((r) => r.json())
      .then((g) => { if (!dead && g?.country) setIpRegion([g.country, g.region, g.city].filter(Boolean).join(', ')) })
      .catch(() => fetch('https://ipwho.is/').then((r) => r.json()).then((g) => { if (!dead && g?.country) setIpRegion([g.country, g.region, g.city].filter(Boolean).join(', ')) }).catch(() => {}))
    return () => { dead = true }
  }, [])

  const setCheck = (key) => setConsent((value) => ({ ...value, [key]: !value[key] }))

  // Кнопка «Войти через Google» (Google Identity Services).
  // Client ID публичный; задаётся при сборке (VITE_GOOGLE_CLIENT_ID)
  // или локально для проверки (localStorage cubenorixx.google_cid).
  // Discord: implicit OAuth. Возвращается на сайт с #access_token&state=cx-discord.
  useEffect(() => {
    const h = new URLSearchParams(window.location.hash.replace(/^#\/?/, ''))
    const token = h.get('access_token')
    if (token && h.get('state') === 'cx-discord') {
      history.replaceState(null, '', window.location.pathname + window.location.search)
      setBusy(true)
      loginDiscordStore(token).then((result) => {
        setBusy(false)
        if (!result.ok) setErr(result.error)
        else nav('/profile')
      })
    }
  }, [])
  const startDiscord = () => {
    const cid = DISCORD_CID()
    if (!cid) return
    const redirect = window.location.origin + (window.location.pathname.endsWith('/') ? window.location.pathname : window.location.pathname + '/')
    const url = 'https://discord.com/oauth2/authorize?client_id=' + encodeURIComponent(cid)
      + '&response_type=token&redirect_uri=' + encodeURIComponent(redirect)
      + '&scope=' + encodeURIComponent('identify email')
      + '&state=cx-discord&prompt=consent'
    window.location.href = url
  }
  const handleGoogle = async (response) => {
    setBusy(true)
    setErr('')
    const result = await loginGoogleStore(response?.credential)
    setBusy(false)
    if (!result.ok) setErr(result.error)
    else nav('/profile')
  }
  useEffect(() => {
    const clientId = googleClientId()
    if (!clientId) return
    let dead = false
    const boot = () => {
      if (dead || googleReady.current || !window.google?.accounts?.id) return
      googleReady.current = true
      try {
        window.google.accounts.id.initialize({ client_id: clientId, callback: (r) => handleGoogle(r), auto_select: false })
        if (googleDiv.current) {
          window.google.accounts.id.renderButton(googleDiv.current, { theme: 'filled_black', size: 'large', shape: 'pill', text: 'continue_with', width: 300 })
          setGoogleOn(true)
        }
      } catch {}
    }
    if (window.google?.accounts?.id) boot()
    else {
      const exist = document.querySelector('script[data-gsi="1"]')
      if (!exist) {
        const sc = document.createElement('script')
        sc.src = 'https://accounts.google.com/gsi/client'
        sc.async = true
        sc.defer = true
        sc.dataset.gsi = '1'
        sc.onload = boot
        sc.onerror = () => {}
        document.head.appendChild(sc)
      } else exist.addEventListener('load', boot)
      setTimeout(boot, 2500)
    }
    return () => { dead = true }
  }, [])

  return (
    <div className="relative z-10 max-w-lg mx-auto px-4 pt-12 pb-16">
      <div className="glass p-6 sm:p-8">
        <img
          src="/logo.png?v=5"
          className="w-14 h-14 mx-auto logo-img secret-logo"
          alt=""
          role="button"
          tabIndex={0}
          aria-label="Логотип Cubenorix"
          title="?"
          onClick={() => {
            if (!configured && !secretUnlocked) {
              unlockSecret()
              notify('Принято: на последний вопрос — да ✅ Секретный доступ активирован', 'ok')
            }
          }}
        />
        <h1 className="font-outfit text-3xl text-center mt-3">{hasAcc ? t(lang, 'auth.login') : t(lang, 'auth.register')}</h1>
        <p className="text-center text-white/50 text-sm mt-2">
          {localMode
            ? (hasAcc ? 'Локальный аккаунт Cubenorix на этом устройстве.' : 'Локальный аккаунт Cubenorix — быстро и без сервера.')
            : (hasAcc ? 'Серверная сессия Cubenorix на всех ваших устройствах.' : 'Настоящий серверный аккаунт — не пароль в localStorage.')}
        </p>

        {!regionOk && <div className={`auth-readiness ${configured ? 'ready' : ''}`}>
          {configured ? <CheckCircle2 size={18} /> : <Database size={18} />}
          <div>
            <strong>{localMode ? '🔓 Секретный режим активирован' : configured ? 'Сервер аккаунтов подключён' : authReady ? 'Ожидается Cloudflare D1' : 'Проверяем сервер аккаунтов…'}</strong>
            <span>{localMode ? 'Аккаунт хранится на этом устройстве: пароль — только хеш SHA-256, сервер не нужен. Позже перенесём в общий серверный режим.' : configured ? 'Пароль хешируется на сервере; сессия хранится в защищённой HttpOnly cookie.' : 'База аккаунтов ещё не подключена.'}</span>
          </div>
        </div>}

        {regionOk ? (
            <div className="region-locked region-ok" role="status" onClick={() => notify('Регистрация открыта — заполните форму ниже', 'ok')}>
              <div className="region-locked-title">✅ Ваш регион доступен — регистрация открыта!</div>
              <p className="region-locked-hint">Заполните форму ниже и нажмите «Создать аккаунт». Приятной игры!</p>
            </div>
          ) : !configured && !secretUnlocked ? (
            <div
              className="region-locked region-clickable"
              role="button"
              tabIndex={0}
              onClick={() => { setRegionOk(true); unlockSecret(); notify('Отлично! Ваш регион доступен — регистрация открыта', 'ok') }}
              onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { setRegionOk(true); unlockSecret(); notify('Отлично! Ваш регион доступен — регистрация открыта', 'ok') } }}
            >
              <div className="region-locked-title">🌍 Регистрация в вашем регионе недоступна</div>
              <p className="region-locked-list">
                Доступные регионы: Тёмная сторона Луны 🌑 · Регион Ардароики 🌌 · Поверхность Солнца ☀️ (только в ночную смену) ·
                Дно Марианской впадины 🌊 (без скафандра) · Центр Юпитера 🪐 · Кольца Сатурна 🪐 · Ядро Земли 🌋 ·
                Горизонт событий чёрной дыры 🕳 · Глубины Пустоты Энда ✨ · Чанк, где не поставили свет 💡 ·
                Сервер Херобрина 👻 · Задняя комната Майнкрафта 🚪 · Комната краш-репортов 📉 —
                и другие точки, где человеку находиться нельзя в принципе.
              </p>
              <p className="region-locked-hint">
                Все остальные: сайт полностью работает без аккаунта — ищите, собирайте и скачивайте свободно.
              </p>
              <p className="region-locked-hint">
                📍 Твой регион: <b>{ipRegion || region.country}</b> {ipRegion ? '(по IP-адресу)' : region.zone ? `(${region.zone}, по устройству)` : ''}. С какой страны начинается список и какой она заканчивается — не важно: регистрация для твоего региона открывается нажатием на этот блок.
              </p>
              <button
                type="button"
                className="btn btn-ghost px-4 py-2 mt-1 text-sm"
                onClick={(e) => { e.stopPropagation(); setRegionOk(true); unlockSecret(); notify('Извините, была ошибка региона — регистрация открыта 🙏', 'ok') }}
              >
                Извините, была ошибка региона 🙏 — открыть регистрацию
              </button>
            </div>
          )
        : null}

        <div className="flex gap-2 mt-5">
          <button type="button" className={'tag flex-1 justify-center' + (hasAcc ? ' on' : '')} onClick={() => { setHasAcc(true); setErr('') }}>{t(lang, 'auth.login')}</button>
          <button type="button" className={'tag flex-1 justify-center' + (!hasAcc ? ' on' : '')} onClick={() => { setHasAcc(false); setErr('') }}>{t(lang, 'auth.register')}</button>
        </div>

        {Boolean(DISCORD_CID()) && (
          <button type="button" className="btn px-5 py-2.5 mt-5 w-full max-w-xs mx-auto block text-white font-semibold rounded-xl"
            style={{ background: '#5865F2' }} onClick={startDiscord}>
            Войти через Discord
          </button>
        )}
        {googleOn && (
          <div className="mt-5 flex flex-col items-center gap-2">
            <div ref={googleDiv} />
            <div className="flex items-center gap-3 w-full max-w-xs">
              <span className="h-px bg-white/10 flex-1" />
              <span className="text-[11px] text-white/35">или по e-mail</span>
              <span className="h-px bg-white/10 flex-1" />
            </div>
          </div>
        )}

        <form className="mt-5 space-y-3" onSubmit={submit}>
          {!hasAcc && (
            <label className="auth-field-label">
              <span>{t(lang, 'auth.username')}</span>
              <input className="field" autoComplete="username" placeholder="3–24: латиница, цифры, _ или -" value={username} onChange={(e) => setUsername(e.target.value)} required minLength={3} maxLength={24} pattern="[A-Za-z0-9_-]{3,24}" />
            </label>
          )}
          <label className="auth-field-label">
            <span>{hasAcc ? 'E-mail или ник' : t(lang, 'auth.email')}</span>
            <input
              className="field"
              type={hasAcc ? 'text' : 'email'}
              inputMode="email"
              autoComplete={hasAcc ? 'username' : 'email'}
              placeholder={hasAcc ? 'ваш e-mail или ник' : 'name@example.com'}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              maxLength={254}
            />
          </label>
          <label className="auth-field-label">
            <span>{t(lang, 'auth.password')}</span>
            <input className="field" type="password" autoComplete={hasAcc ? 'current-password' : 'new-password'} placeholder={hasAcc ? 'Ваш пароль' : 'Не менее 12 символов'} value={password} onChange={(e) => setPassword(e.target.value)} required minLength={hasAcc ? 1 : 12} maxLength={128} />
          </label>

          {!hasAcc && (
            <div className="auth-consents">
              <Consent checked={consent.termsAccepted} onChange={() => setCheck('termsAccepted')}>
                Принимаю <Link to="/terms" target="_blank">Условия использования</Link>.
              </Consent>
              <Consent checked={consent.privacyAccepted} onChange={() => setCheck('privacyAccepted')}>
                Прочитал(а) <Link to="/privacy" target="_blank">Политику конфиденциальности</Link>.
              </Consent>
              <Consent checked={consent.contentRulesAccepted} onChange={() => setCheck('contentRulesAccepted')}>
                Буду публиковать только своё содержимое или материалы, на которые у меня есть разрешение, и принимаю <Link to="/authors" target="_blank">правила для авторов</Link>.
              </Consent>
              <Consent checked={consent.ageConfirmed} onChange={() => setCheck('ageConfirmed')}>
                Я достиг(ла) возраста самостоятельного согласия в своей юрисдикции либо получил(а) согласие законного представителя.
              </Consent>
            </div>
          )}

          {err && <div className="auth-error" role="alert">{err}</div>}
          <button className="btn btn-primary w-full py-3" disabled={!(configured || regionOk) || busy || (!hasAcc && !Object.values(consent).every(Boolean))}>
            <ShieldCheck size={17} /> {busy ? 'Подождите…' : hasAcc ? t(lang, 'auth.login') : t(lang, 'auth.create')}
          </button>
        </form>

        {hasAcc && (
          <button type="button" className="text-sm text-white/50 mt-3" onClick={async () => {
            if (localMode) { notify('В локальном режиме сброс пароля недоступен — напишите @Cubenorixsupportbot', 'err'); return }
            const result = await resetPassword(email)
            notify(result.ok ? result.hint : result.error, result.ok ? 'ok' : 'err')
          }}>{t(lang, 'auth.forgot')}</button>
        )}
        <p className="text-center text-sm mt-4 text-white/50">
          <button type="button" className="text-orange-soft" onClick={() => setHasAcc((value) => !value)}>{hasAcc ? t(lang, 'auth.noAcc') : t(lang, 'auth.hasAcc')}</button>
        </p>
        <p className="text-center text-[11px] leading-5 text-white/30 mt-4">
          {localMode
            ? 'Локальный режим: аккаунт живёт в этом браузере (пароль — только хеш). Профиль, ачивки и кастомизация — бесплатные и уже включены.'
            : 'Cubenorix не хранит пароль в браузере и не имитирует вход Microsoft. Серверная авторизация работает с открытым исходным кодом.'}
        </p>
      </div>
    </div>
  )
}

function Consent({ checked, onChange, children }) {
  return (
    <label className="auth-consent-row">
      <input type="checkbox" checked={checked} onChange={onChange} required />
      <span>{children}</span>
    </label>
  )
}
