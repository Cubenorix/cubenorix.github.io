/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { getProject, getVersion, getVersions, searchProjects, searchAddons, mediaUrl } from '../api'
import DownloadBar, { DownloadPanel, DownloadModal } from '../components/DownloadBar'
import { Icon } from '../components/SearchBox'
import Translated, { BodyMd } from '../components/Translated'
import ProjectCard from '../components/ProjectCard'
import SourceLogo from '../components/SourceLogo'
import VerifyBadge from '../components/VerifyBadge'
import { verifyLevel } from '../stats'
import { useStore } from '../store'
import { t } from '../i18n'
import ReviewCard from '../components/ReviewCard'
import { SOURCES, LOCAL_CONTENT } from '../data'
import { allLocal } from '../localMore'
import { uploadSlug, uploadProject } from '../localUploads'
import { isSkin, skin3d } from '../skin'

function arr(v) {
  return Array.isArray(v) ? v : []
}
function str(v) {
  if (v == null) return ''
  if (typeof v === 'string' || typeof v === 'number') return String(v)
  return ''
}
function fileOf(v) {
  const files = arr(v?.files)
  return files.find((f) => f && f.primary) || files[0] || null
}
function longestText(p) {
  const a = str(p?.body)
  const b = str(p?.description)
  return a.length >= b.length ? a : b
}
function verKey(v) {
  return str(v?.id || v?.version_number)
}

export default function Project() {
  const { slug } = useParams()
  const { lang, user, toggleFav, isFav, addBuildItem, addComment, addReview, db, countLocalDownload } = useStore()
  const [p, setP] = useState(null)
  const [versions, setVersions] = useState([])
  const [tab, setTab] = useState('desc')
  const [comment, setComment] = useState('')
  const [stars, setStars] = useState(5)
  const [rev, setRev] = useState('')
  const [verId, setVerId] = useState('')
  const [dlOpen, setDlOpen] = useState(() => (typeof window !== 'undefined' && window.location.hash === '#dl'))
  const [noAddons, setNoAddons] = useState(false)
  // Наши авторы: файл качаем прямо из GitHub Releases (без сервера).
  const [ghRel, setGhRel] = useState(null) // null=грузим, {url,name,size}, 'none', 'unknown'
  useEffect(() => {
    if (!p?.local_upload || !p?.source_url) return
    let dead = false
    setGhRel(null)
    const m = String(p.source_url).match(/github\.com\/([^/]+)\/([^/]+)/)
    if (!m) { setGhRel('none'); return }
    fetch(`https://api.github.com/repos/${m[1]}/${m[2].replace(/\.git$/, '')}/releases/latest`, { headers: { Accept: 'application/vnd.github+json' } })
      .then((r) => (r.ok ? r.json() : r.status === 404 ? null : Promise.reject(new Error(String(r.status)))))
      .then((rel) => {
        if (dead) return
        const assets = (rel && Array.isArray(rel.assets)) ? rel.assets : []
        const pick = assets.find((a) => /\.(jar|zip)$/i.test(a.name || '')) || assets[0]
        if (pick?.browser_download_url) setGhRel({ url: pick.browser_download_url, name: pick.name || pick.filename || 'file', size: Number(pick.size) || 0 })
        else setGhRel('none')
      })
      .catch(() => { if (!dead) setGhRel('unknown') })
    return () => { dead = true }
  }, [p?.local_upload, p?.source_url])

  useEffect(() => {
    let alive = true
    setP(null); setTab('desc'); setVersions([]); setVerId(''); setNoAddons(false)
    async function load() {
      const pack = allLocal(LOCAL_CONTENT)
      const loc = (db.added || []).find((x) => x.slug === slug)
        || Object.values(pack).flat().find((x) => x.slug === slug)
      // Одобренные загрузки авторов — полноценные страницы проектов (приоритет
      // над внешними источниками: локальный проект не перекрывается чужими слагами).
      const up = (db.uploads || []).find((u) => u.status === 'accepted' && uploadSlug(u.title) === slug)
      let proj = null
      if (up) proj = uploadProject(up, slug)
      if (!proj) {
        try {
          const remote = await getProject(slug)
          if (remote && remote.title) proj = remote
        } catch {}
      }
      if (!proj && loc) {
        proj = { ...loc, project_type: loc.project_type || 'mod', body: loc.body || loc.description, categories: loc.categories || [], gallery: loc.gallery || [], loaders: loc.loaders || [], author: loc.author }
      }
      if (!alive) return
      if (!proj) { setP({ missing: true }); return }
      setP(proj)

      let vs = []
      if (!proj.local_upload) {
      const trySlug = [proj.slug, slug].filter(Boolean)
      for (const id of trySlug) {
        try {
          const got = await getVersions(id)
          if (Array.isArray(got) && got.length) { vs = got; break }
        } catch {}
      }
      if (!vs.length && proj.title) {
        try {
          const d = await searchProjects({ query: String(proj.title).slice(0, 80), limit: 8, type: 'mod' })
          const hit = arr(d.hits).find((h) => !h.external && h.slug && (h.slug === slug || String(h.title).toLowerCase() === String(proj.title).toLowerCase()))
            || arr(d.hits).find((h) => !h.external && h.slug)
          if (hit?.slug) {
            const got = await getVersions(hit.slug)
            if (Array.isArray(got) && got.length) vs = got
          }
        } catch {}
      }
      }
      if (alive) {
        setVersions(vs)
        if (vs[0]) setVerId(verKey(vs[0]))
      }
    }
    load()
    return () => { alive = false }
  }, [slug, db.added, db.uploads])

  useEffect(() => {
    if (!p?.title || p.missing) return
    const name = str(p.title)
    const description = str(p.description || p.body).replace(/\s+/g, ' ').trim().slice(0, 170)
    document.title = `${name} скачать для Minecraft — Cubenorix`
    const meta = document.querySelector('meta[name="description"]')
    const ogTitle = document.querySelector('meta[property="og:title"]')
    const ogDesc = document.querySelector('meta[property="og:description"]')
    if (meta) meta.setAttribute('content', `Скачать ${name} для Minecraft. ${description}`.slice(0, 190))
    if (ogTitle) ogTitle.setAttribute('content', `${name} — Cubenorix`)
    if (ogDesc) ogDesc.setAttribute('content', description)
  }, [p, slug])

  if (!p) {
    return (
      <div className="relative z-10 max-w-6xl mx-auto px-4 pt-10 space-y-4">
        <div className="cx-card"><div className="skel w-20 h-20 rounded-2xl" /><div className="flex-1 space-y-3"><div className="skel h-7 w-1/2" /><div className="skel h-4 w-full" /><div className="skel h-4 w-2/3" /></div></div>
      </div>
    )
  }
  if (p.missing) {
    return (
      <div className="relative z-10 max-w-5xl mx-auto p-10 glass">
        <h1 className="font-outfit text-2xl">{t(lang, 'project.missing')}</h1>
        <p className="text-white/60 mt-2">Slug: <span className="font-mono">{slug}</span></p>
        <Link className="btn btn-primary inline-flex mt-4 px-5 py-2" to="/catalog">{t(lang, 'project.toCatalog')}</Link>
      </div>
    )
  }

  const title = str(p.title) || slug
  const cats = arr(p.categories).map(str).filter(Boolean)
  const loaders = arr(p.loaders).map(str).filter(Boolean)
  const tags = [...loaders, ...cats].slice(0, 10)
  const gallery = arr(p.gallery).map((g) => (typeof g === 'string' ? { url: g } : g)).filter((g) => g && g.url)
  const author = str(p.author) || (typeof p.organization === 'string' ? p.organization : '') || 'community'
  const selected = versions.find((v) => verKey(v) === verId) || versions[0]
  const primary = fileOf(selected) || p.file || null
  const comments = arr(db?.comments?.[slug])
  const reviews = arr(db?.reviews?.[slug])
  const sourceIds = arr(p.sources).map((s) => (typeof s === 'string' ? s : s.platform || s.id)).filter(Boolean)
  const sourceList = sourceIds.length ? sourceIds : [p.external ? null : 'modrinth', ...(p.source_url ? ['github'] : [])].filter(Boolean)
  const sourceRows = SOURCES.filter((s) => sourceList.includes(s.id))
  // Локальные проекты авторов: файл раздаёт автор на своей площадке (GitHub и т.п.)
  const localSrc = p.local_upload && p.source_url ? p.source_url : ''
  // Профиль автора на площадке-источнике (когда он известен)
  const authorUrl = (() => {
    const a = encodeURIComponent(str(p.author) || '')
    if (!a) return ''
    if (sourceIds.includes('modrinth')) return 'https://modrinth.com/user/' + a
    if (sourceIds.includes('hangar')) return 'https://hangar.papermc.io/' + str(p.author)
    if (sourceIds.includes('spigot')) return 'https://www.spigotmc.org/search/?q=' + a
    if (sourceIds.includes('github')) return 'https://github.com/' + str(p.author)
    if (sourceIds.includes('polymart')) return 'https://polymart.org/search?q=' + a
    return ''
  })()

  const vLevel = verifyLevel({ downloads: Number(p.downloads) || 0, likes: Number(p.followers) || 0 })
  const games = arr(selected?.game_versions)
  const vLoaders = arr(selected?.loaders)

  const spark = str(versions[0]?.downloads || p.downloads || 10).split('').map((n, i) => 20 + (Number(n) + i) * 6)
  const tabs = [
    ['desc', t(lang, 'project.desc')],
    gallery.length ? ['gallery', t(lang, 'project.gallery')] : null,
    versions.length ? ['versions', t(lang, 'project.versions')] : null,
    noAddons ? null : ['addons', t(lang, 'project.addons')],
    arr(selected?.dependencies).length ? ['deps', t(lang, 'project.deps')] : null,
    ['stats', t(lang, 'project.stats')],
    ['comments', t(lang, 'project.comments')],
    ['reviews', t(lang, 'project.reviews')],
  ].filter(Boolean)

  return (
    <div className="relative z-10 max-w-6xl mx-auto px-4 pt-8 project-layout">
      <div className="min-w-0">
        <div className="glass p-4 sm:p-6 flex flex-col sm:flex-row gap-4">
          <div className="icon-wrap shrink-0">
            <Icon src={isSkin(p) ? skin3d(p, 'body') : (mediaUrl(p.icon_url) || p.icon_url)} letter={title} className={isSkin(p) ? 'skin-3d-lg' : 'w-16 h-16 sm:w-20 sm:h-20'} />
            {vLevel ? <span className="verify-br"><VerifyBadge level={vLevel} /></span> : null}
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="font-outfit text-3xl font-bold">{title}</h1>
            {p.local_upload && (
              <div className="flex flex-wrap items-center gap-2 mt-2">
                <span className="tag" style={{ fontSize: '.72rem' }}>Одобрено администрацией</span>
                {p.source_url ? <a className="text-orange-soft text-xs" href={p.source_url} target="_blank" rel="noreferrer">Источник ↗</a> : null}
              </div>
            )}
            {vLevel && <p className="text-xs text-white/40 mt-1">{t(lang, 'verify.' + vLevel)} · {t(lang, 'verify.' + vLevel + 'h')}</p>}
            <p className="text-white/50">
              {t(lang, 'ui.author')}:{' '}
              {authorUrl
                ? <a className="text-orange-soft hover:underline" href={authorUrl} target="_blank" rel="noopener noreferrer">{author} ↗</a>
                : author}
            </p>
            <Translated className="mt-2 text-white/80 line-clamp-3 block" text={str(p.description) || str(p.body)} />
            <div className="flex flex-wrap gap-1.5 mt-3">
              {tags.map((c) => <span key={c} className="tag">{c}</span>)}
            </div>
            <div className="flex flex-wrap gap-2 mt-4">
              <button type="button" className="btn btn-primary px-5 py-2.5" onClick={() => setDlOpen(true)}>{t(lang, 'project.download')}</button>
              <button type="button" className="btn btn-ghost px-4 py-2 text-sm" onClick={() => addBuildItem({ slug, title, icon_url: p.icon_url })}>{t(lang, 'project.addBuild')}</button>
              <button type="button" className="btn btn-ghost px-4 py-2 text-sm" onClick={() => toggleFav({ slug, title, icon_url: p.icon_url })}>{isFav(slug) ? '★' : '☆'} {t(lang, 'project.fav')}</button>
            </div>
          </div>
        </div>

        <div className="flex mt-6 border-b border-white/8 overflow-x-auto hide-scroll">
          {tabs.map(([k, label]) => (
            <button key={k} className={`tab ${tab === k ? 'on' : ''}`} onClick={() => setTab(k)}>{label}</button>
          ))}
        </div>

        <div className="glass p-6 mt-3">
          {tab === 'desc' && <BodyMd text={longestText(p)} />}
          {tab === 'addons' && <AddonList title={title} onEmpty={() => { setNoAddons(true); setTab('desc') }} />}
          {tab === 'gallery' && (
            <div className="grid sm:grid-cols-2 gap-3">
              {gallery.map((g, i) => <img key={g.url + i} src={mediaUrl(g.url) || g.url} alt={str(g.title)} className="rounded-card border border-white/10" />)}
            </div>
          )}
          {tab === 'versions' && (
            <div className="space-y-2">
              {versions.length === 0 && !localSrc && <p className="text-white/50">{t(lang, 'project.noFile')}</p>}
              {versions.length === 0 && localSrc && (
                <div className="flex flex-col items-start gap-2">
                  <a className="btn btn-primary px-5 py-2" href={localSrc} target="_blank" rel="noreferrer">Открыть на площадке автора ↗</a>
                  <p className="text-sm text-white/50">Файл раздаёт автор на своей площадке — там же обновления.</p>
                </div>
              )}
              {versions.slice(0, 40).map((v) => (
                <div key={v.id || v.version_number} className="flex flex-col sm:flex-row sm:items-center gap-3 bg-white/5 rounded-2xl px-3 py-3">
                  <div>
                    <div className="font-mono text-sm text-orange-soft">{str(v.version_number)}</div>
                    <div className="text-xs text-white/50">{arr(v.game_versions).slice(0, 4).join(', ')} · {arr(v.loaders).join(', ')}</div>
                  </div>
                  <div className="sm:ml-auto">
                    <DownloadBar file={fileOf(v)} label={t(lang, 'project.download')} />
                  </div>
                </div>
              ))}
            </div>
          )}
          {tab === 'deps' && <Deps versions={versions} addBuildItem={addBuildItem} />}
          {tab === 'stats' && (
            <svg viewBox="0 0 220 80" className="w-full h-32">
              <polyline fill="none" stroke="#FF6B00" strokeWidth="3" points={spark.map((y, i) => `${i * 28},${80 - (y % 70)}`).join(' ')} />
            </svg>
          )}
          {tab === 'comments' && (
            <div>
              {comments.map((c) => (
                <div key={c.id} className="border-b border-white/5 py-3">
                  <div className="text-sm"><b>{c.user}</b> <span className="text-white/40 font-mono text-xs">{c.source}</span></div>
                  <p className="text-white/80">{c.text}</p>
                </div>
              ))}
              {user ? (
                <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); if (comment.trim()) { addComment(slug, comment); setComment('') } }}>
                  <input className="field" value={comment} onChange={(e) => setComment(e.target.value)} />
                  <button className="btn btn-primary px-4">OK</button>
                </form>
              ) : <p className="text-white/40 text-sm mt-2">{t(lang, 'toast.needAuth')}</p>}
            </div>
          )}
          {tab === 'reviews' && (
            <div>
              <div className="rev-grid mb-4">
                {[...reviews].sort((a, b) => (b.stars - a.stars) || ((b.up || 0) - (a.up || 0))).slice(0, 3).map((r) => <ReviewCard key={r.id} r={r} />)}
              </div>
              {!reviews.length && <p className="text-white/45 mb-4">{t(lang, 'review.empty')}</p>}
              <Link to={'/reviews?slug=' + encodeURIComponent(slug)} className="text-orange-soft text-sm">{t(lang, 'review.all')}</Link>
              <div className="mt-6">
                {user ? (
                  <form onSubmit={(e) => { e.preventDefault(); if (!rev.trim()) return; addReview(slug, stars, rev, str(versions[0]?.version_number) || '—', 0); setRev('') }} className="space-y-3">
                    <div className="flex gap-1">{[1, 2, 3, 4, 5].map((n) => <button type="button" key={n} className={'star text-2xl ' + (n <= stars ? 'on' : '')} onClick={() => setStars(n)}>★</button>)}</div>
                    <input className="field" value={rev} onChange={(e) => setRev(e.target.value)} placeholder={t(lang, 'review.ph')} />
                    <button className="btn btn-primary px-4 py-2">{t(lang, 'review.publish')}</button>
                  </form>
                ) : (
                  <p className="text-white/50 text-sm">{t(lang, 'review.needLogin')} <Link className="text-orange-soft" to="/login">{t(lang, 'auth.login')}</Link></p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      <aside className="project-side space-y-3">
        <div className="glass p-4">
          <div className="text-xs text-white/40 mb-2">{t(lang, 'project.pickVer')}</div>
          {versions.length > 0 ? (
            <select
              className="field py-2 font-mono text-sm mb-3"
              value={verId}
              onChange={(e) => setVerId(e.target.value)}
              aria-label={t(lang, 'project.pickVer')}
            >
              {versions.slice(0, 80).map((v) => (
                <option key={verKey(v)} value={verKey(v)} className="bg-[#12122A]">
                  {str(v.version_number)} · {arr(v.game_versions).slice(0, 2).join(', ')}
                </option>
              ))}
            </select>
          ) : null}
          {(games.length > 0 || vLoaders.length > 0) && (
            <div className="mb-3">
              <div className="text-xs text-white/40 mb-1">{t(lang, 'project.compat')}</div>
              <div className="flex flex-wrap gap-1">
                {vLoaders.map((l) => <span key={l} className="tag on">{l}</span>)}
                {games.slice(0, 6).map((g) => <span key={g} className="tag">{g}</span>)}
              </div>
            </div>
          )}
          {localSrc && ghRel && ghRel !== 'none' && ghRel !== 'unknown' ? (
            <div className="dl-panel">
              <a className="btn btn-primary dl-btn" href={ghRel.url} onClick={() => countLocalDownload(p.upload_id)} download>
                Скачать файл{ghRel.size ? ' · ' + (ghRel.size / 1048576).toFixed(1) + ' МБ' : ''}
              </a>
              <p className="text-xs text-white/45 mt-2 truncate">Файл качается напрямую с GitHub автора: {ghRel.name}</p>
              <a className="text-orange-soft text-xs mt-1 inline-block" href={localSrc} target="_blank" rel="noreferrer">Страница автора на GitHub ↗</a>
            </div>
          ) : localSrc && ghRel === 'none' ? (
            <div className="dl-panel">
              <p className="text-sm text-white/55">Файл в Releases пока не опубликован — автор выложит, и он будет качаться прямо здесь.</p>
              <a className="btn btn-primary dl-btn" href={localSrc} target="_blank" rel="noreferrer">Открыть GitHub автора ↗</a>
              <p className="text-xs text-white/35 mt-2">Автору: загрузи .jar/.zip в Releases репозитория — скачивание появится на сайте автоматически.</p>
            </div>
          ) : (
            <DownloadPanel file={primary} lang={lang} onOpen={localSrc ? () => window.open(localSrc, '_blank', 'noopener') : () => setDlOpen(true)} />
          )}
        </div>
        <NeedBox version={selected} addBuildItem={addBuildItem} />
        <div className="glass p-4 text-sm">
          {Number(p.downloads) > 0 && <div>{t(lang, 'project.downloads')}: <b className="font-mono">{Number(p.downloads).toLocaleString()}</b></div>}
          {Number(p.followers) > 0 && <div>{t(lang, 'project.follows')}: <b className="font-mono">{Number(p.followers).toLocaleString()}</b></div>}
        </div>
        <div className="glass p-4">
          <div className="text-xs text-white/40 mb-2">{t(lang, 'project.sources')}</div>
          {sourceRows.slice(0, 10).map((s) => (
            <a key={s.id} className="flex items-center gap-2 py-1.5 text-sm hover:text-orange-soft" href={p.url || s.url} target="_blank" rel="noreferrer">
              <SourceLogo id={s.id} name={s.name} color={s.color} size={24} /> {s.name}
            </a>
          ))}
          {p.url && (
            <a className="btn btn-ghost w-full mt-2 py-2 text-sm" href={p.url} target="_blank" rel="noreferrer">{t(lang, 'project.open')}</a>
          )}
        </div>
        <Similar slug={slug} hideEmpty />
      </aside>
      {!localSrc && <DownloadModal open={dlOpen} onClose={() => setDlOpen(false)} versions={versions} lang={lang} extraFiles={primary ? [primary] : []} />}
    </div>
  )
}

function NeedBox({ version, addBuildItem }) {
  const { lang } = useStore()
  const deps = arr(version?.dependencies)
  const [names, setNames] = useState({})
  useEffect(() => {
    const rows = deps.slice(0, 20)
    if (!rows.length) { setNames({}); return }
    let alive = true
    Promise.all(rows.map(async (d) => {
      let p = null
      let v = null
      try { if (d.project_id) p = await getProject(d.project_id) } catch {}
      try { if (d.version_id) v = await getVersion(d.version_id) } catch {}
      return [d.project_id || d.file_name || d.version_id, {
        title: p?.title || d.file_name || d.project_id || '—',
        slug: p?.slug || d.project_id || '',
        version: v?.version_number || v?.name || '',
      }]
    })).then((next) => { if (alive) setNames(Object.fromEntries(next)) })
    return () => { alive = false }
  }, [version?.id, version?.version_number])

  const need = deps.filter((d) => d.dependency_type === 'required')
  const opt = deps.filter((d) => d.dependency_type === 'optional')
  const bad = deps.filter((d) => d.dependency_type === 'incompatible')
  if (!need.length && !bad.length && !opt.length) return null
  const meta = (d) => names[d.project_id || d.file_name || d.version_id] || {}
  const label = (d) => meta(d).title || d.file_name || d.project_id || '—'
  const exact = (d) => meta(d).version || ''
  const link = (d) => meta(d).slug || d.project_id || ''
  return (
    <div className="glass p-4">
      <div className="text-xs text-white/40 mb-2">{t(lang, 'ui.need')}</div>
      {need.length ? (
        <div className="mb-2">
          <div className="text-[11px] uppercase tracking-wider text-orange-soft mb-1">{t(lang, 'ui.required')}</div>
          {need.map((d, i) => (
            <div key={'n' + i} className="flex items-center gap-2 py-1 text-sm">
              <span className="w-2 h-2 rounded-full bg-orange-soft shrink-0" />
              {link(d) ? <Link className="truncate hover:text-orange-soft" to={'/project/' + link(d)}>{label(d)}</Link> : <span className="truncate">{label(d)}</span>}
              <span className="text-[11px] text-white/35 ml-auto">{exact(d) ? `v${exact(d)}` : `${t(lang, 'ui.dlToo')} · compatible`}</span>
              {link(d) ? <button type="button" className="tag" onClick={() => addBuildItem({ slug: link(d), title: label(d), version: exact(d) })}>+</button> : null}
            </div>
          ))}
        </div>
      ) : null}
      {bad.length ? (
        <div className="mb-2">
          <div className="text-[11px] uppercase tracking-wider text-[#ff8aa0] mb-1">{t(lang, 'ui.conflict')}</div>
          {bad.map((d, i) => (
            <div key={'b' + i} className="flex items-center gap-2 py-1 text-sm text-[#ff8aa0]">
              <span className="w-2 h-2 rounded-full bg-[#ff4d6a] shrink-0" />
              {link(d) ? <Link className="truncate hover:text-white" to={'/project/' + link(d)}>{label(d)}</Link> : <span className="truncate">{label(d)}</span>}
              <span className="text-[11px] ml-auto">{exact(d) ? `v${exact(d)} · ` : ''}{t(lang, 'ui.dontMix')}</span>
            </div>
          ))}
        </div>
      ) : null}
      {opt.length ? (
        <div>
          <div className="text-[11px] uppercase tracking-wider text-white/35 mb-1">{t(lang, 'ui.optional')}</div>
          {opt.slice(0, 6).map((d, i) => (
            <div key={'o' + i} className="flex items-center gap-2 py-1 text-sm text-white/60">
              {link(d) ? <Link className="truncate hover:text-orange-soft" to={'/project/' + link(d)}>{label(d)}{exact(d) ? ` · v${exact(d)}` : ''}</Link> : <span className="truncate">{label(d)}</span>}
            </div>
          ))}
        </div>
      ) : null}
    </div>
  )
}

function AddonList({ title, onEmpty }) {
  const [hits, setHits] = useState(null)
  useEffect(() => {
    let alive = true
    searchAddons({ query: title, limit: 8 })
      .then((d) => {
        if (!alive) return
        const list = arr(d.hits)
        setHits(list)
        if (!list.length && onEmpty) onEmpty()
      })
      .catch(() => {
        if (!alive) return
        setHits([])
        if (onEmpty) onEmpty()
      })
    return () => { alive = false }
  }, [title])
  if (!hits) return null
  if (!hits.length) return null
  return <div className="grid gap-2">{hits.map((p) => <ProjectCard key={p.slug} p={p} compact />)}</div>
}

function Deps({ versions, addBuildItem }) {
  return <NeedBox version={versions[0]} addBuildItem={addBuildItem} />
}

function Similar({ slug }) {
  const [hits, setHits] = useState([])
  useEffect(() => {
    searchProjects({ query: String(slug || '').replace(/-/g, ' '), limit: 4 })
      .then((d) => setHits(arr(d.hits).filter((h) => h.slug && h.slug !== slug)))
      .catch(() => setHits([]))
  }, [slug])
  if (!hits.length) return null
  return (
    <div className="space-y-2">
      {hits.map((p) => (
        <Link key={p.slug} to={'/project/' + p.slug} className="glass p-3 flex gap-2 items-center hover:border-orange/40">
          <Icon src={p.icon_url} letter={p.title} className="w-10 h-10" />
          <span className="truncate text-sm">{p.title}</span>
        </Link>
      ))}
    </div>
  )
}
