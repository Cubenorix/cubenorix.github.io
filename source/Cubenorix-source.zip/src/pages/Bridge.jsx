/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { useState } from 'react'
import { useStore } from '../store'

export default function Bridge() {
  const { db, user, importPack, notify } = useStore()
  const [pack, setPack] = useState('')

  const exp = () => {
    const data = {
      v: 1,
      from: user?.username || 'guest',
      at: Date.now(),
      builds: db.builds || [],
      favorites: db.favorites || [],
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'cubenorixx-pack.json'
    a.click()
  }

  const imp = () => {
    try {
      const data = JSON.parse(pack)
      const r = importPack(data)
      if (!r.ok) notify(r.error, 'err')
      else { notify('Пакет принят'); setPack('') }
    } catch {
      notify('Это не пакет Cubenorix.', 'err')
    }
  }

  return (
    <div className="relative z-10 max-w-3xl mx-auto px-4 pt-8 pb-16">
      <p className="text-[11px] uppercase tracking-wider text-orange-soft mb-2">служебное</p>
      <h1 className="font-outfit text-3xl">Тихий мост</h1>
      <p className="text-white/55 mt-3 leading-7">
        Когда CDN не открывается или превью режет .jar — файл идёт через Cubenorix.
        Сборку можно отдать другу файлом, без аккаунта на чужом сайте.
      </p>

      <div className="why-grid mt-8">
        <div className="why-card">
          <div className="text-orange-soft font-outfit">Скачать</div>
          <p className="text-sm text-white/55 mt-2">Кнопка на карточке уже ходит в /api/file. Мост — запасной путь и передача пакета.</p>
        </div>
        <div className="why-card">
          <div className="text-orange-soft font-outfit">Передать проект</div>
          <p className="text-sm text-white/55 mt-2">Сборка и избранное → cubenorixx-pack.json. Друг вставляет текст и получает тот же список.</p>
        </div>
        <div className="why-card">
          <div className="text-orange-soft font-outfit">Не это</div>
          <p className="text-sm text-white/55 mt-2">Не VPN, не взлом площадок, не обход чужой лицензии. Только наш прокси и твой пакет.</p>
        </div>
      </div>

      <div className="glass p-5 mt-8 space-y-3">
        <h2 className="font-outfit text-xl">Пакет</h2>
        <button className="btn btn-primary px-5 py-2" onClick={exp}>Скачать cubenorixx-pack.json</button>
        <textarea className="field min-h-[120px] font-mono text-xs" value={pack} onChange={(e) => setPack(e.target.value)} placeholder="Вставь JSON пакета" />
        <button className="btn btn-ghost px-5 py-2" onClick={imp}>Принять пакет</button>
      </div>

      <div className="glass p-5 mt-4">
        <h2 className="font-outfit text-xl mb-2">Сканер на диск</h2>
        <p className="text-sm text-white/55 mb-3">Тот же принцип, что у Варделита: локальный файл, без телеметрии.</p>
        <a className="btn btn-primary px-5 py-2" href="/bridge/cubenorixx-bridge-0.1.0.zip" download>cubenorixx-bridge-0.1.0.zip</a>
      </div>
    </div>
  )
}
