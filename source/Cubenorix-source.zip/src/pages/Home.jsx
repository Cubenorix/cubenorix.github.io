/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import SearchBox from '../components/SearchBox'
import ProjectCard, { CardSkeleton } from '../components/ProjectCard'
import CatIcon from '../components/CatIcon'
import SourceLogo from '../components/SourceLogo'
import { CATEGORIES, SOURCES } from '../data'
import { SUPPORT_BOT_TELEGRAM, SUPPORT_BOT_USERNAME } from '../data/community'
import { useStore } from '../store'
import { allAcceptedUploads, uploadSlug } from '../localUploads'
import { t, catName, formatDateTime, formatNumber } from '../i18n'
import { cacheHits, getLiveCatalogStats } from '../api'
import { verifyLevel } from '../stats'
import { ReviewsTeaser } from '../components/ReviewCard'

const TINT = {
  mods: '#ff6b00', addons: '#fb7185', library: '#94a3b8', optimization: '#4ade80',
  resourcepacks: '#f472b6', datapacks: '#c084fc', shaders: '#818cf8', textures: '#38bdf8',
  emotes: '#fbbf24', cosmetics: '#f472b6', models: '#a78bfa', configs: '#cbd5e1', modpacks: '#fb923c',
  plugins: '#facc15', cores: '#60a5fa', bedrock: '#2dd4bf', servers: '#fb7185',
  maps: '#34d399', worlds: '#4ade80', schematics: '#2dd4bf', builds: '#fdba74',
  skins: '#a3e635', guides: '#ffb347', blocks: '#fb923c', recipes: '#f472b6',
  commands: '#67e8f9', dev: '#94a3b8', appearance: '#e879f9',
}
const HOME_IDS = [
  'modpacks', 'mods', 'addons', 'resourcepacks', 'datapacks', 'shaders',
  'plugins', 'cores', 'appearance', 'library', 'optimization', 'bedrock',
]

function glow(color) {
  const c = String(color || '#ff6b00').replace('#', '')
  const hex = c.length === 3 ? c.split('').map((x) => x + x).join('') : c.slice(0, 6)
  const n = parseInt(hex, 16)
  if (!Number.isFinite(n)) return '0 14px 16px -10px rgba(255,107,0,.5)'
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255
  return `0 14px 16px -10px rgba(${r},${g},${b},0.5)`
}

function Rail({ items, reverse }) {
  const loop = [...items, ...items]
  return (
    <div className="rail rail-fade mb-2">
      <div className={`rail-track slow ${reverse ? 'rev' : ''}`}>
        {loop.map((p, i) => (
          <div key={(p.slug || i) + '-' + i} className="mini-card"><ProjectCard p={p} compact /></div>
        ))}
      </div>
    </div>
  )
}

export default function Home() {
  const { lang, db } = useStore()
  const [popular, setPopular] = useState([])
  const [fresh, setFresh] = useState([])
  const [total, setTotal] = useState(0)
  const [liveBy, setLiveBy] = useState({})
  const [stamp, setStamp] = useState(0)

  useEffect(() => {
    const ctrl = new AbortController()
    let loading = false
    let alive = true
    const load = async () => {
      if (loading || !alive) return
      loading = true
      try {
        const [pop, upd, live, extra] = await Promise.all([
          fetch('https://api.modrinth.com/v2/search?limit=18&index=downloads', { signal: ctrl.signal }).then((r) => r.json()).catch(() => ({})),
          fetch('https://api.modrinth.com/v2/search?limit=18&index=updated', { signal: ctrl.signal }).then((r) => r.json()).catch(() => ({})),
          getLiveCatalogStats().catch(() => ({})),
          fetch('/api/home', { signal: ctrl.signal }).then((r) => r.json()).catch(() => ({ hits: [] })),
        ])
        if (!alive) return
        const a = Array.isArray(pop.hits) ? pop.hits : []
        const b = Array.isArray(upd.hits) ? upd.hits : []
        const x = Array.isArray(extra.hits) ? extra.hits : []
        cacheHits([...a, ...b, ...x])
        const nextTotal = Number(live.total) || Number(pop.total_hits) || Number(upd.total_hits) || 0
        if (nextTotal > 0) setTotal(nextTotal)
        if (live.by && typeof live.by === 'object') setLiveBy(live.by)
        if (a.length) setPopular(a.slice(0, 18))
        const mixed = [...x.slice(0, 8), ...b].slice(0, 18)
        if (mixed.length) setFresh(mixed)
        if (nextTotal > 0 || Number(live.at)) setStamp(Number(live.at) || Date.now())
      } finally {
        loading = false
      }
    }
    const onVisible = () => { if (document.visibilityState === 'visible') load() }
    load()
    const id = setInterval(load, 15_000)
    document.addEventListener('visibilitychange', onVisible)
    return () => {
      alive = false
      ctrl.abort()
      clearInterval(id)
      document.removeEventListener('visibilitychange', onVisible)
    }
  }, [])

  const featured = HOME_IDS.map((id) => CATEGORIES.find((c) => c.id === id)).filter(Boolean)
  const rail = SOURCES.filter((s) => !s.hide)
  const loopSrc = [...rail, ...rail]
  const verified = popular.filter((p) => verifyLevel({ downloads: p.downloads, likes: p.follows }))
  const verifiedShow = verified.length >= 6 ? verified : popular

  return (
    <div className="relative z-10 max-w-7xl mx-auto px-5 sm:px-6 pt-10 pb-4 page-in">
      <section className="atlas-hero fade-up">
        <div className="atlas-veil">
          <div className="flex items-center gap-3 mb-5">
            <img src="/logo.png?v=5" alt="Cubenorix" className="logo-img" width="48" height="48" />
            <div className="font-outfit text-2xl leading-none">Cubenorix</div>
          </div>
          <h1 className="font-outfit title-hero text-3xl sm:text-[2.6rem] font-extrabold max-w-3xl leading-tight">{t(lang, 'hero.title')}</h1>
          <p className="mt-4 text-white/60 max-w-2xl leading-7">{t(lang, 'hero.sub')}</p>
          <div className="mt-7"><SearchBox big /></div>
        </div>
      </section>

      <a
        className="official-channel-strip"
        href="https://t.me/Cubenorix"
        target="_blank"
        rel="me noopener noreferrer"
        aria-label="Официальный Telegram Cubenorix — @Cubenorix"
      >
        <img src="/social/telegram.svg" alt="" width="24" height="24" />
        <span>{t(lang, 'comm.verified').replace(/ ?Cubenorix$/, '')}<i className="strip-site"> Cubenorix</i></span>
        <strong>@Cubenorix</strong>
        <span className="official-channel-arrow" aria-hidden="true">↗</span>
      </a>

      <a
        className="official-channel-strip support-strip"
        href={SUPPORT_BOT_TELEGRAM}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Техническая поддержка Cubenorix — @Cubenorixsupportbot"
      >
        <img src="/social/telegram.svg" alt="" width="24" height="24" />
        <span>{t(lang, 'footer.support')}</span>
        <strong>@{SUPPORT_BOT_USERNAME}</strong>
        <span className="official-channel-arrow" aria-hidden="true">↗</span>
      </a>

      <section className="stat-row mt-4">
        <div className="stat-cell stat-live">
          <div className="flex items-center gap-2">
            <span className="safe-dot" title="live" />
            <span className="text-white/60 text-sm">{t(lang, 'stats.content')}:</span>
            <strong className="font-outfit text-xl font-bold text-orange-soft">{total ? formatNumber(total, lang) : '—'}</strong>
          </div>
          <div className="text-white/50 text-xs mt-1">
            {t(lang, 'stats.updated')}: {stamp ? formatDateTime(stamp, lang) : '—'}
          </div>
          {Object.keys(liveBy).length ? (
            <div className="live-source-counts" title="Live API records; the same project can be published on more than one platform">
              {Object.entries(liveBy).filter(([, n]) => Number(n) > 0).map(([id, n]) => (
                <span key={id}>{id} {formatNumber(n, lang)}</span>
              ))}
            </div>
          ) : null}
        </div>
        <div className="stat-cell">
          <div className="font-outfit text-2xl font-bold text-orange-soft">{rail.length}</div>
          <div className="text-white/50 text-sm mt-0.5">{t(lang, 'stats.platforms')}</div>
        </div>
        <div className="stat-cell">
          <div className="font-outfit text-2xl font-bold text-orange-soft">CDN</div>
          <div className="text-white/50 text-sm mt-0.5">{t(lang, 'stats.files')}</div>
        </div>

      </section>

      <h2 className="font-outfit text-xl mt-12 mb-4">{t(lang, 'home.cats')}</h2>
      <div className="cat-flow">
        {featured.map((c) => (
          <Link key={c.id} to={c.to || `/catalog?type=${c.type || ''}`} className="cat-card" style={{ '--cat': TINT[c.id] || '#ff6b00' }}>
            <span className="cat-glow" />
            <span className="cat-ico"><CatIcon id={c.id} /></span>
            <span className="cat-name">{catName(lang, c.id, c.name?.ru)}</span>
          </Link>
        ))}
      </div>

      <div className="flex items-end justify-between mt-12 mb-3">
        <h2 className="font-outfit text-xl">{t(lang, 'home.popular')}</h2>
        <Link to="/catalog" className="text-sm text-orange-soft">{t(lang, 'home.catalog')}</Link>
      </div>
      {popular.length < 6
        ? <div className="grid md:grid-cols-2 gap-3">{Array.from({ length: 4 }).map((_, i) => <CardSkeleton key={i} />)}</div>
        : [0, 1, 2].map((row) => {
          const pool = row === 2 && fresh.length >= 6 ? fresh : verifiedShow
          return <Rail key={'r' + row} items={pool.filter((_, i) => i % 3 === row)} reverse={row === 1} />
        })}

      {allAcceptedUploads(db).length > 0 && (
        <div>
          <div className="flex items-end justify-between mt-12 mb-3">
            <h2 className="font-outfit text-xl">Проекты наших авторов</h2>
          </div>
          <div className="grid md:grid-cols-2 gap-3">
            {allAcceptedUploads(db).slice(0, 4).map((u) => (
              <Link key={u.id} to={'/project/' + uploadSlug(u.title)} className="glass p-3 flex items-center gap-3">
                {u.logo
                  ? <img src={u.logo} alt="" className="w-11 h-11 rounded-xl object-cover border border-white/10" />
                  : <span className="w-11 h-11 rounded-xl bg-white/5 grid place-items-center text-white/40 font-outfit">{String(u.title || '?').slice(0, 1).toUpperCase()}</span>}
                <div className="min-w-0 flex-1">
                  <div className="font-semibold truncate">{u.title}</div>
                  <div className="text-xs text-white/45 truncate">@{u.user || '—'} · {u.type || 'mod'}{u.versions?.length ? ' · ' + u.versions.slice(0, 2).join(', ') : ''}</div>
                </div>
                <span className="tag" style={{ fontSize: '.7rem' }}>Одобрено</span>
              </Link>
            ))}
          </div>
        </div>
      )}

      <section className="mt-14">
        <h2 className="font-outfit text-2xl mb-2">{t(lang, 'home.whyTitle')}</h2>
        <p className="text-white/55 max-w-2xl mb-5">{t(lang, 'home.whyLead')}</p>
        <div className="why-grid">
          {[1, 2, 3].map((i) => (
            <div key={i} className="why-card stagger" style={{ animationDelay: i * 60 + 'ms' }}>
              <div className="text-orange-soft font-outfit">{t(lang, 'home.why' + i + 't')}</div>
              <p className="text-sm text-white/55 mt-2 leading-6">{t(lang, 'home.why' + i)}</p>
            </div>
          ))}
        </div>
      </section>

      <ReviewsTeaser items={Object.values(db.reviews || {}).flat()} to="/reviews" />

      <section className="mt-14">
        <h2 className="font-outfit text-2xl mb-5">{t(lang, 'home.faqTitle')}</h2>
        <div className="space-y-3">
          {[1, 2, 3, 4].map((i) => (
            <details key={i} className="why-card">
              <summary className="cursor-pointer font-outfit text-orange-soft">{t(lang, 'home.faq' + i + 'q')}</summary>
              <p className="text-sm text-white/55 mt-2 leading-6">{t(lang, 'home.faq' + i + 'a')}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="home-src" aria-label="platforms">
        <div className="rail rail-src">
          <div className="rail-track snail">
            {loopSrc.map((s, i) => (
              <Link
                key={s.id + i}
                to={'/source/' + s.id}
                className="source-chip"
                style={{ borderColor: s.color + '66', boxShadow: glow(s.color), '--chip': s.color }}
              >
                <SourceLogo id={s.id} name={s.name} size={22} color={s.color} />
                <span>{s.name}</span>
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
