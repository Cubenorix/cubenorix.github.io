/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { useEffect, useState } from 'react'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { searchProjects, searchAddons, searchEmotes, searchTextures, parseQuery, rankHits, cacheHits, autocomplete, loosenQuery, smartQuery, searchGithub, searchWiki, aiExpandQueries } from '../api'
import ProjectCard, { CardSkeleton } from '../components/ProjectCard'
import AnimatedNumber from '../components/AnimatedNumber'
import SearchBox from '../components/SearchBox'
import { uniqueHits, verifyLevel } from '../stats'
import { CATEGORIES, CATEGORY_ALIASES, FILTERS, MC_VERSIONS, LOCAL_CONTENT, ADDON_HOSTS } from '../data'
import { allLocal, searchLocalAll } from '../localMore'
import { useStore } from '../store'
import { acceptedUploads, uploadSlug } from '../localUploads'
import { t, catName } from '../i18n'
import { formatNumber } from '../languages'

function EmotecraftHub() {
  return (
    <section className="glass p-5 mb-5 emote-hub">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div className="max-w-2xl">
          <div className="text-xs uppercase tracking-widest text-orange-soft">Emotecraft Hub</div>
          <h2 className="font-outfit text-2xl mt-1">Эмоции, позы и анимации</h2>
          <p className="text-sm text-white/55 mt-2 leading-6">Нажми <b>B</b> для колеса эмоций. Свои файлы <code>.emote</code> положи в <code>.minecraft/emotes</code> или открой папку из настроек мода. Ниже — мод, серверные части и найденные наборы.</p>
        </div>
        <div className="emote-key">B</div>
      </div>
      <div className="flex flex-wrap gap-2 mt-4">
        <a className="tag on" href="https://modrinth.com/plugin/emotecraft" target="_blank" rel="noopener noreferrer">Modrinth · official</a>
        <a className="tag" href="https://github.com/KosmX/emotes" target="_blank" rel="noopener noreferrer">GitHub · official</a>
        <a className="tag" href="https://hangar.papermc.io/dima_dencep/emotecraft" target="_blank" rel="noopener noreferrer">Paper / Folia</a>
        <a className="tag" href="https://spemotes.spoverlay.ru/" target="_blank" rel="noopener noreferrer">SPEMOTES · 26 packs</a>
        <a className="tag" href="https://minecraft-inside.ru/mods/150286-emotecraft.html" target="_blank" rel="noopener noreferrer">Minecraft Inside · RU</a>
      </div>
      <p className="text-[11px] text-white/35 mt-3">Безопаснее скачивать исполняемый JAR только с официальных источников: Modrinth, Hangar, GitHub или сайта автора.</p>
    </section>
  )
}

function SkinStudio({ q }) {
  const { lang } = useStore()
  const nick = String(q || '').trim().split(/\s+/)[0]
  const ok = /^[A-Za-z0-9_]{2,16}$/.test(nick)
  const [info, setInfo] = useState(null)
  useEffect(() => {
    if (!ok) { setInfo(null); return }
    let alive = true
    fetch('/api/skin?nick=' + encodeURIComponent(nick))
      .then((r) => r.json())
      .then((j) => { if (alive) setInfo(j) })
      .catch(() => { if (alive) setInfo(null) })
    return () => { alive = false }
  }, [nick, ok])
  const show = info?.ok ? info.nick : (ok ? nick : 'Steve')
  const body = (info?.body) || ('https://mc-heads.net/body/' + encodeURIComponent(show))
  const player = (info?.player) || ('https://mc-heads.net/player/' + encodeURIComponent(show))
  const head = (info?.avatar) || ('https://mc-heads.net/avatar/' + encodeURIComponent(show) + '/64')
  return (
    <div className="glass p-5 mb-5 flex flex-wrap gap-6 items-end">
      <img src={body} alt="" className="h-44 object-contain" />
      <img src={player} alt="" className="h-28 object-contain" />
      <div>
        <div className="flex items-center gap-2">
          <img src={head} alt="" className="w-10 h-10 rounded-lg" />
          <div>
            <div className="font-outfit text-xl">{show}</div>
            <div className="text-xs text-white/40">
              {info?.ok ? 'Mojang · minecraft.net' : (ok ? t(lang, 'catalog.nickHint') : t(lang, 'catalog.nickEx'))}
            </div>
            {info?.uuid ? <div className="font-mono text-[11px] text-white/35 mt-1">{info.uuid}</div> : null}
          </div>
        </div>
        <div className="flex flex-wrap gap-2 mt-3">
          <a className="tag" href="https://www.minecraft.net/" target="_blank" rel="noopener noreferrer">minecraft.net</a>
          {info?.namemc ? <a className="tag" href={info.namemc} target="_blank" rel="noopener noreferrer">NameMC</a> : null}
          <a className="tag" href={'https://skinmc.net/search?search=' + encodeURIComponent(nick || 'Steve')} target="_blank" rel="noopener noreferrer">SkinMC</a>
          <a className="tag" href={'https://www.minecraftskins.com/search/skin/' + encodeURIComponent(nick || 'Steve') + '/1/'} target="_blank" rel="noopener noreferrer">The Skindex</a>
          <a className="tag" href={'https://minecraft.novaskin.me/search?q=' + encodeURIComponent(nick || 'Steve')} target="_blank" rel="noopener noreferrer">Nova Skin</a>
          <a className="tag" href="https://mineskin.org/" target="_blank" rel="noopener noreferrer">MineSkin</a>
        </div>
      </div>
    </div>
  )
}

// Modrinth allows up to 100 results per request. Use the full batch so the
// catalogue feels substantial while paging remains a single network request.
const PAGE = 100
const LOCAL_TYPES = new Set(['map', 'schematic', 'skin', 'core', 'bedrock', 'world', 'config', 'model', 'emote', 'cosmetic', 'appearance'])
const APPEARANCE_TYPES = ['skin', 'cosmetic', 'emote', 'model']
const FACET_CAT = { library: 'library', optimization: 'optimization' }
const LOCAL = allLocal(LOCAL_CONTENT)

const CAT_GROUPS = [
  ['Игра', ['modpacks', 'mods', 'addons', 'resourcepacks', 'datapacks', 'shaders', 'appearance', 'library', 'optimization']],
  ['Сервер', ['plugins', 'cores', 'bedrock']],
  ['Миры', ['maps', 'worlds', 'schematics']],
]

function Pager({ page, pages, goPage, lang }) {
  if (pages <= 1) return null
  const near = [...new Set([1, page - 2, page - 1, page, page + 1, page + 2, pages])]
    .filter((n) => n >= 1 && n <= pages)
    .sort((a, b) => a - b)
  return (
    <nav className="catalog-pager" aria-label={`${page} / ${pages}`}>
      <button className="btn btn-ghost px-4 h-11 text-sm" onClick={() => goPage(page - 1)} disabled={page <= 1}>{t(lang, 'catalog.back')}</button>
      <div className="pager-pages">
        {near.map((n, i) => (
          <span className="contents" key={n}>
            {i > 0 && n - near[i - 1] > 1 ? <span className="pager-gap">…</span> : null}
            <button className={`pager-number${n === page ? ' on' : ''}`} onClick={() => goPage(n)} aria-current={n === page ? 'page' : undefined}>{n}</button>
          </span>
        ))}
      </div>
      <button className="btn btn-ghost px-4 h-11 text-sm" onClick={() => goPage(page + 1)} disabled={page >= pages}>{t(lang, 'catalog.next')}</button>
    </nav>
  )
}

function BuildDraftBar() {
  const { db, draftClear } = useStore()
  const nav = useNavigate()
  const slugs = db.buildDraft?.slugs || []
  if (!slugs.length) return null
  const target = [db.buildDraft.mc, db.buildDraft.loader].filter(Boolean).join(' · ')
  const go = () => {
    const params = new URLSearchParams()
    params.set('mods', slugs.map((x) => x.slug).join(' + '))
    if (db.buildDraft.mc) params.set('mc', db.buildDraft.mc)
    if (db.buildDraft.loader) params.set('loader', db.buildDraft.loader)
    nav('/builds?' + params.toString())
  }
  return (
    <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 glass px-4 py-3 rounded-2xl flex flex-wrap items-center gap-3 shadow-2xl max-w-[94vw] draft-bar">
      <span className="text-sm whitespace-nowrap"><b>{slugs.length}</b> в сборке{target
        ? <span className="text-white/45 font-mono"> · {target}</span>
        : <span className="text-white/35"> · версию выберешь в сборщике</span>}</span>
      <button className="btn btn-ghost px-3 py-1.5 text-xs" onClick={() => draftClear()}>Очистить</button>
      <button className="btn btn-primary px-5 py-2 text-sm whitespace-nowrap" onClick={go}>Собрать</button>
    </div>
  )
}

export default function Catalog() {
  const { lang, db, setSearchMode } = useStore()
  const nav = useNavigate()
  const [sp, setSp] = useSearchParams()
  const q = sp.get('q') || ''
  const ql = q.toLowerCase()
  const authorHits = q ? acceptedUploads(db).filter((u) => (String(u.title || '') + ' ' + String(u.description || '')).toLowerCase().includes(ql)) : []
  const parsedQ = parseQuery(q)
  // Старые ссылки (texture, skin, emote, cosmetic, model) ведут в объединённые разделы.
  const rawType = sp.get('type') || parsedQ.type || (q ? 'all' : 'mod')
  const type = CATEGORY_ALIASES[rawType] || rawType
  const page = Math.max(1, Number(sp.get('page') || 1))
  const [index, setIndex] = useState('relevance')
  const [version, setVersion] = useState('')
  const [loader, setLoader] = useState('')
  const [hits, setHits] = useState([])
  const [total, setTotal] = useState(0)
  const [err, setErr] = useState('')
  const [loading, setLoading] = useState(false)
  const [safeOnly, setSafeOnly] = useState(false)
  const [parent, setParent] = useState(null)
  const [more, setMore] = useState(false)
  const [widened, setWidened] = useState(false)
  const [sugg, setSugg] = useState([])
  const [smartInfo, setSmartInfo] = useState('')
  const [tick, setTick] = useState(0)

  const isAddon = type === 'addon' || parsedQ.addon

  useEffect(() => {
    setParent(null)
    setWidened(false)
    setSugg([])
    setSmartInfo('')
    let alive = true
    const off = (page - 1) * PAGE

    // Новое за сегодня: новые проекты, отсортированы по свежести; за сутки — если есть.
    if (type === 'fresh') {
      setLoading(true)
      searchProjects({ query: q, limit: 40, offset: 0, index: 'newest', type: '' })
        .then((d) => {
          if (!alive) return
          const dayAgo = Date.now() - 24 * 3600 * 1000
          const fresh = (d.hits || []).filter((h) => h.date_published && new Date(h.date_published).getTime() >= dayAgo)
          const list = fresh.length ? fresh : (d.hits || []).slice(0, PAGE)
          cacheHits(list)
          setHits(list)
          setTotal(fresh.length || Number(d.total_hits) || list.length)
          setErr('')
        })
        .catch(() => { if (alive) setErr(t(lang, 'catalog.err')) })
        .finally(() => { if (alive) setLoading(false) })
      return
    }

    // Объединённая категория «Внешность»: скины + косметика/плащи + эмоции + модели.
    if (type === 'appearance') {
      setLoading(true)
      const localMerged = APPEARANCE_TYPES.flatMap((tp) => searchLocalAll(LOCAL, q, tp))
      const localCount = localMerged.length
      const localSlice = localMerged.slice(off, off + PAGE)
      const remaining = Math.max(0, PAGE - localSlice.length)
      const remoteOffset = Math.max(0, off - localCount)
      Promise.all([
        searchProjects({ query: q, limit: PAGE, offset: remoteOffset, type: 'cosmetic' }).catch(() => ({ hits: [], total_hits: 0 })),
        searchEmotes({ query: q, limit: PAGE, offset: Math.max(0, remoteOffset) }).catch(() => ({ hits: [], total_hits: 0 })),
      ])
        .then(([cosmeticRes, emoteRes]) => {
          if (!alive) return
          const remote = uniqueHits([...(cosmeticRes.hits || []), ...(emoteRes.hits || [])])
          const merged = uniqueHits([...localSlice, ...(off < localCount ? remote.slice(0, remaining) : remote)])
          cacheHits(merged)
          setHits(merged)
          const remoteTotal = (Number(cosmeticRes.total_hits) || 0) + (Number(emoteRes.total_hits) || 0)
          setTotal(Math.max(localCount + remoteTotal, merged.length))
        })
        .finally(() => { if (alive) setLoading(false) })
      return
    }

    const localForType = LOCAL_TYPES.has(type)
      ? searchLocalAll(LOCAL, q, type)
      : (q ? searchLocalAll(LOCAL, q, type === 'all' ? 'all' : type) : [])

    if (LOCAL_TYPES.has(type) && !q && type !== 'emote') {
      setLoading(true)
      const localCount = localForType.length
      const localSlice = localForType.slice(off, off + PAGE)
      const remaining = Math.max(0, PAGE - localSlice.length)
      const remoteOffset = Math.max(0, off - localCount)
      searchProjects({ query: type === 'map' || type === 'world' ? 'survival map' : type, limit: PAGE, offset: remoteOffset, type })
        .then((d) => {
          if (!alive) return
          const remote = uniqueHits(d.hits || []).slice(0, remaining || PAGE)
          const merged = uniqueHits([...localSlice, ...(off < localCount ? remote.slice(0, remaining) : remote)])
          cacheHits(merged)
          setHits(merged)
          setTotal(localCount + (Number(d.total_hits) || remote.length))
        })
        .catch(() => {
          if (!alive) return
          setHits(localSlice)
          setTotal(localCount)
        })
        .finally(() => { if (alive) setLoading(false) })
      return
    }

    const facets = []
    if (type === 'library' || type === 'optimization' || type === 'cosmetic') {
      facets.push(['project_type:mod'])
      facets.push([`categories:${type === 'cosmetic' ? 'cosmetic' : FACET_CAT[type]}`])
    } else if (type && type !== 'all' && !['addon', 'emote', 'texture'].includes(type) && !LOCAL_TYPES.has(type)) {
      facets.push([`project_type:${type}`])
    }
    if (version) facets.push([`versions:${version}`])
    if (loader && type !== 'texture') facets.push([`categories:${loader.toLowerCase()}`])
    setLoading(true)
    const run = isAddon
      ? searchAddons({ query: parsedQ.q.join(' ') || q, limit: PAGE, offset: off, version: version || parsedQ.versions[0], loader: loader || parsedQ.loaders[0] })
      : type === 'emote' || parsedQ.extra?.includes('emote')
        ? searchEmotes({ query: q, limit: PAGE, offset: Math.max(0, off - (q ? 0 : localForType.length)) })
        : type === 'texture'
          ? searchTextures({ query: q, limit: PAGE, offset: off, resolution: loader })
          : searchProjects({ query: q, limit: PAGE, offset: off, index, facets, type })
    run
      .then(async (d) => {
        if (!alive) return
        const extra = []
        if (type === 'skin') {
          const nick = String(q || '').trim().split(/\s+/)[0]
          if (/^[A-Za-z0-9_]{2,16}$/.test(nick)) {
            try {
              const sk = await fetch('/api/skin?nick=' + encodeURIComponent(nick)).then((r) => r.json())
              if (sk?.ok) {
                extra.push({
                  slug: 'mojang-' + sk.nick,
                  title: sk.nick,
                  description: 'Официальный скин Mojang · minecraft.net',
                  icon_url: sk.avatar,
                  sources: ['mojang', 'namemc'],
                  project_type: 'skin',
                  author: sk.nick,
                  url: sk.namemc,
                  downloads: 0,
                  external: true,
                  nick: sk.nick,
                })
              }
            } catch {}
          }
        }
        if (!alive) return
        const localPage = type === 'emote' && !q ? localForType.slice(off, off + PAGE) : (q || LOCAL_TYPES.has(type) ? localForType : [])
        const remoteRoom = type === 'emote' && !q ? Math.max(0, PAGE - localPage.length) : PAGE
        const combined = uniqueHits([...extra, ...localPage, ...(d.hits || []).slice(0, remoteRoom)])
        const merged = q ? rankHits(combined, q) : combined  // оригинальный запрос: точное «Mod Menu» не должно проигрывать «Menu Music»
        // Ничего не нашли? Показываем шире: тот же запрос без фильтров и без стоп-слов,
        // чтобы «мод sodium для 1.20.1 скачать» всё равно нашёл Sodium.
        if (q && !isAddon && type !== 'emote' && type !== 'texture' && !parsedQ.extra?.includes('emote')) {
          // Умный путь: пользователь описал СМЫСЛ («мод чтобы руды падали чаще»).
          // Словарь смыслов (работает у всех) +, если на устройстве сохранён HF-токен, ИИ-расширение.
          const smart = smartQuery(q)
          let planned = smart.queries.length ? smart.queries : smart.words
          let aiAdded = false
          try {
            const tok = localStorage.getItem('cubenorixx.hf') || ''
            if (tok) {
              const ai = await aiExpandQueries(q, tok)
              if (ai.length) { planned = [...new Set([...ai, ...planned])].slice(0, 4); aiAdded = true }
            }
          } catch {}
          if (planned.length) {
            const groups = await Promise.all(planned.map((qq) => searchProjects({ query: qq, limit: 12, offset: 0, index, type: '' }).catch(() => ({ hits: [] }))))
            const ghQ = planned[0] || q
            const [gh, wiki] = await Promise.all([
              searchGithub({ query: ghQ }).catch(() => ({ hits: [] })),
              searchWiki({ query: ghQ }).catch(() => ({ hits: [] })),
            ])
            const found = uniqueHits(groups.flatMap((g) => g.hits || []))
            const terms = planned.join(' ').toLowerCase().split(/[^a-z0-9+]+/).filter((w) => w.length > 2)
            const score = (h) => {
              const hay = (String(h.slug || '') + ' ' + String(h.title || '') + ' ' + String(h.description || '')).toLowerCase()
              return terms.reduce((acc, w) => acc + (hay.includes(w) ? 1 : 0), 0)
            }
            if (alive && (found.length || gh.hits.length || wiki.hits.length)) {
              setSmartInfo((aiAdded ? '🤖 ИИ + словарь смыслов' : '🤖 Словарь смыслов') + ': «' + q + '» → искали по смыслу: ' + planned.slice(0, 3).map((x) => '«' + x + '»').join(', ') + (gh.hits.length ? ' · плюс проекты с GitHub' : '') + (wiki.hits.length ? ' · плюс Minecraft-вики' : '') + '.')
              const mods = found.sort((a, b) => score(b) - score(a) || (b.downloads || 0) - (a.downloads || 0)).slice(0, PAGE - 6)
              const mix = !merged.length
                ? [...mods, ...gh.hits.slice(0, 4), ...wiki.hits.slice(0, 3)]
                : uniqueHits([...mods.slice(0, PAGE - 8), ...merged.slice(0, 6), ...gh.hits.slice(0, 3), ...wiki.hits.slice(0, 3)])
              cacheHits(mix)
              setHits(mix)
              setTotal(Math.max(Number(d.total_hits) || 0, mix.length))
              setErr('')
              setLoading(false)
              return
            }
            if (!merged.length) {
              try {
                const wider = await searchProjects({ query: loosenQuery(q), limit: PAGE, offset: off, index, type: '' })
                const wHits = uniqueHits(wider.hits || [])
                if (alive && wHits.length) {
                  cacheHits(wHits)
                  setWidened(true)
                  setHits(wHits.slice(0, PAGE))
                  setTotal(Number(wider.total_hits) || wHits.length)
                  setErr('')
                  setLoading(false)
                  return
                }
              } catch {}
              if (alive) autocomplete(q).then((list) => { if (alive) setSugg((list || []).slice(0, 6).map((h) => h.title || h.slug)) }).catch(() => {})
            }
          } else if (!merged.length) {
            try {
              const wider = await searchProjects({ query: loosenQuery(q), limit: PAGE, offset: off, index, type: '' })
              const wHits = uniqueHits(wider.hits || [])
              if (alive && wHits.length) {
                cacheHits(wHits)
                setWidened(true)
                setHits(wHits.slice(0, PAGE))
                setTotal(Number(wider.total_hits) || wHits.length)
                setErr('')
                setLoading(false)
                return
              }
            } catch {}
            if (alive) autocomplete(q).then((list) => { if (alive) setSugg((list || []).slice(0, 6).map((h) => h.title || h.slug)) }).catch(() => {})
          }
        }
        cacheHits(merged)
        const shown = safeOnly
          ? merged.filter((h) => verifyLevel({ downloads: h.downloads, likes: h.follows || h.likes || 0 }) || h.external)
          : merged
        setHits(shown.slice(0, LOCAL_TYPES.has(type) && q ? 80 : PAGE))
        setTotal(type === 'emote' && !q ? localForType.length + (Number(d.total_hits) || 0) : Math.max(d.total_hits || 0, shown.length, merged.length))
        setParent(d.parent || null)
        setErr(merged.length ? '' : '')
      })
      .catch(() => {
        if (!alive) return
        if (localForType.length) {
          setHits(localForType.slice(off, off + PAGE))
          setTotal(localForType.length)
          setErr('')
        } else setErr(t(lang, 'catalog.err'))
      })
      .finally(() => { if (alive) setLoading(false) })
    return () => { alive = false }
  }, [q, type, index, version, loader, page, safeOnly, tick])

  // Живые цифры: totals обновляются сами раз в минуту и при возврате на вкладку.
  useEffect(() => {
    const bump = () => { if (document.visibilityState === 'visible') setTick((t) => t + 1) }
    const iv = setInterval(bump, 60000)
    document.addEventListener('visibilitychange', bump)
    return () => { clearInterval(iv); document.removeEventListener('visibilitychange', bump) }
  }, [])

  const filters = type === 'plugin' ? FILTERS.plugins : FILTERS.mods
  const pages = Math.max(1, Math.ceil(total / PAGE))
  const goPage = (n) => {
    const next = Math.min(pages, Math.max(1, n))
    const obj = Object.fromEntries(sp.entries())
    obj.page = String(next)
    setSp(obj)
  }

  const heading = isAddon
    ? catName(lang, 'addons')
    : (type === 'all' ? t(lang, 'catalog.title') : catName(lang, CATEGORIES.find((c) => c.type === type)?.id || type, t(lang, 'catalog.title')))

  const setType = (next) => setSp({ q, type: next, page: '1' })

  return (
    <div className="relative z-10 max-w-7xl mx-auto px-4 pt-6 pb-16 page-in">
      <div className="mb-4"><SearchBox /></div>

      <div className="cat-chips hide-scroll">
        <button type="button" className={'tag ' + (type === 'all' ? 'on' : '')} onClick={() => setType('all')}>{t(lang, 'catalog.all')}</button>
        {db.showFresh && (
          <button type="button" className={'tag ' + (type === 'fresh' ? 'on' : '')} onClick={() => setType('fresh')} title="Проекты, добавленные за последние сутки">Новое за сегодня</button>
        )}
        {CAT_GROUPS.flatMap(([, ids]) => ids).map((id) => {
          const c = CATEGORIES.find((x) => x.id === id)
          if (!c?.type) return null
          return (
            <button key={c.id} type="button" className={'tag ' + (type === c.type ? 'on' : '')} onClick={() => setType(c.type)}>
              {catName(lang, c.id)}
            </button>
          )
        })}
      </div>

      <div className="cat-bar">
        <select className="field py-2" value={index} onChange={(e) => { setIndex(e.target.value); goPage(1) }} aria-label={t(lang, 'catalog.sort')}>
          <option value="relevance">{t(lang, 'catalog.relevance')}</option>
          <option value="downloads">{t(lang, 'catalog.downloads')}</option>
          <option value="updated">{t(lang, 'catalog.updated')}</option>
          <option value="newest">{t(lang, 'catalog.newest')}</option>
        </select>
        <select className="field py-2 font-mono text-sm" value={version} onChange={(e) => { setVersion(e.target.value); goPage(1) }}>
          <option value="">{t(lang, 'catalog.versions')}</option>
          {MC_VERSIONS.filter((v) => !v.endsWith('…')).slice().reverse().slice(0, 40).map((v) => (
            <option key={v} value={v}>{v}</option>
          ))}
        </select>
        <button type="button" className={'tag ' + (safeOnly ? 'on' : '')} onClick={() => { setSafeOnly(!safeOnly); goPage(1) }}>
          <span className="safe-dot" /> {t(lang, 'catalog.verified')}
        </button>
        <button type="button" className="tag" title="Случайная страница популярных проектов" onClick={() => goPage(1 + Math.floor(Math.random() * Math.min(pages, 60)))}>Случайное</button>
        <button type="button" className={'tag ' + (db.searchMode === 'exact' ? 'on' : '')} onClick={() => setSearchMode(db.searchMode === 'exact' ? 'smart' : 'exact')}>
          {db.searchMode === 'exact' ? t(lang, 'catalog.exact') : t(lang, 'catalog.smart')}
        </button>
        <button type="button" className={'tag ' + (more ? 'on' : '')} onClick={() => setMore(!more)}>{t(lang, 'catalog.core')}</button>
      </div>
      {more ? (
        <div className="flex flex-wrap gap-1 mb-4">
          {filters.slice(0, 10).map((f) => (
            <button key={f} type="button" className={'tag ' + (loader === f ? 'on' : '')} onClick={() => { setLoader(loader === f ? '' : f); goPage(1) }}>{f}</button>
          ))}
        </div>
      ) : null}

      <p className="text-[11px] text-white/35 -mt-2 mb-3">Поиск — живой: новые проекты появляются в течение суток. Проверки «✓» и описания сайт переизучает при каждом обновлении сайта и правит, если проект изменился.</p>

      <h1 className="font-outfit text-3xl font-bold mb-2">
        {heading} {q && <span className="text-orange-soft font-mono text-xl">«{q}»</span>}
      </h1>
      {parent && <p className="text-sm text-white/55 mb-3">{parent.title}</p>}

      {type === 'addon' && (
        <div className="mb-4">
          <form className="flex gap-2 mb-3" onSubmit={(e) => { e.preventDefault(); const v = e.target.mod.value.trim(); setSp({ q: v, type: 'addon', page: '1' }) }}>
            <input name="mod" className="field" defaultValue={q} placeholder="JEI, Create…" />
            <button className="btn btn-primary px-5">{t(lang, 'hero.find')}</button>
          </form>
          <div className="flex flex-wrap gap-2">
            {ADDON_HOSTS.map((h) => (
              <button key={h.q} className={'tag ' + (q.toLowerCase() === h.q.toLowerCase() ? 'on' : '')} onClick={() => setSp({ q: h.q, type: 'addon', page: '1' })}>{h.name}</button>
            ))}
          </div>
        </div>
      )}

      {(type === 'skin' || type === 'appearance') && <SkinStudio q={q} />}
      {(type === 'emote' || type === 'appearance') && <EmotecraftHub />}
      <Pager page={page} pages={pages} goPage={goPage} lang={lang} />
      <div className="results-summary" aria-live="polite">
        {loading ? <span>{t(lang, 'catalog.searching')}</span> : (
          <>
            <AnimatedNumber value={total} format={(n) => formatNumber(n, lang)} />
            <span>{formatNumber(total ? (page - 1) * PAGE + 1 : 0, lang)}–{formatNumber(Math.min(page * PAGE, total), lang)}</span>
            <span>{page} / {pages}</span>
          </>
        )}
      </div>
      {smartInfo && <p className="text-sm text-orange-soft/90 mb-3">{smartInfo}</p>}
      {!loading && q && authorHits.length > 0 && (
        <div className="mb-5">
          <h2 className="font-outfit text-lg mb-2">Проекты авторов Cubenorix</h2>
          <div className="catalog-list">
            {authorHits.map((u) => (
              <Link key={u.id} to={'/project/' + uploadSlug(u.title)} className="glass p-3 flex items-center gap-3">
                {u.logo
                  ? <img src={u.logo} alt="" className="w-11 h-11 rounded-xl object-cover border border-white/10" />
                  : <span className="w-11 h-11 rounded-xl bg-white/5 grid place-items-center text-white/40 font-outfit">{String(u.title || '?').slice(0, 1).toUpperCase()}</span>}
                <div className="min-w-0 flex-1">
                  <div className="font-semibold truncate">{u.title}</div>
                  <div className="text-xs text-white/45 truncate">@{u.user || '—'} · {u.type || 'mod'}{u.description ? ' · ' + String(u.description).slice(0, 70) : ''}</div>
                </div>
                <span className="tag" style={{ fontSize: '.7rem' }}>Проект автора</span>
              </Link>
            ))}
          </div>
        </div>
      )}
      {widened && <p className="text-sm text-white/50 mb-3">Точного «{q}» не нашлось — показал шире, без фильтров. Проверь опечатки или убери лишние слова.</p>}
      {err && <div className="rounded-2xl border border-orange/30 p-3 text-orange-soft mb-4">{err}</div>}
      {loading && <div className="catalog-list">{Array.from({ length: 12 }).map((_, i) => <CardSkeleton key={i} />)}</div>}
      {!loading && hits.length === 0 && (
        <div className="rounded-[20px] glass p-10 text-center">
          <img src="/logo.png?v=5" alt="" className="w-12 h-12 mx-auto opacity-80 logo-img" />
          <h2 className="font-outfit text-xl mt-4">{t(lang, 'catalog.empty')}</h2>
          {sugg.length > 0 && (
            <div className="mt-5">
              <p className="text-sm text-white/50 mb-2">Может, искали это?</p>
              <div className="flex flex-wrap gap-2 justify-center">
                {sugg.map((s) => <button key={s} className="tag" onClick={() => setSp({ q: s, type, page: '1' })}>{s}</button>)}
              </div>
            </div>
          )}
          <button className="btn btn-ghost mt-5 px-5 py-2" onClick={() => nav('/add')}>{t(lang, 'catalog.addLink')}</button>
        </div>
      )}
      {!loading && hits.length > 0 && (
        <div className="catalog-list">
          {hits.map((p) => <ProjectCard key={p.slug || p.title} p={p} />)}
        </div>
      )}
      <Pager page={page} pages={pages} goPage={goPage} lang={lang} />
      <BuildDraftBar />
    </div>
  )
}
