/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
// Одобренные загрузки авторов становятся полноценными страницами проектов:
// /project/<имя>. Пока сайт работает локально (GitHub Pages, без сервера),
// проекты живут в localStorage устройства — но выглядят и открываются
// как настоящие страницы каталога.

export function uploadSlug(title) {
  const s = String(title || '')
    .trim()
    .toLowerCase()
    .replace(/[\s_]+/g, '-')
    .replace(/[^a-z0-9а-яё-]/gi, '')
    .replace(/-{2,}/g, '-')
    .replace(/^-+|-+$/g, '')
  return s || 'project'
}

export function acceptedUploads(db) {
  return (db?.uploads || []).filter((u) => u && u.status === 'accepted')
}

// Приводит запись загрузки к виду проекта (как у LOCAL_CONTENT/Modrinth),
// чтобы страница проекта рендерила её без отдельных веток.
export function uploadProject(up, slugOverride) {
  const slug = slugOverride || uploadSlug(up.title)
  const desc = String(up.description || '').trim() || 'Проект автора на Cubenorix.'
  return {
    slug,
    title: up.title,
    author: up.display || up.user || 'автор Cubenorix',
    description: desc,
    body: desc,
    project_type: up.type || 'mod',
    categories: up.categories || [],
    loaders: up.loaders || [],
    game_versions: up.versions || [],
    icon_url: up.logo || null,
    downloads: Number(up.downloads) || 0,
    external: true,
    local_upload: true,
    uploadedBy: up.user || '',
    source_url: up.github || up.site || up.src || '',
    mod_note: up.modNote || '',
  }
}
