/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import React, { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { ACHIEVEMENTS } from './data'
import { isRTL, localeOf } from './i18n'
import { detectLanguage } from './languages'
import {
  authErrorText,
  deleteAccount as deleteServerAccount,
  getAuthStatus,
  getCurrentUser,
  loginAccount,
  logoutAccount,
  registerAccount,
  updateAccountProfile,
} from './auth-api'
import {
  changeLocalPassword,
  currentLocalUser,
  decodeJwtPayload,
  loginWithGoogleIdentity,
  deleteLocalAccountAsync,
  loginLocalAccount,
  logoutLocalAccount,
  registerLocalAccount,
  updateLocalProfile,
} from './auth-local'

const KEY = 'cubenorixx.v1'
const Ctx = createContext(null)

function load() {
  try {
    return JSON.parse(localStorage.getItem(KEY) || localStorage.getItem('cubenix.v1') || localStorage.getItem('cubis.v1') || 'null') || {}
  } catch { return {} }
}

const seed = {
  favorites: [],
  follows: [],
  builds: [],
  comments: {},
  reviews: {},
  history: [],
  uploads: [],
    added: [],
    ideas: [],
  stats: { downloads: 0, builds: 0, reviews: 0, uploads: 0, comments: 0 },
  lang: 'ru',
  searchMode: 'smart',
  communityUrl: '',
  secretUnlocked: false,
  registered: false,
  custom: {},
  reports: [],
  team: null,
  buildDraft: { mc: '', loader: '', slugs: [] },
  notifications: { news: true, replies: true, uploads: true, features: false, digest: false },
  newsSubscribed: false,
}

export function StoreProvider({ children }) {
  const autoLocale = useRef(!Object.prototype.hasOwnProperty.call(load(), 'lang'))
  const [db, setDb] = useState(() => {
    const s = load()
    return {
      ...seed,
      ...s,
      // Legacy preview accounts stored plaintext passwords in localStorage.
      // They are deliberately discarded; real identity now comes from the server.
      users: undefined,
      session: undefined,
      favorites: Array.isArray(s.favorites) ? s.favorites : [],
      follows: Array.isArray(s.follows) ? s.follows : [],
      builds: Array.isArray(s.builds) ? s.builds : [],
      history: Array.isArray(s.history) ? s.history : [],
      uploads: Array.isArray(s.uploads) ? s.uploads : [],
      buildDraft: s.buildDraft && typeof s.buildDraft === 'object'
        ? { mc: String(s.buildDraft.mc || ''), loader: String(s.buildDraft.loader || ''), slugs: Array.isArray(s.buildDraft.slugs) ? s.buildDraft.slugs.filter((x) => x && x.slug).slice(0, 200) : [] }
        : { mc: '', loader: '', slugs: [] },
      added: Array.isArray(s.added) ? s.added : [],
      ideas: Array.isArray(s.ideas) ? s.ideas : [],
      comments: s.comments && typeof s.comments === 'object' && !Array.isArray(s.comments) ? s.comments : {},
      reviews: s.reviews && typeof s.reviews === 'object' && !Array.isArray(s.reviews) ? s.reviews : {},
      stats: { ...seed.stats, ...(s.stats || {}) },
      lang: s.lang || detectLanguage({ languages: typeof navigator !== 'undefined' ? navigator.languages : [], country: '' }),
      langManual: Boolean(s.langManual),
    }
  })
  const [toast, setToast] = useState(null)
  const [serverUser, setServerUser] = useState(null)
  const [localUser, setLocalUser] = useState(() => currentLocalUser())
  const [authStatus, setAuthStatus] = useState({ configured: false, loading: true })
  const [authReady, setAuthReady] = useState(false)

  useEffect(() => {
    const { users, session, ...safeLocalPreferences } = db
    localStorage.setItem(KEY, JSON.stringify(safeLocalPreferences))
  }, [db])

  useEffect(() => {
    let alive = true
    Promise.allSettled([getAuthStatus(), getCurrentUser()]).then(([status, current]) => {
      if (!alive) return
      setAuthStatus(status.status === 'fulfilled' ? { ...status.value, loading: false } : { configured: false, loading: false })
      setServerUser(current.status === 'fulfilled' ? current.value.user : null)
      setAuthReady(true)
    })
    return () => { alive = false }
  }, [])

  useEffect(() => {
    if (!autoLocale.current) return
    let alive = true
    fetch('/api/locale')
      .then((r) => r.ok ? r.json() : {})
      .then((info) => {
        if (!alive) return
        const detected = detectLanguage({ languages: navigator.languages || [navigator.language], country: info.country || '' })
        setDb((d) => d.langManual ? d : ({ ...d, lang: detected, localeSource: info.country ? 'browser+country' : 'browser' }))
      })
      .catch(() => {})
    return () => { alive = false }
  }, [])

  useEffect(() => {
    const lang = db.lang || 'ru'
    try {
      document.documentElement.lang = localeOf(lang)
      document.documentElement.dir = isRTL(lang) ? 'rtl' : 'ltr'
      document.documentElement.classList.toggle('lang-gc', lang === 'gc')
      document.documentElement.classList.toggle('lang-morse', lang === 'morse')
    } catch {}
  }, [db.lang])

  const notify = (msg, type = 'ok') => {
    setToast({ msg, type, id: Date.now() })
    setTimeout(() => setToast(null), 2200)
  }

  const user = serverUser || localUser
  const authConfigured = Boolean(authStatus.configured || db.secretUnlocked)

  const api = useMemo(() => ({
    db, user, toast, notify, authStatus, authReady, authConfigured, lang: db.lang || 'ru',
    setLang: (lang) => {
      try {
        document.documentElement.lang = localeOf(lang)
        document.documentElement.dir = isRTL(lang) ? 'rtl' : 'ltr'
      } catch {}
      setDb((d) => ({ ...d, lang, langManual: true, localeSource: 'manual' }))
    },
    setSearchMode: (searchMode) => setDb((d) => ({ ...d, searchMode })),
    login: async (email, password) => {
      if (authStatus.configured) {
        try {
          const result = await loginAccount({ email, password })
          setServerUser(result.user)
          setDb((d) => ({ ...d, registered: true }))
          return { ok: true, user: result.user }
        } catch (error) {
          return { ok: false, error: authErrorText(error), code: error.code }
        }
      }
      const result = await loginLocalAccount({ email, password })
      if (result.ok) {
        setLocalUser(result.user)
        setDb((d) => ({ ...d, registered: true, ...(result.user.profile?.custom ? { custom: { ...d.custom, ...result.user.profile.custom } } : {}) }))
      }
      return result
    },
    oauth: async () => ({ ok: false, error: 'Вход Microsoft пока не подключён и не имитируется.' }),
    loginGoogle: async (credential) => {
      const payload = decodeJwtPayload(credential)
      if (!payload?.email) return { ok: false, error: 'Google не вернул данные входа.' }
      const result = await loginWithGoogleIdentity({ sub: payload.sub, email: payload.email, name: payload.name, picture: payload.picture })
      if (result.ok) {
        setLocalUser(result.user)
        setDb((d) => ({ ...d, registered: true, custom: result.created ? { accent: 'orange', banner: 'sunset' } : d.custom }))
        // Аватар из Google: качаем картинку и сохраняем как свою (если CORS позволяет).
        if (payload.picture) {
          try {
            const blob = await fetch(payload.picture).then((r) => r.blob())
            if (blob && blob.size && blob.size < 900000) {
              const dataUrl = await new Promise((res) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = () => res(''); fr.readAsDataURL(blob) })
              if (dataUrl) setCustom({ avatar: 'custom', avatarData: dataUrl })
            }
          } catch {}
        }
      }
      return result
    },
    register: async (username, email, password, consent = {}) => {
      if (authStatus.configured) {
        try {
          const result = await registerAccount({ username, email, password, ...consent })
          setServerUser(result.user)
          setDb((d) => ({ ...d, registered: true }))
          return { ok: true, user: result.user }
        } catch (error) {
          return { ok: false, error: authErrorText(error), code: error.code, fields: error.fields }
        }
      }
      const result = await registerLocalAccount({ username, email, password, consent })
      if (result.ok) {
        setLocalUser(result.user)
        setDb((d) => ({ ...d, registered: true, custom: { accent: 'orange', banner: 'sunset' } }))
      }
      return result
    },
    logout: async () => {
      try { await logoutAccount() } catch {}
      logoutLocalAccount()
      setServerUser(null)
      setLocalUser(null)
      return { ok: true }
    },
    deleteAccount: async (password, confirm) => {
      if (!authStatus.configured) {
        const result = await deleteLocalAccountAsync()
        if (result.ok) { setLocalUser(null); setDb((d) => ({ ...d, registered: false })) }
        return result
      }
      try {
        await deleteServerAccount({ password, confirm })
        setServerUser(null)
        return { ok: true }
      } catch (error) {
        return { ok: false, error: authErrorText(error), code: error.code }
      }
    },
    resetPassword: async () => ({ ok: false, error: 'Сброс пароля появится после подключения почтового провайдера. Напишите в техподдержку @Cubenorixsupportbot (t.me/Cubenorixsupportbot).' }),
    pushHistory: (q) => {
      if (!q) return
      setDb((d) => {
        const history = [q, ...(d.history || []).filter((x) => x !== q)].slice(0, 10)
        return { ...d, history }
      })
    },
    toggleFav: (project) => {
      if (!project?.slug) return
      let nowIn = false
      setDb((d) => {
        const has = (d.favorites || []).some((f) => f.slug === project.slug)
        nowIn = !has
        return { ...d, favorites: has ? d.favorites.filter((f) => f.slug !== project.slug) : [...(d.favorites || []), { slug: project.slug, title: project.title, icon_url: project.icon_url }] }
      })
      notify(nowIn ? 'В избранном' : 'Убрано из избранного')
    },
    isFav: (slug) => (db.favorites || []).some((f) => f.slug === slug),
    addBuildItem: (item) => {
      if (!item?.slug) return
      setDb((d) => {
        let builds = Array.isArray(d.builds) ? d.builds : []
        if (!builds.length) builds = [{ id: 'draft', name: 'Черновик', items: [], created: Date.now() }]
        builds = builds.map((b, i) => i === 0 ? { ...b, items: [...b.items.filter((x) => x.slug !== item.slug), item] } : b)
        return { ...d, builds }
      })
      notify('Добавлено в сборку')
    },
    saveBuild: (build) => {
      setDb((d) => ({ ...d, builds: [...d.builds.filter((b) => b.id !== build.id), build], stats: { ...d.stats, builds: d.stats.builds + 1 } }))
    },
    deleteBuild: (id) => setDb((d) => ({ ...d, builds: d.builds.filter((b) => b.id !== id) })),
    bump: (stat, n = 1) => setDb((d) => ({ ...d, stats: { ...d.stats, [stat]: (d.stats[stat] || 0) + n } })),
    addComment: (slug, text, parent = null) => {
      if (!user) return notify('Нужно войти в аккаунт', 'err')
      const c = { id: crypto.randomUUID(), user: user.username, text, at: Date.now(), parent, likes: 0, source: 'Cubenorix' }
      setDb((d) => ({
        ...d,
        comments: { ...d.comments, [slug]: [...(d.comments[slug] || []), c] },
        stats: { ...d.stats, comments: d.stats.comments + 1 },
      }))
    },
    addReview: (slug, stars, text, version, hours) => {
      if (!user) return notify('Нужно войти в аккаунт', 'err')
      const r = { id: crypto.randomUUID(), user: user.username, display: user.display || user.username, brand: user.brand || '', nick: user.nick || user.username, stars, text, version, hours, at: Date.now(), up: 0, down: 0, slug }
      setDb((d) => ({
        ...d,
        reviews: { ...d.reviews, [slug]: [...(d.reviews[slug] || []), r] },
        stats: { ...d.stats, reviews: d.stats.reviews + 1 },
      }))
    },
    addUpload: (item) => {
      if (!user) return notify('Нужно войти в аккаунт', 'err')
      const platforms = (item.platforms || ['github']).map((id) => ({ id, ok: true }))
      const rec = {
        ...item,
        id: crypto.randomUUID(),
        at: Date.now(),
        user: user.username,
        display: user.display || user.username,
        status: item.virusChecked ? 'review' : 'rejected',
        platforms,
        downloads: Number(item.downloads) || 0,
        likes: 0,
        comments: [{ user: 'Cubenorix', text: '√ проект принят', at: Date.now() }],
      }
      setDb((d) => ({ ...d, uploads: [...d.uploads, rec], stats: { ...d.stats, uploads: d.stats.uploads + 1 } }))
      notify('√ проект принят')
    },
    publishBuild: (build) => {
      if (!user) return notify('Нужно войти в аккаунт', 'err')
      const rec = { ...build, id: build.id || crypto.randomUUID(), public: true, status: 'accepted', owner: user.username, at: Date.now() }
      setDb((d) => ({ ...d, builds: [...d.builds.filter((b) => b.id !== rec.id), rec], stats: { ...d.stats, builds: d.stats.builds + 1 } }))
      notify('√ сборка опубликована')
    },
    addAggregated: (item) => {
      setDb((d) => {
        const added = [...(d.added || []).filter((x) => x.slug !== item.slug), item]
        return { ...d, added }
      })
    },
    addIdea: (text) => setDb((d) => ({ ...d, ideas: [...d.ideas, { text, at: Date.now(), user: user?.username }] })),
    changePassword: async ({ current, next } = {}) => {
      if (!authStatus.configured) {
        const result = await changeLocalPassword({ current, next })
        if (result.ok) setLocalUser(result.user)
        return result
      }
      return { ok: false, error: 'Смена пароля на сервере появится позже. Вопросы — @Cubenorixsupportbot.' }
    },
    updateProfile: async (patch) => {
      if (!authStatus.configured) {
        const result = updateLocalProfile(patch)
        if (result.ok) setLocalUser(result.user)
        return result.ok ? { ok: true, user: result.user } : { ok: false, error: result.error }
      }
      try {
        const result = await updateAccountProfile(patch)
        setServerUser(result.user)
        return { ok: true, user: result.user }
      } catch (error) {
        return { ok: false, error: authErrorText(error), code: error.code }
      }
    },
    setCommunityUrl: (communityUrl) => setDb((d) => ({ ...d, communityUrl: String(communityUrl || '').trim() })),
    secretUnlocked: Boolean(db.secretUnlocked),
    authConfigured,
    unlockSecret: () => {
      let now = false
      setDb((d) => { now = !d.secretUnlocked; return { ...d, secretUnlocked: true } })
      return now
    },
    setCustom: (patch) => setDb((d) => ({ ...d, custom: { ...(d.custom || {}), ...patch } })),
    setNotifications: (patch) => setDb((d) => ({ ...d, notifications: { ...(d.notifications || {}), ...patch } })),
    setNewsSubscribed: (on) => setDb((d) => ({ ...d, newsSubscribed: Boolean(on) })),
    setTeam: (team) => setDb((d) => ({ ...d, team })),
    draftAdd: (item) => {
      if (!item?.slug) return false
      let added = false
      setDb((d) => {
        const slugs = Array.isArray(d.buildDraft?.slugs) ? d.buildDraft.slugs : []
        if (slugs.some((x) => x.slug === item.slug)) return d
        if (slugs.length >= 200) return d
        added = true
        return { ...d, buildDraft: { ...(d.buildDraft || {}), slugs: [...slugs, { slug: item.slug, title: item.title || item.slug, icon_url: item.icon_url || '' }] } }
      })
      return added
    },
    draftRemove: (slug) => setDb((d) => ({
      ...d,
      buildDraft: { ...(d.buildDraft || {}), slugs: (d.buildDraft?.slugs || []).filter((x) => x.slug !== slug) },
    })),
    draftClear: () => setDb((d) => ({ ...d, buildDraft: { mc: d.buildDraft?.mc || '', loader: d.buildDraft?.loader || '', slugs: [] } })),
    draftTarget: (patch) => setDb((d) => ({
      ...d,
      buildDraft: { ...(d.buildDraft || {}), ...(patch || {}) },
    })),
    moderateUpload: (id, status, note = '') => {
      if (user?.role !== 'admin') return { ok: false, error: 'Модерация доступна только администрации.' }
      let done = false
      setDb((d) => ({
        ...d,
        uploads: d.uploads.map((u) => (u.id === id ? { ...u, status, modNote: note || '', moderatedBy: 'Cubenorix', moderatedAt: Date.now() } : u)),
      }))
      done = true
      return { ok: done }
    },
    pushReport: (report) => {
      const rec = { ...report, id: crypto.randomUUID(), at: Date.now(), status: 'sent' }
      setDb((d) => ({ ...d, reports: [...(d.reports || []), rec] }))
      return rec
    },

    importPack: (data) => {
      if (!data || data.v !== 1) return { ok: false, error: 'Это не пакет Cubenorix' }
      setDb((d) => {
        const fav = [...(d.favorites || [])]
        for (const f of data.favorites || []) {
          if (f?.slug && !fav.some((x) => x.slug === f.slug)) fav.push(f)
        }
        const builds = [...(d.builds || [])]
        for (const b of data.builds || []) {
          if (!b) continue
          const id = b.id || crypto.randomUUID()
          if (!builds.some((x) => x.id === id)) builds.push({ ...b, id })
        }
        return { ...d, favorites: fav, builds }
      })
      return { ok: true }
    },
    unlocked: () => ACHIEVEMENTS.filter((a) => (a.flag ? db[a.flag] : (db.stats[a.stat] || 0) >= a.n)),
  }), [db, user, authStatus, authReady])

  return <Ctx.Provider value={api}>{children}</Ctx.Provider>
}

export const useStore = () => useContext(Ctx)
