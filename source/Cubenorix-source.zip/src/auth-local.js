/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
// Локальные аккаунты Cubenorix: работают на любом статическом хостинге
// (GitHub Pages). Пароль никогда не хранится в открытом виде — только
// SHA-256(salt + password). Аккаунты живут в localStorage этого устройства;
// когда подключится серверный режим (Cloudflare Worker + D1), локальные
// аккаунты можно будет перенести.

const ACCOUNTS_KEY = 'cubenorixx.accounts.v1'
const SESSION_KEY = 'cubenorixx.session.v1'

let storageImpl = null
function storage() {
  if (storageImpl) return storageImpl
  try {
    const probe = '__cx_probe__'
    globalThis.localStorage.setItem(probe, '1')
    globalThis.localStorage.removeItem(probe)
    storageImpl = globalThis.localStorage
  } catch {
    const mem = new Map()
    storageImpl = {
      getItem: (k) => (mem.has(k) ? mem.get(k) : null),
      setItem: (k, v) => mem.set(k, String(v)),
      removeItem: (k) => mem.delete(k),
    }
  }
  return storageImpl
}

export function setAuthStorage(impl) { storageImpl = impl }

export async function sha256hex(text) {
  const data = new TextEncoder().encode(text)
  const digest = await crypto.subtle.digest('SHA-256', data)
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, '0')).join('')
}

function randomSalt() {
  const bytes = new Uint8Array(16)
  crypto.getRandomValues(bytes)
  return [...bytes].map((b) => b.toString(16).padStart(2, '0')).join('')
}

const USERNAME_RE = /^[A-Za-z0-9_-]{3,24}$/
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/

// — Встроенный аккаунт администрации —
// Это обычный аккаунт с ЗАКРЕПЛЁННЫМ логином и МАКСИМАЛЬНЫМ уровнем:
// никаких отдельных «прав» не добавляет. Создаётся автоматически на любом
// устройстве при первом обращении к хранилищу аккаунтов, поэтому владелец
// может войти с любого устройства: логин (почта или ник Cubenorix) + пароль.
// Пароль нигде не хранится открыто — только SHA-256(соль + пароль).
export const ADMIN_EMAIL = 'mc.7cubes.ru@gmail.com'
export const ADMIN_USERNAME = 'Cubenorix'
export const OFFICIAL_EMAIL = 'cubenorix.official@gmail.com'
const ADMIN_SALT = '04a48675320d1242c71c0716b0af6335'
const ADMIN_HASH = 'f395e001fce26d51f925fd9c1a09aabf446bcbc4903abd7b5a42c0cdfd68de56'
const ADMIN_CREATED = '2026-08-29T00:00:00.000Z'

function adminRecord() {
  return {
    username: ADMIN_USERNAME,
    email: ADMIN_EMAIL,
    salt: ADMIN_SALT,
    hash: ADMIN_HASH,
    created: ADMIN_CREATED,
    role: 'admin',
    level: 'max',
    consents: { termsAccepted: true, privacyAccepted: true, contentRulesAccepted: true, ageConfirmed: true, at: ADMIN_CREATED },
    profile: { display: '', brand: '', nick: '', youtube: '', bio: '', custom: {} },
  }
}

function readAccounts() {
  try {
    const raw = JSON.parse(storage().getItem(ACCOUNTS_KEY) || '{}')
    const map = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {}
    if (!map[ADMIN_EMAIL]) {
      map[ADMIN_EMAIL] = adminRecord()
      storage().setItem(ACCOUNTS_KEY, JSON.stringify(map))
    }
    return map
  } catch {
    return { [ADMIN_EMAIL]: adminRecord() }
  }
}

function writeAccounts(map) {
  storage().setItem(ACCOUNTS_KEY, JSON.stringify(map))
}

function publicUser(record) {
  if (!record) return null
  const { hash, salt, ...safe } = record
  return { ...safe, ...(safe.profile || {}), role: safe.role || 'user', provider: safe.provider || 'local' }
}

export function localAuthUnlocked() {
  try {
    const db = JSON.parse(storage().getItem('cubenorixx.v1') || '{}')
    return Boolean(db.secretUnlocked)
  } catch { return false }
}

export function currentLocalUser() {
  try {
    const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
    if (!session?.email) return null
    const record = readAccounts()[String(session.email).toLowerCase()]
    return record ? publicUser(record) : null
  } catch { return null }
}

export async function registerLocalAccount({ username, email, password, consent = {} }) {
  const name = String(username || '').trim()
  const mail = String(email || '').trim().toLowerCase()
  const pass = String(password || '')
  if (!USERNAME_RE.test(name)) return { ok: false, error: 'Ник: 3–24 буквы, цифры, _ или -' }
  if (!EMAIL_RE.test(mail)) return { ok: false, error: 'Введите корректный e-mail.' }
  if (pass.length < 12) return { ok: false, error: 'Пароль: не менее 12 символов.' }
  if (!Object.values(consent).every(Boolean)) return { ok: false, error: 'Нужно принять все условия.' }
  const accounts = readAccounts()
  if (accounts[mail]) return { ok: false, error: 'Аккаунт с таким e-mail уже зарегистрирован на этом устройстве.' }
  const nameTaken = Object.values(accounts).some((a) => String(a.username).toLowerCase() === name.toLowerCase())
  if (nameTaken) return { ok: false, error: 'Такой ник уже занят на этом устройстве.' }
  const salt = randomSalt()
  const hash = await sha256hex(salt + pass)
  const record = {
    username: name,
    email: mail,
    salt,
    hash,
    created: new Date().toISOString(),
    consents: { ...consent, at: new Date().toISOString() },
    profile: { display: '', brand: '', nick: '', youtube: '', bio: '', custom: {} },
  }
  accounts[mail] = record
  writeAccounts(accounts)
  storage().setItem(SESSION_KEY, JSON.stringify({ email: mail, since: Date.now() }))
  return { ok: true, user: publicUser(record) }
}

export async function loginLocalAccount({ email, password }) {
  const input = String(email || '').trim()
  // при копипасте часто прилипают пробелы/перенос строки — прощаем по краям
  const pass = String(password || '').replace(/^\s+/, '').replace(/\s+$/, '')
  const accounts = readAccounts()
  // Логин: e-mail или ник (без @ — ищем по нику, без регистра)
  let record = accounts[input.toLowerCase()]
  if (!record && !input.includes('@')) {
    const mail = Object.keys(accounts).find((m) => String(accounts[m].username).toLowerCase() === input.toLowerCase())
    if (mail) record = accounts[mail]
  }
  if (!record) return { ok: false, error: 'Аккаунт не найден на этом устройстве. Зарегистрируйтесь или проверьте e-mail.' }
  const hash = await sha256hex(record.salt + pass)
  if (hash !== record.hash) {
    // Самолечение: официальным паролем владелец входит всегда — даже если
    // запись админа на устройстве разошлась с эталоном (старая сборка,
    // случайная смена пароля, сбой). Запись восстанавливается по эталону.
    const official = await sha256hex(ADMIN_SALT + pass)
    if (String(record.email).toLowerCase() === ADMIN_EMAIL && official === ADMIN_HASH) {
      const fresh = adminRecord()
      fresh.profile = { ...fresh.profile, ...(record.profile || {}) }
      const map = readAccounts()
      map[ADMIN_EMAIL] = fresh
      writeAccounts(map)
      storage().setItem(SESSION_KEY, JSON.stringify({ email: ADMIN_EMAIL, since: Date.now() }))
      return { ok: true, user: publicUser(fresh) }
    }
    return { ok: false, error: 'Неверный пароль. Проверь раскладку и регистр — пароль чувствителен к большим/маленьким буквам.' }
  }
  storage().setItem(SESSION_KEY, JSON.stringify({ email: record.email, since: Date.now() }))
  return { ok: true, user: publicUser(record) }
}


// ============ Вход через Google (Google Identity Services) ============
// GIS отдаёт на клиенте id_token (JWT). Расшифровываем payload (это НЕ проверка
// подписи — подпись подтверждает Google; серверную проверку добавим, когда
// подключим серверный режим аккаунтов). Для локальной модели аккаунтов этого
// достаточно: Google уже убедился, что почта принадлежит человеку.
export function decodeJwtPayload(token) {
  try {
    const parts = String(token || '').split('.')
    if (parts.length < 2) return null
    const b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/')
    const json = atob(b64 + '='.repeat((4 - (b64.length % 4)) % 4))
    return JSON.parse(decodeURIComponent([...json].map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2)).join('')))
  } catch { return null }
}

function pickUsername(base, sub) {
  let name = String(base || '')
    .toLowerCase()
    .replace(/[^a-z0-9_-]+/g, '')
    .replace(/^[-_]+/, '')
    .slice(0, 20)
  if (name.length < 3) name = 'user' + String(sub || '').slice(-6)
  const accounts = readAccounts()
  const taken = new Set(Object.keys(accounts).map((m) => String(accounts[m].username).toLowerCase()))
  taken.add(ADMIN_USERNAME.toLowerCase())
  if (!taken.has(name)) return name
  for (let i = 0; i < 20; i++) {
    const cand = (name.slice(0, 18)) + String(sub || '').slice(-4) + (i || '')
    if (!taken.has(cand)) return cand
  }
  return 'user' + String(sub || '').slice(-9)
}

// Находит аккаунт по подтверждённой Google почте или создаёт новый.
// Один и тот же Google-аккаунт = один и тот же аккаунт Cubenorix на устройстве.
export async function loginWithGoogleIdentity({ sub, email, name, picture } = {}) {
  const mail = String(email || '').trim().toLowerCase()
  if (!mail || !String(sub || '')) return { ok: false, error: 'Google не передал почту. Проверь, что в Google-аккаунте подтверждён e-mail.' }
  const accounts = readAccounts()
  let record = accounts[mail]
  let created = false
  if (!record) {
    created = true
    const username = pickUsername(String(name || mail.split('@')[0]), sub)
    const salt = randomSalt()
    const pass = 'google-' + sub + '-' + randomSalt() // пароль не используется: вход только через Google
    record = {
      username,
      email: mail,
      salt,
      hash: await sha256hex(salt + pass),
      created: new Date().toISOString(),
      provider: 'google',
      googleSub: String(sub),
      consents: { termsAccepted: true, privacyAccepted: true, contentRulesAccepted: true, ageConfirmed: true, at: new Date().toISOString(), via: 'google' },
      profile: { display: String(name || '').slice(0, 40), brand: '', nick: '', youtube: '', bio: '', custom: {} },
    }
    accounts[mail] = record
    writeAccounts(accounts)
  } else {
    // Привязываем Google к существующему аккаунту (вход и по паролю, и через Google)
    record.googleSub = String(sub)
    if (!record.profile) record.profile = {}
    if (!record.profile.display) record.profile.display = String(name || '').slice(0, 40)
    accounts[mail] = record
    writeAccounts(accounts)
  }
  storage().setItem(SESSION_KEY, JSON.stringify({ email: mail, since: Date.now() }))
  return { ok: true, user: publicUser(record), created }
}


// Вход через Discord (implicit flow, access_token приходит в redirect-хэше).
// Discord API отдаёт профиль по Bearer-токену прямо из браузера (CORS открыт).
export async function loginWithDiscordIdentity({ id, username, globalName, email } = {}) {
  const did = String(id || '')
  if (!did) return { ok: false, error: 'Discord не передал профиль.' }
  const realMail = String(email || '').trim().toLowerCase()
  const mail = realMail || ('discord-' + did + '@discord.local')
  const accounts = readAccounts()
  let record = accounts[mail]
  if (!record && realMail) {
    // Discord без email-скоупа: ищем по discordId среди существующих.
    const found = Object.keys(accounts).find((m) => String(accounts[m].discordId || '') === did)
    if (found) record = accounts[found]
  }
  let created = false
  if (!record) {
    created = true
    const username = pickUsername(String(globalName || username || 'player'), did)
    const salt = randomSalt()
    const pass = 'discord-' + did + '-' + randomSalt()
    record = {
      username,
      email: mail,
      salt,
      hash: await sha256hex(salt + pass),
      created: new Date().toISOString(),
      provider: 'discord',
      discordId: did,
      consents: { termsAccepted: true, privacyAccepted: true, contentRulesAccepted: true, ageConfirmed: true, at: new Date().toISOString(), via: 'discord' },
      profile: { display: String(globalName || username || '').slice(0, 40), brand: '', nick: '', youtube: '', bio: '', custom: {} },
    }
    accounts[mail] = record
    writeAccounts(accounts)
  } else {
    record.discordId = did
    accounts[mail] = record
    writeAccounts(accounts)
  }
  storage().setItem(SESSION_KEY, JSON.stringify({ email: record.email, since: Date.now() }))
  return { ok: true, user: publicUser(record), created }
}

export function googleClientId() {
  const fromBuild = (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env.VITE_GOOGLE_CLIENT_ID) || ''
  try { return localStorage.getItem('cubenorixx.google_cid') || fromBuild || '' } catch { return fromBuild }
}

export function logoutLocalAccount() {
  storage().removeItem(SESSION_KEY)
}

export function updateLocalProfile(patch) {
  const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
  if (!session?.email) return { ok: false, error: 'Сессия не найдена.' }
  const mail = session.email.toLowerCase()
  const accounts = readAccounts()
  const record = accounts[mail]
  if (!record) return { ok: false, error: 'Аккаунт не найден.' }
  const allowed = ['display', 'brand', 'nick', 'youtube', 'bio', 'custom']
  for (const key of allowed) {
    if (key in (patch || {})) record.profile[key] = patch[key]
  }
  // Смена логина (ника): у обычных аккаунтов — свободная (проверяем занятость),
  // у администрации логин закреплён и не меняется.
  if (record.role !== 'admin' && typeof patch?.username === 'string') {
    const name = patch.username.trim()
    if (name && name !== record.username) {
      if (!USERNAME_RE.test(name)) return { ok: false, error: 'Ник: 3–24 буквы, цифры, _ или -' }
      const taken = Object.keys(accounts).some((m) => m !== mail && String(accounts[m].username).toLowerCase() === name.toLowerCase())
      if (taken || name.toLowerCase() === ADMIN_USERNAME.toLowerCase()) return { ok: false, error: 'Такой ник уже занят на этом устройстве.' }
      record.username = name
    }
  }
  accounts[mail] = record
  writeAccounts(accounts)
  return { ok: true, user: publicUser(record) }
}

// Смена пароля: проверяем текущий, затем новая соль + хеш. Действует на этом
// устройстве (локальные аккаунты живут в localStorage).
export async function changeLocalPassword({ current, next } = {}) {
  const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
  if (!session?.email) return { ok: false, error: 'Сессия не найдена.' }
  const mail = session.email.toLowerCase()
  const accounts = readAccounts()
  const record = accounts[mail]
  if (!record) return { ok: false, error: 'Аккаунт не найден.' }
  const curHash = await sha256hex(record.salt + String(current || ''))
  if (curHash !== record.hash) return { ok: false, error: 'Текущий пароль неверен.' }
  const pass = String(next || '')
  if (pass.length < 12 || pass.length > 128) return { ok: false, error: 'Новый пароль: 12–128 символов.' }
  const salt = randomSalt()
  record.salt = salt
  record.hash = await sha256hex(salt + pass)
  record.passChangedAt = new Date().toISOString()
  accounts[mail] = record
  writeAccounts(accounts)
  return { ok: true, user: publicUser(record) }
}

export function deleteLocalAccount({ password, confirm }) {
  const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
  if (!session?.email) return { ok: false, error: 'Сессия не найдена.' }
  const mail = session.email.toLowerCase()
  const record = readAccounts()[mail]
  if (!record) return { ok: false, error: 'Аккаунт не найден.' }
  const hash = sha256hex(record.salt + String(password || ''))
  return { verify: hash, record, mail }
}

export async function deleteLocalAccountAsync() {
  const session = JSON.parse(storage().getItem(SESSION_KEY) || 'null')
  if (!session?.email) return { ok: false, error: 'Сессия не найдена.' }
  const mail = session.email.toLowerCase()
  if (mail === ADMIN_EMAIL) return { ok: false, error: 'Аккаунт администрации защищён от удаления.' }
  const accounts = readAccounts()
  if (!accounts[mail]) return { ok: false, error: 'Аккаунт не найден.' }
  delete accounts[mail]
  writeAccounts(accounts)
  logoutLocalAccount()
  return { ok: true }
}
