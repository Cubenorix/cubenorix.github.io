/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
const cover = Object.freeze({ default: '/no-icon.png' })

function item(type, x) {
  return {
    project_type: type,
    icon_url: x.icon_url || cover[type] || cover.default,
    downloads: x.downloads || 0,
    sources: x.sources || ['modrinth'],
    ...x,
  }
}

export const MORE = {}


export function allLocal(LOCAL_CONTENT) {
  const out = { ...LOCAL_CONTENT }
  for (const [k, arr] of Object.entries(MORE)) {
    if (k === 'extra') continue
    out[k] = [...(out[k] || []), ...arr]
  }
  out.mod = [...(out.mod || []), ...(MORE.extra || [])]
  for (const list of Object.values(out)) {
    for (const x of list) {
      if (!x.icon_url) x.icon_url = cover[x.project_type] || cover.default
      if (!x.project_type) x.project_type = 'map'
    }
  }
  return out
}

export function searchLocalAll(LOCAL, q, type) {
  const query = String(q || '').toLowerCase()
  const bags = []
  if (type && type !== 'all') bags.push(...(LOCAL[type] || []))
  else {
    for (const arr of Object.values(LOCAL)) bags.push(...arr)
    bags.push(...(MORE.extra || []))
  }
  if (type === 'mod' || type === 'all' || !type) bags.push(...(MORE.extra || []))
  let list = bags
  if (query) {
    list = bags.filter((x) => (x.title + ' ' + (x.description || '') + ' ' + (x.author || '') + ' ' + (x.slug || '')).toLowerCase().includes(query))
  }
  const seen = new Set()
  return list.filter((x) => {
    if (seen.has(x.slug)) return false
    seen.add(x.slug)
    return true
  })
}
