/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { lazy, Suspense, useEffect, useState } from 'react'
import { Route, Routes, useLocation } from 'react-router-dom'
import Background from './components/Background'
import Header from './components/Header'
import Footer from './components/Footer'
import Home from './pages/Home'
import { useStore } from './store'
import { t } from './i18n'
import { SUPPORT_BOT_TELEGRAM, SUPPORT_BOT_USERNAME } from './data/community'
import ErrorBoundary from './components/ErrorBoundary'
import Gate from './components/Gate'
import Splash from './components/Splash'
import AutoTranslatePage from './components/AutoTranslatePage'

const Catalog = lazy(() => import('./pages/Catalog'))
const Project = lazy(() => import('./pages/Project'))
const Builds = lazy(() => import('./pages/Builds'))
const Top = lazy(() => import('./pages/Top'))
const Connection = lazy(() => import('./pages/Connection'))
const Add = lazy(() => import('./pages/Add'))
const Auth = lazy(() => import('./pages/Auth'))
const Profile = lazy(() => import('./pages/Profile'))
const SourcePage = lazy(() => import('./pages/Source'))
const Get = lazy(() => import('./pages/Get'))
const Reviews = lazy(() => import('./pages/Reviews'))
const Bridge = lazy(() => import('./pages/Bridge'))
const Community = lazy(() => import('./pages/Community'))
const pick = (name) => lazy(() => import('./pages/Misc').then((m) => ({ default: m[name] })))
const Servers = pick('Servers')
const Hosting = pick('Hosting')
const Guides = pick('Guides')
const GuideDetail = pick('GuideDetail')
const Generators = pick('Generators')
const Wiki = pick('Wiki')
const Forum = pick('Forum')
const Developers = pick('Developers')
const HashSearch = pick('HashSearch')
const LauncherLab = pick('LauncherLab')
const Legal = pick('Legal')

function RouteSeo() {
  const loc = useLocation()
  useEffect(() => {
    const sp = new URLSearchParams(loc.search)
    const type = sp.get('type') || ''
    const query = sp.get('q') || ''
    const category = {
      mod: 'Моды Minecraft', map: 'Карты Minecraft', shader: 'Шейдеры Minecraft',
      plugin: 'Плагины Minecraft', modpack: 'Модпаки Minecraft', resourcepack: 'Ресурспаки Minecraft',
      datapack: 'Датапаки Minecraft', skin: 'Внешность Minecraft', emote: 'Внешность Minecraft',
      appearance: 'Внешность Minecraft (скины, плащи, эмоции, модели)', cosmetic: 'Внешность Minecraft',
    }[type]
    let title = 'Моды, карты, шейдеры и плагины Minecraft — Cubenorix'
    let description = 'Скачать моды, карты, шейдеры, плагины и сборки Minecraft. Поиск проектов, версий и прямых ссылок на Cubenorix.'
    if (loc.pathname === '/catalog') {
      title = query ? `${query} — найти и скачать для Minecraft | Cubenorix` : `${category || 'Каталог проектов Minecraft'} — Cubenorix`
      description = query ? `Найти ${query} для Minecraft: версии, совместимость, зависимости и прямая ссылка на проект в Cubenorix.` : `Найти и скачать ${String(category || 'проекты Minecraft').toLowerCase()} с прямыми ссылками и проверкой версий.`
    } else if (loc.pathname.startsWith('/project/')) {
      title = 'Проект Minecraft — скачать | Cubenorix'
    } else if (loc.pathname === '/builds') {
      title = 'Сборщик модов Minecraft с настоящими JAR — Cubenorix'
      description = 'Соберите совместимый набор модов Minecraft и скачайте готовый ZIP с настоящими JAR-файлами в папке mods.'
    } else if (loc.pathname === '/servers') {
      title = 'Серверы Minecraft — описание, онлайн и технические данные | Cubenorix'
      description = 'Адреса серверов Minecraft, описания, редакции, порты, заявленные версии и живая техническая проверка онлайна без ложной верификации.'
    } else if (loc.pathname === '/launcher-lab') {
      title = 'Launcher Lab — внутренний черновик Cubenorix'
      description = 'Состояние черновых API-манифестов лаунчера Cubenorix без секретов и неподтверждённых бинарных файлов.'
    } else if (loc.pathname === '/guides') title = 'Инструкции по Minecraft — Cubenorix'
    else if (loc.pathname === '/wiki') title = 'Minecraft Wiki и помощь — Cubenorix'
    else if (loc.pathname === '/community') {
      title = 'Telegram Cubenorix — канал @Cubenorix и техподдержка'
      description = 'Официальный канал Cubenorix @Cubenorix и бот технической поддержки @Cubenorixsupportbot: поиск модов, сборки, правила и статус источников.'
    } else if (loc.pathname === '/terms') title = 'Условия использования Cubenorix'
    else if (loc.pathname === '/privacy') title = 'Политика конфиденциальности Cubenorix'
    else if (loc.pathname === '/register') title = 'Регистрация аккаунта Cubenorix'
    else if (loc.pathname === '/login') title = 'Вход в аккаунт Cubenorix'
    document.title = title
    const desc = document.querySelector('meta[name="description"]')
    if (desc) desc.setAttribute('content', description)
    const ogTitle = document.querySelector('meta[property="og:title"]')
    const ogDesc = document.querySelector('meta[property="og:description"]')
    if (ogTitle) ogTitle.setAttribute('content', title)
    if (ogDesc) ogDesc.setAttribute('content', description)
    const robots = document.querySelector('meta[name="robots"]')
    if (robots) robots.setAttribute('content', loc.pathname === '/launcher-lab'
      ? 'noindex, nofollow, noarchive'
      : 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1')
  }, [loc.pathname, loc.search])
  return null
}

function Fallback() {
  const { lang } = useStore()
  return <div className="relative z-10 pt-24 text-center text-white/45">{t(lang, 'common.loading')}</div>
}

function BetaBanner() {
  const { lang } = useStore()
  const [hidden, setHidden] = useState(() => {
    try { return sessionStorage.getItem('cubenorixx.betaBanner') === '1' } catch { return false }
  })
  if (hidden) return null
  const close = () => {
    try { sessionStorage.setItem('cubenorixx.betaBanner', '1') } catch {}
    setHidden(true)
  }
  return (
    <div className="beta-banner" role="note">
      <span className="beta-banner-badge">BETA</span>
      <span>
        {t(lang, 'beta.title')}{' '}
        <a href={SUPPORT_BOT_TELEGRAM} target="_blank" rel="noopener noreferrer">
          {t(lang, 'beta.report')} · @{SUPPORT_BOT_USERNAME}
        </a>
      </span>
      <button type="button" className="beta-banner-close" aria-label={t(lang, 'beta.close')} onClick={close}>✕</button>
    </div>
  )
}

export default function App() {
  const { toast } = useStore()
  const loc = useLocation()
  // Автономная страница лаунчера обслуживается статикой /launcher/
  useEffect(() => {
    if (loc.pathname === '/launcher' && !window.location.hash.startsWith('#/')) {
      window.location.replace('/launcher/')
    }
  }, [loc.pathname])
  return (
    <Gate>
    <div className="app-frame min-h-screen relative">
      <RouteSeo />
      <Splash />
      <AutoTranslatePage />
      <Background />
      <div className="app-col">
      <Header />
      <BetaBanner />
      <main className="pb-10 page-in" key={loc.pathname + loc.search.split('page=')[0]}>
        <ErrorBoundary resetKey={loc.pathname + loc.search}>
        <Suspense fallback={<Fallback />}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/catalog" element={<Catalog />} />
          <Route path="/project/:slug" element={<Project />} />
          <Route path="/builds" element={<Builds />} />
          <Route path="/top" element={<Top />} />
          <Route path="/servers" element={<Servers />} />
          <Route path="/hosting" element={<Hosting />} />
          <Route path="/guides" element={<Guides />} />
          <Route path="/guides/:id" element={<GuideDetail />} />
          <Route path="/generators" element={<Generators />} />
          <Route path="/wiki" element={<Wiki />} />
          <Route path="/forum" element={<Forum />} />
          <Route path="/connection" element={<Connection />} />
          <Route path="/add" element={<Add />} />
          <Route path="/login" element={<Auth mode="login" />} />
          <Route path="/register" element={<Auth mode="register" />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/developers" element={<Developers />} />
          <Route path="/hash" element={<HashSearch />} />
          <Route path="/launcher-lab" element={<LauncherLab />} />
          <Route path="/source/:id" element={<SourcePage />} />
          <Route path="/get" element={<Get />} />
          <Route path="/reviews" element={<Reviews />} />
          <Route path="/bridge" element={<Bridge />} />
          <Route path="/community" element={<Community />} />
          <Route path="/:page" element={<Legal />} />
        </Routes>
        </Suspense>
        </ErrorBoundary>
      </main>
      <Footer />
      {toast && (
        <div className="toast glass-strong px-5 py-3 shadow-glow">
          {toast.msg}
        </div>
      )}
      </div>
    </div>
    </Gate>
  )
}
