/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
const ENT = {
  amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ',
  mdash: '—', ndash: '–', hellip: '…', laquo: '«', raquo: '»',
  copy: '©', reg: '®', trade: '™', times: '×', minus: '−',
}

export function decodeEntities(raw) {
  return String(raw || '').replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (_, e) => {
    const k = String(e).toLowerCase()
    if (ENT[k]) return ENT[k]
    if (k[0] === '#') {
      const n = k[1] === 'x' ? parseInt(k.slice(2), 16) : parseInt(k.slice(1), 10)
      if (Number.isFinite(n) && n > 31 && n < 0x110000) return String.fromCodePoint(n)
    }
    return ' '
  })
}

function holdCode(s) {
  const bag = []
  const put = (m) => {
    bag.push(m)
    return `‹${bag.length - 1}›`
  }
  let out = String(s || '')
  out = out.replace(/```[\s\S]*?```/g, put)
  out = out.replace(/`[^`\n]+`/g, put)
  return { out, bag }
}

function giveHeld(s, bag) {
  return String(s || '').replace(/‹(\d+)›/g, (_, i) => bag[Number(i)] || '')
}

export function htmlToMd(raw) {
  const held = holdCode(String(raw || '').replace(/\r\n/g, '\n'))
  let s = held.out
  s = s.replace(/<style[\s\S]*?<\/style>/gi, ' ')
  s = s.replace(/<script[\s\S]*?<\/script>/gi, ' ')
  s = s.replace(/<!--[\s\S]*?-->/g, ' ')
  s = s.replace(/\[url=([^\]]+)\]([\s\S]*?)\[\/url\]/gi, '[$2]($1)')
  s = s.replace(/\[url\]([\s\S]*?)\[\/url\]/gi, '$1')
  s = s.replace(/\[img\]([\s\S]*?)\[\/img\]/gi, '![]($1)')
  s = s.replace(/\[\/?(?:b|bold)\]/gi, '**')
  s = s.replace(/\[\/?(?:i|em)\]/gi, '*')
  s = s.replace(/\[quote(?:=[^\]]*)?\]/gi, '\n> ')
  s = s.replace(/\[\/?(?:center|size|color|font|spoiler|list|code|\*|left|right|justify)(?:=[^\]]*)?\]/gi, '\n')
  s = s.replace(/<br\s*\/?>/gi, '\n')
  s = s.replace(/<\/(p|div|h[1-6]|li|tr|blockquote|section|article|header|footer|table)>/gi, '\n\n')
  s = s.replace(/<h([1-6])[^>]*>/gi, (_, n) => '\n' + '#'.repeat(Number(n)) + ' ')
  s = s.replace(/<li[^>]*>/gi, '\n- ')
  s = s.replace(/<img[^>]*src=["']([^"']+)["'][^>]*>/gi, '\n![]($1)\n')
  s = s.replace(/<a[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi, (_, href, t) => {
    const label = String(t).replace(/<[^>]+>/g, '').trim() || href
    return `[${label}](${href})`
  })
  s = s.replace(/<\/?(?:b|strong)[^>]*>/gi, '**')
  s = s.replace(/<\/?(?:i|em)[^>]*>/gi, '*')
  s = s.replace(/<hr\s*\/?>/gi, '\n---\n')
  s = s.replace(/<(?:center|font|span|div|p|section|article|table|tbody|thead|tr|td|th|ul|ol|blockquote)[^>]*>/gi, '\n')
  s = s.replace(/<[^>]+>/g, ' ')
  s = decodeEntities(s)
  s = s.replace(/<\/?[a-zA-Z][^>\n]{0,120}>/g, ' ')
  s = s.replace(/\[\/[a-z*][a-z0-9=_#:-]{0,24}\]/gi, ' ')
  s = s.replace(/\[(?:center|size|color|font|spoiler|list|code|quote|img|url|b|i|u|s|\*)(?:=[^\]]*)?\]/gi, ' ')
  s = s.replace(/[<>]{1,}/g, ' ')
  s = s.replace(/[ \t]+\n/g, '\n')
  s = s.replace(/\n{3,}/g, '\n\n')
  s = s.replace(/[ \t]{2,}/g, ' ')
  return giveHeld(s, held.bag).trim()
}

export function plainPreview(raw, max = 280) {
  return htmlToMd(raw)
    .replace(/!\[[^\]]*\]\([^)]+\)/g, ' ')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/[#*_`>]/g, '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max)
}

export function holdProtect(raw) {
  const bag = []
  const put = (m) => {
    bag.push(m)
    return `‹${bag.length - 1}›`
  }
  let out = String(raw || '')
  out = out.replace(/https?:\/\/[^\s)\]>'"]+/g, put)
  out = out.replace(/```[\s\S]*?```/g, put)
  out = out.replace(/`[^`\n]+`/g, put)
  out = out.replace(/!\[[^\]]*\]\([^)]+\)/g, put)
  return { out, bag }
}

export function giveProtect(s, bag) {
  return String(s || '').replace(/‹(\d+)›/g, (_, i) => bag[Number(i)] || '')
}
