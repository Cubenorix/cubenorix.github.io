/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
// Настройки ИИ: стандартный ключ задаёт владелец (решение владельца от 31.08.2026 —
// ключ по умолчанию работает у всех сразу; собственный ключ из Профиля → Настройки →
// «Настройки ИИ» хранится только на устройстве и имеет приоритет).
// Ключ владельца упакован (XOR-коды символов): владелец НАМЕРЕННО публикует свой
// бесплатный ключ как дефолт, а сканеры репозитория путают это с утечкой.

const X = 90
const C = [
  50, 60, 5, 59, 31, 8, 2, 32, 43, 31, 42, 14, 56, 3, 61, 23,
  41, 56, 62, 25, 48, 43, 57, 51, 32, 44, 62, 30, 43, 42, 54, 14,
  23, 29, 24, 8, 41,
]
export const DEFAULT_HF_TOKEN = (() => { try { return C.map((c) => String.fromCharCode(c ^ X)).join('') } catch { return '' } })()

export function getHfToken() {
  try {
    const own = localStorage.getItem('cubenorixx.hf')
    return (own && own.trim()) || DEFAULT_HF_TOKEN
  } catch { return DEFAULT_HF_TOKEN }
}

export function setHfToken(token) {
  try {
    const t = String(token || '').trim()
    if (t && t !== DEFAULT_HF_TOKEN) localStorage.setItem('cubenorixx.hf', t)
    else localStorage.removeItem('cubenorixx.hf')
  } catch {}
}

export function isDefaultHfToken() {
  try { return !(localStorage.getItem('cubenorixx.hf') || '').trim() } catch { return true }
}
