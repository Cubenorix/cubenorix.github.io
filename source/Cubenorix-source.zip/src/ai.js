/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
// Настройки ИИ. Стандартный ключ — решение владельца (31.08.2026): ИИ работает
// у всех сразу. Ключ хранится упакованно (числовые коды), собирается на лету и
// ТОЛЬКО на разрешённых доменах сайта. Открытым текстом его в коде и в сети нет.
// Защита от расхода лимита: суточная/часовая квота на устройстве; свой ключ
// из Профиля → Настройки → «Настройки ИИ» работает без наших квот.
// Честное ограничение: тот, кто целенапременно достаёт ключ из сетевых запросов,
// обойдёт любую клиентскую защиту — полная защита появится вместе с серверным
// режимом (ключ будет жить только на сервере).

const K = [60, 17, 126, 41, 84, 13, 102, 27, 72, 35, 95, 8, 113, 54, 9, 98]
const X = [
  84, 119, 33, 72, 17, 95, 62, 97, 57, 102, 47, 92,
  19, 111, 110, 47, 79, 115, 26, 106, 62, 124, 5, 114,
  50, 85, 59, 76, 0, 70, 101, 54, 113, 86, 60, 123,
  39,
]
export const DEFAULT_HF_TOKEN = (() => {
  try {
    let s = ''
    for (let i = 0; i < X.length; i++) s += String.fromCharCode(X[i] ^ K[i % K.length])
    return s
  } catch { return '' }
})()

// ИИ-функции — только на доменах Cubenorix (на чужих сайтах наш бандл молчит).
export function aiAllowed() {
  try {
    const h = String((typeof location !== 'undefined' && location.hostname) || '')
    return /(^|\.)cubenorix\.github\.io$|^(localhost|127\.0\.0\.1)$/.test(h)
  } catch { return false }
}

export function hasOwnKey() {
  try { return Boolean((localStorage.getItem('cubenorixx.hf') || '').trim()) } catch { return false }
}

export function getHfToken() {
  if (!aiAllowed()) return ''
  try {
    const own = (localStorage.getItem('cubenorixx.hf') || '').trim()
    if (own) return own
  } catch {}
  return DEFAULT_HF_TOKEN
}

export function setHfToken(token) {
  try {
    const t = String(token || '').trim()
    if (t && t !== DEFAULT_HF_TOKEN) localStorage.setItem('cubenorixx.hf', t)
    else localStorage.removeItem('cubenorixx.hf')
  } catch {}
}

export function isDefaultHfToken() { return !hasOwnKey() }

// ===== Квоты стандартного ключа (свой ключ не ограничен) =====
const QKEY = 'cubenorixx.ai.q'
export const AI_DAY_LIMIT = 30
export const AI_HOUR_LIMIT = 10

function qLoad() {
  try {
    const q = JSON.parse(localStorage.getItem(QKEY) || 'null') || {}
    const day = String(new Date().toISOString().slice(0, 10))
    if (q.d !== day) return { d: day, n: 0, h: [] }
    return { d: day, n: Number(q.n) || 0, h: Array.isArray(q.h) ? q.h.filter((t) => Date.now() - t < 3600000) : [] }
  } catch { return { d: String(new Date().toISOString().slice(0, 10)), n: 0, h: [] } }
}

function qSave(q) {
  try { localStorage.setItem(QKEY, JSON.stringify(q)) } catch {}
}

export function aiQuota() {
  if (hasOwnKey()) return { own: true, dayUsed: 0, dayLeft: Infinity, hourUsed: 0, hourLeft: Infinity }
  const q = qLoad()
  return { own: false, dayUsed: q.n, dayLeft: Math.max(0, AI_DAY_LIMIT - q.n), hourUsed: q.h.length, hourLeft: Math.max(0, AI_HOUR_LIMIT - q.h.length) }
}

export function aiCan(n = 1) {
  if (hasOwnKey()) return true
  const q = aiQuota()
  return q.dayLeft >= n && q.hourLeft >= n
}

export function aiSpend(n = 1) {
  if (hasOwnKey()) return true
  if (!aiCan(n)) return false
  const q = qLoad()
  q.n += n
  q.h.push(Date.now())
  qSave(q)
  return true
}
