// E2E: локальные проекты — скачивание ведёт на площадку автора (без тупика CDN); капча не мешает на localhost
import { chromium } from 'playwright'
const BASE = 'http://127.0.0.1:5174'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const ctx = await b.newContext({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
const p = await ctx.newPage()
const errs = []; p.on('pageerror', (e) => errs.push(String(e)))
await ctx.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    db.uploads = [{ id: 't1', title: 'AFK_Use-Jubik', description: 'АФК-мод', status: 'accepted', user: 'qwe8', display: 'qwe8', github: 'https://github.com/khlsha-web/AFK_Use-Jubik', versions: ['1.21.5'], loaders: ['fabric'], type: 'mod', downloads: 12, likes: 0, comments: [] }]
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})

// 1) Страница локального проекта: нет тупика, панель ведёт на GitHub
await p.goto(BASE + '/project/afk-use-jubik', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(4500)
const txt = await p.evaluate(() => document.body.innerText)
ok('нет текста «Файла на CDN нет»', !txt.includes('Файла на CDN нет'))
ok('вкладка «Версии» не рисуется (нет тупика)', !txt.includes('Версии') || await p.locator('button:has-text("Версии")').count() === 0)
const panelBtn = p.locator('.dl-panel button, .dl-panel a').first()
ok('панель скачивания есть', await panelBtn.count() > 0)
const [popup] = await Promise.all([p.waitForEvent('popup', { timeout: 15000 }).catch(() => null), panelBtn.click()])
ok('скачивание открывает GitHub автора в новой вкладке', popup != null && String(popup.url()).includes('github.com/khlsha-web'))
if (popup) await popup.close()
ok('бейдж «Источник ↗» на странице', await p.locator('a:has-text("Источник")').count() > 0)

// 2) Капча на localhost не блокирует (авто-обход) — свежая страница
const p2 = await ctx.newPage()
p2.on('pageerror', (e) => errs.push(String(e)))
await p2.goto(BASE + '/', { waitUntil: 'domcontentloaded' })
await p2.waitForTimeout(3000)
await p2.locator('button:has-text("Войти"), a:has-text("Войти")').first().click()
await p2.waitForTimeout(2000)
const rb = p2.locator('.region-locked-title')
if (await rb.count()) { await rb.click(); await p2.waitForTimeout(1000)
  { const ob = p2.locator('.region-open-btn'); if (await ob.count()) { await ob.click(); await p2.waitForTimeout(1200) } } }
const capVisible = await p2.locator('.g-recaptcha, iframe[src*="recaptcha"]').count()
const submitEnabled = await p2.locator('form button.btn-primary').isEnabled().catch(() => false)
ok('капча на localhost скрыта/не мешает, кнопка активна', capVisible === 0 && submitEnabled)
await p2.locator('input[type="text"]').fill('Cubenorix')
await p2.locator('input[type="password"]').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await p2.locator('form button.btn-primary').click()
await p2.waitForTimeout(3000)
ok('вход сработал без капчи на localhost', p2.url().includes('profile'))

ok('0 JS-ошибок', errs.length === 0)
if (errs.length) console.log(errs.slice(0, 3))
await b.close()
