/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { LANGUAGE_META, localeOf, isRTL, detectLanguage } from '../src/languages.js'
import { SERVERS, SOURCES } from '../src/data.js'
import { isBundledTranslation, toMorse } from '../src/i18n.js'
import { aggSearch } from '../agg-middleware.js'
import { existsSync, readFileSync } from 'node:fs'
import { SPEMOTES_PACKS, searchSpemotes } from '../src/spemotes.js'
import { fetchArchiveBlob, getLiveCatalogStats, rankHits, searchAllLiveProjects } from '../src/api.js'
import { PASSWORD_ITERATIONS, hashPassword, validateRegistration, verifyPassword } from '../functions/_auth.js'
import { normalizeProjectQuery } from '../src/search-aliases.js'
import {
  MAX_PACK_CONCURRENCY,
  MAX_PACK_ITEMS,
  mapLimit,
  parseBuildSpec,
  parseCrash,
  parseParts,
  splitTasks,
} from '../src/packfix.js'

test('all requested interface languages are registered and visible', () => {
  assert.equal(LANGUAGE_META.length, 64)
  assert.equal(new Set(LANGUAGE_META.map((x) => x.id)).size, 64)
  assert.equal(LANGUAGE_META.every((x) => typeof x.flag === 'string' && x.flag.length > 0), true)
  assert.equal(LANGUAGE_META.find((x) => x.id === 'gc')?.flag, '🌌')
  assert.equal(LANGUAGE_META.find((x) => x.id === 'morse')?.flag, '🔊')
  assert.equal(localeOf('pt-br'), 'pt-BR')
  assert.equal(isRTL('ar'), true)
  assert.equal(isBundledTranslation('pl', 'Strona główna'), true)
  assert.equal(detectLanguage({ languages: ['uk-UA'], country: 'RU' }), 'ua')
  assert.equal(detectLanguage({ languages: ['xx-ZZ'], country: 'RU' }), 'ru')
  assert.equal(detectLanguage({ languages: [], country: 'BR' }), 'pt-br')
})

test('common Russian and Latin mod misspellings resolve to canonical projects', () => {
  assert.equal(normalizeProjectQuery('мод крейд скачать'), 'create')
  assert.equal(normalizeProjectQuery('Криэйт мод для майнкрафт'), 'create')
  assert.equal(normalizeProjectQuery('соудим мод'), 'sodium')
  assert.equal(normalizeProjectQuery('Содиум для Minecraft'), 'sodium')
  assert.equal(normalizeProjectQuery('wood crate'), 'wood crate')
  const ranked = rankHits([
    { title: 'Create Factory Alpha', downloads: 900 },
    { title: 'Create', downloads: 10 },
    { title: 'Recreate', downloads: 5000 },
  ], 'create')
  assert.equal(ranked[0].title, 'Create')
})

test('server registration requires versioned legal consent and strong input', () => {
  const valid = validateRegistration({
    email: 'Player@Example.com', username: 'Player_2026', password: 'correct horse battery staple',
    termsAccepted: true, privacyAccepted: true, contentRulesAccepted: true, ageConfirmed: true,
  })
  assert.equal(valid.ok, true)
  assert.equal(valid.email, 'player@example.com')
  const invalid = validateRegistration({ email: 'bad', username: 'x', password: 'short' })
  assert.equal(invalid.ok, false)
  for (const field of ['email', 'username', 'password', 'terms', 'privacy', 'contentRules', 'age']) assert.equal(invalid.errors.includes(field), true)
})

test('password hashing is salted, peppered and verifiable without storing plaintext', async () => {
  const password = 'a long unique passphrase'
  const pepper = 'server-only-pepper-that-is-at-least-32-bytes'
  const first = await hashPassword(password, undefined, PASSWORD_ITERATIONS, pepper)
  const second = await hashPassword(password, undefined, PASSWORD_ITERATIONS, pepper)
  assert.equal(first.iterations, PASSWORD_ITERATIONS)
  assert.notEqual(first.salt, second.salt)
  assert.notEqual(first.hash, second.hash)
  assert.equal(first.hash.includes(password), false)
  assert.equal(await verifyPassword(password, first, pepper), true)
  assert.equal(await verifyPassword('wrong password', first, pepper), false)
})

test('all ordinary languages have a bundled genuine SVG flag', () => {
  const ordinary = LANGUAGE_META.filter((x) => !x.special)
  assert.equal(ordinary.length, 62)
  for (const row of ordinary) {
    const region = row.locale.split('-').at(-1).toLowerCase()
    assert.equal(existsSync(new URL(`../public/flags/${region}.svg`, import.meta.url)), true, `${row.id}: ${region}`)
  }
})

test('SPEMOTES exposes all 26 original pack records without bundling payloads', () => {
  assert.equal(SPEMOTES_PACKS.length, 26)
  assert.equal(new Set(SPEMOTES_PACKS.map((x) => x.url)).size, 26)
  assert.equal(SPEMOTES_PACKS.every((x) => x.external && x.sources.includes('spemotes') && x.url.startsWith('https://drive.google.com/file/d/')), true)
  assert.equal(searchSpemotes('New Year').length, 3)
})

test('SEO exposes the requested title, square logo and direct Create project page', () => {
  const index = readFileSync(new URL('../index.html', import.meta.url), 'utf8')
  const sitemap = readFileSync(new URL('../public/sitemap.xml', import.meta.url), 'utf8')
  const create = readFileSync(new URL('../public/projects/create/index.html', import.meta.url), 'utf8')
  assert.match(index, /<title>Моды, карты, шейдеры и плагины Minecraft — Cubenorix<\/title>/)
  assert.match(index, /application\/ld\+json/)
  assert.match(index, /logo-512\.png/)
  assert.match(index, /https:\/\/t\.me\/Cubenorix/)
  assert.match(sitemap, /https:\/\/cubenorixx\.romantic-buffalo\.workers\.dev\/official\//)
  assert.match(sitemap, /https:\/\/cubenorixx\.romantic-buffalo\.workers\.dev\/how\//)
  assert.match(sitemap, /https:\/\/cubenorixx\.romantic-buffalo\.workers\.dev\/projects\/create\//)
  assert.equal((sitemap.match(/<url>/g) || []).length >= 250, true)
  assert.match(index, /href="\/projects\/create\/"/)
  assert.match(create, /<title>Create для Minecraft — версии и загрузка \| Cubenorix<\/title>/)
  assert.match(create, /BreadcrumbList/)
  assert.match(create, /Криэйт/)
  assert.match(create, /href="\/#\/project\/create"/)
  assert.match(create, /href="https:\/\/modrinth\.com\/mod\/create\/versions"/)
})

test('launcher API is truthful, secret-free and disabled until real signed assets exist', () => {
  const readJson = (name) => JSON.parse(readFileSync(new URL(`../public/api/${name}`, import.meta.url), 'utf8'))
  const update = readJson('launcher-update.json')
  const versions = readJson('mc-versions.json')
  const packs = readJson('modpacks.json')
  const java = readJson('java-runtimes.json')
  const featured = readJson('featured-mods.json')
  assert.equal(update.enabled, false)
  assert.equal(update.download_url_windows, null)
  assert.equal(update.download_url_mac, null)
  assert.equal(java.enabled, false)
  assert.deepEqual(packs, [])
  assert.deepEqual(featured, ['sodium', 'lithium', 'iris', 'jei', 'create'])
  assert.equal(versions.versions.length >= 20, true)
  assert.equal(versions.versions.every((row) => row.url.startsWith('https://piston-meta.mojang.com/') && Number(row.java_version) > 0), true)
  const text = [update, versions, packs, java, featured].map(JSON.stringify).join('\n')
  assert.doesNotMatch(text, /\b\d{6,}:[A-Za-z0-9_-]{25,}\b|\bhf_[A-Za-z0-9]{20,}\b/)
})

test('server catalogue includes descriptions and technical metadata without treating status as endorsement', () => {
  assert.equal(SERVERS.length >= 9, true)
  assert.equal(SERVERS.every((server) => server.ip && server.type && server.version && server.edition && server.description && server.features?.length), true)
  assert.equal(SERVERS[0].bedrock, 'mc.7cubes.ru:19132')
})

test('no license is claimed yet and corresponding source is offered', () => {
  const index = readFileSync(new URL('../index.html', import.meta.url), 'utf8')
  const sourcePage = readFileSync(new URL('../public/source-code.html', import.meta.url), 'utf8')
  assert.match(sourcePage, /source\/Cubenorix-source\.zip/)
  assert.equal(/AGPL/.test(index), false, 'index.html must not claim AGPL')
  assert.equal(/AGPL/.test(sourcePage), false, 'source page must not claim AGPL')
})

test('expanded source registry is unique and includes safe requested adapters', () => {
  assert.equal(SOURCES.length, 67)
  assert.equal(new Set(SOURCES.map((x) => x.id)).size, SOURCES.length)
  assert.equal(SOURCES.every((x) => x.url && x.name && x.live), true)
  for (const id of ['modrinth', 'hangar', 'spigot', 'poggit', 'polymart', 'builtbybit', 'sponge', 'smithed', 'modpackindex', 'blockbench', 'misode', 'velocity', 'folia', 'powernukkitx', 'emotecraft', 'novaskin', 'minecraftcapes', 'mcdoctor', 'mcvalidator', 'virustotal', 'spemotes']) {
    assert.equal(SOURCES.some((x) => x.id === id), true, id)
  }
})

test('builder parses aliases and strict version pins', () => {
  const parts = parseParts('crate 1.3 + jeu 93.14 + sodiom 4.6.2')
  assert.deepEqual(parts.map(({ q, pin }) => [q, pin]), [
    ['create', '1.3'],
    ['jei', '93.14'],
    ['sodium', '4.6.2'],
  ])
})

test('hash mode enables at most twelve concurrent tasks', () => {
  const fast = parseBuildSpec('# create + jei + sodium')
  assert.equal(fast.parallel, true)
  assert.equal(fast.concurrency, MAX_PACK_CONCURRENCY)
  const safe = parseBuildSpec('create + jei + sodium')
  assert.equal(safe.parallel, false)
  assert.equal(safe.concurrency, 1)
})

test('forty hash-mode items are visibly split across twelve bounded tasks', () => {
  const tasks = splitTasks(40)
  assert.equal(tasks.length, 12)
  assert.equal(tasks.reduce((sum, x) => sum + x.total, 0), 40)
  assert.deepEqual(tasks.map((x) => x.total), [4, 4, 4, 4, 3, 3, 3, 3, 3, 3, 3, 3])
  assert.equal(tasks[0].from, 1)
  assert.equal(tasks.at(-1).to, 40)
})

test('crash parser identifies exact dependency ranges and repair clues', () => {
  const parsed = parseCrash(`Minecraft Version: 1.21.1\nFabric Loader: 0.16.10\nMod 'Create Addon' (createaddon) 1.0 requires version 0.6.13 or later of mod 'Sodium' (sodium), which is missing!\njava.lang.NoClassDefFoundError: dev/architectury/Platform\nOutOfMemoryError: Java heap space`)
  assert.equal(parsed.game, '1.21.1')
  assert.equal(parsed.loader, 'fabric')
  assert.equal(parsed.loaderVer, '0.16.10')
  assert.equal(parsed.missing.some((x) => x.id === 'sodium' && x.range.includes('0.6.13')), true)
  assert.equal(parsed.issues.some((x) => x.kind === 'class'), true)
  assert.equal(parsed.issues.some((x) => x.kind === 'memory'), true)
})

test('builder deduplicates and caps a pack at 200 entries', () => {
  const input = Array.from({ length: MAX_PACK_ITEMS + 8 }, (_, i) => `mod-${i}`).join(' + ')
  const spec = parseBuildSpec(input)
  assert.equal(spec.parts.length, MAX_PACK_ITEMS)
  assert.equal(spec.truncated, true)
  assert.equal(parseParts('create + crate + create').length, 1)
})

test('mapLimit preserves order and never exceeds the cap', async () => {
  let active = 0
  let peak = 0
  const out = await mapLimit(Array.from({ length: 40 }, (_, i) => i), 12, async (n) => {
    active += 1
    peak = Math.max(peak, active)
    await new Promise((resolve) => setTimeout(resolve, 2))
    active -= 1
    return n * 2
  })
  assert.equal(peak <= 12, true)
  assert.deepEqual(out, Array.from({ length: 40 }, (_, i) => i * 2))
})

test('Morse interface transform is deterministic', () => {
  assert.equal(toMorse('SOS 2'), '... --- ... / ..---')
})

test('live catalogue count exceeds 200k using real source records and exposes a mixed page', { concurrency: false }, async () => {
  const originalFetch = globalThis.fetch
  try {
    globalThis.fetch = async (input) => {
      const url = String(input)
      if (url === '/api/live') return new Response('<!doctype html>', { headers: { 'content-type': 'text/html' } })
      if (url.includes('api.modrinth.com/v2/search')) {
        const u = new URL(url)
        const limit = Number(u.searchParams.get('limit') || 1)
        const offset = Number(u.searchParams.get('offset') || 0)
        const hits = Array.from({ length: limit }, (_, i) => ({ slug: `mr-${offset + i}`, title: `MR ${offset + i}`, project_type: 'mod' }))
        return Response.json({ total_hits: 152232, hits })
      }
      if (url.includes('api.spiget.org')) {
        const u = new URL(url)
        const size = Number(u.searchParams.get('size') || 1)
        const rows = size === 1 ? [] : Array.from({ length: size }, (_, i) => ({ id: i + 1, name: `Spigot ${i + 1}`, tag: 'plugin', downloads: 10 }))
        return new Response(JSON.stringify(rows), { headers: { 'content-type': 'application/json', 'x-page-count': '90519' } })
      }
      if (url.includes('hangar.papermc.io')) {
        const u = new URL(url)
        const limit = Number(u.searchParams.get('limit') || 1)
        const rows = Array.from({ length: limit }, (_, i) => ({ name: `Hangar ${i + 1}`, namespace: { owner: 'team', slug: `hangar-${i + 1}` }, stats: { downloads: 5 } }))
        return Response.json({ pagination: { count: 3684 }, result: rows })
      }
      throw new Error('unexpected URL ' + url)
    }
    const stats = await getLiveCatalogStats()
    assert.equal(stats.total, 246435)
    assert.deepEqual(stats.by, { modrinth: 152232, spigot: 90519, hangar: 3684 })
    const page = await searchAllLiveProjects({ limit: 100, offset: 0 })
    assert.equal(page.total_hits, 246435)
    assert.equal(page.hits.length, 100)
    assert.equal(page.hits.some((x) => x.sources?.includes('spigot')), true)
    assert.equal(page.hits.some((x) => x.sources?.includes('hangar')), true)
  } finally {
    globalThis.fetch = originalFetch
  }
})

test('pack download accepts real JAR bytes and rejects static-host HTML', { concurrency: false }, async () => {
  const originalFetch = globalThis.fetch
  const calls = []
  try {
    globalThis.fetch = async (url) => {
      calls.push(String(url))
      return new Response(Uint8Array.from([0x50, 0x4b, 0x03, 0x04, 1, 2, 3, 4]), {
        headers: { 'content-type': 'application/java-archive', 'content-length': '8' },
      })
    }
    const blob = await fetchArchiveBlob({ url: 'https://cdn.modrinth.com/data/test/test.jar', filename: 'test.jar' })
    assert.equal(blob.size, 8)
    assert.equal(calls[0].startsWith('https://cdn.modrinth.com/'), true)

    globalThis.fetch = async () => new Response('<!doctype html><title>Cubenorix</title>', {
      headers: { 'content-type': 'text/html' },
    })
    await assert.rejects(
      fetchArchiveBlob({ url: 'https://cdn.modrinth.com/data/test/broken.jar', filename: 'broken.jar' }),
      /not a binary file|not a JAR\/ZIP archive/,
    )
  } finally {
    globalThis.fetch = originalFetch
  }
})

test('catalogue relay bounds and coalesces source fan-out', { concurrency: false }, async () => {
  const originalFetch = globalThis.fetch
  const calls = []
  globalThis.fetch = async (url) => {
    calls.push(String(url))
    if (String(url).includes('api.spiget.org')) return new Response('[]', { headers: { 'content-type': 'application/json' } })
    return new Response('{}', { headers: { 'content-type': 'application/json' } })
  }
  try {
    const query = 'bounded-relay-' + Date.now()
    const [a, b] = await Promise.all([
      aggSearch({ q: query, type: 'plugin', limit: 20 }),
      aggSearch({ q: query, type: 'plugin', limit: 20 }),
    ])
    assert.equal(calls.length <= 5, true, `unexpected fan-out: ${calls.length}`)
    assert.deepEqual(a.hits, [])
    assert.deepEqual(b.hits, [])
  } finally {
    globalThis.fetch = originalFetch
  }
})
