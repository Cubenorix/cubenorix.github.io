/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
// СТРОГИЙ выбор версии: чужой лоадер и чужой MC больше не подсовываются.
import test from 'node:test'
import assert from 'node:assert/strict'
import { pickVer } from '../src/packfix.js'

const V = (vn, games, loaders) => ({ version_number: vn, game_versions: games, loaders })

test('точное совпадение выбирается первым', () => {
  const vers = [V('2.0.0', ['1.21.1'], ['fabric']), V('1.0.0', ['1.21.5'], ['fabric'])]
  assert.equal(pickVer(vers, '1.21.5', 'fabric')?.version_number, '1.0.0')
})

test('нет для 1.21.5 fabric — НЕ даёт forge 1.12.2 (главный баг)', () => {
  const vers = [V('9.9.9', ['1.12.2'], ['forge']), V('0.1.0', ['1.16.5'], ['forge'])]
  assert.equal(pickVer(vers, '1.21.5', 'fabric'), null)
})

test('нет точной MC, но есть та же линейка (1.21.x) — берём её', () => {
  const vers = [V('1.4.0', ['1.21.1'], ['fabric'])]
  assert.equal(pickVer(vers, '1.21.5', 'fabric')?.version_number, '1.4.0')
})

test('закреплённая версия строго по номеру', () => {
  const vers = [V('1.0.0', ['1.21.5'], ['fabric']), V('2.0.0', ['1.21.5'], ['fabric'])]
  assert.equal(pickVer(vers, '1.21.5', 'fabric', '2.0.0')?.version_number, '2.0.0')
  assert.equal(pickVer(vers, '1.21.5', 'fabric', '9.9.9'), null)
})

test('ресурспаки без лоадеров ищутся по MC-версии', () => {
  const vers = [V('p2', ['1.20.1'], []), V('p1', ['1.21.5'], [])]
  assert.equal(pickVer(vers, '1.21.5', 'fabric')?.version_number, 'p1')
})

test('пустой список безопасен', () => {
  assert.equal(pickVer([], '1.21.5', 'fabric'), null)
})
