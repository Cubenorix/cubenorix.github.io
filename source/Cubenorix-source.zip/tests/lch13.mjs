// E2E: сохранение сборки, группы, ZIP-папки, шейдер→Iris, ИИ-подбор
import { chromium } from 'playwright'
import JSZip from 'jszip'
import fs from 'fs'
const BASE = 'http://127.0.0.1:5174'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch(); const p = await b.newPage({ acceptDownloads: true })
const errs = []; p.on('pageerror', e => errs.push(String(e)))
await p.addInitScript(() => { try { const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}'); db.lang = 'ru'; localStorage.setItem('cubenorixx.v1', JSON.stringify(db)) } catch {} })

await p.goto(BASE + '/builds', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2500)
await p.locator('select').nth(1).selectOption('1.21.5')
const lv = await p.locator('select').nth(2).inputValue()
if (lv !== 'fabric') await p.locator('select').nth(2).selectOption('fabric')

// 1. Добавляем sodium через встроенный каталог
await p.locator('input[placeholder*="sodium, create"]').fill('sodium')
await p.locator('button:has-text("Найти")').last().click()
await p.waitForTimeout(5000)
await p.locator('button[title*="Добавить под"]').first().click({ force: true })
await p.waitForTimeout(4000)

// 2. Переход на другую страницу и обратно — сборка жива
await p.goto(BASE + '/catalog', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2500)
await p.goto(BASE + '/builds', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
const itemsAfter = await p.locator('div.glass.p-3.flex.items-center.gap-3').count()
ok('сборка пережила переход между страницами', itemsAfter >= 1)
await p.reload({ waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3500)
const itemsReload = await p.locator('div.glass.p-3.flex.items-center.gap-3').count()
ok('сборка пережила перезагрузку страницы', itemsReload >= 1)
ok('заголовок группы «Моды»', await p.getByText('Моды', { exact: true }).count() > 0)

// 3. Шейдер → Iris автоматически
await p.locator('select').first().selectOption('shader')
await p.locator('input[placeholder*="sodium, create"]').fill('complementary')
await p.locator('button:has-text("Найти")').last().click()
await p.waitForTimeout(5000)
await p.locator('button[title*="Добавить под"]').first().click({ force: true })
await p.waitForTimeout(6000)
await p.waitForTimeout(1000)
const rowsText = await p.locator('div.glass.p-3.flex.items-center.gap-3').allInnerTexts().catch(() => [])
ok('ядро шейдеров добавлено автоматически (Iris в списке)', rowsText.some((t) => /[Ii]ris/.test(t)))
const totalItems = await p.locator('div.glass.p-3.flex.items-center.gap-3').count()
ok('в сборке теперь моды + шейдер + ядро (>=3)', totalItems >= 3)
ok('группа «Шейдеры» появилась', await p.getByText('Шейдеры', { exact: true }).count() > 0)

// 4. ZIP: папки по типам + config
const dl = p.waitForEvent('download', { timeout: 120000 })
await p.locator('button:has-text("Скачать ZIP")').click()
try {
  const download = await dl
  const zip = await JSZip.loadAsync(await fs.promises.readFile(await download.path()))
  const names = Object.keys(zip.files)
  ok('config/README.txt в архиве', names.some((n) => n === 'config/README.txt'))
  ok('mods/ в архиве', names.some((n) => n.startsWith('mods/') && n.endsWith('.jar')))
  ok('shaderpacks/ в архиве', names.some((n) => n.startsWith('shaderpacks/')))
  console.log('   структура:', names.filter((n) => n.includes('/')).slice(0, 8).join(', '))
} catch (e) { ok('ZIP скачался: ' + String(e).slice(0, 80), false) }

// 5. ИИ-подбор: без токена — честная подсказка
await p.locator('input[placeholder*="ИИ-подбор"]').fill('военная сборка')
await p.locator('form button:has-text("Подобрать")').last().click()
await p.waitForTimeout(1500)
ok('ИИ-подбор без токена даёт подсказку', await p.getByText('нужен HF-токен').count() > 0)

ok('0 JS-ошибок', errs.length === 0)
if (errs.length) console.log(errs.slice(0, 3))
await b.close()
