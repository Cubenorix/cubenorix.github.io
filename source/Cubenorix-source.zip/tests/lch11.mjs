// E2E: каталог внутри сборщика, код сборки, «Новое за сегодня», чистка эмодзи
import { chromium } from 'playwright'
const BASE = 'http://127.0.0.1:5174'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch(); const p = await b.newPage()
const errs = []; p.on('pageerror', e => errs.push(String(e)))
await p.addInitScript(() => { try { const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}'); db.lang = 'ru'; localStorage.setItem('cubenorixx.v1', JSON.stringify(db)) } catch {} })

// 1. Каталог внутри сборщика
await p.goto(BASE + '/builds', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2500)
ok('блок «Каталог — прямо здесь»', await p.getByText('Каталог — прямо здесь').count() > 0)
await p.locator('select').nth(1).selectOption('1.21.5')
const lv = await p.locator('select').nth(2).inputValue()
if (lv !== 'fabric') await p.locator('select').nth(2).selectOption('fabric')
await p.locator('input[placeholder*="sodium, create"]').fill('sodium')
await p.locator('button:has-text("Найти")').last().click()
await p.waitForTimeout(5000)
const plus = p.locator('button[title*="Добавить под 1.21.5 / fabric"]').first()
ok('кнопка «+» в каталоге сборщика', await plus.count() > 0)
if (await plus.count()) {
  await plus.click({ force: true })
  await p.waitForTimeout(4000)
  const items = await p.locator('button:has-text("✕")').count()
  ok('мод добавился в список сборки', items > 0)
  const name1 = await p.locator('input.field.max-w-xs').inputValue().catch(() => '')
  // 2. Код сборки
  await p.locator('button:has-text("Код сборки")').click()
  await p.waitForTimeout(400)
  const name2 = await p.locator('input.field.max-w-xs').inputValue().catch(() => '')
  ok('код сборки сгенерирован: ' + name2, /^Cubenorix_x[\w]{6}$/.test(name2))
  await p.locator('button:has-text("Код сборки")').click()
  const name3 = await p.locator('input.field.max-w-xs').inputValue()
  ok('код детерминирован (дважды = одинаково)', name2 === name3)
}

// 3. Русификатор (кнопка есть; без jar скажет честно)
const rusBtn = p.locator('button:has-text("Русификатор (RU)")')
ok('кнопка «Русификатор (RU)»', await rusBtn.count() > 0)

// 4. «Новое за сегодня»
await p.goto(BASE + '/catalog', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3500)
ok('чип «Новое за сегодня»', await p.locator('button.tag:has-text("Новое за сегодня")').count() > 0)
await p.locator('button.tag:has-text("Новое за сегодня")').click()
await p.waitForTimeout(5000)
ok('выдача «нового» есть', await p.locator('.cx-card').count() > 0)
ok('кнопка «Случайное»', await p.locator('button.tag:has-text("Случайное")').count() > 0)

// 5. Плавный счётчик
const anim = await p.locator('.results-summary span, .results-summary strong').count()
console.log('   элементов summary:', anim)

// 6. Эмодзи-чистка: на профиле нет «🔓» и вкладок с эмодзи
await p.goto(BASE + '/login', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2300)
ok('нет «Секретный режим активирован»', await p.getByText('Секретный режим активирован').count() === 0)
const body = await p.evaluate(() => document.body.innerText)
ok('на странице входа нет 🔓', !body.includes('🔓'))

// 7. Ключ секретный сносится при обновлении (повтор проверки)
const lk = p.locator('.region-locked.region-clickable')
if (await lk.count()) await lk.click()
await p.waitForTimeout(300)
await p.reload({ waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2300)
ok('после reload шутка-регион снова активна', await p.locator('.region-locked.region-clickable').count() > 0)

ok('0 JS-ошибок', errs.length === 0)
if (errs.length) console.log(errs.slice(0, 3))
await b.close()
