import { chromium } from 'playwright'
const b = await chromium.launch()
const p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
p.on('pageerror', e => console.log('PAGEERR:', String(e).slice(0, 300)))
p.on('console', m => { if (m.text().includes('CX-') || m.type() === 'error') console.log('CON-' + m.type() + ':', m.text().slice(0, 220)) })
p.on('requestfailed', r => console.log('REQFAIL:', r.url().slice(0, 100)))
await p.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    db.uploads = [{ id: 't1', title: 'AFK_Use-Jubik', description: 'тест', status: 'accepted', user: 'qwe8', display: 'qwe8', github: 'https://github.com/khlsha-web/AFK_Use-Jubik', versions: ['1.21.5'], loaders: ['fabric'], type: 'mod', downloads: 12, likes: 0, comments: [] }]
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})
await p.goto('http://127.0.0.1:5174/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
await p.locator('a:has-text("AFK_Use-Jubik")').first().click()
await p.waitForTimeout(6000)
console.log('--- h1:', await p.locator('h1').count() ? await p.locator('h1').first().textContent() : 'НЕТ')
console.log('--- скелетон?', await p.locator('.skel').count())
await b.close()
