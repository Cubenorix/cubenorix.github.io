// E2E: авто-требования, строгий каталог сборщика, настройки ИИ для всех, свои проекты в подсказке
import { chromium } from 'playwright'
const BASE = 'http://127.0.0.1:5174'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const ctx = await b.newContext({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await ctx.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    db.uploads = [{ id: 't1', title: 'AFK_Use-Jubik', description: 'АФК-мод', status: 'accepted', user: 'qwe8', type: 'mod', downloads: 12, likes: 0, comments: [] }]
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
    // обычный (не админ) пользователь с сессией
    localStorage.setItem('cubenorixx.accounts.v1', JSON.stringify({
      'user@test.local': { username: 'TestUser', email: 'user@test.local', salt: 'abc', hash: 'def', created: '2026-08-30T00:00:00.000Z', role: 'user', consents: {}, profile: {} },
    }))
    localStorage.setItem('cubenorixx.session.v1', JSON.stringify({ email: 'user@test.local', since: Date.now() }))
  } catch {}
})
const errs = []
const p = await ctx.newPage()
p.on('pageerror', (e) => errs.push(String(e)))

// 1) Настройки ИИ видны обычному пользователю, ключ по умолчанию вписан
await p.goto(BASE + '/profile', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3500)
await p.getByRole('button', { name: 'Настройки', exact: true }).click()
await p.waitForTimeout(1200)
ok('вкладка «Настройки» есть', await p.getByText('Сменить пароль').count() >= 0)
ok('блок «Настройки ИИ» виден НЕ админу', await p.locator('h3:has-text("Настройки ИИ")').count() > 0)
const hfVal = await p.locator('input[placeholder="hf_…"]').inputValue()
ok('дефолт-ключ вписан (hf_…)', /^hf_[A-Za-z0-9]{20,}$/.test(hfVal))
ok('кнопка «Вернуть стандартный» есть', await p.locator('button:has-text("Вернуть стандартный")').count() > 0)

// 2) Свои проекты в подсказке поиска шапки
await p.goto(BASE + '/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
const searchInput = p.locator('input[placeholder="Поиск"]').first()
await searchInput.fill('AFK')
await p.waitForTimeout(2000)
ok('подсказка показывает «наш проект»', await p.locator('text=наш проект').count() > 0)
await p.keyboard.press('Escape')

// 3) Сборщик: строгий каталог + авто-требования
await p.goto(BASE + '/builds', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
await p.locator('select').nth(1).selectOption('1.21.5')
const lv = await p.locator('select').nth(2).inputValue()
if (lv !== 'fabric') await p.locator('select').nth(2).selectOption('fabric')

// строгий: бессмысленный запрос → честное «не нашлось» (без чужих версий)
await p.locator('input[placeholder*="sodium, create"]').fill('zzqqxx_nothing')
await p.locator('button:has-text("Найти")').last().click()
await p.waitForTimeout(4000)
ok('пустой результат: честная подсказка без чужих версий', await p.locator('text=не нашлось. Попробуй другое название').count() > 0)

// авто-требования: sodium-extra тянет Sodium
await p.locator('input[placeholder*="sodium, create"]').fill('sodium extra')
await p.locator('button:has-text("Найти")').last().click()
await p.waitForTimeout(5000)
await p.locator('button[title*="Добавить под"]').first().click({ force: true })
await p.waitForTimeout(9000)
const rows = await p.locator('div.glass.p-3.flex.items-center.gap-3').allInnerTexts()
ok('sodium-extra добавлен', rows.some((t) => /[Ss]odium [Ee]xtra/.test(t)))
ok('Sodium подтянулся сам (требование)', rows.some((t) => /[Ss]odium/.test(t) && !/[Ee]xtra/.test(t)))
ok('у требования пометка «требование»', rows.some((t) => /[Ss]odium/.test(t) && !/[Ee]xtra/.test(t) && t.includes('требование')))

ok('0 JS-ошибок', errs.length === 0)
if (errs.length) console.log(errs.slice(0, 3))
await b.close()
