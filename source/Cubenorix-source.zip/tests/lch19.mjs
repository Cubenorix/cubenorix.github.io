// E2E: (1) jar из файлов репозитория (без Releases) скачивается; (2) устаревший чанк → авто-перезагрузка
import { chromium } from 'playwright'
const BASE = 'http://127.0.0.1:5174'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const ctx = await b.newContext({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await ctx.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    if (!db.uploads?.length) {
      db.uploads = [{ id: 't1', title: 'AFK_Use-Jubik', description: 'АФК-мод', status: 'accepted', user: 'qwe8', display: 'qwe8', github: 'https://github.com/khlsha-web/AFK_Use-Jubik', versions: ['1.21.5'], loaders: ['fabric'], type: 'mod', downloads: 3, likes: 0, comments: [] }]
    }
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})

// 1) AFK_Use-Jubik: релизов нет, но jar лежит в файлах репозитория → кнопка с файлом
const p = await ctx.newPage()
const errs = []
p.on('pageerror', (e) => errs.push(String(e)))
await p.goto(BASE + '/project/afk-use-jubik', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(8000)
const dl = p.locator('.dl-panel a:has-text("Скачать файл")')
ok('кнопка «Скачать файл» (jar из репозитория)', await dl.count() > 0)
const href = (await dl.count()) ? await dl.getAttribute('href') : ''
ok('ссылка на raw.githubusercontent', (href || '').includes('raw.githubusercontent.com/khlsha-web/AFK_Use-Jubik/HEAD/'))
ok('размер показан', await p.locator('text=МБ').count() > 0)
const txt = await p.evaluate(() => document.body.innerText)
ok('пометка «из файлов репозитория»', /из файлов репозитория/.test(txt))

// HEAD-ссылка реально отвечает файлом
if (href) {
  const head = await p.evaluate(async (u) => { const r = await fetch(u, { method: 'HEAD' }); return { ok: r.ok, type: r.headers.get('content-type') } }, href).catch(() => null)
  ok('raw-файл отвечает (HEAD ok)', !!head && head.ok)
}

// 2) Устаревший чанк: блокируем Builds-чанк → авто-перезагрузка → страница открывается
let blocked = 0
await ctx.route('**/assets/Builds-*.js', (route) => {
  if (blocked++ === 0) return route.abort()
  return route.continue()
})
await p.goto(BASE + '/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2000)
await p.locator('a:has-text("Сборки"), button:has-text("Сборки")').first().click()
// первая попытка упадёт, страница сама перезагрузится, вторая — пройдёт
await p.waitForURL('**/builds', { timeout: 25000 }).catch(() => {})
await p.waitForTimeout(4000)
ok('устаревший чанк: авто-перезагрузка открыла страницу сборок', p.url().includes('/builds') && await p.locator('h1').count() > 0)
ok('0 JS-ошибок', errs.length === 0)
if (errs.length) console.log(errs.slice(0, 3))
await b.close()
