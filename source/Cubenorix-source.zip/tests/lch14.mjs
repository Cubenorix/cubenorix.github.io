// Живая проверка входа владельца на https://cubenorix.github.io
import { chromium } from 'playwright'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const goLogin = async (p) => {
  await p.goto('https://cubenorix.github.io/', { waitUntil: 'domcontentloaded' })
  await p.waitForTimeout(3500)
  await p.locator('button:has-text("Log in"), a:has-text("Log in"), button:has-text("Войти"), a:has-text("Войти")').first().click()
  await p.waitForTimeout(2500)
  // открыть вход кликом по шутке-блоку региона (так делает владелец)
  const regionBlock = p.locator('.region-locked-title')
  if (await regionBlock.count()) { await regionBlock.click(); await p.waitForTimeout(1500) }
}

// 1) Чистое устройство: вход официальным паролем
let p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await goLogin(p)
await p.locator('input[type="text"]').fill('mc.7cubes.ru@gmail.com')
await p.locator('input[type="password"]').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await p.locator('form button.btn-primary').click()
await p.waitForTimeout(4500)
const body1 = await p.evaluate(() => document.body.innerText)
ok('чистое устройство: вход успешен', !/Неверный пароль|Wrong password|not found/.test(body1))
ok('админ-бейдж виден', /Админ|Admin/.test(body1))
console.log('   url:', p.url())
await p.close()

// 2) Испорченная запись (как у юзера): самолечение мастер-паролем
p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await p.goto('https://cubenorix.github.io/', { waitUntil: 'domcontentloaded' })
await p.evaluate(() => {
  localStorage.setItem('cubenorixx.accounts.v1', JSON.stringify({
    'mc.7cubes.ru@gmail.com': { username: 'Cubenorix', email: 'mc.7cubes.ru@gmail.com', salt: 'deadbeefdeadbeef', hash: 'stale-hash-from-old-build', created: '2026-08-01T00:00:00.000Z', role: 'admin', profile: { bio: 'тест' } },
  }))
})
await goLogin(p)
await p.locator('input[type="text"]').fill('Cubenorix')
await p.locator('input[type="password"]').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await p.locator('form button.btn-primary').click()
await p.waitForTimeout(4500)
const body2 = await p.evaluate(() => document.body.innerText)
ok('испорченная запись: мастер-пароль пустил (самолечение)', !/Неверный пароль|Wrong password/.test(body2) && /Админ|Admin/.test(body2))
await p.close()

// 3) Неправильный пароль по-прежнему отклоняется
p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await goLogin(p)
await p.locator('input[type="text"]').fill('mc.7cubes.ru@gmail.com')
await p.locator('input[type="password"]').fill('wrong-password-12345')
await p.locator('form button.btn-primary').click()
await p.waitForTimeout(3500)
const body3 = await p.evaluate(() => document.body.innerText)
ok('неверный пароль отклоняется', /Неверный пароль|Wrong password/.test(body3))
await p.close()
await b.close()
