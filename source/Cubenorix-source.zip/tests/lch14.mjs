// Живая проверка входа владельца на https://cubenorix.github.io (+ капча-виджет)
import { chromium } from 'playwright'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const goLogin = async (p, withCaptcha = false) => {
  await p.goto('https://cubenorix.github.io/', { waitUntil: 'domcontentloaded' })
  await p.waitForTimeout(6000)
  if (!withCaptcha) await p.evaluate(() => localStorage.setItem('cubenorixx.recaptcha', 'off'))
  const loginSel = 'button:has-text("Log in"), a:has-text("Log in"), button:has-text("Войти"), a:has-text("Войти")'
  for (let i = 0; i < 3 && !(await p.locator(loginSel).count()); i++) {
    await p.reload({ waitUntil: 'domcontentloaded' })
    await p.waitForTimeout(6000)
  }
  await p.locator(loginSel).first().click()
  await p.waitForTimeout(3000)
  // открыть вход кликом по шутке-блоку региона (так делает владелец)
  const regionBlock = p.locator('.region-locked-title')
  if (await regionBlock.count()) { await regionBlock.click(); await p.waitForTimeout(1500) }
}

// 1) Чистое устройство: вход официальным паролем (капча отключена флагом)
let p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await goLogin(p)
await p.locator('input[type="text"]').fill('mc.7cubes.ru@gmail.com')
await p.locator('input[type="password"]').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await p.locator('form button.btn-primary').click()
await p.waitForTimeout(4500)
const body1 = await p.evaluate(() => document.body.innerText)
ok('чистое устройство: вход успешен', !/Неверный пароль|Wrong password|не найден/.test(body1))
ok('админ-бейдж виден', /Админ|Admin/.test(body1))
console.log('   url:', p.url())
await p.close()

// 2) Испорченная запись (как у юзера): самолечение мастер-паролем
p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await p.goto('https://cubenorix.github.io/', { waitUntil: 'domcontentloaded' })
await p.evaluate(() => {
  localStorage.setItem('cubenorixx.recaptcha', 'off')
  localStorage.setItem('cubenorixx.accounts.v1', JSON.stringify({
    'mc.7cubes.ru@gmail.com': { username: 'Cubenorix', email: 'mc.7cubes.ru@gmail.com', salt: 'deadbeefdeadbeef', hash: 'stale-hash-from-old-build', created: '2026-08-01T00:00:00.000Z', role: 'admin', profile: { bio: 'тест' } },
  }))
})
await goLogin(p)
await p.locator('input[type="text"]').fill('Cubenorix')
await p.locator('input[type="password"]').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await p.locator('form button.btn-primary').click()
await p.waitForTimeout(4500)
const body2 = await p.evaluate(() => document.body.innerText)
ok('испорченная запись: мастер-пароль пустил (самолечение)', !/Неверный пароль|Wrong password/.test(body2) && /Админ|Admin/.test(body2))
await p.close()

// 3) Капча на живом сайте: виджет рендерится, кнопка заблокирована до решения, консоль Google без ошибок домена
p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
const capConsole = []
p.on('console', (m) => { if (/invalid domain|invalid site key/i.test(m.text())) capConsole.push(m.text().slice(0, 120)) })
await goLogin(p, true)
await p.waitForTimeout(12000)
const capFrames = await p.locator('iframe[src*="recaptcha"], .g-recaptcha').count()
const capGateActive = !(await p.locator('form button.btn-primary').isEnabled().catch(() => true))
console.log('капча-виджет: iframe/.g-recaptcha =', capFrames, '| кнопка ждёт капчу:', capGateActive, '| ошибки домена:', capConsole.length ? capConsole.slice(0, 2) : 'нет')
ok('капча-виджет отрендерился на живом сайте', capFrames > 0)
ok('ключ принят для домена (нет ошибок в консоли)', capConsole.length === 0)
await p.close()

// 4) Неправильный пароль по-прежнему отклоняется
p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await goLogin(p)
await p.locator('input[type="text"]').fill('mc.7cubes.ru@gmail.com')
await p.locator('input[type="password"]').fill('wrong-password-12345')
await p.locator('form button.btn-primary').click()
await p.waitForTimeout(3500)
const body3 = await p.evaluate(() => document.body.innerText)
ok('неверный пароль отклоняется', /Неверный пароль|Wrong password/.test(body3))
await p.close()
await b.close()
