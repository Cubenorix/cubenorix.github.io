/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { allAcceptedUploads, uploadSlug, uploadProject } from '../src/localUploads.js'
import { PUBLISHED_UPLOADS } from '../src/published-uploads.js'

const store = new Map()
globalThis.localStorage = {
  getItem: (k) => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, String(v)),
  removeItem: (k) => store.delete(k),
}

test('Публикация: зашитые проекты видны даже с ПУСТЫМ устройством', () => {
  const list = allAcceptedUploads({ uploads: [] })
  assert.ok(list.length >= 1)
  assert.ok(list.some((u) => uploadSlug(u.title) === 'afk-use-jubik'))
  assert.equal(list[0].published, true)
})

test('Публикация: локальный дубль не задваивается', () => {
  const db = { uploads: [{ id: 'x', title: 'AFK_Use-Jubik', status: 'accepted' }, { id: 'y', title: 'Другой мод', status: 'accepted' }] }
  const list = allAcceptedUploads(db)
  const afk = list.filter((u) => uploadSlug(u.title) === 'afk-use-jubik')
  assert.equal(afk.length, 1)
  assert.ok(list.some((u) => u.title === 'Другой мод'))
})

test('Публикация: у проекта есть публичный комментарий и поля страницы', () => {
  const up = allAcceptedUploads({ uploads: [] })[0]
  assert.equal(up.published, true)
  const pr = uploadProject(up, uploadSlug(up.title))
  assert.equal(pr.slug, 'afk-use-jubik')
  assert.equal(pr.published, true)
  assert.equal(pr.local_upload, true)
  assert.equal(pr.source_url, 'https://github.com/khlsha-web/AFK_Use-Jubik')
  assert.ok(pr.published_comments.length >= 1)
  assert.equal(pr.author, 'qwe8')
})
