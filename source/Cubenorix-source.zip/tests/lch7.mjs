// E2E: регион в регистрации, ИИ-блоки, заметка каталога
import { chromium } from 'playwright'
const BASE = 'http://127.0.0.1:5174'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch(); const p = await b.newPage()
const errs = []; p.on('pageerror', e => errs.push(String(e)))
await p.addInitScript(() => { try { const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}'); db.lang = 'ru'; localStorage.setItem('cubenorixx.v1', JSON.stringify(db)) } catch {} })

// 1. Регистрация: регион определён + кнопка-извинение
await p.goto(BASE + '/register', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2600)
ok('регион определён («ты из:») — ', await p.getByText('По настройкам устройства ты из:').count() > 0)
ok('кнопка «Извините, была ошибка региона»', await p.locator('button:has-text("Извините, была ошибка региона")').count() > 0)
await p.locator('button:has-text("Извините, была ошибка региона")').click()
await p.waitForTimeout(500)
ok('после извинения открыта регистрация (форма видна)', await p.getByPlaceholder('name@example.com').count() > 0)
ok('тост «была ошибка региона»', await p.getByText('была ошибка региона').count() > 0)

// 2. Каталог: заметка о свежести
await p.goto(BASE + '/catalog?q=sodium', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(4500)
ok('заметка «новые проекты появляются в течение суток»', await p.getByText('новые проекты появляются в течение суток').count() > 0)
ok('заметка «переизучает при каждом обновлении сайта»', await p.getByText('при каждом обновлении сайта', { exact: false }).count() > 0)

// 3. Сборщик: кнопка ИИ + подсказка без токена
await p.goto(BASE + '/builds', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2500)
ok('кнопка «🤖 ИИ-проверка» есть', await p.locator('button:has-text("ИИ-проверка")').count() > 0)
await p.locator('button:has-text("ИИ-проверка")').click()
await p.waitForTimeout(500)
ok('без токена — подсказка где ввести', await p.getByText('нужен HF-токен').count() > 0)

// 4. Профиль админа: блок ИИ + сохранение токена
await p.goto(BASE + '/login', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2400)
const locked = p.locator('.region-locked.region-clickable')
if (await locked.count()) await locked.click()
await p.getByPlaceholder('ваш e-mail или ник').fill('Cubenorix')
await p.getByPlaceholder('Ваш пароль').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await p.locator('form button[type="submit"], form button:not([type])').first().click()
await p.waitForTimeout(1600)
await p.locator('button.tag:has-text("Настройки")').first().click()
await p.waitForTimeout(400)
ok('блок «ИИ-проверка (Hugging Face)» у админа', await p.getByText('ИИ-проверка (Hugging Face)').count() > 0)
await p.locator('input[placeholder="hf_…"]').fill('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')
await p.locator('button:has-text("Сохранить токен")').click()
await p.waitForTimeout(400)
ok('токен сохранён (тост)', await p.getByText('HF-токен сохранён').count() > 0) // тосты иногда замирают (старый баг, вне скоупа)
const stored = await p.evaluate(() => localStorage.getItem('cubenorixx.hf') || '')
ok('токен в localStorage устройства', stored.startsWith('hf_'))
// реальный вызов ИИ из браузера
await p.goto(BASE + '/builds', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2500)
await p.locator('button:has-text("ИИ-проверка")').click()
await p.waitForTimeout(25000)
const ai = await p.getByText('ИИ-проверка:').count()
const aiFail = await p.getByText('ИИ недоступен').count()
ok('ИИ ответил на реальный токен (или сетьsandbox): ' + (ai ? 'ответ' : aiFail ? 'недоступен' : 'нет лога'), ai > 0 || aiFail > 0)
ok('0 JS-ошибок', errs.length === 0)
if (errs.length) console.log(errs.slice(0, 3))
await b.close()
