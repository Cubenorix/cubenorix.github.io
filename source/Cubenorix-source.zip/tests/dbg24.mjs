import { chromium } from 'playwright'
const b = await chromium.launch()
const ctx = await b.newContext({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await ctx.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    if (db.uploads?.length) { localStorage.setItem('cubenorixx.v1', JSON.stringify(db)); return }
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})
const p = await ctx.newPage()
p.on('pageerror', e => console.log('ERR:', String(e).slice(0, 200)))
await p.goto('http://127.0.0.1:5174/builds', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
const today = new Date().toISOString().slice(0, 10)
await p.evaluate((d) => localStorage.setItem('cubenorixx.ai.q', JSON.stringify({ d, n: 30, h: [Date.now() - 1000] })), today)
await p.reload({ waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
await p.goto('http://127.0.0.1:5174/profile', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(6000)
console.log('url:', p.url())
const btns = await p.locator('button').allInnerTexts()
console.log('кнопки:', btns.slice(0, 20).join(' | '))
await b.close()
