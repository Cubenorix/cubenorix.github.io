// E2E: админ-аккаунт + переделанный редактор профиля + официальная почта
import { chromium } from 'playwright'

const BASE = 'http://127.0.0.1:5174'
const results = []
const ok = (name, cond) => { results.push([cond ? 'PASS' : 'FAIL', name]); console.log(cond ? 'PASS' : 'FAIL', '—', name); if (!cond) process.exitCode = 1 }

const browser = await chromium.launch()
const page = await browser.newPage()
await page.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})
const jsErrors = []
page.on('pageerror', (e) => jsErrors.push(String(e)))

await page.goto(BASE + '/login', { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(2600) // splash

// 1. Секретный регион-клик открывает форму
const locked = page.locator('.region-locked.region-clickable')
if (await locked.count()) await locked.click()
await page.waitForTimeout(400)

// 2. Вход АДМИНА по e-mail
await page.getByPlaceholder('ваш e-mail или ник').fill('mc.7cubes.ru@gmail.com')
await page.getByPlaceholder('Ваш пароль').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await page.locator('form button[type="submit"], form button:not([type])').first().click()
await page.waitForTimeout(1500)
ok('админ вошёл по e-mail → /profile', page.url().includes('/profile'))
ok('роль в шапке «Админ · максимальный уровень»', await page.getByText('Админ · максимальный уровень').count() > 0)
ok('бейдж «Админ — максимальный уровень»', await page.getByText('Админ — максимальный уровень').count() > 0)

// 3. Редактор профиля: карточка «Аккаунт»
await page.locator('button.tag:has-text("Настройки")').first().click()
await page.waitForTimeout(400)
ok('карточка «Аккаунт» есть', await page.locator('h3:has-text("Аккаунт")').count() > 0)
ok('чип «АДМИН · уровень МАКС»', await page.getByText('АДМИН · уровень МАКС').count() > 0)
ok('e-mail админа виден', await page.getByText('mc.7cubes.ru@gmail.com').count() > 0)
ok('уровень МАКСИМАЛЬНЫЙ', await page.getByText('МАКСИМАЛЬНЫЙ').count() > 0)
ok('логин закреплён', await page.getByText('закреплён').count() > 0)
ok('официальная почта в карточке', await page.locator('a[href="mailto:cubenorix.official@gmail.com"]').count() > 0)
ok('логин-инпут задизейблен у админа', await page.locator('form input[disabled]').count() > 0)
ok('блок «Смена пароля» есть', await page.getByText('Смена пароля').count() > 0)
ok('у админа нет кнопки «Удалить аккаунт»', await page.locator('button:has-text("Удалить аккаунт")').count() === 0)
ok('блок защиты администрации', await page.getByText('Аккаунт администрации').count() > 0)

// 4. Смена пароля у админа
await page.getByLabel('Текущий пароль').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await page.getByLabel('Новый (12–128)').fill('TestNewPassword123')
await page.getByLabel('Новый ещё раз').fill('TestNewPassword123')
await page.locator('button:has-text("Сменить пароль")').click()
await page.waitForTimeout(600)
ok('тост «Пароль изменён»', await page.getByText('Пароль изменён').count() > 0)

// 5. Выход; старый пароль больше не работает, новый — работает
await page.locator('button:has-text("Выйти")').first().click()
await page.waitForTimeout(900)
await page.goto(BASE + '/login', { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(2200)
await page.getByPlaceholder('ваш e-mail или ник').fill('mc.7cubes.ru@gmail.com')
await page.getByPlaceholder('Ваш пароль').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await page.locator('form button[type="submit"], form button:not([type])').first().click()
await page.waitForTimeout(900)
ok('старый пароль отклонён', await page.getByText('Неверный пароль').count() > 0)
await page.getByPlaceholder('Ваш пароль').fill('TestNewPassword123')
await page.locator('form button[type="submit"], form button:not([type])').first().click()
await page.waitForTimeout(1200)
ok('вход с новым паролем → /profile', page.url().includes('/profile'))

// 6. Выход по НИКУ «Cubenorix»
await page.locator('button:has-text("Выйти")').first().click()
await page.waitForTimeout(900)
await page.goto(BASE + '/login', { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(2200)
await page.getByPlaceholder('ваш e-mail или ник').fill('Cubenorix')
await page.getByPlaceholder('Ваш пароль').fill('TestNewPassword123')
await page.locator('form button[type="submit"], form button:not([type])').first().click()
await page.waitForTimeout(1200)
ok('вход по нику «Cubenorix» → /profile', page.url().includes('/profile'))
await page.locator('button:has-text("Выйти")').first().click()
await page.waitForTimeout(900)

// 7. Обычный пользователь: регистрация, «игрок», удаление работает
await page.goto(BASE + '/login', { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(2200)
await page.locator('button.tag:has-text("Регистрация"), button.tag:has-text("Создать")').first().click()
await page.getByPlaceholder(/латиница, цифры/).fill('TestPlayer1')
await page.getByPlaceholder('name@example.com').fill('player1@example.com')
await page.getByPlaceholder('Не менее 12 символов').fill('PlayerPassword123')
const boxes = page.locator('form input[type="checkbox"]:not(:checked)')
while (await boxes.count()) await boxes.nth(0).check()
await page.locator('form button[type="submit"], form button:not([type])').first().click()
await page.waitForTimeout(1500)
ok('обычный пользователь зарегистрирован → /profile', page.url().includes('/profile'))
ok('у игрока нет админ-бейджа', await page.getByText('АДМИН · уровень МАКС').count() === 0)
await page.locator('button.tag:has-text("Настройки")').first().click()
await page.waitForTimeout(400)
ok('у игрока логин активен', await page.locator('form input[disabled]').count() === 0)
ok('у игрока есть «Удалить аккаунт»', await page.locator('button:has-text("Удалить аккаунт")').count() > 0)
await page.locator('button:has-text("Удалить аккаунт")').click()
await page.waitForTimeout(300)
await page.locator('button:has-text("Да, удалить навсегда")').click()
await page.waitForTimeout(1200)
ok('аккаунт игрока удалён (2 клика, без пароля)', !page.url().includes('/profile'))

// 8. Официальная почта в футере
await page.goto(BASE + '/', { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(2400)
ok('футер: официальная почта', await page.locator('a[href="mailto:cubenorix.official@gmail.com"]').count() > 0)

ok('0 JS-ошибок на страницах', jsErrors.length === 0)
for (const [st, name] of results) console.log(st, '—', name)
if (jsErrors.length) console.log('JS ERRORS:', jsErrors.slice(0, 5))
await browser.close()
