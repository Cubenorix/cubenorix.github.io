/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { chromium } from 'playwright'
import assert from 'node:assert/strict'

const base = process.env.CUBENORIXX_URL || 'http://127.0.0.1:5173'
const browser = await chromium.launch({ headless: true })
const context = await browser.newContext({ locale: 'en-US', viewport: { width: 1365, height: 900 } })
const page = await context.newPage()
const errors = []
page.on('console', (msg) => { if (msg.type() === 'error') errors.push('console: ' + msg.text()) })
page.on('pageerror', (err) => errors.push('page: ' + err.message))

await page.goto(base + '/catalog?type=emote', { waitUntil: 'domcontentloaded', timeout: 30000 })
await page.getByText('Emotecraft Hub', { exact: true }).waitFor({ timeout: 15000 })
assert.equal(await page.getByText('Minecraft Inside · RU', { exact: true }).isVisible(), true)
assert.equal(await page.locator('.catalog-list .cx-card').count() > 0, true)

await page.goto(base + '/builds', { waitUntil: 'domcontentloaded', timeout: 30000 })
const input = page.locator('textarea').first()
const mods = Array.from({ length: 40 }, (_, i) => `example-mod-${i + 1}`).join(' + ')
await input.fill('# ' + mods)
await page.getByText('40 элементов разделено на 12 задач', { exact: true }).waitFor()
assert.equal(await page.locator('.task-cell').count(), 12)
await page.locator('details.diagnostics-lab > summary').click()
assert.equal(await page.getByText('MCDoctor.ai', { exact: true }).isVisible(), true)
assert.equal(await page.getByText('Dig Yourself Out', { exact: true }).isVisible(), true)

const dummy = Buffer.from('Cubenorix test jar bytes')
await page.locator('details.diagnostics-lab input[type=file]').setInputFiles({ name: 'example.jar', mimeType: 'application/java-archive', buffer: dummy })
await page.getByText(/SHA-256:/).waitFor()
assert.match(await page.getByText(/SHA-256:/).innerText(), /[a-f0-9]{64}/)

await page.getByRole('button', { name: /Сборки|Packs/ }).click()
await page.getByText('Все сборки мира', { exact: true }).waitFor()
await page.waitForTimeout(1200)
assert.equal(await page.locator('.catalog-list .cx-card').count() > 0, true)

const locale = await page.request.get(base + '/api/locale')
assert.equal(locale.ok(), true)
assert.equal(typeof (await locale.json()).country, 'string')

await page.setViewportSize({ width: 390, height: 844 })
await page.goto(base + '/catalog?type=skin&q=Notch', { waitUntil: 'domcontentloaded' })
await page.getByText('SkinMC', { exact: true }).waitFor({ timeout: 15000 })
assert.equal((await page.locator('body').evaluate((el) => el.scrollWidth <= window.innerWidth + 2)), true)

await browser.close()
if (errors.length) {
  console.error(errors.join('\n'))
  process.exit(1)
}
console.log('browser smoke passed: Emotecraft, 12-task UI, diagnostics hash, modpack catalogue, locale and mobile skin sources')
