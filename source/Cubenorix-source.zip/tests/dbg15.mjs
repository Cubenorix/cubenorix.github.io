import { chromium } from 'playwright'
const b = await chromium.launch()
const p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await p.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    db.uploads = [{ id: 't1', title: 'AFK_Use-Jubik', status: 'review', user: 'qwe8', virusChecked: true, github: 'https://github.com/x/y', type: 'mod', downloads: 0, likes: 0, comments: [] }]
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})
await p.goto('http://127.0.0.1:5174/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
await p.locator('button:has-text("Войти")').first().click()
await p.waitForTimeout(2000)
const rb = p.locator('.region-locked-title')
if (await rb.count()) { await rb.click(); await p.waitForTimeout(1000) }
await p.locator('input[type="text"]').fill('Cubenorix')
await p.locator('input[type="password"]').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await p.locator('form button.btn-primary').click()
await p.waitForTimeout(3000)
console.log('url:', p.url())
const tabs = await p.locator('button, a').allInnerTexts()
console.log('кнопки с «Проект»:', tabs.filter(t => t.includes('Проект')).slice(0, 6))
await p.locator('button:has-text("Проекты")').first().click()
await p.waitForTimeout(1500)
const body = await p.evaluate(() => document.body.innerText)
console.log('AFK на странице?', body.includes('AFK_Use-Jubik'))
console.log('фрагмент:', body.slice(body.indexOf('Проекты'), body.indexOf('Проекты') + 300).replace(/\n+/g, ' | '))
await b.close()
