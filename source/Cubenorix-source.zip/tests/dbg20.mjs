import { chromium } from 'playwright'
const b = await chromium.launch()
const p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
p.on('pageerror', e => console.log('PAGEERR:', String(e).slice(0, 200)))
await p.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    db.uploads = [{ id: 't1', title: 'AFK_Use-Jubik', description: 'тест', status: 'accepted', user: 'qwe8', type: 'mod', downloads: 0, likes: 0, comments: [] }]
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})
await p.goto('http://127.0.0.1:5174/catalog?q=AFK', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(6000)
const txt = await p.evaluate(() => document.body.innerText)
console.log('секция авторов?', txt.includes('Проекты авторов Cubenorix'))
console.log('карточка AFK?', txt.includes('AFK_Use-Jubik'))
await b.close()
