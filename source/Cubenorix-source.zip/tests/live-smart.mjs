import { chromium } from 'playwright'
const b = await chromium.launch(); const p = await b.newPage()
const errs = []; p.on('pageerror', e => errs.push(String(e)))
await p.addInitScript(() => { try { const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}'); db.lang = 'ru'; localStorage.setItem('cubenorixx.v1', JSON.stringify(db)) } catch {} })

await p.goto('https://cubenorix.github.io/#/catalog?q=' + encodeURIComponent('мод на летающие корабли'), { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(8000)
console.log('live «летающие корабли»:')
console.log('  плашка словаря:', await p.getByText('Словарь смыслов').count() > 0 ? 'OK' : 'FAIL')
const ships = (await p.locator('.cx-card h3').allTextContents().catch(() => [])).slice(0, 5)
console.log('  топ:', ships.map(s => s.trim()).join(' | '))
console.log('  корабли найдены:', /ship|sail|eureka|valkyrien|flight/i.test(ships.join(' ')) ? 'OK' : 'FAIL')

await p.goto('https://cubenorix.github.io/#/catalog?q=' + encodeURIComponent('что такое редстоун'), { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(8000)
console.log('live «что такое редстоун» → вики:', await p.getByText('Minecraft Wiki').count() > 0 || await p.locator('.cx-card h3:has-text("Redstone")').count() > 0 ? 'OK' : 'FAIL')
console.log('JS-ошибок:', errs.length, errs.slice(0, 2))
await b.close()
