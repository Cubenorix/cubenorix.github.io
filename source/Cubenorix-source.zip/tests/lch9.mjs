import { chromium } from 'playwright'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch(); const p = await b.newPage()
const errs = []; p.on('pageerror', e => errs.push(String(e)))
await p.addInitScript(() => { try { const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}'); db.lang = 'ru'; localStorage.setItem('cubenorixx.v1', JSON.stringify(db)) } catch {} })
await p.goto('http://127.0.0.1:5174/wiki', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2500)
ok('блок «Информация из официальных источников»', await p.getByText('Информация из официальных источников').count() > 0)
ok('ссылки на minecraft.net / help.mojang.com', await p.locator('a[href="https://help.mojang.com/"]').count() > 0)
// вкладка блоков/мобов с картинками
const tabs = p.locator('button.tag')
const tabTexts = await tabs.allTextContents()
const mobTab = tabTexts.findIndex(x => /моб|mobs/i.test(x))
const blockTab = tabTexts.findIndex(x => /блок|blocks/i.test(x))
if (blockTab >= 0) { await tabs.nth(blockTab).click(); await p.waitForTimeout(2500) }
ok('карточки блоков с картинками', await p.locator('.wiki-img').count() > 10)
ok('ссылка «Официальная Minecraft Wiki» на карточках', await p.locator('a.wiki-official').count() > 10)
const broken = await p.evaluate(() => [...document.querySelectorAll('img.wiki-img')].filter(i => i.complete && i.naturalWidth === 0).length)
console.log('   битых картинок сразу:', broken)
if (mobTab >= 0) { await tabs.nth(mobTab).click(); await p.waitForTimeout(2000) }
ok('у мобов тоже картинки', await p.locator('.wiki-img').count() > 10)
ok('0 JS-ошибок', errs.length === 0)
if (errs.length) console.log(errs.slice(0, 3))
await b.close()
