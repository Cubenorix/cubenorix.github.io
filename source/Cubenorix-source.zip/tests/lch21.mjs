// Живая проверка: нерабочий ключ капчи НЕ блокирует вход (авто-открытие ~10с)
import { chromium } from 'playwright'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await p.goto('https://cubenorix.github.io/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(5000)
const loginSel = 'button:has-text("Log in"), a:has-text("Log in"), button:has-text("Войти"), a:has-text("Войти")'
await p.locator(loginSel).first().click()
await p.waitForTimeout(3000)
const rb = p.locator('.region-locked-title')
if (await rb.count()) { await rb.click(); await p.waitForTimeout(1500)
  { const ob = p.locator('.region-open-btn'); if (await ob.count()) { await ob.click(); await p.waitForTimeout(1200) } } }
// НЕ отключаем капчу — ровно то, что видит юзер
const t0 = Date.now()
// ждём, пока кнопка станет активной (после авто-открытия)
let opened = false
for (let i = 0; i < 20; i++) {
  if (await p.locator('form button.btn-primary').isEnabled().catch(() => false)) { opened = true; break }
  await p.waitForTimeout(2000)
}
const waited = Math.round((Date.now() - t0) / 1000)
ok(`вход открылся сам без капчи (ждали ${waited}с)`, opened && waited <= 25)
const txt = await p.evaluate(() => document.body.innerText)
ok('есть понятное объяснение про ключ', /Google не принял ключ|вход открыт без неё/.test(txt))
// и вход реально срабатывает
await p.evaluate(() => localStorage.setItem('cubenorixx.recaptcha', 'off'))
await p.locator('input[type="text"]').fill('mc.7cubes.ru@gmail.com')
await p.locator('input[type="password"]').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await p.locator('form button.btn-primary').click()
await p.waitForTimeout(4500)
const body = await p.evaluate(() => document.body.innerText)
ok('вход владельца работает', !/Неверный пароль/.test(body) && /Админ|Admin/.test(body))
await b.close()
