/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { withRetry } from '../src/api.js'

test('withRetry: возвращает результат сразу при успехе', async () => {
  let n = 0
  const r = await withRetry(async () => { n++; return 'ok' })
  assert.equal(r, 'ok')
  assert.equal(n, 1)
})

test('withRetry: повторяет при сбое и отдаёт результат со второй попытки', async () => {
  let n = 0
  const r = await withRetry(async () => { n++; if (n < 2) throw new Error('net'); return 'done' }, 2, 5)
  assert.equal(r, 'done')
  assert.equal(n, 2)
})

test('withRetry: бросает последнюю ошибку после всех попыток', async () => {
  await assert.rejects(() => withRetry(async () => { throw new Error('always') }, 2, 5), /always/)
})
