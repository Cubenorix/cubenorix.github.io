// Юридические формулировки: пугающих заявлений нет, дисклеймер Mojang на месте
import { chromium } from 'playwright'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await p.goto('http://127.0.0.1:5174/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(4000)
const txt = await p.evaluate(() => document.body.innerText)
ok('нет «бренд и оригинальный контент защищены»', !/бренд и оригинальный контент защищены/i.test(txt))
ok('нет «защищены законом»', !/защищены законом/i.test(txt))
ok('есть фанатский некоммерческий проект', /фанатский некоммерческий проект/i.test(txt))
ok('дисклеймер Mojang на месте', /не аффилированный с Mojang/i.test(txt) || /товарный знак Mojang/i.test(txt))
await b.close()
