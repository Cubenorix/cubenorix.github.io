// E2E: лимит ИИ + скачивание наших авторов (GitHub Releases)
import { chromium } from 'playwright'
const BASE = 'http://127.0.0.1:5174'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const ctx = await b.newContext({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await ctx.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    if (db.uploads?.length) { localStorage.setItem('cubenorixx.v1', JSON.stringify(db)); return }
    db.uploads = [{ id: 't1', title: 'AFK_Use-Jubik', description: 'АФК-мод', status: 'accepted', user: 'qwe8', display: 'qwe8', github: 'https://github.com/octocat/Hello-World', versions: ['1.21.5'], loaders: ['fabric'], type: 'mod', downloads: 3, likes: 0, comments: [] }]
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
    localStorage.setItem('cubenorixx.accounts.v1', JSON.stringify({ 'user@test.local': { username: 'TestUser', email: 'user@test.local', salt: 'abc', hash: 'def', created: '2026-08-30T00:00:00.000Z', role: 'user', consents: {}, profile: {} } }))
    localStorage.setItem('cubenorixx.session.v1', JSON.stringify({ email: 'user@test.local', since: Date.now() }))
  } catch {}
})
const errs = []
const p = await ctx.newPage()
p.on('pageerror', (e) => errs.push(String(e)))

// 1) Проект автора без Releases: честная карточка вместо тупика
await p.goto(BASE + '/project/afk-use-jubik', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(6000)
const txt = await p.evaluate(() => document.body.innerText)
ok('текст «Файл в Releases пока не опубликован»', /Releases пока не опубликован/.test(txt))
ok('кнопка «Открыть GitHub автора»', await p.locator('a:has-text("Открыть GitHub автора")').count() > 0)
ok('подсказка автору про Releases', /выложи собранный \.jar\/\.zip в Releases/i.test(txt))

// 2) Проект автора С Releases: реальное скачивание (тестовый репозиторий с релизом)
await p.evaluate(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.uploads[0].github = 'https://github.com/FabricMC/fabric-api'
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})
await p.reload({ waitUntil: 'domcontentloaded' })
await p.waitForTimeout(6000)
const txt2 = await p.evaluate(() => document.body.innerText)
ok('кнопка «Скачать файл» с размером', await p.locator('a:has-text("Скачать файл ·")').count() > 0)
ok('подпись «качается напрямую с GitHub автора»', /качается напрямую с GitHub автора/.test(txt2))
ok('вкладка «Версии» не тупиковая (без CDN-текста)', !txt2.includes('Файла на CDN нет'))

// 3) Квота: исчерпываем лимит — ИИ-подбор честно отказывает
await p.goto(BASE + '/builds', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
await p.evaluate(() => {
  const today = new Date().toISOString().slice(0, 10)
  localStorage.setItem('cubenorixx.ai.q', JSON.stringify({ d: today, n: 30, h: [Date.now() - 1000] }))
})
await p.reload({ waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
await p.locator('input[placeholder*="ИИ-подбор"]').fill('военная сборка')
await p.locator('form button:has-text("Подобрать")').last().click()
await p.waitForTimeout(1500)
ok('ИИ-подбор при лимите: честное сообщение', await p.getByText('Суточный лимит стандартного ИИ-ключа').count() > 0)

// 4) В настройках ИИ виден остаток лимита
await p.goto(BASE + '/profile', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(5000)
await p.getByRole('button', { name: 'Настройки', exact: true }).click({ timeout: 20000 })
await p.waitForTimeout(1500)
ok('в настройках показан остаток лимита', await p.getByText('Стандартный ключ: сегодня использовано').count() > 0)

ok('0 JS-ошибок', errs.length === 0)
if (errs.length) console.log(errs.slice(0, 3))
await b.close()
