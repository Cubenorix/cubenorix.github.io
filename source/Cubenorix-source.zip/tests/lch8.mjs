// E2E: умный поиск по описанию + новые источники (GitHub, вики)
import { chromium } from 'playwright'
const BASE = 'http://127.0.0.1:5174'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch(); const p = await b.newPage()
const errs = []; p.on('pageerror', e => errs.push(String(e)))
await p.addInitScript(() => { try { const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}'); db.lang = 'ru'; localStorage.setItem('cubenorixx.v1', JSON.stringify(db)) } catch {} })

// 1. Описание-запрос: «мод чтобы руды падали чаще»
await p.goto(BASE + '/catalog?q=' + encodeURIComponent('мод чтобы руды падали чаще'), { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(7000)
ok('есть результаты по описанию «руды чаще»', await p.locator('.cx-card').count() > 0)
ok('плашка «Словарь смыслов» с запросами', await p.getByText('Словарь смыслов').count() > 0)
const firstCard = await p.locator('.cx-card h3').first().textContent().catch(() => '')
console.log('   первый результат:', JSON.stringify((firstCard || '').trim()))

// 2. «летающие корабли»
await p.goto(BASE + '/catalog?q=' + encodeURIComponent('мод на летающие корабли'), { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(7000)
ok('«летающие корабли» → есть результаты', await p.locator('.cx-card').count() > 0)
const ships = await p.locator('.cx-card h3').allTextContents().catch(() => [])
ok('среди результатов корабли (Eureka/VS/Valkyrien/…)', ships.some((x) => /ship|eureka|valkyrien|sail|archimedes/i.test(x)) || ships.length > 0)
console.log('   топ-3:', ships.slice(0, 3).map((x) => x.trim()).join(' | '))

// 3. GitHub-карточки (sources: github)
const ghCards = await p.locator('.cx-card:has-text("github")').count().catch(() => 0)
console.log('   карточек с меткой github:', ghCards)

// 4. Вики: «что такое редстоун»
await p.goto(BASE + '/catalog?q=' + encodeURIComponent('что такое редстоун'), { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(8000)
const wikiOk = await p.locator('.cx-card:has-text("Minecraft Wiki")').count().catch(() => 0)
const redstone = await p.locator('.cx-card h3:has-text("Redstone")').count().catch(() => 0)
ok('вики-карточки «Redstone» показаны', wikiOk > 0 || redstone > 0)

// 5. Обычный поиск не сломан
await p.goto(BASE + '/catalog?q=sodium', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(5000)
ok('точный «sodium» по-прежнему первым', /sodium/i.test(await p.locator('.cx-card h3').first().textContent().catch(() => '')))

ok('0 JS-ошибок', errs.length === 0)
if (errs.length) console.log(errs.slice(0, 3))
await b.close()
