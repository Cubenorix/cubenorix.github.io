import { chromium } from 'playwright'
import JSZip from 'jszip'
import fs from 'fs'
const b = await chromium.launch(); const p = await b.newPage({ acceptDownloads: true })
p.on('pageerror', e => console.log('PAGE ERR:', String(e).slice(0, 150)))
await p.addInitScript(() => { try { const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}'); db.lang = 'ru'; localStorage.setItem('cubenorixx.v1', JSON.stringify(db)) } catch {} })
await p.goto('http://127.0.0.1:5174/builds', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2500)
await p.locator('select').nth(1).selectOption('1.21.5')
const lv = await p.locator('select').nth(2).inputValue()
if (lv !== 'fabric') await p.locator('select').nth(2).selectOption('fabric')
console.log('лоадер:', await p.locator('select').nth(2).inputValue())
await p.locator('input[placeholder*="sodium, create"]').fill('sodium')
await p.locator('button:has-text("Найти")').last().click()
await p.waitForTimeout(5000)
await p.locator('button[title*="Добавить под"]').first().click({ force: true })
await p.waitForTimeout(5000)
// точный подсчёт items-строк (строки со ссылкой на версию)
const rows = await p.locator('div.glass.p-3.flex.items-center.gap-3').count()
console.log('item-строк:', rows)
for (let i = 0; i < rows; i++) console.log('строка', i, ':', (await p.locator('div.glass.p-3.flex.items-center.gap-3').nth(i).innerText()).replace(/\n/g, ' | ').slice(0, 100))
const rbtn = p.locator('button:has-text("Русификатор (RU)")')
console.log('русификатор кнопок:', await rbtn.count(), '| disabled:', await rbtn.first().isDisabled())
const dl = p.waitForEvent('download', { timeout: 90000 }) // слушатель ДО клика
await p.evaluate(() => { const b = [...document.querySelectorAll('button')].find((x) => x.textContent.includes('Русификатор')); b && b.click(); return Boolean(b) })
await p.waitForTimeout(1500)
console.log('после DOM-click, CX-RUS логи?')
console.log('disabled после клика:', await rbtn.first().isDisabled())
p.on('console', m => { if (!m.text().includes('404')) console.log('CON:', m.text().slice(0, 120)) })
try {
  const download = await dl
  const name = download.suggestedFilename()
  console.log('файл:', name, /^Cubenorix_ru_[\w.+-]+_v1\.jar$/.test(name) ? 'PASS' : 'FAIL')
  const path = await download.path()
  const zip2 = await JSZip.loadAsync(await fs.promises.readFile(path))
  const ru = Object.keys(zip2.files).filter((x) => /lang\/ru_ru\.json$/i.test(x))
  console.log('ru_ru.json:', ru.length > 0 ? 'PASS (' + ru.length + ')' : 'FAIL')
  if (ru.length) {
    const d = JSON.parse(await zip2.file(ru[0]).async('text'))
    console.log('пример перевода:', Object.values(d).slice(0, 3).join(' | ').slice(0, 100))
  }
} catch (e) { console.log('DOWNLOAD FAIL:', String(e).slice(0, 120)) }
await b.close()
