import { chromium } from 'playwright'
const b = await chromium.launch()
const p = await b.newPage()
p.on('pageerror', e => console.log('PAGEERR:', String(e).slice(0, 150)))
await p.goto('http://127.0.0.1:5174/project/sodium', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(6000)
console.log('sodium h1:', await p.locator('h1').count() ? await p.locator('h1').first().textContent() : 'НЕТ', '| скелетон:', await p.locator('.skel').count())
await b.close()
