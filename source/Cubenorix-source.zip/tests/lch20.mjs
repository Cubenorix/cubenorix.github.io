// Живая проверка: AFK_Use-Jubik скачивается с сайта (jar из файлов репозитория)
import { chromium } from 'playwright'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await p.goto('https://cubenorix.github.io/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(5000)
await p.evaluate(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    if (!db.uploads?.length) {
      db.uploads = [{ id: 't1', title: 'AFK_Use-Jubik', description: 'АФК-мод', status: 'accepted', user: 'qwe8', display: 'qwe8', github: 'https://github.com/khlsha-web/AFK_Use-Jubik', versions: ['1.21.5'], loaders: ['fabric'], type: 'mod', downloads: 3, likes: 0, comments: [] }]
    }
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})
// данные в localStorage уже есть — перезагружаем, чтобы store их прочитал
await p.reload({ waitUntil: 'domcontentloaded' })
await p.waitForTimeout(6000)
await p.goto('https://cubenorix.github.io/#/project/afk-use-jubik', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(12000)
const dl = p.locator('.dl-panel a:has-text("Скачать файл")')
ok('на LIVE: кнопка «Скачать файл» у проекта автора', await dl.count() > 0)
const href = (await dl.count()) ? await dl.getAttribute('href') : ''
ok('raw-ссылка на jar автора', (href || '').includes('raw.githubusercontent.com/khlsha-web/AFK_Use-Jubik/HEAD/MINECR~1.JAR'))
if (href) {
  const head = await p.evaluate(async (u) => { const r = await fetch(u, { method: 'GET', headers: { Range: 'bytes=0-3' } }); const buf = await r.arrayBuffer(); return { ok: r.ok, zip: new Uint8Array(buf)[0] === 0x50 } }, href).catch(() => null)
  ok('это настоящий jar (PK-подпись zip)', !!head && head.ok && head.zip)
}
await b.close()
