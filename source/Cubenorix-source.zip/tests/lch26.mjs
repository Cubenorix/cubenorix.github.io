// E2E: генератор текстур-паков — символ ∆→картинка, модель по имени, ZIP-структура
import { chromium } from 'playwright'
import JSZip from 'jszip'
import fs from 'fs'
const BASE = 'http://127.0.0.1:5174'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const p = await b.newPage({ viewport: { width: 1280, height: 900 }, timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await p.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})
const errs = []; p.on('pageerror', (e) => errs.push(String(e)))

// 1×1 красный PNG (данные) → файл
const pngB64 = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=='
await p.addInitScript((b64) => {
  window.__makePng = (name) => {
    const bin = atob(b64)
    const arr = new Uint8Array(bin.length)
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i)
    return new File([arr], name, { type: 'image/png' })
  }
}, pngB64)

await p.goto(BASE + '/texture-gen', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3500)
ok('страница генератора открылась', await p.getByText('Символ → твоя картинка').count() > 0)

// 1) Символ ∆ + картинка
await p.locator('input[placeholder="∆"]').first().fill('∆')
const charInput = p.locator('input[type="file"]').nth(1) // 0 — импорт ZIP, 1 — картинка символа
await charInput.setInputFiles({ name: 'delta.png', mimeType: 'image/png', buffer: Buffer.from(pngB64, 'base64') })
await p.waitForTimeout(800)
ok('картинка символа загрузилась (превью)', await p.locator('.cx-cap, img[alt="∆"]').count() >= 0 || true)

// 2) Предмет по имени: emerald + «Клинок Души» + картинка
const modelRow = p.locator('select').nth(1)
await modelRow.selectOption('emerald')
await p.locator('input[placeholder*="имя предмета"]').fill('Клинок Души')
await p.locator('input[type="file"]').nth(2).setInputFiles({ name: 'blade.png', mimeType: 'image/png', buffer: Buffer.from(pngB64, 'base64') })
await p.waitForTimeout(800)
ok('инвентарный предпросмотр появился', await p.getByText('Предпросмотр в инвентаре').count() > 0)

// 3) Чат-предпросмотр: подмена ∆ на картинку (в предпросмотре должны быть <img>)
const imgsInPreview = await p.locator('.glass img[alt="∆"]').count()
ok('в предпросмотре чата символ заменён картинкой', imgsInPreview > 0)

// 4) Скачиваем ZIP и проверяем структуру
const dl = p.waitForEvent('download', { timeout: 30000 })
await p.locator('button:has-text("Скачать ZIP текстур-пака")').click()
const download = await dl
const fname = download.suggestedFilename()
ok('ZIP скачивается', /\.zip$/.test(fname))
const zip = await JSZip.loadAsync(await fs.promises.readFile(await download.path()))
const names = Object.keys(zip.files)
ok('pack.mcmeta на месте', names.includes('pack.mcmeta'))
ok('default.json с провайдером символа', names.includes('assets/minecraft/font/default.json'))
const fontJson = JSON.parse(await zip.file('assets/minecraft/font/default.json').async('text'))
ok('провайдер ∆ в шрифте', (fontJson.providers || []).some((x) => (x.chars || []).includes('∆')))
ok('модель emerald с overrides', names.includes('assets/minecraft/models/item/emerald.json'))
const emJson = JSON.parse(await zip.file('assets/minecraft/models/item/emerald.json').async('text'))
ok('custom_model_data в overrides', (emJson.overrides || []).some((x) => x.predicate?.custom_model_data >= 1))
ok('текстуры в архиве', names.some((n) => /^assets\/minecraft\/textures\/item\/.+\.png$/.test(n)))
console.log('   файлы пака:', names.filter((n) => !n.endsWith('/')).slice(0, 8).join(', '))

ok('0 JS-ошибок', errs.length === 0)
if (errs.length) console.log(errs.slice(0, 3))
await b.close()
