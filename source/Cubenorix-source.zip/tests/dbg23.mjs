import { chromium } from 'playwright'
const b = await chromium.launch()
const ctx = await b.newContext({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await ctx.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    db.uploads = [{ id: 't1', title: 'AFK_Use-Jubik', description: 'АФК', status: 'accepted', user: 'qwe8', github: 'https://github.com/FabricMC/fabric-api', versions: ['1.21.5'], loaders: ['fabric'], type: 'mod', downloads: 3, likes: 0, comments: [] }]
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})
const p = await ctx.newPage()
const reqs = []
p.on('response', async (r) => { if (r.url().includes('api.github.com')) reqs.push(r.status() + ' ' + r.url().slice(0, 90)) })
await p.goto('http://127.0.0.1:5174/project/afk-use-jubik', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(7000)
console.log('gh-запросы:', reqs)
const txt = await p.evaluate(() => document.body.innerText)
console.log('Скачать файл?', await p.locator('a:has-text("Скачать файл")').count(), '| Releases-надпись?', /Releases/.test(txt))
console.log(txt.slice(0, 100).replace(/\n+/g, ' | '))
await b.close()
