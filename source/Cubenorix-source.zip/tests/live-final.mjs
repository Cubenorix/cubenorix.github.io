import { chromium } from 'playwright'
const b = await chromium.launch(); const p = await b.newPage()
const errs = []; p.on('pageerror', e => errs.push(String(e)))
await p.addInitScript(() => { try { const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}'); db.lang = 'ru'; localStorage.setItem('cubenorixx.v1', JSON.stringify(db)) } catch {} })

// 1. Поиск «shine» → мод Shine первым
await p.goto('https://cubenorix.github.io/#/catalog?q=shine', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(6000)
const firstTitle = await p.locator('.cx-card h3').first().textContent().catch(() => '')
console.log('поиск «shine» на live → первый:', JSON.stringify(firstTitle.trim()), /shine/i.test(firstTitle) ? 'OK' : 'FAIL')

// 2. Регистрация: регион + извинение
await p.goto('https://cubenorix.github.io/#/register', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
console.log('регион-строка:', await p.getByText('По настройкам устройства ты из:').count() > 0 ? 'OK' : 'FAIL')
const regionText = await p.getByText('По настройкам устройства ты из:').textContent().catch(() => '')
console.log('  →', regionText.trim().slice(0, 90))
console.log('кнопка-извинение:', await p.locator('button:has-text("Извините, была ошибка региона")').count() > 0 ? 'OK' : 'FAIL')

// 3. Заметки о живом каталоге
await p.goto('https://cubenorix.github.io/#/catalog', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(4000)
console.log('заметка «в течение суток»:', await p.getByText('в течение суток').count() > 0 ? 'OK' : 'FAIL')

// 4. ИИ-проверка: блок в профиле админа + реальный вызов
await p.goto('https://cubenorix.github.io/#/login', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
const locked = p.locator('.region-locked.region-clickable')
if (await locked.count()) await locked.click()
await p.getByPlaceholder('ваш e-mail или ник').fill('Cubenorix')
await p.getByPlaceholder('Ваш пароль').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await p.locator('form button[type="submit"], form button:not([type])').first().click()
await p.waitForTimeout(2500)
await p.locator('button.tag:has-text("Настройки")').first().click()
await p.waitForTimeout(600)
console.log('HF-блок в профиле:', await p.getByText('ИИ-проверка (Hugging Face)').count() > 0 ? 'OK' : 'FAIL')
await p.locator('input[placeholder="hf_…"]').fill('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')
await p.locator('button:has-text("Сохранить токен")').click()
await p.waitForTimeout(500)
console.log('токен на устройстве:', (await p.evaluate(() => localStorage.getItem('cubenorixx.hf') || '')).startsWith('hf_') ? 'OK' : 'FAIL')
await p.goto('https://cubenorix.github.io/#/builds', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
await p.locator('button:has-text("ИИ-проверка")').click()
await p.waitForTimeout(25000)
const aiText = await p.evaluate(() => document.body.innerText.slice(0, 4000))
console.log('ИИ-проверка на live:', aiText.includes('ИИ-проверка:') && !aiText.includes('ИИ недоступен') ? 'OK — ИИ ответил' : 'FAIL/сеть')
console.log('JS-ошибок:', errs.length, errs.slice(0, 2))
await b.close()
