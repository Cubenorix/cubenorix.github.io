/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import {
  setAuthStorage,
  decodeJwtPayload,
  loginWithGoogleIdentity,
  registerLocalAccount,
  loginLocalAccount,
  currentLocalUser,
  ADMIN_EMAIL,
  ADMIN_USERNAME,
} from '../src/auth-local.js'

const mem = new Map()
setAuthStorage({
  getItem: (k) => (mem.has(k) ? mem.get(k) : null),
  setItem: (k, v) => mem.set(k, String(v)),
  removeItem: (k) => mem.delete(k),
})

const b64url = (obj) => Buffer.from(JSON.stringify(obj)).toString('base64url')
const fakeToken = (payload) => 'aaa.' + b64url(payload) + '.bbb'

test('decodeJwtPayload разбирает payload и выживает на мусоре', () => {
  const p = decodeJwtPayload(fakeToken({ sub: '123', email: 'a@b.c' }))
  assert.equal(p.sub, '123')
  assert.equal(decodeJwtPayload('not-a-jwt'), null)
  assert.equal(decodeJwtPayload(''), null)
  assert.equal(decodeJwtPayload(null), null)
})

test('вход через Google создаёт аккаунт и повторный вход даёт ТОТ ЖЕ аккаунт', async () => {
  const first = await loginWithGoogleIdentity({ sub: 'g-sub-1', email: 'ivan@gmail.com', name: 'Иван Петров' })
  assert.equal(first.ok, true)
  assert.equal(first.created, true)
  assert.equal(first.user.provider, 'google')
  const second = await loginWithGoogleIdentity({ sub: 'g-sub-1', email: 'ivan@gmail.com', name: 'Иван Петров' })
  assert.equal(second.created, false)
  assert.equal(second.user.username, first.user.username)
  assert.equal(currentLocalUser()?.email, 'ivan@gmail.com')
})

test('ник из Google-имени проходит санитизацию и не занимает чужие/зарезервированные ники', async () => {
  const a = await loginWithGoogleIdentity({ sub: 'g-sub-2', email: 'someone@gmail.com', name: 'Cubenorix!' })
  assert.notEqual(a.user.username.toLowerCase(), ADMIN_USERNAME.toLowerCase())
  assert.match(a.user.username, /^[A-Za-z0-9_-]{3,24}$/)
  const b = await loginWithGoogleIdentity({ sub: 'g-sub-3', email: 'other@gmail.com', name: 'Иван Петров' })
  assert.notEqual(b.user.username, a.user.username)
})

test('Google-вход не может пересоздать админа, но связывается с его почтой не должен', async () => {
  const r = await loginWithGoogleIdentity({ sub: 'attacker', email: ADMIN_EMAIL, name: 'Fake' })
  assert.equal(r.ok, true)
  assert.equal(r.created, false) // аккаунт уже существует (встроенный админ) — это ССЫЛКА, а не новый
  assert.equal(r.user.role, 'admin')
})

test('Google-вход привязывается к существующему аккаунту с паролем (оба способа работают)', async () => {
  const reg = await registerLocalAccount({ username: 'MixedUser', email: 'mixed@example.com', password: 'long-enough-password-123', consent: { termsAccepted: true, privacyAccepted: true, contentRulesAccepted: true, ageConfirmed: true } })
  assert.equal(reg.ok, true)
  const viaGoogle = await loginWithGoogleIdentity({ sub: 'g-mixed', email: 'mixed@example.com', name: 'Mixed' })
  assert.equal(viaGoogle.ok, true)
  assert.equal(viaGoogle.created, false)
  const viaPass = await loginLocalAccount({ email: 'mixed@example.com', password: 'long-enough-password-123' })
  assert.equal(viaPass.ok, true)
})

test('без почты от Google вход отклоняется', async () => {
  const r = await loginWithGoogleIdentity({ sub: 'x' })
  assert.equal(r.ok, false)
})
