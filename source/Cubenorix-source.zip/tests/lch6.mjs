// E2E: ± в каталоге → сборщик; модерация проектов админом
import { chromium } from 'playwright'

const BASE = 'http://127.0.0.1:5174'
const results = []
const ok = (name, cond) => { results.push([cond ? 'PASS' : 'FAIL', name]); console.log(cond ? 'PASS' : 'FAIL', '—', name); if (!cond) process.exitCode = 1 }

const browser = await chromium.launch()
const page = await browser.newPage()
const jsErrors = []
page.on('pageerror', (e) => jsErrors.push(String(e)))
await page.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})

// — 1. Каталог: + добавляет в черновик, бар внизу, «Собрать» ведёт в сборщик
await page.goto(BASE + '/catalog?q=sodium', { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(5000)
const addBtn = page.locator('.cx-card button[title="Добавить в сборку"]').first()
ok('кнопка «+ в сборку» на карточке', await addBtn.count() > 0)
if (await addBtn.count()) {
  await addBtn.click({ force: true })
  await page.waitForTimeout(500)
  ok('бар черновика появился «1 в сборке»', await page.getByText('в сборке').count() > 0)
  const second = page.locator('.cx-card button[title="Добавить в сборку"]').nth(1)
  if (await second.count()) { await second.click({ force: true }); await page.waitForTimeout(400) }
  ok('кнопка стала «−» у добавленного', await page.locator('.cx-card button[title="Убрать из сборки"]').count() > 0)
  await page.locator('button:has-text("Собрать")').first().click()
  await page.waitForTimeout(2500)
  ok('«Собрать» ведёт в /builds с модами', page.url().includes('/builds') && page.url().includes('mods='))
  const rawVal = await page.locator('textarea').first().inputValue().catch(() => '')
  ok('сборщик получил slug-и из каталога', /sodium|sodium-extra|reeses-sodium/i.test(rawVal) || page.url().includes('sodium'))
}

// — 2. Модерация: игрок отправляет проект, админ одобряет
const playerNick = 'TestPlayer' + String(Date.now()).slice(-6)
await page.goto(BASE + '/login', { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(2500)
const locked = page.locator('.region-locked.region-clickable')
if (await locked.count()) await locked.click()
await page.waitForTimeout(300)
await page.locator('button.tag:has-text("Создать аккаунт"), button.tag:has-text("Регистрация")').first().click()
await page.getByPlaceholder(/латиница, цифры/).fill(playerNick)
await page.getByPlaceholder('name@example.com').fill(playerNick.toLowerCase() + '@example.com')
await page.getByPlaceholder('Не менее 12 символов').fill('PlayerPassword123')
const boxes = page.locator('form input[type="checkbox"]:not(:checked)')
while (await boxes.count()) await boxes.nth(0).check()
await page.locator('form button[type="submit"], form button:not([type])').first().click()
await page.waitForTimeout(1500)
ok('игрок зарегистрирован', page.url().includes('/profile'))
ok('у игрока НЕТ вкладки «Модерация»', await page.locator('button.tag:has-text("Модерация")').count() === 0)

// отправка проекта: название + github + антивирус + отправить
await page.locator('button.tag:has-text("Мои проекты"), button.tag:has-text("проекты")').first().click()
await page.waitForTimeout(400)
await page.locator('input[placeholder*="азвание"], form input.field').first().fill('Мод-который-не-найдут')
await page.locator('form input.field').nth(1).fill('https://github.com/tester/repo')
await page.locator('button:has-text("Запустить проверку")').click()
await page.waitForTimeout(3000)
ok('антивирус пройден', await page.getByText('Проверка пройдена').count() > 0)
await page.locator('button[type="submit"]:has-text("Отправить"), form button.btn-primary[type="submit"], form button.btn-primary:not([type])').first().click()
await page.waitForTimeout(800)
ok('проект отправлен на модерацию', await page.getByText('на модерацию').count() > 0)
await page.locator('button:has-text("Выйти")').first().click()
await page.waitForTimeout(900)

// админ одобряет
await page.goto(BASE + '/login', { waitUntil: 'domcontentloaded' })
await page.waitForTimeout(2500)
await page.getByPlaceholder('ваш e-mail или ник').fill('Cubenorix')
await page.getByPlaceholder('Ваш пароль').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await page.locator('form button[type="submit"], form button:not([type])').first().click()
await page.waitForTimeout(1800)
await page.locator('button.tag:has-text("Модерация")').first().click()
await page.waitForTimeout(500)
ok('у админа есть вкладка «Модерация»', true)
const row = page.locator('div:has-text("Мод-который-не-найдут")').locator('button[title="Одобрить"]').first()
ok('проект игрока виден в очереди', await page.getByText('Мод-который-не-найдут').count() > 0)
if (await row.count()) {
  await row.click()
  await page.waitForTimeout(500)
  ok('после ✓ статус «принято»', await page.getByText('✓ принято').count() > 0)
}

ok('0 JS-ошибок', jsErrors.length === 0)
if (jsErrors.length) console.log('JS ERRORS:', jsErrors.slice(0, 5))
await browser.close()
