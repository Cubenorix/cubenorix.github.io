/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { uploadSlug, acceptedUploads, uploadProject } from '../src/localUploads.js'

test('uploadSlug: латиница, подчёркивания, регистр', () => {
  assert.equal(uploadSlug('AFK_Use-Jubik'), 'afk-use-jubik')
  assert.equal(uploadSlug('  My  Cool  Mod  '), 'my-cool-mod')
})

test('uploadSlug: кириллица допустима, мусор вырезается, пустота → fallback', () => {
  assert.equal(uploadSlug('Мод на мебель!'), 'мод-на-мебель')
  assert.equal(uploadSlug('???'), 'project')
  assert.equal(uploadSlug(''), 'project')
})

test('uploadProject: запись загрузки → объект проекта', () => {
  const up = { title: 'AFK_Use-Jubik', user: 'qwe8', display: 'qwe8', type: 'mod', description: 'АФК мод', github: 'https://github.com/khlsha-web/AFK_Use-Jubik', versions: ['1.21.5'], loaders: ['fabric'], status: 'accepted', modNote: 'Одобрено администрацией' }
  const pr = uploadProject(up)
  assert.equal(pr.slug, 'afk-use-jubik')
  assert.equal(pr.title, 'AFK_Use-Jubik')
  assert.equal(pr.author, 'qwe8')
  assert.equal(pr.local_upload, true)
  assert.equal(pr.external, true)
  assert.equal(pr.source_url, 'https://github.com/khlsha-web/AFK_Use-Jubik')
  assert.deepEqual(pr.game_versions, ['1.21.5'])
  assert.deepEqual(pr.loaders, ['fabric'])
})

test('acceptedUploads: только одобренные', () => {
  const db = { uploads: [{ id: '1', status: 'accepted', title: 'A' }, { id: '2', status: 'review', title: 'B' }, { id: '3', status: 'rejected', title: 'C' }, { id: '4', status: 'accepted', title: 'D' }] }
  assert.deepEqual(acceptedUploads(db).map((u) => u.title), ['A', 'D'])
  assert.deepEqual(acceptedUploads(null), [])
})
