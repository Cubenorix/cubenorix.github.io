// E2E: одобренная загрузка → страница проекта + ссылки (модерация/каталог/главная)
import { chromium } from 'playwright'
const BASE = 'http://127.0.0.1:5174'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
const errs = []; p.on('pageerror', (e) => errs.push(String(e)))
await p.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    if (db.uploads?.length) { localStorage.setItem('cubenorixx.v1', JSON.stringify(db)); return }
    db.uploads = [{
      id: 'test-up-1', title: 'AFK_Use-Jubik', description: 'Мод для АФК-игры: пусть работает за тебя.',
      type: 'mod', github: 'https://github.com/khlsha-web/AFK_Use-Jubik',
      versions: ['1.21.5'], loaders: ['fabric'], categories: ['utility'],
      user: 'qwe8', display: 'qwe8', status: 'review', virusChecked: true,
      platforms: [{ id: 'github', ok: true }], downloads: 12, likes: 0, at: Date.now(),
      comments: [{ user: 'Cubenorix', text: 'проект принят', at: Date.now() }],
    }]
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})

// 1) Админ входит и одобряет
await p.goto(BASE + '/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
await p.locator('button:has-text("Войти"), a:has-text("Войти")').first().click()
await p.waitForTimeout(2000)
const regionBlock = p.locator('.region-locked-title')
if (await regionBlock.count()) { await regionBlock.click(); await p.waitForTimeout(1200)
  { const ob = p.locator('.region-open-btn'); if (await ob.count()) { await ob.click(); await p.waitForTimeout(1200) } } }
await p.locator('input[type="text"]').fill('Cubenorix')
await p.locator('input[type="password"]').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await p.locator('form button.btn-primary').click()
await p.waitForTimeout(3000)
ok('админ вошёл', p.url().includes('profile'))

// 2) Профиль → Проекты → одобрить
await p.getByRole('button', { name: 'Проекты', exact: true }).click()
await p.waitForTimeout(1500)
ok('загрузка видна в очереди', await p.getByText('AFK_Use-Jubik').count() > 0)
await p.locator('button[title="Одобрить"]').first().click()
await p.waitForTimeout(1500)
ok('статус «принято»', await p.getByText('принято').count() > 0)

// 3) Ссылка «Открыть проект» → страница проекта
const openLink = p.locator('a:has-text("Открыть проект")')
ok('ссылка «Открыть проект» появилась', await openLink.count() > 0)
await openLink.first().click()
await p.waitForTimeout(2500)
ok('URL страницы проекта', p.url().includes('/project/afk-use-jubik'))
const proj = await p.evaluate(() => document.body.innerText)
ok('название на странице', /AFK_Use-Jubik/.test(proj))
ok('бейдж «Одобрено администрацией»', /Одобрено администрацией/.test(proj))
ok('ссылка на источник (GitHub)', await p.locator('a[href*="github.com/khlsha-web"]').count() > 0)
ok('автор @qwe8 виден', /qwe8/.test(proj))

// 4) Каталог: поиск находит проект автора
await p.goto(BASE + '/catalog?q=AFK', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(4500)
ok('каталог: секция «Проекты авторов Cubenorix»', await p.getByText('Проекты авторов Cubenorix').count() > 0)
await p.locator('a:has-text("AFK_Use-Jubik")').first().click()
await p.waitForTimeout(2000)
ok('из каталога открылся проект', p.url().includes('/project/afk-use-jubik'))

// 5) Главная: полоса «Проекты наших авторов»
await p.goto(BASE + '/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
ok('главная: «Проекты наших авторов»', await p.getByText('Проекты наших авторов').count() > 0)

ok('0 JS-ошибок', errs.length === 0)
if (errs.length) console.log(errs.slice(0, 3))
await b.close()
