// Выравнивание капчи: скриншот + геометрия (виджет по центру формы, не шире полей)
import { chromium } from 'playwright'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const LIVE = process.env.LIVE === '1'
const p = await b.newPage({ viewport: { width: 1280, height: 900 }, timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await p.goto(LIVE ? 'https://cubenorix.github.io/' : 'http://127.0.0.1:5174/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(5000)
const loginSel = 'button:has-text("Войти"), a:has-text("Войти")'
await p.locator(loginSel).first().click({ timeout: 20000 })
await p.waitForTimeout(3000)
const rb = p.locator('.region-locked-title')
if (await rb.count()) { await rb.click(); await p.waitForTimeout(1200)
  { const ob = p.locator('.region-open-btn'); if (await ob.count()) { await ob.click(); await p.waitForTimeout(1200) } } }
await p.waitForSelector('iframe[src*="api2/anchor"]', { timeout: 15000 }).catch(() => {})
await p.waitForTimeout(2000)
const cap = await p.locator('.cx-cap').boundingBox()
const form = await p.locator('form').first().boundingBox()
ok('виджет есть', !!cap)
if (cap && form) {
  const capCenter = cap.x + cap.width / 2
  const formCenter = form.x + form.width / 2
  ok(`виджет по центру формы (расхождение ${Math.abs(capCenter - formCenter).toFixed(0)}px)`, Math.abs(capCenter - formCenter) < 8)
  ok('виджет не шире полей формы', cap.width <= form.width + 2)
}
const inner = await p.locator('.cx-cap iframe').first().boundingBox().catch(() => null)
if (cap && inner) {
  const cropOk = inner.x >= cap.x - 2 && inner.x + inner.width <= cap.x + cap.width + 2 && inner.y + inner.height <= cap.y + cap.height + 42
  ok('iframe обрезан рамкой (баннер Google скрыт, низ на месте)', cropOk)
  ok('сдвиг вверх ≈24px (баннер срезан)', Math.abs((cap.y - inner.y) - 24) <= 4)
}
await p.locator('form').first().screenshot({ path: 'tests/artifacts/captcha-aligned.png' }).catch(() => {})
await b.close()
