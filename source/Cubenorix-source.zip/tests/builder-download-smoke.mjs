/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { chromium } from 'playwright'
import JSZip from 'jszip'
import assert from 'node:assert/strict'
import { readFile, rm } from 'node:fs/promises'

const base = process.env.CUBENORIXX_URL || 'http://127.0.0.1:5173'
const route = (path) => base.includes('.yapp.page') ? '/#' + path : path
const out = '/tmp/cubenorixx-builder-smoke.zip'
await rm(out, { force: true })

const browser = await chromium.launch({ headless: true })
const context = await browser.newContext({ locale: 'ru-RU', acceptDownloads: true })
const page = await context.newPage()
const errors = []
page.on('pageerror', (e) => errors.push(e.message))

await page.goto(base + route('/builds'), { waitUntil: 'domcontentloaded', timeout: 30000 })
await page.locator('textarea').first().fill('jei')
await page.getByRole('button', { name: /Подобрать|Resolve/i }).click()
await page.getByText(/1 из 1|1 of 1/i).waitFor({ timeout: 45000 })

const downloadPromise = page.waitForEvent('download', { timeout: 120000 })
await page.getByRole('button', { name: /Скачать ZIP|Download ZIP/i }).click()
const download = await downloadPromise
await download.saveAs(out)

const archive = await JSZip.loadAsync(await readFile(out))
const jars = Object.keys(archive.files).filter((name) => /^mods\/.*\.jar$/i.test(name) && !archive.files[name].dir)
assert.equal(jars.length >= 1, true, 'archive has no mods/*.jar')
for (const name of jars) {
  const bytes = await archive.file(name).async('uint8array')
  assert.equal(bytes[0], 0x50, `${name} is not ZIP/JAR`)
  assert.equal(bytes[1], 0x4b, `${name} is not ZIP/JAR`)
  assert.notEqual(new TextDecoder().decode(bytes.slice(0, 80)).toLowerCase().includes('<!doctype html'), true)
}
const readme = await archive.file('README.txt').async('text')
assert.match(readme, /\.minecraft\/mods/)
assert.deepEqual(errors, [])
console.log(JSON.stringify({ downloaded: download.suggestedFilename(), jars, bytes: (await readFile(out)).length }, null, 2))
await browser.close()
