// E2E: сборщик строго держит версию/лоадер; регистрация с IP-регионом; форма проекта
import { chromium } from 'playwright'
const BASE = 'http://127.0.0.1:5174'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch(); const p = await b.newPage()
const errs = []; p.on('pageerror', e => errs.push(String(e)))
await p.addInitScript(() => { try { const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}'); db.lang = 'ru'; localStorage.setItem('cubenorixx.v1', JSON.stringify(db)) } catch {} })

// 1. Сборщик: мод только на forge не должен подменить лоадер на fabric-сборке
await p.goto(BASE + '/builds', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2600)
const mcSel = p.locator('select').nth(1)   // 0: тип, 1: MC, 2: лоадер
await mcSel.selectOption('1.21.5')
const loaderSel = p.locator('select').nth(2)
const loaderVal = await loaderSel.inputValue().catch(() => '')
console.log('   лоадер по умолчанию:', loaderVal)
if (loaderVal !== 'fabric') await loaderSel.selectOption('fabric').catch(() => {})
await p.locator('textarea').first().fill('rubidium')
await p.getByRole('button', { name: 'Исправить сборку' }).first().click()
await p.waitForTimeout(16000)
const log = await p.evaluate(() => document.body.innerText)
ok('честный отчёт: forge-мод в fabric-сборке (без подмены ядра)', /совместимый файл[\s\S]{0,40}fabric|чужого ядра|лучше смотрится|нет для fabric/.test(log))
const fabricKept = await p.locator('select').nth(2).inputValue({ timeout: 8000 }).catch(() => 'нет')
ok('выбранный лоадер не изменён молча: ' + fabricKept, fabricKept === 'fabric')

// 2. Регистрация: IP-регион
await p.goto(BASE + '/register', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3500)
const regText = await p.getByText('Твой регион:').textContent().catch(() => '')
ok('строка региона есть', Boolean(regText))
console.log('   ', (regText || '').trim().slice(0, 110))
ok('больше регионов (кольца Сатурна и др.)', await p.getByText('Кольца Сатурна').count() > 0)

// 3. Ключ «секретный доступ» сносится при обновлении
const locked = p.locator('.region-locked.region-clickable')
if (await locked.count()) await locked.click()
await p.waitForTimeout(300)
await p.reload({ waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2500)
ok('после обновления страницы ключ снова не «активен» (шутка заново)', await p.locator('.region-locked.region-clickable').count() > 0)

// 4. Форма проекта: логотип, версии, лоадеры, категории
await locked.click().catch(() => {})
await p.waitForTimeout(300)
await p.getByPlaceholder(/латиница, цифры/).fill('UploadTest1')
await p.getByPlaceholder('name@example.com').fill('upload1@example.com')
await p.getByPlaceholder('Не менее 12 символов').fill('UploadPassword123')
const boxes = p.locator('form input[type="checkbox"]:not(:checked)')
while (await boxes.count()) await boxes.nth(0).check()
await p.locator('form button[type="submit"], form button:not([type])').first().click()
await p.waitForTimeout(1500)
await p.locator('button.tag:has-text("Мои проекты"), button.tag:has-text("проекты")').first().click()
await p.waitForTimeout(400)
ok('блок «Логотип проекта — как на Modrinth»', await p.getByText('Логотип проекта — как на Modrinth').count() > 0)
ok('чипы версий MC', await p.locator('button.tag:has-text("1.21.5")').count() > 0)
ok('чипы загрузчиков', await p.locator('button.tag:has-text("neoforge")').count() > 0)
ok('чипы категорий', await p.locator('button.tag:has-text("technology")').count() > 0)

// 5. Вкладка проектов модератора
await p.locator('button:has-text("Выйти")').first().click()
await p.waitForTimeout(800)
await p.goto(BASE + '/login', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(2300)
const lk2 = p.locator('.region-locked.region-clickable')
if (await lk2.count()) await lk2.click()
await p.getByPlaceholder('ваш e-mail или ник').fill('Cubenorix')
await p.getByPlaceholder('Ваш пароль').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await p.locator('form button[type="submit"], form button:not([type])').first().click()
await p.waitForTimeout(1600)
ok('вкладка «Проекты 📦» у админа', await p.locator('button.tag:has-text("Проекты 📦")').count() > 0)

// 6. Кнопка Discord скрыта без Client ID (код ждёт CID)
ok('0 JS-ошибок', errs.length === 0)
if (errs.length) console.log(errs.slice(0, 3))
await b.close()
