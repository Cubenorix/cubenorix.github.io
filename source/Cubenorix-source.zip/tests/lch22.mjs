// Живая проверка: капча с тестовым ключом — виджет, клик по галочке, вход с капчой
import { chromium } from 'playwright'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await p.goto('https://cubenorix.github.io/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(5000)
// чистим флаг «капча выключена» и старые переопределения ключа
await p.evaluate(() => { try { localStorage.removeItem('cubenorixx.recaptcha') } catch {} })
const loginSel = 'button:has-text("Log in"), a:has-text("Log in"), button:has-text("Войти"), a:has-text("Войти")'
await p.locator(loginSel).first().click()
await p.waitForTimeout(3000)
const rb = p.locator('.region-locked-title')
if (await rb.count()) { await rb.click(); await p.waitForTimeout(1500)
  { const ob = p.locator('.region-open-btn'); if (await ob.count()) { await ob.click(); await p.waitForTimeout(1200) } } }

// 1) виджет отрисовался
await p.waitForSelector('iframe[src*="api2/anchor"]', { timeout: 15000 }).catch(() => {})
ok('капча-виджет на странице (iframe)', await p.locator('iframe[src*="api2/anchor"]').count() > 0)

// 2) кликаем галочку внутри iframe Google
let clicked = false
try {
  const fl = p.frameLocator('iframe[src*="api2/anchor"]')
  await fl.locator('#recaptcha-anchor').click({ timeout: 8000 })
  clicked = true
} catch {}
ok('галочку «Я не робот» можно нажать', clicked)

// 3) токен получен, кнопка разблокировалась
let token = ''
for (let i = 0; i < 15; i++) {
  token = await p.evaluate(() => { try { return String(window.grecaptcha?.getResponse?.() || '') } catch { return '' } }).catch(() => '')
  if (token) break
  await p.waitForTimeout(1000)
}
ok('токен капчи получен (галочка решена)', token.length > 10)
const btnEnabled = await p.locator('form button.btn-primary').isEnabled().catch(() => false)
ok('кнопка входа активна с решённой капчой', btnEnabled)

// 4) вход владельца ПРОХОДИТ ВМЕСТЕ С КАПЧОЙ (без обходов)
await p.locator('input[type="text"]').fill('mc.7cubes.ru@gmail.com')
await p.locator('input[type="password"]').fill('pReEiCQPENveDHtnrfPI7dIA8Z6')
await p.locator('form button.btn-primary').click()
await p.waitForTimeout(5000)
const body = await p.evaluate(() => document.body.innerText)
ok('вход с капчой работает → профиль', p.url().includes('profile') && !/Неверный пароль/.test(body))
await b.close()
