import { chromium } from 'playwright'
const b = await chromium.launch()
const ctx = await b.newContext({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
await ctx.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    db.uploads = [{ id: 't1', title: 'AFK_Use-Jubik', description: 'АФК-мод', status: 'accepted', user: 'qwe8', display: 'qwe8', github: 'https://github.com/khlsha-web/AFK_Use-Jubik', versions: ['1.21.5'], loaders: ['fabric'], type: 'mod', downloads: 12, likes: 0, comments: [] }]
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})
const p = await ctx.newPage()
p.on('pageerror', e => console.log('PAGEERR:', String(e).slice(0, 200)))
await p.goto('http://127.0.0.1:5174/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(4000)
const txt = await p.evaluate(() => document.body.innerText)
console.log('Войти?', txt.includes('Войти'), '| первый текст:', txt.slice(0, 150).replace(/\n+/g, ' | '))
console.log('кнопок:', await p.locator('button').count())
await b.close()
