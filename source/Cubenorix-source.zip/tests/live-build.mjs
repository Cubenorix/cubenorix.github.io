import { chromium } from 'playwright'
const b = await chromium.launch(); const p = await b.newPage()
const errs = []; p.on('pageerror', e => errs.push(String(e)))
await p.addInitScript(() => { try { const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}'); db.lang = 'ru'; localStorage.setItem('cubenorixx.v1', JSON.stringify(db)) } catch {} })
await p.goto('https://cubenorix.github.io/#/catalog?q=sodium', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(6000)
const add = p.locator('.cx-card button[title="Добавить в сборку"]').first()
console.log('кнопка «+» на live:', await add.count() > 0 ? 'OK' : 'FAIL')
if (await add.count()) {
  await add.click({ force: true })
  await p.waitForTimeout(800)
  console.log('бар сборки на live:', await p.locator('.draft-bar').count() > 0 ? 'OK' : 'FAIL')
  const соб = p.locator('.draft-bar button:has-text("Собрать")')
  if (await соб.count()) {
    await соб.click()
    await p.waitForTimeout(3500)
    console.log('после «Собрать» URL:', p.url().includes('/builds') ? 'OK ' + decodeURIComponent(p.url()).slice(0, 90) : 'FAIL ' + p.url())
    const raw = await p.locator('textarea').first().inputValue().catch(() => '')
    console.log('сборщик получил мод:', /sodium/i.test(raw) ? 'OK (' + raw.slice(0, 40) + ')' : 'FAIL')
  }
}
console.log('JS-ошибок:', errs.length, errs.slice(0, 2))
await b.close()
