/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { setAuthStorage, loginWithDiscordIdentity, currentLocalUser } from '../src/auth-local.js'

const mem = new Map()
setAuthStorage({
  getItem: (k) => (mem.has(k) ? mem.get(k) : null),
  setItem: (k, v) => mem.set(k, String(v)),
  removeItem: (k) => mem.delete(k),
})

test('Discord: создаёт аккаунт без email (discord-id ключ) и повторный вход — тот же профиль', async () => {
  const a = await loginWithDiscordIdentity({ id: '555000111', username: 'dis.user', globalName: 'DisUser' })
  assert.equal(a.ok, true)
  assert.equal(a.created, true)
  assert.equal(a.user.provider, 'discord')
  const b = await loginWithDiscordIdentity({ id: '555000111', username: 'dis.user', globalName: 'DisUser' })
  assert.equal(b.created, false)
  assert.equal(b.user.username, a.user.username)
  assert.equal(currentLocalUser()?.discordId, '555000111')
})

test('Discord: с реальной почтой связывается с существующим аккаунтом этой почты', async () => {
  const a = await loginWithDiscordIdentity({ id: '777', username: 'someone', globalName: 'S', email: 'shared@gmail.com' })
  assert.equal(a.created, true)
  const b = await loginWithDiscordIdentity({ id: '888', username: 'another', globalName: 'A', email: 'shared@gmail.com' })
  assert.equal(b.created, false)
  assert.equal(b.user.username, a.user.username)
})

test('Discord: без id отказ', async () => {
  assert.equal((await loginWithDiscordIdentity({})).ok, false)
})
