// ПУБЛИЧНОСТЬ: обычный посетитель (пустое устройство) видит проекты авторов и их комментарии
import { chromium } from 'playwright'
const BASE = process.env.LIVE ? 'https://cubenorix.github.io' : 'http://127.0.0.1:5174'
const ok = (n, c) => { console.log(c ? 'PASS' : 'FAIL', '—', n); if (!c) process.exitCode = 1 }
const b = await chromium.launch()
const ctx = await b.newContext({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
const p = await ctx.newPage()
const errs = []; p.on('pageerror', (e) => errs.push(String(e)))
// НИКАКОГО посева: это чистый посетитель

// 1) Главная: секция «Проекты наших авторов» с карточкой AFK
await p.goto(BASE + '/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(6000)
ok('глава: секция «Проекты наших авторов» видна посетителю', await p.getByText('Проекты наших авторов').count() > 0)
ok('карточка AFK_Use-Jubik на главной', await p.locator('a:has-text("AFK_Use-Jubik")').count() > 0)

// 2) Каталог: секция авторов по запросу
await p.goto(BASE + '/catalog?q=AFK', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(6000)
ok('каталог: «Проекты авторов Cubenorix» видна посетителю', await p.getByText('Проекты авторов Cubenorix').count() > 0)

// 3) Страница проекта: бейдж, автор, публичный комментарий
await p.goto(BASE + (process.env.LIVE ? '/#/project/afk-use-jubik' : '/project/afk-use-jubik'), { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(9000)
const txt = await p.evaluate(() => document.body.innerText)
ok('страница проекта открылась у посетителя', /AFK_Use-Jubik/.test(txt))
ok('бейдж «Одобрено администрацией»', /Одобрено администрацией/.test(txt))
ok('автор @qwe8 виден', /qwe8/.test(txt))
const comTab = p.locator('button:has-text("Комментарии"), [role="tab"]:has-text("Комментарии")').first()
if (await comTab.count()) { await comTab.click().catch(() => {}); await p.waitForTimeout(1500) }
const txt2 = await p.evaluate(() => document.body.innerText)
ok('публичный комментарий администрации виден', /Проект принят администрацией Cubenorix/.test(txt2))
ok('кнопка скачивания с GitHub у посетителя', await p.locator('.dl-panel a:has-text("Скачать файл"), a:has-text("Открыть GitHub автора")').count() > 0)

ok('0 JS-ошибок', errs.length === 0)
if (errs.length) console.log(errs.slice(0, 3))
await b.close()
