/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
// Встроенный аккаунт администрации: вход, уровень МАКС, защита от удаления,
// закреплённый логин, смена пароля, резервирование ника и почты.
import test from 'node:test'
import assert from 'node:assert/strict'
import {
  setAuthStorage,
  registerLocalAccount,
  loginLocalAccount,
  currentLocalUser,
  updateLocalProfile,
  deleteLocalAccountAsync,
  changeLocalPassword,
  logoutLocalAccount,
  ADMIN_EMAIL,
  ADMIN_USERNAME,
  OFFICIAL_EMAIL,
} from '../src/auth-local.js'

const mem = new Map()
setAuthStorage({
  getItem: (k) => (mem.has(k) ? mem.get(k) : null),
  setItem: (k, v) => mem.set(k, String(v)),
  removeItem: (k) => mem.delete(k),
})

const ADMIN_PASS = 'pReEiCQPENveDHtnrfPI7dIA8Z6'
const CONSENT = { termsAccepted: true, privacyAccepted: true, contentRulesAccepted: true, ageConfirmed: true }

test('admin: вход по e-mail, роль admin и максимальный уровень', async () => {
  const result = await loginLocalAccount({ email: ADMIN_EMAIL, password: ADMIN_PASS })
  assert.equal(result.ok, true)
  assert.equal(result.user.username, ADMIN_USERNAME)
  assert.equal(result.user.role, 'admin')
  assert.equal(result.user.level, 'max')
  assert.equal(currentLocalUser()?.role, 'admin')
})

test('admin: вход по нику Cubenorix без e-mail', async () => {
  const result = await loginLocalAccount({ email: ADMIN_USERNAME, password: ADMIN_PASS })
  assert.equal(result.ok, true)
  assert.equal(result.user.email, ADMIN_EMAIL)
  assert.equal(result.user.role, 'admin')
})

test('admin: неверный пароль отклоняется', async () => {
  const result = await loginLocalAccount({ email: ADMIN_EMAIL, password: 'wrong-pass-12345' })
  assert.equal(result.ok, false)
  assert.match(result.error, /Неверный пароль/)
})

test('почта администрации зарезервирована при регистрации', async () => {
  const result = await registerLocalAccount({ username: 'SomeoneElse', email: ADMIN_EMAIL, password: 'long-enough-password-123', consent: CONSENT })
  assert.equal(result.ok, false)
  assert.match(result.error, /уже зарегистрирован/)
})

test('ник Cubenorix зарезервирован при регистрации', async () => {
  const result = await registerLocalAccount({ username: 'Cubenorix', email: 'fan@example.com', password: 'long-enough-password-123', consent: CONSENT })
  assert.equal(result.ok, false)
  assert.match(result.error, /ник уже занят/i)
})

test('обычный пользователь: регистрация, роль user, вход по никy и смена ника', async () => {
  const reg = await registerLocalAccount({ username: 'SteveTest', email: 'steve@example.com', password: 'long-enough-password-123', consent: CONSENT })
  assert.equal(reg.ok, true)
  assert.equal(reg.user.role, 'user')
  assert.notEqual(reg.user.level, 'max')
  logoutLocalAccount()
  const byNick = await loginLocalAccount({ email: 'stevetest', password: 'long-enough-password-123' })
  assert.equal(byNick.ok, true)
  const rename = updateLocalProfile({ username: 'AlexTest' })
  assert.equal(rename.ok, true)
  assert.equal(rename.user.username, 'AlexTest')
})

test('admin: логин закреплён — сменить ник нельзя', async () => {
  await loginLocalAccount({ email: ADMIN_EMAIL, password: ADMIN_PASS })
  const result = updateLocalProfile({ username: 'NotAdmin', display: 'Владелец' })
  assert.equal(result.ok, true)
  assert.equal(result.user.username, ADMIN_USERNAME)
  assert.equal(result.user.display, 'Владелец')
})

test('admin: аккаунт защиты от удаления', async () => {
  await loginLocalAccount({ email: ADMIN_EMAIL, password: ADMIN_PASS })
  const result = await deleteLocalAccountAsync()
  assert.equal(result.ok, false)
  assert.match(result.error, /защищён от удаления/)
  assert.equal(currentLocalUser()?.role, 'admin')
})

test('admin: смена пароля (неверный текущий → отказ; корректный → вход только с новым)', async () => {
  await loginLocalAccount({ email: ADMIN_EMAIL, password: ADMIN_PASS })
  const bad = await changeLocalPassword({ current: 'nope-not-the-password', next: 'brand-new-password-456' })
  assert.equal(bad.ok, false)
  const ok = await changeLocalPassword({ current: ADMIN_PASS, next: 'brand-new-password-456' })
  assert.equal(ok.ok, true)
  logoutLocalAccount()
  const oldPw = await loginLocalAccount({ email: ADMIN_EMAIL, password: ADMIN_PASS })
  assert.equal(oldPw.ok, false)
  const newPw = await loginLocalAccount({ email: ADMIN_EMAIL, password: 'brand-new-password-456' })
  assert.equal(newPw.ok, true)
  assert.equal(newPw.user.role, 'admin')
})

test('официальная почта проекта имеет корректный вид', () => {
  assert.equal(OFFICIAL_EMAIL, 'cubenorix.official@gmail.com')
})
