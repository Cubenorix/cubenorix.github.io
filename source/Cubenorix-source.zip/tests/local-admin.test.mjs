/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
// Встроенный аккаунт администрации: вход, уровень МАКС, защита от удаления,
// закреплённый логин, смена пароля, резервирование ника и почты.
import test from 'node:test'
import assert from 'node:assert/strict'
import {
  setAuthStorage,
  registerLocalAccount,
  loginLocalAccount,
  currentLocalUser,
  updateLocalProfile,
  deleteLocalAccountAsync,
  changeLocalPassword,
  logoutLocalAccount,
  ADMIN_EMAIL,
  ADMIN_USERNAME,
  OFFICIAL_EMAIL,
} from '../src/auth-local.js'

const mem = new Map()
setAuthStorage({
  getItem: (k) => (mem.has(k) ? mem.get(k) : null),
  setItem: (k, v) => mem.set(k, String(v)),
  removeItem: (k) => mem.delete(k),
})

const ADMIN_PASS = 'pReEiCQPENveDHtnrfPI7dIA8Z6'
const CONSENT = { termsAccepted: true, privacyAccepted: true, contentRulesAccepted: true, ageConfirmed: true }

test('admin: вход по e-mail, роль admin и максимальный уровень', async () => {
  const result = await loginLocalAccount({ email: ADMIN_EMAIL, password: ADMIN_PASS })
  assert.equal(result.ok, true)
  assert.equal(result.user.username, ADMIN_USERNAME)
  assert.equal(result.user.role, 'admin')
  assert.equal(result.user.level, 'max')
  assert.equal(currentLocalUser()?.role, 'admin')
})

test('admin: вход по нику Cubenorix без e-mail', async () => {
  const result = await loginLocalAccount({ email: ADMIN_USERNAME, password: ADMIN_PASS })
  assert.equal(result.ok, true)
  assert.equal(result.user.email, ADMIN_EMAIL)
  assert.equal(result.user.role, 'admin')
})

test('admin: неверный пароль отклоняется', async () => {
  const result = await loginLocalAccount({ email: ADMIN_EMAIL, password: 'wrong-pass-12345' })
  assert.equal(result.ok, false)
  assert.match(result.error, /Неверный пароль/)
})

test('почта администрации зарезервирована при регистрации', async () => {
  const result = await registerLocalAccount({ username: 'SomeoneElse', email: ADMIN_EMAIL, password: 'long-enough-password-123', consent: CONSENT })
  assert.equal(result.ok, false)
  assert.match(result.error, /уже зарегистрирован/)
})

test('ник Cubenorix зарезервирован при регистрации', async () => {
  const result = await registerLocalAccount({ username: 'Cubenorix', email: 'fan@example.com', password: 'long-enough-password-123', consent: CONSENT })
  assert.equal(result.ok, false)
  assert.match(result.error, /ник уже занят/i)
})

test('обычный пользователь: регистрация, роль user, вход по никy и смена ника', async () => {
  const reg = await registerLocalAccount({ username: 'SteveTest', email: 'steve@example.com', password: 'long-enough-password-123', consent: CONSENT })
  assert.equal(reg.ok, true)
  assert.equal(reg.user.role, 'user')
  assert.notEqual(reg.user.level, 'max')
  logoutLocalAccount()
  const byNick = await loginLocalAccount({ email: 'stevetest', password: 'long-enough-password-123' })
  assert.equal(byNick.ok, true)
  const rename = updateLocalProfile({ username: 'AlexTest' })
  assert.equal(rename.ok, true)
  assert.equal(rename.user.username, 'AlexTest')
})

test('admin: логин закреплён — сменить ник нельзя', async () => {
  await loginLocalAccount({ email: ADMIN_EMAIL, password: ADMIN_PASS })
  const result = updateLocalProfile({ username: 'NotAdmin', display: 'Владелец' })
  assert.equal(result.ok, true)
  assert.equal(result.user.username, ADMIN_USERNAME)
  assert.equal(result.user.display, 'Владелец')
})

test('admin: аккаунт защиты от удаления', async () => {
  await loginLocalAccount({ email: ADMIN_EMAIL, password: ADMIN_PASS })
  const result = await deleteLocalAccountAsync()
  assert.equal(result.ok, false)
  assert.match(result.error, /защищён от удаления/)
  assert.equal(currentLocalUser()?.role, 'admin')
})

// Семантика с 30.08.2026: официальный пароль владельца — «мастер-пароль».
// Смена пароля в профиле работает, но мастер-пароль всегда восстанавливает
// доступ и эталонную запись (самолечение при утере/старой сборке).
test('admin: смена пароля (неверный текущий → отказ; новый входит; мастер-пароль восстанавливает эталон)', async () => {
  await loginLocalAccount({ email: ADMIN_EMAIL, password: ADMIN_PASS })
  const bad = await changeLocalPassword({ current: 'nope-not-the-password', next: 'brand-new-password-456' })
  assert.equal(bad.ok, false)
  const ok = await changeLocalPassword({ current: ADMIN_PASS, next: 'brand-new-password-456' })
  assert.equal(ok.ok, true)
  logoutLocalAccount()
  const newPw = await loginLocalAccount({ email: ADMIN_EMAIL, password: 'brand-new-password-456' })
  assert.equal(newPw.ok, true)
  assert.equal(newPw.user.role, 'admin')
  logoutLocalAccount()
  // мастер-пароль владельца пускает даже после смены пароля
  const master = await loginLocalAccount({ email: ADMIN_EMAIL, password: ADMIN_PASS })
  assert.equal(master.ok, true)
  assert.equal(master.user.role, 'admin')
  logoutLocalAccount()
  const newPwAgain = await loginLocalAccount({ email: ADMIN_EMAIL, password: 'brand-new-password-456' })
  assert.equal(newPwAgain.ok, false, 'после самолечения запись эталонная — сменённый пароль больше не действует')
})

test('официальная почта проекта имеет корректный вид', () => {
  assert.equal(OFFICIAL_EMAIL, 'cubenorix.official@gmail.com')
})

test('самолечение: официальный пароль восстанавливает разошедшуюся запись админа', async () => {
  const store = new Map()
  setAuthStorage({
    getItem: (k) => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => store.set(k, String(v)),
    removeItem: (k) => store.delete(k),
  })
  // «сломанная» запись: другой соль/хеш (старая сборка или случайная смена)
  store.set('cubenorixx.accounts.v1', JSON.stringify({
    [ADMIN_EMAIL]: { username: 'Cubenorix', email: ADMIN_EMAIL, salt: 'deadbeef', hash: 'not-the-right-hash', created: '2026-08-01T00:00:00.000Z', role: 'admin', profile: { bio: 'мой профиль' } },
  }))
  const bad = await loginLocalAccount({ email: ADMIN_EMAIL, password: 'totally-wrong-password' })
  assert.equal(bad.ok, false)
  const result = await loginLocalAccount({ email: ADMIN_EMAIL, password: ADMIN_PASS })
  assert.equal(result.ok, true)
  assert.equal(result.user.role, 'admin')
  const fixed = JSON.parse(store.get('cubenorixx.accounts.v1'))[ADMIN_EMAIL]
  assert.equal(fixed.hash, 'f395e001fce26d51f925fd9c1a09aabf446bcbc4903abd7b5a42c0cdfd68de56')
  assert.equal(fixed.profile.bio, 'мой профиль', 'профиль пользователя сохраняется')
  // и обычный вход после лечения тоже работает
  const again = await loginLocalAccount({ email: ADMIN_USERNAME, password: ADMIN_PASS })
  assert.equal(again.ok, true)
})
