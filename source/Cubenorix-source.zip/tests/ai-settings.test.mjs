/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { DEFAULT_HF_TOKEN, getHfToken, setHfToken, isDefaultHfToken } from '../src/ai.js'

const store = new Map()
globalThis.localStorage = {
  getItem: (k) => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, String(v)),
  removeItem: (k) => store.delete(k),
}

test('ИИ: по умолчанию используется стандартный ключ владельца', () => {
  assert.equal(getHfToken(), DEFAULT_HF_TOKEN)
  assert.equal(isDefaultHfToken(), true)
})

test('ИИ: свой ключ сохраняется и имеет приоритет, «вернуть стандартный» стирает', () => {
  setHfToken('hf_my_own_key_123')
  assert.equal(getHfToken(), 'hf_my_own_key_123')
  assert.equal(isDefaultHfToken(), false)
  setHfToken('')
  assert.equal(getHfToken(), DEFAULT_HF_TOKEN)
  assert.equal(isDefaultHfToken(), true)
})

test('ИИ: стандартный ключ имеет форму токена Hugging Face', () => {
  assert.match(DEFAULT_HF_TOKEN, /^hf_[A-Za-z0-9]{20,}$/)
})
