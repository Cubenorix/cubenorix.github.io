/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { DEFAULT_HF_TOKEN, getHfToken, setHfToken, isDefaultHfToken, aiAllowed, aiQuota, aiCan, aiSpend, hasOwnKey, AI_DAY_LIMIT, AI_HOUR_LIMIT } from '../src/ai.js'

const store = new Map()
globalThis.localStorage = {
  getItem: (k) => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, String(v)),
  removeItem: (k) => store.delete(k),
}
globalThis.location = { hostname: 'cubenorix.github.io' }

test('ИИ: ключ собирается из упакованных кодов на разрешённом домене', () => {
  assert.equal(aiAllowed(), true)
  assert.match(getHfToken(), /^hf_[A-Za-z0-9]{20,}$/)
  assert.equal(isDefaultHfToken(), true)
})

test('ИИ: на чужом домене ключ не отдаётся вовсе', () => {
  const old = globalThis.location
  globalThis.location = { hostname: 'evil-site.example' }
  assert.equal(aiAllowed(), false)
  assert.equal(getHfToken(), '')
  globalThis.location = old
})

test('ИИ: свой ключ приоритетен, «вернуть стандартный» стирает', () => {
  setHfToken('hf_my_own_key_123')
  assert.equal(hasOwnKey(), true)
  assert.equal(getHfToken(), 'hf_my_own_key_123')
  setHfToken('')
  assert.equal(getHfToken(), DEFAULT_HF_TOKEN)
})

test('ИИ: квота стандартного ключа ограничивает и восстанавливается с новым днём', () => {
  assert.equal(hasOwnKey(), false)
  for (let i = 0; i < AI_HOUR_LIMIT; i++) assert.equal(aiSpend(1), true)
  assert.equal(aiCan(1), false, 'часовой лимит исчерпан')
  // свой ключ снимает лимиты
  setHfToken('hf_my_own_key_123')
  assert.equal(aiCan(1), true)
  assert.equal(aiSpend(5), true)
  setHfToken('')
  // новый день — счётчики обнулились
  const raw = JSON.parse(store.get('cubenorixx.ai.q'))
  raw.d = '2000-01-01'
  store.set('cubenorixx.ai.q', JSON.stringify(raw))
  assert.equal(aiCan(1), true)
})
