import { chromium } from 'playwright'
const b = await chromium.launch()
const p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
p.on('pageerror', e => console.log('PAGE ERR:', String(e).slice(0, 300)))
await p.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    db.uploads = [{ id: 't1', title: 'AFK_Use-Jubik', description: 'тест описание', status: 'accepted', user: 'qwe8', display: 'qwe8', github: 'https://github.com/khlsha-web/AFK_Use-Jubik', versions: ['1.21.5'], loaders: ['fabric'], type: 'mod', downloads: 12, likes: 0, comments: [] }]
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})
await p.goto('http://127.0.0.1:5174/', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(3000)
// клиентская навигация по Link на главной «Проекты наших авторов»
const card = p.locator('a:has-text("AFK_Use-Jubik")').first()
if (await card.count()) {
  await card.click()
  await p.waitForTimeout(4000)
  console.log('url:', p.url())
  console.log('h1:', await p.locator('h1').first().textContent().catch(() => 'НЕТ'))
  const txt = await p.evaluate(() => document.body.innerText)
  console.log('бейдж?', txt.includes('Одобрено администрацией'), '| github-ссылка?', await p.locator('a[href*="github.com/khlsha-web"]').count(), '| qwe8?', txt.includes('qwe8'))
} else {
  console.log('карточка на главной НЕ найдена')
  const errs = await p.evaluate(() => document.body.innerText.slice(0, 200))
  console.log(errs.replace(/\n+/g, ' | '))
}
await b.close()
