import { chromium } from 'playwright'
const b = await chromium.launch(); const p = await b.newPage()
p.on('pageerror', e => console.log('PAGE ERR:', String(e).slice(0, 300)))
p.on('console', m => { if (m.type() === 'error' && !m.text().includes('404')) console.log('CON:', m.text().slice(0, 200)) })
await p.goto('http://127.0.0.1:5174/builds', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(4000)
console.log('h1:', await p.locator('h1').first().textContent().catch(() => 'НЕТ'))
console.log('selects:', await p.locator('select').count())
await b.close()
