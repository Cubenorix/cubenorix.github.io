import { chromium } from 'playwright'
const b = await chromium.launch()
const p = await b.newPage({ timezoneId: 'Europe/Moscow', locale: 'ru-RU' })
p.on('pageerror', e => console.log('PAGE ERR:', String(e).slice(0, 200)))
p.on('console', m => { if (m.type() === 'error') console.log('CON:', m.text().slice(0, 160)) })
await p.addInitScript(() => {
  try {
    const db = JSON.parse(localStorage.getItem('cubenorixx.v1') || '{}')
    db.lang = 'ru'
    db.uploads = [{ id: 't1', title: 'AFK_Use-Jubik', description: 'тест описание', status: 'accepted', user: 'qwe8', display: 'qwe8', github: 'https://github.com/khlsha-web/AFK_Use-Jubik', versions: ['1.21.5'], loaders: ['fabric'], type: 'mod', downloads: 12, likes: 0, comments: [] }]
    localStorage.setItem('cubenorixx.v1', JSON.stringify(db))
  } catch {}
})
await p.goto('http://127.0.0.1:5174/#/project/afk-use-jubik', { waitUntil: 'domcontentloaded' })
await p.waitForTimeout(5000)
console.log('h1:', await p.locator('h1').first().textContent().catch(() => 'НЕТ'))
const txt = await p.evaluate(() => document.body.innerText)
console.log('бейдж?', txt.includes('Одобрено администрацией'), '| github?', txt.includes('github.com'), '| qwe8?', txt.includes('qwe8'))
console.log(txt.slice(0, 350).replace(/\n+/g, ' | '))
await b.close()
