/*
 * Cubenorixx - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorixx Team
 */
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
