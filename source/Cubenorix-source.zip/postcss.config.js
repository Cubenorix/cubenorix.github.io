/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
