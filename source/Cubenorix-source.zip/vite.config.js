/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { createHash, randomBytes } from 'crypto'
import { writeFileSync, createReadStream, unlink, readdirSync, readFileSync, statSync } from 'fs'
import { tmpdir } from 'os'
import { join } from 'path'
import { handleAgg } from './agg-middleware.js'
import { pngZip } from './polyglot.js'

const DEFAULT_PUBLIC_ORIGIN = 'https://cubenorixx.romantic-buffalo.workers.dev'
const PUBLIC_ORIGIN = String(process.env.CUBENORIXX_ORIGIN || DEFAULT_PUBLIC_ORIGIN).replace(/\/$/, '')
if (!/^https:\/\/[A-Za-z0-9.-]+(?::\d+)?$/.test(PUBLIC_ORIGIN)) {
  throw new Error('CUBENORIXX_ORIGIN must be an HTTPS origin without a path')
}

const nonces = new Map()
const tokens = new Map()
const hits = new Map()
const trCache = new Map()
const ipCache = new Map()
const pingCache = new Map()
const pingPromises = new Map()
let gtxBlockedUntil = 0

function mapLang(code) {
  const c = String(code || 'en')
  if (c === 'zh-Hans' || c === 'zh') return 'zh-CN'
  if (c === 'ua') return 'uk'
  return c
}

async function viaGtx(q, to, from) {
  const tl = mapLang(to)
  const sl0 = !from || from === 'auto' ? 'auto' : mapLang(from)
  const once = async (sl) => {
    const u = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=' + encodeURIComponent(sl) + '&tl=' + encodeURIComponent(tl) + '&dt=t&q=' + encodeURIComponent(String(q).slice(0, 1800))
    if (Date.now() < gtxBlockedUntil) throw new Error('gtx cooldown')
    const r = await fetch(u, { headers: { 'User-Agent': 'Mozilla/5.0 Cubenorix' } })
    if (!r.ok) {
      if (r.status === 429) gtxBlockedUntil = Date.now() + 10 * 60 * 1000
      throw new Error('gtx ' + r.status)
    }
    const j = await r.json()
    return (j?.[0] || []).map((x) => x?.[0] || '').join('').trim()
  }
  let text = await once(sl0)
  if (!text) text = await once('auto')
  if (!text) throw new Error('gtx empty')
  return text
}

function decodeHtmlText(value) {
  const named = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' }
  return String(value || '')
    .replace(/<[^>]+>/g, '')
    .replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (_, code) => {
      if (code[0] === '#') {
        const n = code[1].toLowerCase() === 'x' ? parseInt(code.slice(2), 16) : parseInt(code.slice(1), 10)
        return Number.isFinite(n) ? String.fromCodePoint(n) : _
      }
      return named[code.toLowerCase()] || _
    })
    .trim()
}

async function viaGoogleMobile(q, to, from) {
  const params = new URLSearchParams({
    sl: !from || from === 'auto' ? 'auto' : mapLang(from),
    tl: mapLang(to),
    q: String(q).slice(0, 1500),
  })
  const r = await fetch('https://translate.google.com/m?' + params, {
    headers: { 'User-Agent': 'Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Cubenorix' },
  })
  if (!r.ok) throw new Error('google mobile ' + r.status)
  const html = await r.text()
  const match = html.match(/class=["']result-container["'][^>]*>([\s\S]*?)<\/div>/i)
  const text = decodeHtmlText(match?.[1])
  if (!text) throw new Error('google mobile empty')
  return text
}

function ipOf(req) {
  return String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '0').split(',')[0].trim()
}
function cookie(req, name) {
  const m = String(req.headers.cookie || '').match(new RegExp('(?:^|; )' + name + '=([^;]*)'))
  return m ? decodeURIComponent(m[1]) : ''
}
function gated(req) {
  const t = cookie(req, 'cx_gate')
  const rec = tokens.get(t)
  return Boolean(rec && rec.exp > Date.now())
}
function limited(ip, key, max, windowMs) {
  const k = ip + ':' + key
  const now = Date.now()
  const rec = hits.get(k) || { n: 0, t: now }
  if (now - rec.t > windowMs) { rec.n = 0; rec.t = now }
  rec.n += 1
  hits.set(k, rec)
  return rec.n > max
}
function readBody(req) {
  return new Promise((resolve) => {
    const chunks = []
    req.on('data', (c) => chunks.push(c))
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString() || '{}')) } catch { resolve({}) }
    })
  })
}

const ALLOW_HOSTS = [
  'modrinth.com', 'cdn.modrinth.com', 'api.modrinth.com', 'modrinth.black',
  'curseforge.com', 'forgecdn.net', 'mediafilez.forgecdn.net',
  'planetminecraft.com', 'hangar.papermc.io', 'papermc.io',
  'spigotmc.org', 'polymart.org', 'voxel.shop', 'builtbybit.com', 'spongepowered.org',
  'mcpedl.com', 'minecraftmaps.com', 'smithed.net', 'vanillatweaks.net',
  'shaderlabs.org', 'minecraft-inside.ru', 'bbsmc.net', 'minebbs.com',
  'shadersmods.com', 'createmod.com', 'github.com', 'githubusercontent.com',
  '10minecraft.ru', 'namemc.com', 'poggit.pmmp.io', 'feed-the-beast.com',
  'hangarcdn.papermc.io', 'papermc.io', 'api.spiget.org',
  'mcsrvstat.us', 'api.mcsrvstat.us', 'mc-heads.net', 'crafatar.com', 'minotar.net', 'namemc.com',
  'ru-minecraft.ru', 'minecraft-max.net', 'schematics.gg', 'blockbench.net', 'minecraftstorage.com',
  'mcmod.cn', 'mcpehub.org', 'minecraftshader.com', 'minecraft-schematics.com', 'mcbuild.ru',
  'resourcepack.net', 'modpackindex.com', 'optifine.net', 'purpurmc.org', 'minecraftforge.net',
  'fabricmc.net', 'neoforged.net', 'minecraftworld.at.ua', 'shaderlabs.org',
  'minecraft.net', 'mojang.com', 'minecraftservices.com', 'textures.minecraft.net',
  'sessionserver.mojang.com', 'wiki.bedrock.dev', 'minecraft.wiki', 'geysermc.org',
  'ore.spongepowered.org', 'dev.bukkit.org', 'api.smithed.dev',
  'mcbase.ru', 'minecraftskins.com', 'skinmc.net', 'mcreator.net', 'github.io',
  'minecraftforum.net', 'leavesmc.org', 'cuberite.org', 'powernukkitx.com',
  'mcbuild.org', 'minebbs.com', 'download.geysermc.org',
]
function hostAllowed(raw) {
  try {
    const u = new URL(raw)
    if (u.protocol !== 'https:') return false
    const h = u.hostname.toLowerCase()
    if (/^(localhost|127\.|10\.|192\.168\.|169\.254\.|0\.|\[::1\])/.test(h)) return false
    return ALLOW_HOSTS.some((x) => h === x || h.endsWith('.' + x))
  } catch { return false }
}

function pingMiddleware(req, res, next) {
  const url = req.url || ''
  const ip = ipOf(req)
  if (handleAgg(req, res, next)) return

  if ((req.url || '').startsWith('/api/ok')) {
    const txt = (req.url || '').includes('.txt')
    const body = txt ? ('cubenorixx-ok ' + Date.now() + '\n') : JSON.stringify({ ok: true, app: 'cubenorixx', t: Date.now() })
    const name = txt ? 'cubenorixx-ok.txt' : 'cubenorixx-ok.json'
    res.setHeader('Content-Type', txt ? 'text/plain; charset=utf-8' : 'application/json; charset=utf-8')
    res.setHeader('Content-Disposition', 'attachment; filename="' + name + '"')
    res.setHeader('X-Content-Type-Options', 'nosniff')
    res.setHeader('Cache-Control', 'no-store')
    res.setHeader('X-Cubenorix-Relay', 'cx-pass')
    res.setHeader('X-Cubenorix-Relay', 'cx-pass')
    res.end(body)
    return
  }

  if ((req.url || '').startsWith('/go-dl')) {
    const u = new URL(req.url, 'http://local')
    const qs = u.searchParams.toString()
    res.statusCode = 302
    res.setHeader('Location', '/take.html' + (qs ? '?' + qs : ''))
    res.end()
    return
  }


  if (url.startsWith('/api/gate/start')) {
    const nonce = randomBytes(16).toString('hex')
    nonces.set(nonce, Date.now() + 120000)
    res.setHeader('Content-Type', 'application/json')
    res.end(JSON.stringify({ nonce, zeros: 3 }))
    return
  }
  if (url.startsWith('/api/gate/ok') && req.method === 'POST') {
    readBody(req).then((body) => {
      const nonce = String(body.nonce || '')
      if (!nonces.has(nonce) || nonces.get(nonce) < Date.now()) {
        res.statusCode = 400
        res.end(JSON.stringify({ ok: false }))
        return
      }
      nonces.delete(nonce)
      if (!body.human) {
        const hex = createHash('sha256').update(nonce + ':' + body.n).digest('hex')
        if (!hex.startsWith('000')) {
          res.statusCode = 403
          res.end(JSON.stringify({ ok: false }))
          return
        }
      }
      const tok = randomBytes(24).toString('hex')
      tokens.set(tok, { exp: Date.now() + 86400000, ip })
      res.setHeader('Set-Cookie', 'cx_gate=' + tok + '; Path=/; Max-Age=86400; SameSite=Lax; HttpOnly')
      res.setHeader('Content-Type', 'application/json')
      res.end(JSON.stringify({ ok: true }))
    })
    return
  }

  if (url.startsWith('/api/locale')) {
    const country = String(req.headers['cf-ipcountry'] || req.headers['x-vercel-ip-country'] || req.headers['x-country-code'] || '').toUpperCase().replace(/[^A-Z]/g, '').slice(0, 2)
    const browser = String(req.headers['accept-language'] || '').slice(0, 180)
    res.setHeader('Content-Type', 'application/json; charset=utf-8')
    res.setHeader('Cache-Control', 'private, max-age=300')
    res.end(JSON.stringify({ country, browser, source: country ? 'edge' : 'browser' }))
    return
  }

  if (url.startsWith('/api/ping')) {
    const u = new URL(url, 'http://local')
    const target = u.searchParams.get('url') || 'https://api.modrinth.com/v2/'
    if (!hostAllowed(target)) { res.statusCode = 400; res.end(JSON.stringify({ ok: false, error: 'host' })); return }
    const hot = pingCache.get(target)
    if (hot && Date.now() - hot.at < (hot.ok ? 60000 : 20000)) {
      res.setHeader('Content-Type', 'application/json')
      res.setHeader('Cache-Control', 'private, max-age=15')
      res.end(JSON.stringify({ ...hot, cached: true }))
      return
    }
    if (limited(ip, 'ping', 120, 60000)) { res.statusCode = 429; res.end(JSON.stringify({ ok: false, error: 'rate' })); return }
    let work = pingPromises.get(target)
    if (!work) {
      work = (async () => {
        const start = Date.now()
        const ctrl = new AbortController()
        const timer = setTimeout(() => ctrl.abort(), 6000)
        try {
          let r = await fetch(target, { method: 'HEAD', signal: ctrl.signal, redirect: 'follow', headers: { 'User-Agent': 'Cubenorix/1.0' } })
          if (!r.ok) r = await fetch(target, { method: 'GET', signal: ctrl.signal, redirect: 'follow', headers: { 'User-Agent': 'Cubenorix/1.0' } })
          return { ok: r.ok, status: r.status, ms: Date.now() - start, target, at: Date.now() }
        } catch (e) {
          return { ok: false, ms: Date.now() - start, error: String(e.message || e), target, at: Date.now() }
        } finally {
          clearTimeout(timer)
        }
      })()
      pingPromises.set(target, work)
      work.finally(() => pingPromises.delete(target))
    }
    work.then((data) => {
      pingCache.set(target, data)
      if (pingCache.size > 200) pingCache.delete(pingCache.keys().next().value)
      res.setHeader('Content-Type', 'application/json')
      res.setHeader('Cache-Control', 'private, max-age=15')
      res.end(JSON.stringify(data))
    })
    return
  }
  if (url.startsWith('/api/skin')) {
    const u = new URL(url, 'http://local')
    const nick = String(u.searchParams.get('nick') || '').trim()
    if (!/^[A-Za-z0-9_]{2,16}$/.test(nick)) {
      res.setHeader('Content-Type', 'application/json')
      res.end(JSON.stringify({ ok: false, error: 'nick' }))
      return
    }
    ;(async () => {
      let uuid = ''
      let ign = nick
      for (const t of [
        'https://api.mojang.com/users/profiles/minecraft/' + encodeURIComponent(nick),
        'https://api.minecraftservices.com/minecraft/profile/lookup/name/' + encodeURIComponent(nick),
      ]) {
        try {
          const r = await fetch(t, { headers: { 'User-Agent': 'Cubenorix/1.0' } })
          if (!r.ok) continue
          const j = await r.json()
          if (j?.id) { uuid = String(j.id).replace(/-/g, ''); ign = j.name || nick; break }
        } catch {}
      }
      if (!uuid) {
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify({ ok: false, nick }))
        return
      }
      let skin = ''
      let cape = ''
      try {
        const r = await fetch('https://sessionserver.mojang.com/session/minecraft/profile/' + uuid, { headers: { 'User-Agent': 'Cubenorix/1.0' } })
        const j = await r.json()
        const b64 = (j.properties || []).find((p) => p.name === 'textures')?.value
        if (b64) {
          const tex = JSON.parse(Buffer.from(b64, 'base64').toString('utf8'))
          skin = tex?.textures?.SKIN?.url || ''
          cape = tex?.textures?.CAPE?.url || ''
        }
      } catch {}
      res.setHeader('Content-Type', 'application/json')
      res.setHeader('Cache-Control', 'public, max-age=300')
      res.end(JSON.stringify({
        ok: true, nick: ign, uuid, skin, cape,
        official: 'https://www.minecraft.net/',
        namemc: 'https://namemc.com/profile/' + encodeURIComponent(ign),
        body: 'https://mc-heads.net/body/' + encodeURIComponent(ign),
        player: 'https://mc-heads.net/player/' + encodeURIComponent(ign),
        avatar: 'https://mc-heads.net/avatar/' + encodeURIComponent(ign) + '/64',
      }))
    })()
    return
  }
  if (url.startsWith('/api/ip')) {
    const clientIp = ipOf(req).replace(/^::ffff:/, '')
    const privateIp = /^(0\.|10\.|127\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|::1$|fc|fd)/i.test(clientIp)
    const hit = ipCache.get(clientIp)
    if (hit && Date.now() - hit.t < 10 * 60_000) {
      res.setHeader('Content-Type', 'application/json')
      res.setHeader('Cache-Control', 'private, max-age=300')
      res.end(JSON.stringify(hit.data))
      return
    }
    if (privateIp || !clientIp) {
      res.setHeader('Content-Type', 'application/json')
      res.end(JSON.stringify({ ip: clientIp || '—', local: true }))
      return
    }
    fetch('https://ipapi.co/' + encodeURIComponent(clientIp) + '/json/', { headers: { 'User-Agent': 'Cubenorix/1.0' } })
      .then((r) => r.json())
      .then((data) => {
        const clean = { ...data, ip: data.ip || clientIp }
        ipCache.set(clientIp, { t: Date.now(), data: clean })
        res.setHeader('Content-Type', 'application/json')
        res.setHeader('Cache-Control', 'private, max-age=300')
        res.end(JSON.stringify(clean))
      })
      .catch((e) => {
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify({ ip: clientIp, error: String(e.message || e) }))
      })
    return
  }
  if (url.startsWith('/api/translate')) {
    const run = (q, to, from) => {
      res.setHeader('Content-Type', 'application/json; charset=utf-8')
      if (!q) { res.end(JSON.stringify({ text: '', engine: 'none' })); return }
      const ck = mapLang(to) + '|' + mapLang(from) + '|' + q.slice(0, 240)
      if (trCache.has(ck)) { res.end(JSON.stringify({ text: trCache.get(ck), engine: 'cache' })); return }
      if (limited(ip, 'tr', 240, 60000)) { res.statusCode = 429; res.end(JSON.stringify({ text: q, engine: 'rate' })); return }
      ;(async () => {
        try {
          const text = await viaGtx(q, to, from)
          if (trCache.size > 800) trCache.clear()
          trCache.set(ck, text)
          res.end(JSON.stringify({ text, engine: 'gtx' }))
          return
        } catch {}
        try {
          const text = await viaGoogleMobile(q, to, from)
          if (trCache.size > 800) trCache.clear()
          trCache.set(ck, text)
          res.end(JSON.stringify({ text, engine: 'google-mobile' }))
          return
        } catch {}
        try {
          const token = await fetch('https://edge.microsoft.com/translate/auth').then((r) => r.text())
          const r = await fetch('https://api-edge.cognitive.microsofttranslator.com/translate?from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to) + '&api-version=3.0', {
            method: 'POST',
            headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' },
            body: JSON.stringify([{ Text: q }]),
          })
          const j = await r.json()
          const text = j?.[0]?.translations?.[0]?.text
          if (text) {
            trCache.set(ck, text)
            res.end(JSON.stringify({ text, engine: 'bing' }))
            return
          }
        } catch {}
        try {
          const r = await fetch('https://api.mymemory.translated.net/get?q=' + encodeURIComponent(q.slice(0, 450)) + '&langpair=' + encodeURIComponent(from + '|' + to))
          const j = await r.json()
          const text = String(j?.responseData?.translatedText || '').replace(/MYMEMORY WARNING:.*/i, '').trim()
          if (text && text !== q) {
            trCache.set(ck, text)
            res.end(JSON.stringify({ text, engine: 'fallback' }))
            return
          }
        } catch {}
        res.end(JSON.stringify({ text: q, engine: 'none' }))
      })()
    }
    if (req.method === 'POST') {
      readBody(req).then((body) => {
        run(String(body.q || '').slice(0, 1500), body.to || 'ru', body.from || 'en')
      })
      return
    }
    const u = new URL(url, 'http://local')
    run((u.searchParams.get('q') || '').slice(0, 900), u.searchParams.get('to') || 'ru', u.searchParams.get('from') || 'en')
    return
  }
  if (url.startsWith('/api/probe')) {
    if (limited(ip, 'probe', 30, 60000)) { res.statusCode = 429; res.end(JSON.stringify({ ok: false })); return }
    const u = new URL(url, 'http://local')
    const target = u.searchParams.get('url')
    const q = u.searchParams.get('q') || ''
    if (!target || !hostAllowed(target)) {
      res.setHeader('Content-Type', 'application/json')
      res.end(JSON.stringify({ ok: false, error: 'host' }))
      return
    }
    const start = Date.now()
    ;(async () => {
      try {
        const ctrl = new AbortController()
        const t = setTimeout(() => ctrl.abort(), 7000)
        const r = await fetch(target, { signal: ctrl.signal, redirect: 'follow', headers: { 'User-Agent': 'CubenorixBot/1.0' } })
        clearTimeout(t)
        const html = await r.text()
        const title = (html.match(/<title[^>]*>([^<]{0,180})/i) || [])[1] || ''
        const hit = q ? html.toLowerCase().includes(q.toLowerCase()) : r.ok
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify({ ok: r.ok, status: r.status, ms: Date.now() - start, title: title.replace(/\s+/g, ' ').trim(), found: hit, url: target }))
      } catch (e) {
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify({ ok: false, ms: Date.now() - start, error: String(e.message || e), url: target }))
      }
    })()
    return
  }
  if (url.startsWith('/api/mcping')) {
    const u = new URL(url, 'http://local')
    const host = String(u.searchParams.get('host') || '').trim()
    const requestedPort = Number(host.split(':')[1] || 25565)
    if (!/^[A-Za-z0-9.-]{1,253}(?::\d{1,5})?$/.test(host) || requestedPort < 1 || requestedPort > 65535) { res.statusCode = 400; res.end(JSON.stringify({ online: false })); return }
    const start = Date.now()
    const controller = new AbortController()
    const timer = setTimeout(() => controller.abort(), 6500)
    fetch('https://api.mcsrvstat.us/3/' + encodeURIComponent(host), { signal: controller.signal, headers: { 'User-Agent': 'Cubenorix/1.0' } })
      .then((r) => r.json())
      .then((j) => {
        res.setHeader('Content-Type', 'application/json')
        res.setHeader('Cache-Control', 'public, max-age=30, stale-while-revalidate=120')
        res.end(JSON.stringify({
          online: !!j.online,
          players: j.players?.online ?? 0,
          max: j.players?.max ?? 0,
          version: j.version || '',
          protocol: j.protocol && typeof j.protocol === 'object'
            ? [j.protocol.name, j.protocol.version != null ? `#${j.protocol.version}` : ''].filter(Boolean).join(' ')
            : (j.protocol ?? null),
          software: j.software || '',
          motd: Array.isArray(j.motd?.clean) ? j.motd.clean.join(' ') : '',
          hostname: j.hostname || host,
          ip: j.ip || '',
          port: j.port || 25565,
          checkedAt: Date.now(),
          ms: Date.now() - start,
          host,
        }))
      })
      .catch(() => {
        res.setHeader('Content-Type', 'application/json')
        res.end(JSON.stringify({ online: false, ms: Date.now() - start, host }))
      })
      .finally(() => clearTimeout(timer))
    return
  }
  if (url.startsWith('/api/file') || url.startsWith('/api/img')) {
    const u = new URL(url, 'http://local')
    const target = u.searchParams.get('url')
    const name = (u.searchParams.get('name') || 'cubenorixx-file').replace(/[^\w.\-+]+/g, '_')
    const as = String(u.searchParams.get('as') || '').toLowerCase()
    const pack = u.searchParams.get('pack') === '1' || as === 'json' || as === 'txt'
    const view = u.searchParams.get('view') === '1'
    const img = url.startsWith('/api/img')
    const okRe = /^https:\/\/(cdn\.modrinth\.com|cdn-raw\.modrinth\.com|hangarcdn\.papermc\.io|mediafilez\.forgecdn\.net|edge\.forgecdn\.net|forgecdn\.net|objects\.githubusercontent\.com|github\.com|avatars\.githubusercontent\.com|api\.spiget\.org|poggit\.pmmp\.io)\//i
    if (!target || !(img ? hostAllowed(target) : okRe.test(target))) {
      res.statusCode = 400
      res.end(img ? '' : 'bad url')
      return
    }
    ;(async () => {
      try {
        const r = await fetch(target, { redirect: 'follow', headers: { 'User-Agent': 'Cubenorix/1.0' } })
        if (!r.ok) { res.statusCode = r.status; res.end('cdn'); return }
        if (img) {
          const buf = Buffer.from(await r.arrayBuffer())
          res.setHeader('Content-Type', r.headers.get('content-type') || 'image/png')
          res.setHeader('Cache-Control', 'public, max-age=86400')
          res.setHeader('Content-Length', String(buf.length))
          res.end(buf)
          return
        }
        if (as === 'png') {
          const buf = Buffer.from(await r.arrayBuffer())
          if (buf.length > 40 * 1024 * 1024) { res.statusCode = 413; res.end('too large'); return }
          const out = pngZip(buf)
          const outName = String(name).replace(/\.(jar|zip|png)$/i, '') + '.png'
          const ascii = outName.replace(/[^\x20-\x7E]/g, '_') || 'mod.png'
          res.setHeader('Content-Type', 'image/png')
          res.setHeader('Content-Disposition', (view ? 'inline' : 'inline') + '; filename="' + ascii + '"; filename*=UTF-8\'\'' + encodeURIComponent(outName))
          res.setHeader('Cache-Control', 'no-store')
          res.setHeader('X-Cubenorix-Relay', 'cx-pass')
          res.setHeader('X-Cubenorix-Relay', 'cx-pass')
          res.setHeader('Content-Length', String(out.length))
          res.end(out)
          return
        }
        const wantPack = pack && as !== 'zip' && as !== 'bin' && as !== 'png'
        if (wantPack) {
          const buf = Buffer.from(await r.arrayBuffer())
          if (buf.length > 40 * 1024 * 1024) { res.statusCode = 413; res.end('too large for pack'); return }
          const payload = JSON.stringify({
            app: 'cubenorixx',
            name,
            size: buf.length,
            b64: buf.toString('base64'),
          })
          const outName = as === 'txt'
            ? (/\.txt$/i.test(name) ? name : name.replace(/\.(jar|zip)$/i, '') + '.txt')
            : (/\.json$/i.test(name) ? name : name.replace(/\.(jar|zip)$/i, '') + '.json')
          const ascii = outName.replace(/[^\x20-\x7E]/g, '_') || 'file.json'
          res.setHeader('Content-Type', as === 'txt' ? 'text/plain; charset=utf-8' : 'application/json; charset=utf-8')
          res.setHeader('Content-Disposition', (view ? 'inline' : 'attachment') + '; filename="' + ascii + '"; filename*=UTF-8\'\'' + encodeURIComponent(outName))
          res.setHeader('X-Content-Type-Options', 'nosniff')
          res.setHeader('Cache-Control', 'no-store')
          res.setHeader('X-Cubenorix-Relay', 'cx-pass')
          res.setHeader('X-Cubenorix-Relay', 'cx-pass')
          res.setHeader('Content-Length', String(Buffer.byteLength(payload)))
          res.end(payload)
          return
        }
        const ascii = name.replace(/[^\x20-\x7E]/g, '_') || 'file'
        const zip = as === 'zip' || /\.zip$/i.test(name)
        res.setHeader('Content-Type', zip ? 'application/zip' : 'application/octet-stream')
        res.setHeader('Content-Disposition', (view ? 'inline' : 'attachment') + '; filename="' + ascii + '"; filename*=UTF-8\'\'' + encodeURIComponent(name))
        res.setHeader('X-Content-Type-Options', 'nosniff')
        res.setHeader('Cache-Control', 'no-store')
        res.setHeader('X-Cubenorix-Relay', 'cx-pass')
        res.setHeader('X-Cubenorix-Relay', 'cx-pass')
        const len = r.headers.get('content-length')
        if (len) res.setHeader('Content-Length', len)
        const reader = r.body.getReader()
        let sent = 0
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          sent += value.byteLength
          if (sent > 250 * 1024 * 1024) break
          res.write(Buffer.from(value))
        }
        res.end()
      } catch (e) {
        res.statusCode = 502
        res.end(String(e.message || e))
      }
    })()
    return
  }
  if (url.startsWith('/api/dl')) {
    if (!gated(req)) {
      res.statusCode = 403
      res.setHeader('Content-Type', 'application/json')
      res.end(JSON.stringify({ error: 'gate' }))
      return
    }
    if (limited(ip, 'dl', 8, 180000)) {
      res.statusCode = 429
      res.end('too many downloads')
      return
    }
    const u = new URL(url, 'http://local')
    const target = u.searchParams.get('url')
    const name = (u.searchParams.get('name') || 'download.jar').replace(/[^\w.\-]+/g, '_')
    if (!target || !/^https:\/\/(cdn\.modrinth\.com|github\.com|objects\.githubusercontent\.com|hangarcdn\.papermc\.io|api\.spiget\.org|poggit\.pmmp\.io|mediafilez\.forgecdn\.net|edge\.forgecdn\.net|forgecdn\.net)/i.test(target)) {
      res.statusCode = 400
      res.end('bad url')
      return
    }
    ;(async () => {
      const tmp = join(tmpdir(), 'cx-' + Date.now() + '-' + name)
      try {
        await new Promise((r) => setTimeout(r, 350))
        const r = await fetch(target, { redirect: 'follow' })
        if (!r.ok) {
          res.statusCode = r.status
          res.end('cdn error')
          return
        }
        const buf = Buffer.from(await r.arrayBuffer())
        if (buf.length > 250 * 1024 * 1024) {
          res.statusCode = 413
          res.end('too large')
          return
        }
        writeFileSync(tmp, buf)
        res.setHeader('Content-Type', r.headers.get('content-type') || 'application/octet-stream')
        res.setHeader('Content-Disposition', 'attachment; filename="' + name + '"')
        res.setHeader('Content-Length', String(buf.length))
        const stream = createReadStream(tmp)
        stream.pipe(res)
        const done = () => unlink(tmp, () => {})
        stream.on('close', done)
        stream.on('error', done)
        res.on('close', done)
      } catch (e) {
        unlink(tmp, () => {})
        res.statusCode = 502
        res.end(String(e.message || e))
      }
    })()
    return
  }
  next()
}

function pingPlugin() {
  return {
    name: 'cubenorixx-ping',
    configureServer(server) {
      server.middlewares.use(pingMiddleware)
    },
    configurePreviewServer(server) {
      server.middlewares.use(pingMiddleware)
    },
  }
}

function publicOriginPlugin() {
  const replaceOrigin = (text) => text.replaceAll(DEFAULT_PUBLIC_ORIGIN, PUBLIC_ORIGIN)
  return {
    name: 'cubenorixx-public-origin',
    transformIndexHtml(html) {
      return replaceOrigin(html)
    },
    closeBundle() {
      if (PUBLIC_ORIGIN === DEFAULT_PUBLIC_ORIGIN) return
      const walk = (dir) => {
        for (const name of readdirSync(dir)) {
          const file = join(dir, name)
          if (statSync(file).isDirectory()) walk(file)
          else if (/\.(?:html|json|txt|xml|js|css|webmanifest)$/i.test(name)) {
            const source = readFileSync(file, 'utf8')
            const replaced = replaceOrigin(source)
            if (replaced !== source) writeFileSync(file, replaced)
          }
        }
      }
      walk(join(process.cwd(), 'dist'))
    },
  }
}

export default defineConfig({
  plugins: [react(), pingPlugin(), publicOriginPlugin()],
  define: {
    __BUILD_DATE__: JSON.stringify(new Date().toISOString().slice(0, 10)),
  },
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    allowedHosts: true,
    cors: true,
    proxy: {
      '/mr-api': {
        target: 'https://api.modrinth.com',
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/mr-api/, ''),
      },
      '/mr-cdn': {
        target: 'https://cdn.modrinth.com',
        changeOrigin: true,
        rewrite: (p) => p.replace(/^\/mr-cdn/, ''),
      },
    },
  },
  preview: {
    host: '0.0.0.0',
    port: 5173,
    allowedHosts: true,
    cors: true,
  },
})
