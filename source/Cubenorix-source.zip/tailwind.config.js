/*
 * Cubenorix - Minecraft content aggregator
 * Copyright (C) 2025-2026 Cubenorix Team
 */
/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#0A0A18',
        panel: '#12122A',
        orange: {
          DEFAULT: '#FF6B00',
          soft: '#FFB347',
          deep: '#CC5500',
        },
      },
      fontFamily: {
        outfit: ['Unbounded', 'Noto Sans', 'system-ui', 'sans-serif'],
        inter: ['Noto Sans', 'system-ui', 'sans-serif'],
        noto: ['Noto Sans', 'system-ui', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'monospace'],
      },
      borderRadius: {
        card: '20px',
        pill: '100px',
        field: '16px',
      },
      boxShadow: {
        glow: '0 0 40px rgba(255,107,0,0.25)',
        deep: '0 24px 80px rgba(0,0,0,0.55)',
      },
    },
  },
  plugins: [],
}
