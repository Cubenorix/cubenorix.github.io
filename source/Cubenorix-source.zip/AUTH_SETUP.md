# Real Cubenorix registration — Cloudflare Pages + D1

The source contains real server-side registration, login, logout, session lookup, profile updates and account deletion. It intentionally does **not** fall back to localStorage passwords.

Current state: prepared and tested in source; production activation is deferred until the owner connects Cloudflare D1. Static Yapp cannot host secure accounts.

## Security design

- D1 stores users and server sessions.
- Passwords are PBKDF2-SHA-256 with a random 128-bit salt, 600,000 iterations and a server-only pepper.
- The raw password is never stored or returned.
- The browser receives a random `Secure; HttpOnly; SameSite=Lax; Path=/` session cookie.
- D1 stores only SHA-256 of the session token.
- Sessions expire after 30 days and are deleted on logout/account deletion.
- State-changing requests require a same-origin `Origin` header.
- Registration/login attempts are rate-limited using an HMAC bucket; raw IP is not stored in the account table.
- Terms, Privacy, author rules and age confirmation are required and versioned.
- There is no fake Microsoft login, fake reset email or fake 2FA switch.

## One-time owner actions

These commands must be run by the Cloudflare account owner. Never send the Cloudflare password or API token to another person.

1. Authenticate Wrangler:

```bash
npx wrangler login
```

2. Create the D1 database:

```bash
npx wrangler d1 create cubenorixx-auth
```

3. Copy `wrangler.auth.example.toml` bindings into `wrangler.toml` and replace `REPLACE_WITH_D1_DATABASE_ID` with the returned database ID.

4. Apply migrations:

```bash
npx wrangler d1 migrations apply cubenorixx-auth --remote
```

5. Generate and store a strong pepper as a Pages secret:

```bash
openssl rand -base64 48
npx wrangler pages secret put AUTH_PEPPER --project-name cubenorixx
```

Paste the generated value only into Wrangler's secret prompt. Do not write it into `.env`, source control, screenshots or chat.

6. Deploy:

```bash
npm run deploy:pages
```

7. Verify:

```text
GET  https://cubenorixx.pages.dev/api/auth/status
POST https://cubenorixx.pages.dev/api/auth/register
GET  https://cubenorixx.pages.dev/api/auth/me
```

`/api/auth/status` must return `"configured": true` before enabling public registration.

## Email status

The selected first release accepts an email but does not send verification or reset messages. The UI states this truthfully. Add a verified mail provider and a reset-token migration before promising email verification or password recovery.

## Maintenance

Periodically remove expired rows:

```sql
DELETE FROM auth_sessions WHERE expires_at <= unixepoch() * 1000;
DELETE FROM auth_rate_limits WHERE reset_at <= unixepoch();
```

Before production, review the legal documents for the operator's jurisdiction and test with a Cloudflare preview deployment.
