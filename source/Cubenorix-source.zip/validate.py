#!/usr/bin/env python3
# Copyright (C) 2025-2026 Cubenorix Team
# SPDX-License-Identifier: AGPL-3.0-or-later
# -*- coding: utf-8 -*-
"""Валидатор сайта. Только читает. Стандартная библиотека. Офлайн по умолчанию."""
from __future__ import print_function

import json
import os
import re
import sys

try:
    from html.parser import HTMLParser
    from urllib.parse import urlparse, unquote
    from urllib.request import Request, urlopen
except ImportError:
    from HTMLParser import HTMLParser
    from urlparse import urlparse
    from urllib import unquote
    from urllib2 import Request, urlopen

USAGE = """Валидатор сайта Cubenorix (программа для программы, не мод).

  python validate.py                 проверить эту папку
  python validate.py путь/к/папке
  python validate.py --strict        предупреждения = ошибки
  python validate.py --links         ещё внешние ссылки (нужен интернет)

Код выхода: 0 чисто, 1 есть ошибки.
Ничего не меняет и не удаляет.
"""

SKIP_DIRS = {
    ".git", "node_modules", ".venv", "venv", "__pycache__", ".arena",
    ".cache", "dist", "build", ".next", "coverage", "out", "target",
}
SKIP_FILES = {".ds_store", "thumbs.db"}
HTML_EXT = {".html", ".htm"}
CSS_EXT = {".css"}
CODE_EXT = {".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"}
JSON_EXT = {".json"}
IMG_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".ico", ".bmp", ".avif"}
TEXT_SCAN = HTML_EXT | CSS_EXT | CODE_EXT | {".md"}
VOID = {
    "area", "base", "br", "col", "embed", "hr", "img", "input", "link",
    "meta", "param", "source", "track", "wbr",
}
IGNORE_CLOSE = VOID | {"script", "style"}
ROUTE_PREFIX = (
    "/api/", "/mr-api", "/mr-cdn", "/catalog", "/project/", "/builds",
    "/top", "/servers", "/hosting", "/guides", "/generators", "/wiki",
    "/forum", "/connection", "/add", "/login", "/register", "/profile",
    "/developers", "/hash", "/source/", "/get", "/reviews", "/bridge",
    "/about", "/how", "/rules", "/terms", "/privacy", "/dmca",
    "/authors", "/disclaimer", "/extension", "/app",
)
ATTR_SRC = re.compile(
    r"""(?i)(?:\b(?:href|src|srcset|poster|data-src|to)\s*=\s*|url\s*\(\s*)(['"]?)([^'")\s]+)\1"""
)
SRCSET_SPLIT = re.compile(r"\s*,\s*")
ID_RE = re.compile(r"""\bid\s*=\s*['"]([^'"]+)['"]""", re.I)
IMG_TAG = re.compile(r"<img\b([^>]*)>", re.I)
ATTR = re.compile(r"""(\w+)\s*=\s*(?:'([^']*)'|"([^"]*)"|([^\s>]+))""", re.I)
TITLE_RE = re.compile(r"<title\b[^>]*>(.*?)</title>", re.I | re.S)
HTML_LANG = re.compile(r"<html\b([^>]*)>", re.I)
META_NAME = re.compile(
    r"""<meta\b[^>]*name\s*=\s*['"]([^'"]+)['"][^>]*>""", re.I
)
META_CONTENT_VIEW = re.compile(r"""name\s*=\s*['"]viewport['"]""", re.I)
META_CONTENT_DESC = re.compile(r"""name\s*=\s*['"]description['"]""", re.I)


class Issue(object):
    def __init__(self, path, line, level, msg):
        self.path = path
        self.line = line
        self.level = level
        self.msg = msg

    def __str__(self):
        loc = "%s:%s" % (self.path, self.line or 1)
        return "%-28s %-8s %s" % (loc, self.level, self.msg)


class TagParser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.stack = []
        self.errors = []
        self.ids = {}
        self.ids_order = []

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        line = self.getpos()[0]
        ad = dict((k.lower(), v if v is not None else "") for k, v in attrs)
        if "id" in ad and ad["id"] != "":
            i = ad["id"]
            if i in self.ids:
                self.errors.append((line, "повторяется id=\"%s\" (ещё на строке %s)" % (i, self.ids[i])))
            else:
                self.ids[i] = line
                self.ids_order.append(i)
        if tag not in VOID:
            self.stack.append((tag, line))

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag.lower() not in VOID and self.stack and self.stack[-1][0] == tag.lower():
            self.stack.pop()

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in VOID:
            return
        if not self.stack:
            self.errors.append((self.getpos()[0], "лишний закрывающий тег </%s>" % tag))
            return
        # pop until match (HTML is messy; only flag if never opened)
        opened = [t for t, _ in self.stack]
        if tag not in opened:
            self.errors.append((self.getpos()[0], "лишний закрывающий тег </%s>" % tag))
            return
        while self.stack:
            t, ln = self.stack.pop()
            if t == tag:
                break


def rel(root, path):
    try:
        return os.path.relpath(path, root).replace("\\", "/")
    except Exception:
        return path.replace("\\", "/")


def read_text(path):
    raw = open(path, "rb").read()
    if raw.startswith(b"\xef\xbb\xbf"):
        raw = raw[3:]
    for enc in ("utf-8", "cp1251", "latin-1"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def line_of(text, idx):
    return text.count("\n", 0, idx) + 1


def walk_files(root):
    out = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
        for name in filenames:
            if name.lower() in SKIP_FILES:
                continue
            out.append(os.path.join(dirpath, name))
    return out


def web_root(root):
    pub = os.path.join(root, "public")
    if os.path.isdir(pub):
        return pub
    return root


def is_external(url):
    u = url.strip()
    return u.startswith("http://") or u.startswith("https://") or u.startswith("//")


def is_special(url):
    u = url.strip()
    if not u or u.startswith("data:") or u.startswith("mailto:") or u.startswith("tel:"):
        return True
    if u.startswith("javascript:") or u.startswith("blob:") or u.startswith("{"):
        return True
    if "${" in u or u.startswith("`"):
        return True
    return False


def looks_like_route(url):
    path = url.split("?", 1)[0].split("#", 1)[0]
    if not path.startswith("/"):
        return False
    if os.path.splitext(path)[1]:
        return False
    if path in ("/", ""):
        return True
    for p in ROUTE_PREFIX:
        if path == p.rstrip("/") or path.startswith(p):
            return True
    # /styles/ — может быть папка в public
    return False


def split_srcset(val):
    parts = []
    for chunk in SRCSET_SPLIT.split(val):
        bit = chunk.strip().split()
        if bit:
            parts.append(bit[0])
    return parts


def extract_refs(text, kind):
    refs = []
    if kind == "css" or kind == "code":
        for m in re.finditer(r"""url\(\s*['"]?([^'")]+)['"]?\s*\)""", text):
            refs.append((m.start(), "url", m.group(1).strip()))
    if kind in ("html", "code"):
        for m in re.finditer(
            r"""\b(href|src|poster|data-src|to)\s*=\s*(['"])(.*?)\2""", 
            text,
            re.I | re.S,
        ):
            refs.append((m.start(), m.group(1).lower(), m.group(3).strip()))
        for m in re.finditer(r"""\bsrcset\s*=\s*(['"])(.*?)\1""", text, re.I | re.S):
            for u in split_srcset(m.group(2)):
                refs.append((m.start(), "srcset", u))
        # JSX: src={'/x'} or src={"/x"}
        for m in re.finditer(
            r"""\b(href|src|to)\s*=\s*\{\s*(['"])([^'"]+)\2\s*\}""",
            text,
            re.I,
        ):
            refs.append((m.start(), m.group(1).lower(), m.group(3).strip()))
        # Static public assets commonly live in data records (icon_url, logo,
        # avatar) rather than literal JSX src attributes.
        if kind == "code":
            for m in re.finditer(r"""(['"])(/[^'"\s]+\.(?:png|jpe?g|gif|webp|svg|ico|avif))\1""", text, re.I):
                refs.append((m.start(), "asset", m.group(2).strip()))
    return refs


def resolve_candidates(root, wroot, from_file, url):
    raw = unquote(url.strip())
    raw = raw.split("?", 1)[0].split("#", 1)[0]
    if not raw:
        return []
    if raw.startswith("/"):
        rel_path = raw.lstrip("/").replace("\\", "/")
        return [
            os.path.join(wroot, rel_path),
            os.path.join(root, rel_path),
            os.path.join(wroot, rel_path, "index.html"),
            os.path.join(root, rel_path, "index.html"),
        ]
    base = os.path.dirname(from_file)
    return [
        os.path.normpath(os.path.join(base, raw)),
        os.path.normpath(os.path.join(wroot, raw)),
    ]


def case_sibling(parent, name):
    try:
        names = os.listdir(parent)
    except OSError:
        return None
    low = name.lower()
    for n in names:
        if n.lower() == low:
            return n
    return None


def exists_exact(path):
    """(ok, other_case_name). ok=True only if every component matches case."""
    parent, name = os.path.split(path)
    if not os.path.isdir(parent) and not os.path.lexists(path):
        # climb to first existing parent for a case hint
        cur = os.path.abspath(path)
        while True:
            par, nm = os.path.split(cur)
            if par == cur:
                return False, None
            hit = case_sibling(par, nm)
            if hit is not None and hit != nm:
                return False, hit
            if os.path.isdir(par):
                return False, None
            cur = par
        return False, None
    if not os.path.lexists(path):
        hit = case_sibling(parent, name)
        if hit is not None and hit != name:
            return False, hit
        return False, None
    cur = os.path.abspath(path)
    parts = []
    while True:
        par, nm = os.path.split(cur)
        if nm in ("", os.path.sep):
            break
        parts.append((par, nm))
        if par == cur:
            break
        cur = par
    for par, nm in reversed(parts):
        hit = case_sibling(par, nm)
        if hit is None:
            return False, None
        if hit != nm:
            return False, hit
    return True, None


def check_html_doc(rel_path, text, issues, wroot, root, from_file, referenced):
    parser = TagParser()
    try:
        parser.feed(text)
        parser.close()
    except Exception as e:
        issues.append(Issue(rel_path, 1, "ОШИБКА", "не разобрал HTML: %s" % e))
        return
    for line, msg in parser.errors:
        issues.append(Issue(rel_path, line, "ОШИБКА", msg))
    for tag, line in parser.stack:
        issues.append(Issue(rel_path, line, "ОШИБКА", "не закрыт тег <%s>" % tag))

    # title / meta / lang
    tm = TITLE_RE.search(text)
    if not tm or not tm.group(1).strip():
        issues.append(Issue(rel_path, 1, "ВНИМАНИЕ", "нет <title> или он пустой"))
    if not META_CONTENT_DESC.search(text):
        issues.append(Issue(rel_path, 1, "ВНИМАНИЕ", "нет <meta name=\"description\">"))
    if not META_CONTENT_VIEW.search(text):
        issues.append(Issue(rel_path, 1, "ВНИМАНИЕ", "нет <meta name=\"viewport\">"))
    hm = HTML_LANG.search(text)
    if not hm:
        issues.append(Issue(rel_path, 1, "ВНИМАНИЕ", "нет <html lang=\"...\">"))
    else:
        attrs = hm.group(1)
        if not re.search(r"""\blang\s*=""", attrs, re.I):
            issues.append(Issue(rel_path, line_of(text, hm.start()), "ВНИМАНИЕ", "нет lang у <html>"))

    for m in IMG_TAG.finditer(text):
        chunk = m.group(1)
        attrs = {}
        for am in ATTR.finditer(chunk):
            attrs[am.group(1).lower()] = am.group(2) or am.group(3) or am.group(4) or ""
        if "alt" not in attrs:
            issues.append(Issue(rel_path, line_of(text, m.start()), "ВНИМАНИЕ", "у <img> нет alt"))

    # internal anchors
    for m in re.finditer(r"""\bhref\s*=\s*['"](#[^'"]+)['"]""", text, re.I):
        aid = m.group(1)[1:]
        if aid == "" or aid == "top":
            continue
        if aid not in parser.ids:
            issues.append(Issue(rel_path, line_of(text, m.start()), "ОШИБКА", "якорь #%s никуда не ведёт" % aid))


def check_json(rel_path, text, issues):
    try:
        json.loads(text)
    except ValueError as e:
        issues.append(Issue(rel_path, 1, "ОШИБКА", "сломанный JSON: %s" % e))


def check_external(url, rel_path, line, issues):
    if url.startswith("//"):
        url = "https:" + url
    try:
        req = Request(url, headers={"User-Agent": "CubenorixValidator/1.0"})
        req.get_method = lambda: "HEAD"
        r = urlopen(req, timeout=8)
        code = getattr(r, "getcode", lambda: 200)()
        if code >= 400:
            issues.append(Issue(rel_path, line, "ОШИБКА", "внешняя ссылка %s → HTTP %s" % (url, code)))
    except Exception as e:
        # GET fallback
        try:
            req = Request(url, headers={"User-Agent": "CubenorixValidator/1.0"})
            r = urlopen(req, timeout=8)
            code = getattr(r, "getcode", lambda: 200)()
            if code >= 400:
                issues.append(Issue(rel_path, line, "ОШИБКА", "внешняя ссылка %s → HTTP %s" % (url, code)))
        except Exception as e2:
            issues.append(Issue(rel_path, line, "ОШИБКА", "внешняя ссылка не открылась: %s (%s)" % (url, e2)))


def main(argv):
    args = list(argv[1:])
    if "--help" in args or "-h" in args:
        print(USAGE)
        return 0
    strict = "--strict" in args
    do_links = "--links" in args
    args = [a for a in args if a not in ("--strict", "--links", "--help", "-h")]
    root = os.path.abspath(args[0] if args else os.getcwd())
    if not os.path.isdir(root):
        print("нет такой папки: %s" % root)
        return 1

    wroot = web_root(root)
    issues = []
    referenced = set()
    files = walk_files(root)
    scanned = 0

    index = os.path.join(root, "index.html")
    pub_index = os.path.join(wroot, "index.html")
    if not os.path.isfile(index) and not os.path.isfile(pub_index):
        issues.append(Issue(".", 1, "ОШИБКА", "нет главной страницы index.html в корне сайта"))

    for path in files:
        ext = os.path.splitext(path)[1].lower()
        rpath = rel(root, path)
        if ext in JSON_EXT:
            scanned += 1
            check_json(rpath, read_text(path), issues)
            continue
        if ext not in TEXT_SCAN:
            continue
        scanned += 1
        text = read_text(path)
        kind = "html" if ext in HTML_EXT else ("css" if ext in CSS_EXT else "code")
        if ext in HTML_EXT:
            check_html_doc(rpath, text, issues, wroot, root, path, referenced)

        for pos, attr, url in extract_refs(text, kind):
            ln = line_of(text, pos)
            if url == "" or url == "#" or url == "?":
                if attr in ("href", "src", "srcset", "poster", "data-src"):
                    issues.append(Issue(rpath, ln, "ОШИБКА", "пустой %s=\"\"" % attr))
                continue
            if is_special(url):
                continue
            if any(tok in url for tok in ("+", "${", "encodeURI", "%23", "\\")):
                continue
            if url.startswith("%") or url.startswith("&"):
                continue
            if url.startswith("http://"):
                issues.append(Issue(rpath, ln, "ВНИМАНИЕ", "ссылка http:// вместо https://: %s" % url))
            if is_external(url):
                if attr == "href" and 'target="_blank"' in text[max(0, pos - 80):pos + 120]:
                    chunk = text[max(0, pos - 160):pos + 200]
                    if "noopener" not in chunk:
                        issues.append(Issue(rpath, ln, "ВНИМАНИЕ", "target=\"_blank\" без rel=\"noopener\": %s" % url[:80]))
                if do_links:
                    check_external(url, rpath, ln, issues)
                continue
            # hash-only already handled in html
            if url.startswith("#"):
                continue
            if looks_like_route(url) and not os.path.splitext(url.split("?", 1)[0])[1]:
                # if a real file also exists, count it referenced
                for cand in resolve_candidates(root, wroot, path, url):
                    ok, _ = exists_exact(cand)
                    if ok:
                        referenced.add(os.path.normpath(cand))
                continue
            found = False
            case_hit = None
            chosen = None
            for cand in resolve_candidates(root, wroot, path, url):
                ok, wrong = exists_exact(cand)
                if ok:
                    found = True
                    chosen = cand
                    break
                if wrong:
                    case_hit = (cand, wrong)
            if found:
                referenced.add(os.path.normpath(chosen))
                continue
            if case_hit:
                issues.append(Issue(
                    rpath, ln, "ОШИБКА",
                    "регистр: ссылка %s, на диске %s" % (url, case_hit[1]),
                ))
            else:
                issues.append(Issue(rpath, ln, "ОШИБКА", "файл не найден: %s" % url))

        # target=_blank without noopener on any <a>
        if ext in HTML_EXT:
            for m in re.finditer(r"<a\b([^>]*)>", text, re.I):
                a = m.group(1)
                if re.search(r"""target\s*=\s*['"]_blank['"]""", a, re.I) and "noopener" not in a.lower():
                    issues.append(Issue(rpath, line_of(text, m.start()), "ВНИМАНИЕ", "target=\"_blank\" без rel=\"noopener\""))

    # heavy images + unused public files
    pub_files = []
    if os.path.isdir(wroot):
        for dirpath, dirnames, filenames in os.walk(wroot):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
            for name in filenames:
                pub_files.append(os.path.join(dirpath, name))

    for path in pub_files:
        ext = os.path.splitext(path)[1].lower()
        rpath = rel(root, path)
        if ext in IMG_EXT:
            try:
                sz = os.path.getsize(path)
            except OSError:
                sz = 0
            if sz > 500 * 1024:
                issues.append(Issue(rpath, 1, "ВНИМАНИЕ", "картинка тяжелее 500 КБ (%s КБ)" % (sz // 1024)))
        # unused: only flag obvious static assets, not every font/source dump
        norm = os.path.normpath(path)
        if norm not in referenced and ext in IMG_EXT | {".css", ".js", ".html"}:
            # index.html of styles gallery is linked as /styles/
            base = os.path.basename(path).lower()
            if base in ("index.html", "favicon.png", "favicon.ico"):
                continue
            # Flag filenames are selected dynamically from the locale registry.
            if rpath.startswith("public/flags/"):
                continue
            issues.append(Issue(rpath, 1, "ВНИМАНИЕ", "на файл никто не ссылается — возможно мусор"))

    # sort: errors first
    rank = {"ОШИБКА": 0, "ВНИМАНИЕ": 1}
    issues.sort(key=lambda x: (rank.get(x.level, 9), x.path, x.line or 0))

    errors = sum(1 for i in issues if i.level == "ОШИБКА")
    warns = sum(1 for i in issues if i.level == "ВНИМАНИЕ")
    if strict:
        errors += warns
        for i in issues:
            if i.level == "ВНИМАНИЕ":
                i.level = "ОШИБКА"

    for i in issues:
        print(i)
    if issues:
        print("")
    print("Проверено %s файлов." % scanned)
    print("%s ошибок, %s предупреждений." % (
        sum(1 for i in issues if i.level == "ОШИБКА"),
        sum(1 for i in issues if i.level == "ВНИМАНИЕ"),
    ))
    return 1 if any(i.level == "ОШИБКА" for i in issues) else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
