@echo off
chcp 65001 >nul
cd /d "%~dp0"
python validate.py
echo.
pause
