-- Cubexus metadata cache (задачи 7 и 9).
-- Локальное хранение метаданных проектов, чтобы не делать лишних запросов
-- к API источников, держать last-good копии и обновляться инкрементально.
-- Применение: npx wrangler d1 migrations apply cubexus-auth --remote

CREATE TABLE IF NOT EXISTS project_meta (
  slug              TEXT PRIMARY KEY,
  source            TEXT NOT NULL DEFAULT 'unknown',
  title             TEXT NOT NULL DEFAULT '',
  author            TEXT NOT NULL DEFAULT '',
  description       TEXT NOT NULL DEFAULT '',
  icon_url          TEXT NOT NULL DEFAULT '',
  url               TEXT NOT NULL DEFAULT '',
  project_type      TEXT NOT NULL DEFAULT '',
  downloads         INTEGER NOT NULL DEFAULT 0,
  likes             INTEGER NOT NULL DEFAULT 0,
  versions          TEXT NOT NULL DEFAULT '[]',
  source_updated_at TEXT,
  fetched_at        TEXT NOT NULL DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_project_meta_fetched  ON project_meta (fetched_at);
CREATE INDEX IF NOT EXISTS idx_project_meta_type_dl  ON project_meta (project_type, downloads DESC);
CREATE INDEX IF NOT EXISTS idx_project_meta_title    ON project_meta (LOWER(title));

CREATE TABLE IF NOT EXISTS sync_state (
  source        TEXT PRIMARY KEY,
  last_sync_at  TEXT NOT NULL DEFAULT '',
  cursor        TEXT NOT NULL DEFAULT '',
  ok            INTEGER NOT NULL DEFAULT 0
);
